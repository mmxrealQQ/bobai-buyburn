# Buyback & Burn Bot

The bot that has run every ten minutes since launch.

Collects the trading tax, swaps it to BNB, buys $BOBAI back off the market and sends it to the dead address. Runs as a Cloudflare Worker on a cron trigger, writes one log entry per cycle to KV, and serves that log publicly so the dashboard can read it. The local Node script is the same logic as a manual fallback.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A wallet with a little gas in it**
    ours: one BSC wallet, topped up from the tax itself
    also: the token was launched on four.meme and trades on PancakeSwap V2; the swap calls are the only PancakeSwap-specific part
- **Somewhere that runs code on a schedule**
    ours: a Cloudflare Worker on a 10-minute cron
    also: a VPS with crontab, GitHub Actions, Fly.io, Railway, a Raspberry Pi, or node on your own machine
- **Somewhere to keep a small run log**
    ours: one Cloudflare KV namespace
    also: Redis, SQLite, Postgres, or a JSON file on disk — it writes one entry per cycle
- **A BSC RPC endpoint**
    ours: the public endpoints, with failover
    also: NodeReal, Ankr, QuickNode or your own node if you want the headroom
- **One secret at runtime: PRIVATE_KEY**
    ours: wrangler secret put
    also: a .env file, your host's secret store — anything but the source code

## Run it

    npx wrangler deploy
    or locally: npm i && node -r dotenv/config buyback-bot.js

## What is in here

- `buyback-bot.js`  (740 lines)
- `worker/index.js`  (740 lines)
- `worker/wrangler.toml`  (11 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/buyback-bot.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/buyback-bot.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
