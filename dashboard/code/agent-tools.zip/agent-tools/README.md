# Agent Tools — MCP & llms.txt

What an AI agent sees when it asks this project a question.

The MCP server and the HTTP tool endpoints that let an agent read live token data straight off the chain, plus the agent card, the ERC-8004 registration and the llms.txt that tells a crawler what is here. This is the piece that made the project discoverable to agents rather than only to people.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A machine that can run Node 18+**
    ours: the MCP server over stdio, locally
    also: point any MCP client at it — Claude Desktop, Claude Code, Cursor, or your own
- **Somewhere to serve the HTTP tools**
    ours: the Pages worker already serving the site
    also: any HTTPS endpoint, or skip it and run the MCP server only
- **No keys at all**
    ours: every tool reads public chain data
    also: there is nothing to secure here, which is why it can be pointed at an agent without a second thought

## Run it

    node mcp/server.mjs
    or deploy the Pages worker and point your client at /mcp

## What is in here

- `dashboard/_worker.js`  (1094 lines)
- `dashboard/llms.txt`  (57 lines)
- `mcp/server.mjs`  (146 lines)
- `scripts/bobai-agent-card.json`  (64 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/agent-tools.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/agent-tools.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
