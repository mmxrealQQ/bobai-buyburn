# Pool Scanner

Reads any BNB Chain pool. No backend at all.

Paste a token, a pool or a DexScreener link and it measures what a trader actually meets: price impact and real cost per trade size, the transfer tax derived from executed trades rather than from a label, and whether the LP is burned, locked or withdrawable. Everything happens in the visitor's browser — it costs the operator nothing to run, because there is nothing to run.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A static host**
    ours: Cloudflare Pages
    also: GitHub Pages, Netlify, Vercel, S3, nginx, or python -m http.server on your laptop
- **Public RPC endpoints**
    ours: six, with failover, all free
    also: your own node if you expect traffic. Note the requests leave from the visitor's browser, not your server — which is why this costs nothing to run
- **Nothing else**
    ours: no backend, no database, no API key, no build step
    also: that is the whole point of it

## Run it

    drop the files on any static host, or: python -m http.server

## What is in here

- `dashboard/scanner-chain.js`  (897 lines)
- `dashboard/scanner-scan.js`  (511 lines)
- `dashboard/scanner.html`  (457 lines)
- `dashboard/scanner.js`  (1252 lines)
- `dashboard/styles.css`  (1256 lines)
- `dashboard/tier-scan.js`  (423 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/pool-scanner.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/pool-scanner.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
