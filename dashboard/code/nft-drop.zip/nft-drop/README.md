# NFT Buy Drops

The contract, the metadata server and the collection page.

An ERC-721 of 1,925 pieces that mints itself to buyers. In here: the Solidity source, the deploy, base-URI and renounce scripts, the worker that serves the metadata, and the public collection page. The bot that decides who gets one is its own bundle.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A wallet with gas for the deployment**
    ours: one transaction on BSC, a few cents
    also: any EVM chain — the contract is plain Solidity with no chain-specific parts
- **Somewhere to serve the metadata**
    ours: a small Cloudflare Worker
    also: static JSON files on any host. It is one file per token id and nothing else
- **Somewhere to host the images**
    ours: our own domain, over plain HTTPS
    also: IPFS or Arweave — but link them by https gateway. Several marketplaces will not resolve an ipfs:// URL
- **Your marketplace metadata set BEFORE you renounce**
    ours: set, checked, then renounced
    also: none. After renouncing it is permanent, and no marketplace can help you

## Run it

    node scripts/deploy.js
    npx wrangler deploy

## What is in here

- `dashboard/nft/index.html`  (580 lines)
- `nft/contract/scripts/build-verify-input.js`  (63 lines)
- `nft/contract/scripts/compile.js`  (57 lines)
- `nft/contract/scripts/deploy.js`  (58 lines)
- `nft/contract/scripts/renounce.js`  (64 lines)
- `nft/contract/scripts/set-base-uri.js`  (36 lines)
- `nft/contract/scripts/setup.js`  (83 lines)
- `nft/contract/src/BobaiBuyDrops.sol`  (104 lines)
- `worker-nft-meta/index.js`  (195 lines)
- `worker-nft-meta/wrangler.toml`  (10 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/nft-drop.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/nft-drop.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
