# Worldcup Tipping Game

A full tournament game that paid out on-chain.

Signup, tips locked at kickoff, live brackets through the knockout rounds, penalties and extra time, a leaderboard, a bonus round and an on-chain prize payout — 8.94M tokens across 39 wallets, each with its transaction hash. The Postgres schema and every migration are in here, so the scoring rules are readable rather than described.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A Postgres with row-level security and auth**
    ours: Supabase, free tier, all the way through
    also: any Postgres plus an auth layer. The schema is plain SQL; the RLS policies are the part worth reading
- **Somewhere that pulls fixtures on a schedule**
    ours: a Cloudflare Worker cron
    also: any scheduler. It fetches, compares and writes — nothing exotic
- **A fixtures and results feed**
    ours: football-data.org, free tier
    also: any sports API, or type the results in by hand for a small tournament
- **A wallet, only if you pay out on-chain**
    ours: one wallet, one payout script, 39 transactions
    also: skip it entirely and the game still works — the prize pool is optional scaffolding

## Run it

    run the SQL in app/sql/schema.sql, then the migrations in order
    npx wrangler deploy

## What is in here

- `dashboard/worldcup/app/assets/auth.js`  (185 lines)
- `dashboard/worldcup/app/assets/avatar.js`  (424 lines)
- `dashboard/worldcup/app/assets/config.js`  (21 lines)
- `dashboard/worldcup/app/assets/countries.js`  (60 lines)
- `dashboard/worldcup/app/assets/nav.js`  (83 lines)
- `dashboard/worldcup/app/assets/profile.js`  (324 lines)
- `dashboard/worldcup/app/assets/projection.js`  (554 lines)
- `dashboard/worldcup/app/assets/style.css`  (203 lines)
- `dashboard/worldcup/app/assets/twemojify.js`  (26 lines)
- `dashboard/worldcup/app/bonus.html`  (312 lines)
- `dashboard/worldcup/app/crypto.html`  (323 lines)
- `dashboard/worldcup/app/dashboard.html`  (476 lines)
- `dashboard/worldcup/app/for-designer.html`  (300 lines)
- `dashboard/worldcup/app/index.html`  (250 lines)
- `dashboard/worldcup/app/leaderboard.html`  (1615 lines)
- `dashboard/worldcup/app/prize-pool.html`  (983 lines)
- `dashboard/worldcup/app/reset.html`  (116 lines)
- `dashboard/worldcup/app/rules.html`  (621 lines)
- `dashboard/worldcup/app/sql/migration_phase_c.sql`  (41 lines)
- `dashboard/worldcup/app/sql/migration_phase_d.sql`  (155 lines)
- `dashboard/worldcup/app/sql/migration_phase_e.sql`  (131 lines)
- `dashboard/worldcup/app/sql/migration_phase_e_grants.sql`  (13 lines)
- `dashboard/worldcup/app/sql/migration_phase_g.sql`  (70 lines)
- `dashboard/worldcup/app/sql/migration_phase_h_auth.sql`  (36 lines)
- `dashboard/worldcup/app/sql/migration_phase_h_crypto_lock.sql`  (20 lines)
- `dashboard/worldcup/app/sql/migration_phase_h_grants.sql`  (30 lines)
- `dashboard/worldcup/app/sql/migration_phase_h_signup_trigger.sql`  (46 lines)
- `dashboard/worldcup/app/sql/migration_phase_h_wallet_signature.sql`  (14 lines)
- `dashboard/worldcup/app/sql/migration_phase_i_wallet_simple.sql`  (134 lines)
- `dashboard/worldcup/app/sql/migration_phase_j_scoring_rebalance.sql`  (87 lines)
- `dashboard/worldcup/app/sql/migration_phase_k_bonus_20.sql`  (29 lines)
- `dashboard/worldcup/app/sql/migration_phase_l_md2_reopen.sql`  (44 lines)
- `dashboard/worldcup/app/sql/migration_phase_m_md_staircase.sql`  (139 lines)
- `dashboard/worldcup/app/sql/migration_phase_n_bonus_live.sql`  (43 lines)
- `dashboard/worldcup/app/sql/migration_phase_o_bobai_snapshot.sql`  (226 lines)
- `dashboard/worldcup/app/sql/migration_phase_p_group_payouts.sql`  (45 lines)
- `dashboard/worldcup/app/sql/migration_phase_q_penalties.sql`  (29 lines)
- `dashboard/worldcup/app/sql/reset_test_data.sql`  (37 lines)
- `dashboard/worldcup/app/sql/schema.sql`  (226 lines)
- `dashboard/worldcup/app/tips.html`  (480 lines)
- `dashboard/worldcup/app/user.html`  (444 lines)
- `dashboard/worldcup/index.html`  (536 lines)
- `worker-wc/index.js`  (1245 lines)
- `worker-wc/migrations/2026-06-28_match_number.sql`  (12 lines)
- `worker-wc/wrangler.toml`  (25 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/worldcup-tipgame.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/worldcup-tipgame.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
