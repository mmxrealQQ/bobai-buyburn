// The DeFi agent's tick: AI income into the position, half of the position's
// fees kept as capital, the other half into $BOBAI the agent holds.
//
// THE FLOW, as the user set it on 2026-09-02 (fee rule as of 2026-09-09)
//   1. everything the AI side earns (USD1 for watches, $U for delivered jobs)
//      goes to the DeFi wallet, in BNB                      -> sweep
//   2. the DeFi wallet's profit — the fees the position earns — is
//      split: part stays as capital so the position grows out of its own
//      earnings (LP_FEE_KEEP_PCT, half since 2026-09-04: "er soll auch davon
//      wachsen"), the rest buys $BOBAI that stays in this wallet, never sold
//      (since 2026-09-09; before that it went to the buyback wallet); the
//      capital stays in the position, always                       -> collect
//   3. a range the price has left is re-set beside the price, one-sided, with
//      the token it ended in and no trade (2026-09-16); the old range's fees
//      are split the same way on the way                           -> rebalance
//   4. BNB that arrives while the main range is all of the other side opens
//      a reserve range below the price (2026-09-16)                -> ladder
//   5. capital that arrived — swept income, the kept fee share, deposits —
//      grows the same position                                     -> increase
// The buyback bot and the dev sweep are not touched by any of this; this
// worker sends them nothing and reads nothing from either.
//
// The three steps live in shared/lp-agent.js, shared with the hand script
// scripts/lp-agent.mjs — the same functions, so what a person can plan on a
// laptop is what this cron sends. The keys are Worker secrets, the same class
// of thing the buyback bot has held since July. This worker has no public
// face beyond a secret-gated /run: everything readable about it is served by
// the agent worker from the KV record it writes (agent.brainonbnb.com/lp/agent).
import { createPublicClient, createWalletClient, http, fallback } from 'viem';
import { bsc } from 'viem/chains';
import { privateKeyToAccount } from 'viem/accounts';
import { settleX402Queue } from './x402-settle.js';
import {
  RPCS, INCOME_SOURCES,
  planSweep, executeSweep, planCollect, executeCollect, planIncrease, executeIncrease,
  planRebalance, executeRebalance, readBnbUsd, planLadder, executeLadder, healLadder,
} from '../shared/lp-agent.js';
import { readLpWindows, verdict, measuredResetCost, readLpTicks, recordLpTick } from '../worker-agent/lp-windows.js';
import { trimHistory, ARCHIVE_KEY } from '../shared/lp-flow.js';
import { alertsOf, nodeHiccupOnly } from '../shared/lp-alerts.js';
import { rebalanceWait, splitFees, widthUpgrade, depositForcesReset, rangeLeft, RESET_AFTER_HOURS, HOME_POOL, LADDER_GATE, ladderActsInWatch, ladderActive, MIN_SWEEP_BNB } from '../shared/lp-guards.js';

export const KV_KEY = 'lp:agent';
// When the agent first saw the price outside the range, so an hourly check
// can tell "just left" from "gone for two hours". Cleared the moment the
// price is back inside or the range has been re-set.
export const OUT_SINCE_KEY = 'lp:out_since';
// THE EDGE DOES NOT RESTART THE WAIT (2026-11-16, A-Z review 15.11.): a centred range the price left by more than the
// slack, came back to within it and left again had its note cleared at the edge and stamped anew — a price swinging
// around edge + 0.5 % restarted the two hours every swing, and the range, earning nothing, was never re-set. Beside a
// centred range the note now stays until the price is back INSIDE; the edge still re-sets nothing. Beside a one-sided
// range (minted at the edge by design) it is cleared as before. Pure; pinned by scripts/lp-lock-edge-regressions.mjs.
export function edgeKeepsClock(env, inRange) { return env.LP_RESET_MODE === 'centred' && !inRange; }
// ONE RE-SET AT A TIME (2026-11-16, A-Z review 15.11.): a re-set asks the second opinion first (up to five minutes)
// and then sends; the :50 check or the 04:23 run doing so can still be at it when the next ten-minute watch starts,
// and the two would send from the same wallet into a range half unwound. The re-set holds this key while it works
// (15 min at most, a cron's whole life); a watch that finds it held does nothing, an hourly or daily run waits for it.
// THE RE-SET IS STILL DUE AFTER THE SECOND OPINION (2026-11-16, A-Z review 15.11.): the plan was read before the ask,
// and the ask may take five minutes. Read again after it: null = still due (go on with the fresh plan), else the reason
// it is not — a price back inside or at the edge is no re-set to pay for. A resume (no position, the two tokens in the
// wallet) stays due while the fresh read still finds it. Pure; pinned by scripts/lp-lock-edge-regressions.mjs.
export function stillDue(fresh, old) {
  if (old.resume) return fresh.resume && !fresh.no ? null : `the re-set to finish is no longer there after the second opinion${fresh.no ? ` (${fresh.no})` : ''}`;
  if (fresh.resume || String(fresh.summary?.position ?? '') !== String(old.summary?.position ?? '')) return 'the position changed while the second opinion was asked — nothing sent, the next check reads it anew';
  if (fresh.summary?.in_range) return 'the price came back inside the range while the second opinion was asked — no re-set';
  if (fresh.summary?.at_edge) return 'the price came back to the edge of the range while the second opinion was asked — no re-set';
  if (fresh.no) return `after the second opinion: ${fresh.no}`;
  return null;
}
export const BUSY_KEY = 'lp:busy';
export const BUSY_TTL_S = 900;
export const BUSY_WAIT_MS = 8 * 60000;
export async function busyAfterWait(env, { watch = false, waitMs = BUSY_WAIT_MS, stepMs = 15000, sleep = (ms) => new Promise((r) => setTimeout(r, ms)) } = {}) {
  let held = await env.AGENT.get(BUSY_KEY).catch(() => null);
  if (!held || watch) return held;
  for (let waited = 0; held && waited < waitMs; waited += stepMs) { await sleep(stepMs); held = await env.AGENT.get(BUSY_KEY).catch(() => null); }
  return held;
}
// THE LADDER RECORD (2026-09-16): which position is the main range and
// which the reserve range below the price (shared/lp-agent.js, planLadder).
// Every step reads the wallet through it, so two positions it names read as
// one main range with a reserve attached; two it does not name are refused
// as before. Written by the ladder step (a reserve minted, re-set, or
// merged away) and corrected here when the chain holds fewer positions
// than the record says.
export const LADDER_KEY = 'lp:ladder';
async function readLadder(env) {
  try { const raw = await env.AGENT.get(LADDER_KEY); const l = raw ? JSON.parse(raw) : null; return l && typeof l === 'object' ? { main: l.main ?? null, reserve: l.reserve ?? null, since: l.since ?? null } : { main: null, reserve: null, since: null }; }
  catch { return { main: null, reserve: null, since: null }; }
}
async function writeLadder(env, ladder) { await env.AGENT.put(LADDER_KEY, JSON.stringify(ladder)); }
// WHAT WAS SENT IS RECORDED, WHATEVER KV DOES AFTERWARDS (2026-09-18). The KV
// writes that follow a step's transactions used to sit in the same try: a put
// that threw turned a re-set that had happened into `{ error, txs }` without
// its new position, its fees or its $BOBAI — the money flow never counted it
// and the ladder record went stale. They run on their own now; a failure is
// named beside the result (`kv_error`), and ladderHeal follows the chain on
// the next tick.
async function afterSend(fn) { try { await fn(); return {}; } catch (e) { return { kv_error: String(e.message || e).slice(0, 200) }; } }
// relocate sits before rebalance: a day on which the pool record's switch
// rule says "move" ends with the position in the new pool, and the re-set
// step then finds it in range. It runs in the daily tick only.
// ladder sits between rebalance and increase (2026-09-16): a deposit that
// waits beside a sell ladder above the price becomes a buy ladder below it
// before the increase can refuse it; gated by LP_LADDER in wrangler.toml.
const STEPS = ['sweep', 'collect', 'relocate', 'rebalance', 'ladder', 'increase'];
const DAILY_CRON = '23 4 * * *';
// The hourly check re-sets the range and, since 2026-09-09, also puts in
// what the wallet holds — a re-set that lands the position back in range
// used to leave a deposit idle until the next 04:23. The deposit watch
// runs every ten minutes on the other minutes and does only the increase:
// one balance read, and nothing at all under the floor or out of range.
// The operator's rule, 2026-09-09: "such things have to happen within
// seconds or minutes" — a deposit that sits for a day is a broken agent.
const HOURLY_CRON = '50 * * * *';

const json = (obj, status = 200) => new Response(JSON.stringify(obj, null, 2), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
const account = (key) => privateKeyToAccount(key.startsWith('0x') ? key : `0x${key}`);
// Three public endpoints in turn. The first build used one and a throttled
// node would have read as "the position holds nothing".
const transport = () => fallback(RPCS.map((u) => http(u, { timeout: 15000 })));

async function readState(env) {
  const raw = await env.AGENT.get(KV_KEY);
  return raw ? JSON.parse(raw) : { history: [], last: null };
}

// One run. `dry` reads and decides but signs nothing — the same code path up
// to the first transaction, which is the part worth being able to test after
// a deploy without moving money. `steps` narrows a hand-triggered run.
// `watch` marks the ten-minute deposit watch: it re-sets the range only when
// a large deposit waits beside a range the price has left (depositForcesReset),
// and its rebalance step is not recorded otherwise, so the hourly check's
// own record is not overwritten six times an hour with "no re-set".
// The second opinion, asked of the agent worker over its service binding (AGENT_SRV); never throws.
async function askSecondOpinion(env, why, own = null) {
  if (!env.AGENT_SRV || !env.AGENT_HIT_SECRET) return { status: 'not asked', reason: 'no AGENT_SRV binding or AGENT_HIT_SECRET on this worker' };
  // 2026-10-18: 60 s cut off a hire that took over two minutes (job 57021, paid and answered, never logged); a cron
  // has 15 minutes, so five are waited. Every outcome is kept in KV (opinion:ask:last, shown on GET /second-opinion).
  const at = new Date().toISOString();
  let out;
  try {
    const r = await env.AGENT_SRV.fetch('https://agent/second-opinion', { method: 'POST', headers: { 'content-type': 'application/json', 'x-hit-secret': env.AGENT_HIT_SECRET }, body: JSON.stringify({ why, own }), signal: AbortSignal.timeout(300000) });
    const j = await r.json();
    out = { status: j.status || 'unknown', job: j.job || null, tx: j.tx || null, agrees: j.agrees ?? null, answer: j.answer || null, reason: j.reason || j.error || null };
  } catch (e) { out = { status: 'failed', reason: String(e && e.message || e).slice(0, 120) }; }
  await env.AGENT.put('opinion:ask:last', JSON.stringify({ at, why, status: out.status, job: out.job, reason: out.reason })).catch(() => {});
  return out;
}

// The daily ask, asked once more two minutes later when it got no job at all (a refusal by a rail is not retried:
// the same rail would refuse again). A hire that went out but came back without an answer is not bought twice.
async function dailySecondOpinion(env) {
  const first = await askSecondOpinion(env, 'daily');
  if (first.job || first.status === 'refused' || first.status === 'not asked') return first;
  const since = Date.now() - 6 * 60000;
  await new Promise((r) => setTimeout(r, 120000));
  // the first attempt may still have hired after this side stopped waiting: its row says so, then nothing is bought again
  const log = await env.AGENT_SRV.fetch('https://agent/second-opinion').then((r) => r.json()).catch(() => null);
  if (!log || !Array.isArray(log.opinions)) return first;
  const went = log.opinions.find((o) => Date.parse(o.at) >= since && (o.job || o.status === 'hiring'));
  if (went) return { status: went.status, job: went.job || null, agrees: went.agrees ?? null, reason: 'the first ask hired after all' };
  return askSecondOpinion(env, 'daily, asked again');
}

export async function agentTick(env, { dry = false, steps = STEPS, watch = false, retriedAfter = null } = {}) {
  const at = new Date().toISOString();
  const pub = createPublicClient({ chain: bsc, transport: transport() });
  const entry = { at, dry, ok: true, acted: false, steps: {}, ...(retriedAfter ? { retried_after: retriedAfter } : {}) };

  const run = async (name, fn) => {
    if (!steps.includes(name)) return;
    try {
      const out = await fn();
      entry.steps[name] = out;
      const parts = Array.isArray(out) ? out : [out];
      for (const p of parts) {
        if (p.acted) entry.acted = true;
        if (p.error) entry.ok = false;
      }
    } catch (e) {
      entry.ok = false;
      entry.steps[name] = { acted: false, error: String(e.shortMessage || e.message).slice(0, 300) };
    }
  };

  // 1. sweep, one income wallet at a time. A missing key is a red line, not a
  //    quiet day: the flow the site describes would silently not be running.
  await run('sweep', async () => {
    const feed = await readBnbUsd(pub);
    const out = [];
    for (const src of INCOME_SOURCES) {
      const key = env[src.keyEnv];
      if (!key) { out.push({ source: src.key, acted: false, error: `${src.keyEnv} is not set on this worker` }); continue; }
      const acct = account(key);
      if (acct.address.toLowerCase() !== src.wallet.toLowerCase()) { out.push({ source: src.key, acted: false, error: `${src.keyEnv} does not open ${src.wallet}` }); continue; }
      const txs = [];
      try {
        const plan = await planSweep(pub, src, feed);
        if (plan.no) { out.push({ ...plan.summary, acted: false, why: plan.no }); continue; }
        if (dry) { out.push({ ...plan.summary, acted: false, why: 'dry run — would have bought $BOBAI with it and held it in the income wallet' }); continue; }
        const wallet = createWalletClient({ account: acct, chain: bsc, transport: transport() });
        // SWEEP_LIQ (2026-10-22): half of the $BOBAI half into the pool, LP burned — off until the operator's second go
        out.push({ ...plan.summary, acted: true, ...(await executeSweep(pub, wallet, acct, plan, () => {}, { txs, liquidity: env.SWEEP_LIQ === 'on' })) });
      } catch (e) {
        // A sweep that sent before it failed did act: saying otherwise would
        // hide its transactions from the record and from the day's counters.
        out.push({ source: src.key, acted: txs.length > 0, error: String(e.shortMessage || e.message).slice(0, 300), txs });
      }
    }
    return out;
  });

  const lpKey = env.LP_PRIVATE_KEY;
  if (!lpKey) {
    entry.ok = false;
    for (const s of ['collect', 'relocate', 'rebalance', 'ladder', 'increase']) if (steps.includes(s)) entry.steps[s] = { acted: false, error: 'LP_PRIVATE_KEY is not set on this worker' };
    entry.why = whyOf(entry.steps);
    return record(env, entry, steps.length < STEPS.length);
  }
  const lp = account(lpKey);
  entry.wallet = lp.address;
  // a re-set still at work (BUSY_KEY): the watch leaves the wallet to it; the hourly and daily runs wait, then stop
  // with a red line rather than send beside it. The sweep above moved other wallets and is not held up.
  if (!dry) {
    const busy = await busyAfterWait(env, { watch });
    if (busy) {
      const why = `a re-set is still at work (${busy}) — ${watch ? 'the watch leaves the wallet to it' : `still at work after ${BUSY_WAIT_MS / 60000} min, nothing sent beside it`}`;
      if (watch) { console.log(`[LP] ${at}: ${why}`); return { ...entry, skipped: why }; }
      entry.ok = false;
      for (const s of ['collect', 'relocate', 'rebalance', 'ladder', 'increase']) if (steps.includes(s)) entry.steps[s] = { acted: false, error: why };
      entry.why = whyOf(entry.steps);
      return record(env, entry, steps.length < STEPS.length);
    }
  }
  const lpWallet = () => createWalletClient({ account: lp, chain: bsc, transport: transport() });
  const ladder = await readLadder(env);
  // The record follows the chain (ladderHeal, 2026-09-17): a main range the
  // wallet no longer holds is replaced by the one position that stands beside
  // the reserve in the same pool. A dry run heals in hand only.
  try {
    const healed = await healLadder(pub, lp.address, ladder);
    if (healed) { entry.ladder_healed = { from: ladder.main, to: healed.main, ...(healed.closed ? { reserve_closed: ladder.reserve } : {}), ...(healed.adopted ? { reserve_adopted: healed.reserve, reserve_was: ladder.reserve ?? null } : {}), why: healed.why }; ladder.main = healed.main; if (healed.closed) ladder.reserve = null; if (healed.adopted) ladder.reserve = healed.reserve; if (!dry) await writeLadder(env, ladder); }
  } catch { /* an RPC that did not answer heals nothing; the guards refuse as before */ }
  const ladderOn = ladderActive(env); // off under centred re-sets (2026-10-09), whatever LP_LADDER says
  // The width record's verdict, replayed once per tick (the rebalance step
  // fills it; the ladder step reads it).
  let widthRecord = null;
  // The width record's verdict with the agent's own measured re-set cost —
  // one loader for the rebalance and the ladder step, so the two never pick
  // a different width from the same record (2026-09-16: a hand-narrowed
  // ladder run replayed without the cost and named ±4% where the re-set
  // had just taken ±7%).
  const loadWidthRecord = async () => {
    const log = await readLpWindows(env);
    let costOpts = {}, bnbUsd = null;
    try {
      bnbUsd = (await readBnbUsd(pub)).bnbUsd;
      const m = measuredResetCost(await readState(env), bnbUsd);
      if (m) costOpts = { resetCostUsd: m.usd_per_50 ?? m.usd, resetCostFullUsd: m.usd, resetCostBasis: `measured: the re-set of ${m.at.slice(0, 16).replace('T', ' ')} UTC cost $${m.usd} on a $${m.position_usd_at_reset ?? '?'} position — ${m.gas_bnb} BNB of gas and ${m.swap_fee_bnb} BNB of swap fee (${m.swap_basis})` };
    } catch { /* the replay's assumption stands */ }
    const record = log ? verdict(log, { ...costOpts, tape: await readLpTicks(env), centred: env.LP_RESET_MODE === 'centred', fixedWidth: Number(env.LP_WIDTH_PCT) || null }) : null;
    return { log, record, costOpts, bnbUsd };
  };

  // 2. collect: fees -> BNB -> part kept as capital, the rest to the buyback
  //    wallet. Only what this run produced. The share is a var, not a secret:
  //    it is public policy, and the record names it with every collect.
  const keptPct = splitFees(0n, env.LP_FEE_KEEP_PCT).pct;
  await run('collect', async () => {
    const plan = await planCollect(pub, lp.address, ladder);
    const split = { kept_pct: keptPct, buyback_pct: 100 - keptPct };
    if (plan.no) return { ...plan.summary, ...split, acted: false, why: plan.no };
    if (dry) return { ...plan.summary, ...split, acted: false, why: `dry run — would have collected, kept ${keptPct}% as capital and forwarded the rest`, would_forward_bnb_about: plan.state.owedBnbEquivalent };
    const txs = [];
    try {
      return { ...plan.summary, ...split, acted: true, ...(await executeCollect(pub, lpWallet(), lp, plan, () => {}, { keptPct, txs })) };
    } catch (e) {
      return { ...plan.summary, acted: txs.length > 0, error: String(e.shortMessage || e.message).slice(0, 300), txs };
    }
  });

  // 2b. relocate: retired on 2026-09-11. For one day (2026-09-10) the pool
  //     record replayed fifty dollars in twelve pools each hour and this
  //     step would have moved the position to whichever led by a quarter.
  //     The operator closed the question: the agent stays in CAKE/BNB 0.05%
  //     and optimises there (HOME_POOL in shared/lp-guards.js). The step
  //     stays in the record so the day's entries keep their shape, and says
  //     so in words; the hand script can still bring a stray position home.
  await run('relocate', async () => ({ acted: false, move: false, why: `stay: ${HOME_POOL.why}` }));

  // 3. rebalance: a position the price has left is re-set around today's
  //    price, in the width the window record's earnings test picked — the
  //    width that netted the most per day over the recorded prices, re-sets
  //    included. Checked every hour, not once a day: a position outside its
  //    range earns nothing, and the daily tick left it there for up to a day.
  //    But not on the first hour outside — a price that just left is often
  //    back on its own, so the agent waits before paying for a re-set. The
  //    wait is the record's own since 2026-09-09: delay_test.in_use_hours,
  //    the wait that netted the most per day when every width was replayed
  //    with each wait (a set 2 h until the record clears the bar). Gated by
  //    LP_REBALANCE in wrangler.toml: the first re-set was run by hand and
  //    watched (2026-09-02), then the cron took over.
  await run('rebalance', async () => {
    // THE WATCH LOOKS BEFORE IT REPLAYS (2026-09-13). Every ten minutes the
    // watch used to read the width record (~100 KB), the price tape and
    // replay ten widths with ten waits, twice — to decide, nearly always,
    // that there is nothing for it to do: it re-sets only when a large
    // deposit waits beside a range the price has left, or finishes a re-set
    // that stopped half way. Both show in one look at the position and the
    // wallet, which the increase step reads anyway. So the watch looks first
    // and replays only when it may act; the hourly check and the daily run
    // still replay every time, since they may re-set on the wait alone.
    if (watch) {
      const inc = await planIncrease(pub, lp.address, null, ladder);
      const s = inc.summary;
      if (inc.pos && s.in_range != null) {
        // "Left" is the guard's word, not the pool's: a one-sided range sits
        // beside the price by construction, and a price within the slack of
        // an edge has not left (rangeLeft, 2026-09-16).
        const lf = rangeLeft(s.tick, Number(inc.pos[5]), Number(inc.pos[6]));
        const settled = s.in_range || !lf.left;
        const forced = settled || (ladderOn && s.side === 'other') ? null : depositForcesReset({ inRange: false, spendableBnb: s.spendable_bnb, valueBnb: s.value_bnb });
        if (!forced) {
          const outSinceRaw = await env.AGENT.get(OUT_SINCE_KEY);
          const edgeKeeps = edgeKeepsClock(env, s.in_range);
          if (settled) { if (outSinceRaw != null && !dry && !edgeKeeps) await env.AGENT.delete(OUT_SINCE_KEY); }
          else if (outSinceRaw == null && !dry) await env.AGENT.put(OUT_SINCE_KEY, at);
          return {
            position: s.position, ticks: [Number(inc.pos[5]), Number(inc.pos[6])], tick: s.tick, in_range: s.in_range,
            pool: s.pool, wbnb_is0: inc.wbnbIs0, value_bnb: s.value_bnb,
            acted: false, watch: true, looked_only: true, ...(lf.outside && !lf.left ? { at_edge: true, ticks_beyond_edge: lf.ticks_away } : {}),
            outside_since: settled ? (edgeKeeps ? outSinceRaw : null) : (outSinceRaw || at),
            deposit_beside: { spendable_bnb: s.spendable_bnb, value_bnb: s.value_bnb },
            why: 'deposit watch: the range is re-set here only when a large deposit waits beside it; the hourly check does the rest',
          };
        }
      }
    }
    // The width is picked with the cost the agent really pays, once it has
    // paid one: the last re-set's gas from its own record, in today's dollars
    // (loadWidthRecord; the replay is charged the cost per $50 of the
    // position, the full figure stays for the record).
    const { log, record, costOpts, bnbUsd } = await loadWidthRecord();
    // The pool the record watches lets the plan finish a re-set that stopped
    // between its unwind and its mint: no position, the two tokens in the
    // wallet (2026-09-05 12:50). Such a resume does not wait the two hours —
    // the capital is already out of the pool and earning nothing.
    widthRecord = record;
    // The width and the re-set's mode by the operator's word (2026-10-07: ±20%, centred): LP_WIDTH_PCT names the
    // width (empty = the record's pick, floor ±10%), LP_RESET_MODE "centred" re-sets around the price with one trade
    // ("one-sided" or empty = beside the price, no trade). Both read again on every run, reversible in wrangler.toml.
    const fixedWidth = Number(env.LP_WIDTH_PCT) > 0 && Number(env.LP_WIDTH_PCT) <= 50 ? Number(env.LP_WIDTH_PCT) : null;
    const plan = await planRebalance(pub, lp.address, { record, pool: log?.pool || null, keptPct, ladder, widthOverride: fixedWidth, centred: env.LP_RESET_MODE === 'centred' });
    const outSinceRaw = await env.AGENT.get(OUT_SINCE_KEY);
    const outSince = outSinceRaw ? Date.parse(outSinceRaw) : null;
    let upgrade = null;
    // At the edge (within the slack) is not a re-set: the price may be back
    // within the hour. Beside a one-sided range a note that ran is cleared —
    // the edge is where such a range lives. Beside a centred range the note
    // stays (edgeKeepsClock): it is still outside and earning nothing.
    if (plan.summary.at_edge === true && !plan.summary.in_range) {
      const edgeKeeps = edgeKeepsClock(env, false);
      if (outSince != null && !dry && !edgeKeeps) await env.AGENT.delete(OUT_SINCE_KEY);
      return { ...plan.summary, acted: false, ...(edgeKeeps && outSinceRaw ? { outside_since: outSinceRaw } : {}), why: plan.no };
    }
    if (plan.summary.in_range) {
      if (outSince != null && !dry) await env.AGENT.delete(OUT_SINCE_KEY);
      // In range, nothing forces a re-set — unless the record's pick now
      // nets enough more on this capital to pay for one within a day. The
      // daily run alone may upgrade (once a day, by construction).
      upgrade = widthUpgrade({
        daily: steps.length === STEPS.length, inRange: true, ticks: plan.summary.ticks, tick: plan.summary.tick,
        pick: record?.earnings_pick || null, rows: record?.rows || [], hoursOfPrices: record?.hours_of_prices || 0,
        valueBnb: plan.summary.value_bnb, bnbUsd, resetCostUsd: costOpts.resetCostFullUsd ?? record?.reset_cost?.usd ?? 0,
      });
      if (!upgrade.upgrade) return { ...plan.summary, acted: false, why: plan.no, upgrade: upgrade.why };
      if (plan.width == null || !plan.ticks) return { ...plan.summary, acted: false, why: plan.no, upgrade: 'the plan carries no new ticks to upgrade into' };
    } else if (plan.no) return { ...plan.summary, acted: false, outside_since: outSinceRaw || null, why: plan.no };
    // A large deposit waiting beside a range the price has left ends the wait.
    let forced = null, waiting = null;
    if (!plan.resume && !plan.summary.in_range) {
      try {
        const inc = await planIncrease(pub, lp.address, null, ladder);
        waiting = { spendable_bnb: inc.state.spendableBnb, value_bnb: plan.summary.value_bnb };
        // With the ladder on, a deposit beside a sell ladder (the main range
        // all of the other side, above the price) is the ladder step's: it
        // becomes a buy ladder below the price, no trade. Forcing a re-set
        // here would buy the other side with it, the very trade the ladder
        // exists to avoid.
        forced = ladderOn && inc.summary.side === 'other' ? null : depositForcesReset({ inRange: false, spendableBnb: inc.state.spendableBnb, valueBnb: plan.summary.value_bnb });
      } catch (e) { waiting = { error: String(e.shortMessage || e.message).slice(0, 160) }; forced = null; }
    }
    const forcedNote = { ...(waiting ? { deposit_beside: waiting } : {}), ...(forced ? { forced_by_deposit: forced } : {}) };
    // The ten-minute watch stamps the moment the price left the range, so the
    // wait runs from then; until 2026-09-12 only the :50 check stamped it, and
    // a range left at :51 waited up to an hour longer than the record says.
    if (watch && !plan.resume && !plan.summary.in_range && outSince == null && !dry) await env.AGENT.put(OUT_SINCE_KEY, at);
    if (watch && !forced && !plan.resume) return { ...plan.summary, ...forcedNote, acted: false, watch: true, outside_since: outSinceRaw || at, why: 'deposit watch: the range is re-set here only when a large deposit waits beside it; the hourly check does the rest' };
    if (upgrade && upgrade.upgrade) {
      if (String(env.LP_REBALANCE || '0') !== '1') return { ...plan.summary, acted: false, why: 'a width upgrade is due and LP_REBALANCE is not 1', upgrade: upgrade.why };
      if (dry) return { ...plan.summary, acted: false, why: `dry run — would have upgraded the width from ${upgrade.from}% to ${upgrade.to}%`, upgrade: upgrade.why };
      const txs = [];
      try {
        const done = await executeRebalance(pub, lpWallet(), lp, plan, () => {}, { keptPct, txs });
        return { ...plan.summary, acted: true, upgrade: upgrade.why, upgraded_from_pct: upgrade.from, upgraded_to_pct: upgrade.to, gain_usd_per_day: upgrade.gain_usd_per_day, ...done };
      } catch (e) {
        return { ...plan.summary, acted: txs.length > 0, upgrade: upgrade.why, error: String(e.shortMessage || e.message).slice(0, 300), txs };
      }
    }
    const waitH = record?.delay_test?.in_use_hours ?? RESET_AFTER_HOURS;
    const waitNote = { wait_h: waitH, wait_basis: record?.delay_test?.wait_basis || 'set', ...(forced ? { forced_by_deposit: forced } : {}) };
    if (!plan.resume && !forced) {
      if (outSince == null) {
        if (!dry) await env.AGENT.put(OUT_SINCE_KEY, at);
        const first = rebalanceWait(null, Date.parse(at), waitH);
        if (first) return { ...plan.summary, ...waitNote, acted: false, outside_since: at, why: first };
      } else {
        const wait = rebalanceWait(outSince, Date.parse(at), waitH);
        if (wait) return { ...plan.summary, ...waitNote, acted: false, outside_since: outSinceRaw, why: wait };
      }
    }
    if (String(env.LP_REBALANCE || '0') !== '1') return { ...plan.summary, ...forcedNote, acted: false, outside_since: outSinceRaw, why: 'a re-set is due and LP_REBALANCE is not 1 — the first one is run by hand and watched, then the cron takes over' };
    if (dry) return { ...plan.summary, ...forcedNote, acted: false, outside_since: outSinceRaw, why: plan.resume ? 'dry run — would have minted the range from what the wallet holds' : `dry run — would have re-set the range${plan.oneSided ? ` one-sided, ${plan.ticks.side === 'above_price' ? 'above' : 'below'} the price, no trade` : ''}${plan.summary.fees_to_bobai_bnb > 0 ? ` and bought BOBAI with ${plan.summary.fees_to_bobai_bnb} BNB of the old range's fees` : ''}` };
    // THE SECOND OPINION (2026-10-14, operator's choice "an agent that hires an agent"; stage 1: recorded beside the
    // run, it decides nothing): before money moves, an outside agent is paid to read the position independently
    // (agent worker /second-opinion: Mandate Range-1 over the ERC-8183 kernel, through the Altana leash). A failed or
    // slow opinion never stops the re-set; it is waited for up to five minutes (askSecondOpinion), and then the plan is
    // read again (stillDue): a price back in the range by then is no re-set any more, and one still out is re-set from
    // the pool as it is now, not as it was five minutes before. BUSY_KEY is held from the ask to the last send.
    await env.AGENT.put(BUSY_KEY, `${watch ? 'watch' : steps.length === STEPS.length ? 'daily run' : 'hourly check'} of ${at}`, { expirationTtl: BUSY_TTL_S }).catch(() => {});
    try {
    entry.second_opinion = await askSecondOpinion(env, 'before a re-set', { position: plan.summary.position ?? null, in_range: plan.summary.in_range ?? null, tick: plan.summary.tick ?? null });
    let fresh = null;
    try { fresh = await planRebalance(pub, lp.address, { record, pool: log?.pool || null, keptPct, ladder, widthOverride: fixedWidth, centred: env.LP_RESET_MODE === 'centred' }); } catch { fresh = null; }
    const gone = fresh ? stillDue(fresh, plan) : null;
    if (gone) return { ...fresh.summary, ...forcedNote, acted: false, outside_since: outSinceRaw, why: gone };
    // a read that failed keeps the plan in hand (the re-set as it was before 2026-11-16), and says so
    const go = fresh || plan;
    const replanNote = fresh ? {} : { replan: 'the plan could not be read again after the second opinion — the first plan was used' };
    const txs = [];
    try {
      // THE MERGE (2026-09-16). A reserve range that holds the same token as
      // the main range (the price went through one of them) is unwound
      // first; its tokens and fees come back to the wallet, and the mint
      // below takes them with the rest — one range again, no trade.
      let merged = null;
      if (go.summary.reserve) {
        const lp2 = await planLadder(pub, lp.address, { record: widthRecord, ladder });
        if (lp2.act === 'merge') {
          const m = await executeLadder(pub, lpWallet(), lp, lp2, () => {}, { txs });
          merged = { merged_reserve: m.merged_reserve, reserve_fees_folded: m.reserve_fees_folded };
          ladder.reserve = null; Object.assign(merged, await afterSend(() => writeLadder(env, ladder)));
        }
      }
      // A re-set a deposit forced takes the deposit with it: wrapped after
      // the unwind, minted with the rest, no sell-then-buy-back.
      const done = await executeRebalance(pub, lpWallet(), lp, go, () => {}, { keptPct, wrapFirst: !!forced, txs });
      if (done.new_position) { ladder.main = String(done.new_position); ladder.since = ladder.since || at; }
      const kv = await afterSend(async () => { await env.AGENT.delete(OUT_SINCE_KEY); if (done.new_position) await writeLadder(env, ladder); });
      return { ...go.summary, ...forcedNote, ...replanNote, acted: true, outside_since: outSinceRaw, ...(merged || {}), ...done, ...kv };
    } catch (e) {
      return { ...go.summary, ...forcedNote, ...replanNote, acted: txs.length > 0, outside_since: outSinceRaw, error: String(e.shortMessage || e.message).slice(0, 300), txs };
    }
    } finally { await env.AGENT.delete(BUSY_KEY).catch(() => {}); }
  });
  // The price the check saw goes on the tape, every ten minutes, whatever
  // the step decided (lp-windows.js, THE PRICE TAPE). The price is WBNB per
  // unit of the other side, the way the window record quotes it.
  {
    const rb = entry.steps.rebalance;
    if (!dry && rb && rb.tick != null && rb.pool) {
      const raw = Math.pow(1.0001, Number(rb.tick));
      await recordLpTick(env, { at, tick: Number(rb.tick), price: rb.wbnb_is0 ? 1 / raw : raw, pool: rb.pool }).catch(() => {});
    }
  }
  // The watch's rebalance step is kept only when it did something or a
  // deposit forced it; a "no re-set here" every ten minutes is not a record.
  // A dry run keeps it, so a hand check can see what the watch saw.
  if (watch && !dry && entry.steps.rebalance && !entry.steps.rebalance.acted && !entry.steps.rebalance.forced_by_deposit && !entry.steps.rebalance.error) delete entry.steps.rebalance;

  // 3b. ladder (2026-09-16): BNB waiting beside a main range that is all of
  //     the other side above the price opens, or grows, a reserve range
  //     below the price — WBNB only, no trade (planLadder, ladderDecision).
  //     A reserve the price has left is re-set beside it the same way. The
  //     merge back into one range happens at the main range's re-set above.
  //     Gated by LP_LADDER: "0" plans and records, "1" runs. The ten-minute
  //     watch runs it too, so a deposit becomes a ladder within minutes.
  await run('ladder', async () => {
    // A hand-narrowed run (step=ladder) has no rebalance step before it to
    // fill the width record; replay it here then, so the reserve's width is known.
    if (!widthRecord) { try { widthRecord = (await loadWidthRecord()).record; } catch { widthRecord = null; } }
    const plan = await planLadder(pub, lp.address, { record: widthRecord, ladder });
    const base = { ...plan.summary, gate: ladderOn ? 'on' : 'off' };
    if (plan.no) return { ...base, acted: false, why: `${plan.why} — ${plan.no}` };
    if (!plan.act) return { ...base, acted: false, why: plan.why };
    if (plan.act === 'merge') return { ...base, acted: false, why: `${plan.why} (done at the main range's re-set)` };
    if (!ladderOn) return { ...base, acted: false, why: `${plan.why} — ${env.LP_RESET_MODE === 'centred' ? 're-sets are centred, so a deposit joins the re-set and no reserve is minted' : `${LADDER_GATE} is not 1`}: planned, not run` };
    // The watch opens and grows the reserve; re-setting it is the hourly
    // check's (ladderActsInWatch) — the reserve does not chase the price
    // every ten minutes.
    if (watch && !ladderActsInWatch(plan.act)) return { ...base, acted: false, why: `${plan.why} — left to the hourly check: the ten-minute watch does not re-set the reserve` };
    if (dry) return { ...base, acted: false, why: `dry run — would have ${plan.act === 'mint_reserve' ? 'minted the reserve range' : plan.act === 'increase_reserve' ? 'grown the reserve range' : 're-set the reserve range'}: ${plan.why}` };
    const txs = [];
    try {
      const done = await executeLadder(pub, lpWallet(), lp, plan, () => {}, { txs });
      // The record on KV and the one this tick holds in hand: the increase
      // step that follows must read the wallet through the new reserve too.
      let kv = {};
      if (done.new_reserve) { ladder.main = plan.summary.position; ladder.reserve = String(done.new_reserve); ladder.since = ladder.since || at; kv = await afterSend(() => writeLadder(env, ladder)); }
      return { ...base, acted: true, ...done, ...kv };
    } catch (e) {
      return { ...base, acted: txs.length > 0, error: String(e.shortMessage || e.message).slice(0, 300), txs };
    }
  });
  // The watch keeps its ladder step only when it did something.
  if (watch && !dry && entry.steps.ladder && !entry.steps.ladder.acted && !entry.steps.ladder.error) delete entry.steps.ladder;

  // 4. increase: whatever is above the reserve, into the same position.
  await run('increase', async () => {
    const plan = await planIncrease(pub, lp.address, null, ladder);
    if (plan.no) return { ...plan.summary, acted: false, why: plan.no };
    if (dry) return { ...plan.summary, acted: false, why: 'dry run — would have grown the position' };
    const txs = [];
    try {
      return { ...plan.summary, acted: true, ...(await executeIncrease(pub, lpWallet(), lp, plan, () => {}, { txs })) };
    } catch (e) {
      return { ...plan.summary, acted: txs.length > 0, error: String(e.shortMessage || e.message).slice(0, 300), txs };
    }
  });

  entry.why = whyOf(entry.steps);
  // A NODE THAT DID NOT ANSWER (2026-10-14, operator's go; shared/lp-alerts.js nodeHiccupOnly): a run that acted nowhere,
  // sent nothing and failed only on a node timing out is run once more a minute later — the same run, not a second
  // action — and its record says it was the retry and what the first try met. Anything else is recorded and told as before.
  if (nodeHiccupOnly(entry)) {
    const met = Object.entries(entry.steps).flatMap(([k, v]) => (Array.isArray(v) ? v : [v]).filter((x) => x && x.error).map((x) => `${k}: ${String(x.error).slice(0, 80)}`));
    console.log(`[LP] ${at}: only a node did not answer (${met.join(' · ')}) — the same run once more in 60 s`);
    await new Promise((r) => setTimeout(r, 60000));
    return agentTick(env, { dry, steps, watch, retriedAfter: { at, met } });
  }
  return record(env, entry, steps.length < STEPS.length);
}

// The one-line summary of a record, rebuilt from its steps — so a daily
// record whose rebalance step was replaced by an hourly check does not keep
// saying "inside the range" from the morning while the step says "outside".
function whyOf(steps) {
  const out = [];
  for (const name of STEPS) {
    const v = steps[name];
    if (!v) continue;
    for (const p of Array.isArray(v) ? v : [v]) if (p.why) out.push(`${name}${p.source ? ` ${p.source}` : ''}: ${p.why}`);
  }
  return out.join(' · ') || null;
}

// `partial` is an hourly range check (or a hand-narrowed run): it becomes
// `last_check`, and its rebalance step is folded into the daily record so
// the page and the series see the range as it is now — but the daily
// record's sweep, collect and increase are not wiped by a run that never
// looked at them. A full run replaces the daily record as before.
// THE OPERATOR IS TOLD AT ONCE (2026-09-18) what cannot wait for the morning
// card: a failed step, a step waiting for a person, a healed record, and the
// money moving in a way it rarely does (shared/lp-alerts.js decides what).
// Sent through the Telegram bot's own worker (service binding TG, target
// "operator": the operator's private chat, never the channel). Each message
// has a key the worker remembers for its quiet hours, so a refusal that
// repeats every ten minutes is said once. Never throws: a message that did
// not go out must not cost the tick its record.
async function tellOperator(env, entry) {
  if (!env.TG || !env.BROADCAST_SECRET) return { told: 0, why: 'no TG binding or BROADCAST_SECRET on this worker' };
  let told = 0;
  for (const m of alertsOf(entry)) {
    try {
      const k = `lp:alert:${m.key}`;
      if (await env.AGENT.get(k)) continue;
      const r = await env.TG.fetch('https://tg/broadcast', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-broadcast-secret': env.BROADCAST_SECRET },
        body: JSON.stringify({ target: 'operator', text: m.text }),
      }).then((x) => x.json()).catch(() => null);
      if (r && r.ok === true) { told++; await env.AGENT.put(k, entry.at, { expirationTtl: Math.max(3600, Math.round((m.quietHours || 6) * 3600)) }); }
    } catch { /* the next tick says it */ }
  }
  return { told };
}

async function record(env, entry, partial = false) {
  const st = await readState(env);
  // A dry run reads and decides but signs nothing, and it is not the day's
  // run: on 2026-09-10 a hand-triggered dry run at 04:41 replaced the 04:23
  // daily record, the series had no point for it, and the 05:00 card was
  // held back. A dry run is kept as `last_dry` and touches nothing else.
  if (entry.dry) {
    st.last_dry = entry;
    await env.AGENT.put(KV_KEY, JSON.stringify(st));
    return entry;
  }
  // Every real action and every error is kept; quiet days are summarised as
  // the last check so the history is a history of what happened, not of the
  // cron firing.
  if (entry.acted || !entry.ok) {
    // The cap keeps the record readable every ten minutes; a run it pushes
    // out goes to the archive, where the sums still find it (lp-flow.js).
    const { kept, dropped } = trimHistory(st.history, entry);
    if (dropped.length) {
      const arch = JSON.parse((await env.AGENT.get(ARCHIVE_KEY)) || 'null') || { what_this_is: 'Runs the DeFi agent record no longer holds (it keeps the newest 200): the writer moves them here, oldest first, and every total the agent worker reports still counts them.', entries: [] };
      // Idempotent: if the archive put went through and the record's put after
      // it did not, the same oldest runs are dropped again on the next trim —
      // a run already in the archive (by its `at`) is not appended twice.
      const have = new Set((Array.isArray(arch.entries) ? arch.entries : []).map((x) => x && x.at));
      arch.entries = (Array.isArray(arch.entries) ? arch.entries : []).concat(dropped.filter((x) => x && !have.has(x.at)));
      await env.AGENT.put(ARCHIVE_KEY, JSON.stringify(arch));
    }
    st.history = kept;
  }
  st.last_check = entry;
  // Where the position lives, for the records that follow it (the width and
  // pool records watch this pool). A relocate names the new one the moment
  // it minted; every other run names what the increase step read.
  const pool = entry.steps?.relocate?.new_pool || entry.steps?.increase?.pool;
  if (pool && /^0x[0-9a-f]{40}$/i.test(pool)) st.pool = String(pool).toLowerCase();
  if (partial && st.last && st.last.steps) {
    const steps = { ...st.last.steps, ...entry.steps };
    // "Range checked" only when the range was: a hand-narrowed collect run
    // must not read as an hourly check on the record page.
    st.last = { ...st.last, steps, why: whyOf(steps), ...(entry.steps.rebalance ? { range_checked_at: entry.at } : {}) };
  } else {
    st.last = entry;
  }
  st.note = dailyNote(env) + ' the position stays in its home pool, CAKE/BNB 0.05% — the pool question is closed since 2026-09-11, and the relocate step only records that it stays. ' + hourlyNote(env) + ' The capital never leaves. Each step has a floor under which moving the money would cost more than the money, and a run under a floor is recorded as a decision, not an error.';
  st.cadence = { daily_utc: '04:23 — sweep, collect, rebalance, ladder, increase (relocate is retired and only records that the position stays)', hourly_utc: `:50 — rebalance (${env.LP_RESET_MODE === 'centred' ? 'centred, one swap, since 2026-10-07' : 'one-sided, no trade'}), ladder (${ladderActive(env) ? 'on' : 'off'}), then increase`, deposit_watch_utc: 'every 10 min — increase (a deposit goes in within minutes, in range and above the floor), and a re-set at once when a deposit of a quarter of the position or more waits beside a range the price has left' };
  await env.AGENT.put(KV_KEY, JSON.stringify(st));
  await tellOperator(env, entry).catch(() => {});
  return entry;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    // Proves the alert channel end to end (binding, secret, the bot's operator
    // target) without waiting for something to go wrong. Same secret as /run.
    if (url.pathname === '/alert-test' && request.method === 'POST') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return new Response('forbidden', { status: 403 });
      if (!env.TG || !env.BROADCAST_SECRET) return new Response(JSON.stringify({ ok: false, why: 'no TG binding or BROADCAST_SECRET on this worker' }), { status: 503, headers: { 'content-type': 'application/json' } });
      const r = await env.TG.fetch('https://tg/broadcast', { method: 'POST', headers: { 'content-type': 'application/json', 'x-broadcast-secret': env.BROADCAST_SECRET }, body: JSON.stringify({ target: 'operator', text: '🔔 <b>DeFi agent · alert channel test</b>\nThis is where a failed step, a step waiting for a person, a healed record and every re-set or ladder move will be said at once. Routine (looks, collects, top-ups) stays on the daily card.' }) }).then((x) => x.json()).catch((e) => ({ ok: false, error: String(e && e.message || e) }));
      return new Response(JSON.stringify({ ok: r && r.ok === true, bot: r }), { headers: { 'content-type': 'application/json' } });
    }
    if (url.pathname === '/run' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      // Dry unless asked otherwise: a hand-triggered run is for checking the
      // deploy, and checking must not be the thing that moves money.
      const dry = url.searchParams.get('dry') !== '0';
      const step = url.searchParams.get('step');
      const steps = step && STEPS.includes(step) ? [step] : STEPS;
      const watch = url.searchParams.get('watch') === '1';
      return json(await agentTick(env, { dry, steps, watch }));
    }
    if (url.pathname === '/') return json(await readState(env));
    return json({ error: 'not found' }, 404);
  },
  async scheduled(event, env, ctx) {
    // The daily tick runs all five steps; the :50 firing is the hourly range
    // check (rebalance, then increase so a fresh range takes what waits in the
    // wallet); every other firing is the deposit watch: increase, and a re-set
    // only when a large deposit waits beside a range the price has left.
    const watch = event.cron !== DAILY_CRON && event.cron !== HOURLY_CRON;
    const steps = event.cron === DAILY_CRON ? STEPS : ['rebalance', 'ladder', 'increase'];
    // the daily second opinion (2026-10-14): once a morning, beside the daily run, so the loop is seen every day
    if (event.cron === DAILY_CRON) ctx.waitUntil(dailySecondOpinion(env).then((o) => console.log(`[LP] second opinion: ${o.status}${o.job ? ` job ${o.job}` : ''}${o.agrees != null ? `, agrees ${o.agrees}` : ''}`)));
    ctx.waitUntil(agentTick(env, { steps, watch }).catch(async (e) => record(env, { at: new Date().toISOString(), ok: false, acted: false, error: String(e.message).slice(0, 300) })));
    // The x402 Permit2 queue (A8, 2026-09-24): apart from the agent's run, so
    // nothing in it can stop a re-set, and nothing in a re-set can stop it.
    ctx.waitUntil(settleX402Queue(env, RPCS)
      .then((r) => (r && (r.results || []).length ? env.AGENT.put('x402:settle:last', JSON.stringify({ at: new Date().toISOString(), ...r })) : null))
      .catch((e) => env.AGENT.put('x402:settle:last', JSON.stringify({ at: new Date().toISOString(), error: String(e && e.message || e).slice(0, 300) }))));
  },
};

// THE RECORD'S OWN WORDS, FROM THE SETTINGS IN FORCE (2026-10-29, the promise check: the note still said "re-set beside
// the price, one-sided, the width the replay put most ahead" while the cadence beside it said "centred, one swap" and the
// re-sets minted ±20% by hand since 2026-10-07): the hourly sentence is built from LP_RESET_MODE, LP_WIDTH_PCT and the
// ladder gate, the same values the code acts on, so the two cannot part again. Text only; no step reads it.
function hourlyNote(env) {
  const centred = env.LP_RESET_MODE === 'centred', width = Number(env.LP_WIDTH_PCT) || 0;
  const how = centred
    ? 'is re-set centred on the price, with one trade back to the range\'s mix (centred since 2026-10-07)'
    : 'is re-set beside the price, on the side the price came from, with the one token the old range ended in and no trade (one-sided)';
  const wide = width
    ? `the width is ±${width}%, set by hand in LP_WIDTH_PCT; the width record (/lp/windows) replays every width against holding, and on the recorded prices none came out ahead of holding, the wider ones losing less`
    : 'the width is the one that ended the most ahead against holding over the last week, fees in, when every width was replayed that way, kept unless another leads it by a tenth';
  const ladder = ladderActive(env)
    ? 'BNB that waits beside a main range that is all of the other side above the price opens a reserve range below the price, WBNB only, no trade (ladder, gated by LP_LADDER); the two merge back into one at the main range\'s next re-set once they hold the same token.'
    : 'The buy ladder (a reserve range below the price) is off while re-sets are centred.';
  return `Every hour: a position the price has left (more than half a percent past an edge, for the wait in use) ${how}; ${wide} (rebalance). ${ladder}`;
}

// THE DAILY SENTENCE, FROM THE RULES IN FORCE (2026-10-29, the page fact-check: the note still said the AI income is
// "sold for BNB and sent to the DeFi wallet" and the fees split "kept / $BOBAI" — since 2026-10-14 half of a sweep goes
// to the operator in the coin it was paid in and half buys $BOBAI held in the income wallet, the fees go in thirds, and
// since 2026-10-22 (SWEEP_LIQ "on") half of the $BOBAI half deepens the $BOBAI pool). Text only; no step reads it.
function dailyNote(env) {
  const bobai = env.SWEEP_LIQ === 'on'
    ? 'half buys $BOBAI: half of that stays in the income wallet, never sold, and half is paired into the $BOBAI/WBNB pool with the LP burned when its gas is at most 5% of it'
    : 'half buys $BOBAI that stays in the income wallet, never sold';
  return `Once a day: what the AI side earned (the income wallets) is split once it is over ${MIN_SWEEP_BNB} BNB — half goes to the operator in the coin it was paid in, ${bobai} (sweep; the DeFi capital is not touched by it); the fees the PancakeSwap V3 position earned are sold for BNB and split in thirds — a third stays as capital, a third is paid out to the operator, a third buys $BOBAI that the agent holds in its own wallet, never sold (collect, thirds since 2026-10-14); BNB above the reserve — the kept fees and what the operator puts in — grows the same position (increase);`;
}