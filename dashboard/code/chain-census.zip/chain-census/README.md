# The Census — reading a whole registry

Every agent id on BNB Chain, and every job they were ever paid for.

The measurement behind Brain Plaza, and the reason its numbers can be checked rather than believed. Two exhaustive scans, no sampling: one reads all 285,447 ids in the ERC-8004 identity registry and contacts every endpoint they name; the other reads all 56,655 jobs in the ERC-8183 escrow kernel and works out who has actually been hired and paid. Both resume after interruption, both treat a node refusing a batch as a fact about the node rather than about the chain, and both report what stayed unreadable instead of quietly dropping it. The publisher turns the two into the page and the JSON endpoints, and refuses to publish a scan that did not finish.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **Node 18+ and time**
    ours: about three hours for the registry, twenty minutes for the jobs
    also: both resume, so it can be run in pieces — the state file is the progress
- **RPC endpoints**
    ours: eleven public BSC nodes in rotation, 25 calls per batch
    also: any node list. Breadth matters more than speed: each one rate-limits separately, and 40 per batch is refused where 25 goes through
- **No keys**
    ours: every call is a read
    also: nothing here can move anything, which is why it can be pointed at a stranger’s contract without a second thought

## Run it

    node scripts/erc8004-scan.mjs           # the identity registry, every id
    node scripts/erc8004-probe.mjs          # does the endpoint answer?
    node scripts/erc8183-job-scan.mjs       # the job escrow, every job
    node scripts/erc8183-job-scan.mjs --owners --report
    node scripts/erc8004-publish.mjs        # writes the page and the JSON

## What is in here

- `scripts/erc8004-enrich.mjs`  (132 lines)
- `scripts/erc8004-probe.mjs`  (339 lines)
- `scripts/erc8004-publish.mjs`  (1724 lines)
- `scripts/erc8004-scan.mjs`  (472 lines)
- `scripts/erc8183-job-scan.mjs`  (383 lines)
- `scripts/lib/group-agents.mjs`  (148 lines)
- `scripts/lib/job-aggregate.mjs`  (140 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/chain-census.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/chain-census.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
