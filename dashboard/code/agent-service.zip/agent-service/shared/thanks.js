// A thank-you on every answer we give away (2026-09-26, the operator's idea).
//
// Everything BOBAI measures for other agents is free: no key, no account, no fee. Whoever calls it gets the
// same answer as anyone else, and with it one short note: thank you, and if it helped, a tip is welcome —
// voluntary, never required, and the answer does not change either way. The note is data, not an instruction:
// it tells the operator behind the caller where a tip would go and what it does there, nothing more.
//
// Where a tip goes is where our money already goes (see the money flow in shared/lp-agent.js): an x402 tip lands
// in the x402 wallet the paid services use and the DeFi agent's daily sweep takes it; BNB sent straight to the
// DeFi agent's wallet is picked up by its deposit watch. The sweep splits an x402 tip like any income — half to
// $BOBAI, half to the operator (since 14.10.); BNB at the DeFi wallet is capital, and a third of what its pool earns
// buys $BOBAI (the fees in thirds since 14.10.; this said "half" until 25.10.). ONE SOURCE: the worker at brainonbnb.com (REST + MCP) and
// the agent server at agent.brainonbnb.com both import this object; neither re-words it.

export const DEFI_WALLET = '0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A';
export const BOBAI_TOKEN = '0x245c386dcfed896f5c346107596141e5edcbffff';

export const THANKS = Object.freeze({
  note: 'Thank you for using BOBAI. This answer is free: no key, no account, no fee. If it helped you, a tip is welcome, entirely voluntary and never required. The answer is the same either way.',
  tip: {
    x402: 'https://agent.brainonbnb.com/tip?usd=1',
    x402_how: 'An x402 client tips in one step: that URL answers 402, the amount is yours to set with ?usd= (0.10 to 1000), paid in USDC or USD1 on BNB Smart Chain.',
    or_bnb_to: DEFI_WALLET,
    what_it_does: "An x402 tip is income like any payment to BOBAI's agents: half goes to $BOBAI (bought and held, part added to the $BOBAI pool with the LP burned), half to the operator. BNB sent to the DeFi agent's wallet becomes capital in its PancakeSwap pool, where a third of the fees buys $BOBAI the agent keeps.",
  },
  bobai: {
    token: BOBAI_TOKEN,
    what_it_is: 'The token of the project that runs these tools. Every trade pays 3% tax, split on-chain: BOBAI bought back and burned, liquidity added and burned, the DeFi agent and more.',
    pancakeswap: `https://pancakeswap.finance/swap?chain=bsc&outputCurrency=${BOBAI_TOKEN}`,
  },
  by: 'BOBAI · https://brainonbnb.com',
});

// The same in one line, for an HTTP header and for places where a JSON field does not fit.
export const THANKS_LINE = `Free to use. A voluntary tip is welcome, never required: x402 at https://agent.brainonbnb.com/tip or BNB to ${DEFI_WALLET}. brainonbnb.com`;

// Adds the note to an answer that is a plain JSON object; anything else (a bare number, a list, a string) is
// returned untouched, because callers parse those exactly as they are.
export function withThanks(out) {
  return out && typeof out === 'object' && !Array.isArray(out) ? { ...out, _thanks: THANKS } : out;
}

// ONLY THE FIRST TIME (operator, 2026-10-01: "whoever uses our code or asks one of our agents gets the note, but
// only once, the first time"). A caller is remembered by a hash of its IP (never the IP itself) in Cloudflare's
// cache for a year — free, no KV write. The cache lives per data center and may be cleared, so now and then a
// caller sees the note a second time; never the other way round: when the cache cannot answer, the note is given.
// Both workers use the same key, so the site's MCP/REST and the agent server count as one place.
// A caller who wants it again sends `X-BOBAI-Thanks: always` (our own smoke test does).
const SEEN_TTL = 365 * 24 * 3600;
export async function firstCall(request) {
  try {
    if (/^always$/i.test(request.headers.get('x-bobai-thanks') || '')) return true;
    const ip = request.headers.get('cf-connecting-ip') || '';
    if (!ip || typeof caches === 'undefined') return true;
    const d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('bobai-thanks:' + ip));
    const key = new Request('https://brainonbnb.com/__thanks-seen/' + [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, '0')).join(''));
    const cache = caches.default;
    if (await cache.match(key)) return false;
    await cache.put(key, new Response('1', { headers: { 'Cache-Control': `public, max-age=${SEEN_TTL}` } }));
    return true;
  } catch {
    return true;
  }
}