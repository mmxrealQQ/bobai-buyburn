// BOBAI AGENT SERVICE — the paid surface, and the numbers behind it.
//
// Two jobs, deliberately in one worker because they are the same story:
//
//   1. A pool watch that agents pay for. The free scanner answers "what does
//      this trade cost right now"; this answers "tell me when that changes",
//      which is the part that cannot be done client-side because somebody has
//      to still be running in an hour.
//
//   2. The counters behind the public transparency block: how often we were
//      asked, what we earned, where the money went. Kept here rather than in
//      the dashboard worker so that the thing being measured and the thing
//      doing the measuring are not the same process.
//
// PAYMENT MODEL
// x402, scheme "exact": the caller sends USD1 to our address and hands us the
// transaction hash; we read the chain and confirm it. We do NOT use eip3009
// here even though the Bazaar entries do, and the reason is gas: an eip3009
// authorization has to be submitted by the recipient, so we would be paying gas
// to collect payment, with no facilitator sponsoring it until a Binance partner
// account exists. Direct transfer costs us nothing and needs nobody's approval.
// When the partner account lands, eip3009 gets added alongside — the accepts[]
// array is built to carry both.
//
// The receiving wallet's private key is NOT here and must never be. Verifying a
// payment is a read; the worker never moves funds.

import { bindSelf } from './self-fetch.js';
import { v3BuyDepthUsd, readV3Pool } from './v3-depth.js';
import { isHolderProof, holderWalletOf, useHolderPass, holderPassTerms, HOLDER_PASS } from './holder-pass.js';
import { issueScanPass, checkScanPass, SCAN_PASS_PRICE_USD1, SCAN_PASS_HOURS, SCAN_PASS_CAP, SCAN_FREE_PER_DAY, SCAN_PASS_URL } from '../shared/scan-pass.js';
// The pass in one clause, where a price is written (2026-10-16): cards, the agents' MCP tools. It covers the x402 route.
const HOLDER_PRICE_NOTE = `or nothing for a wallet holding ${HOLDER_PASS.lineText} (holder pass over x402: a signature, no transaction — see holder_pass)`;
// On every card that takes an escrow job (2026-10-16): Pokter hired the DeFi
// Agent (job 57001) and read notify_funded on the hub card only, so it could
// not tell the agent the job was funded; the job watch found it 14 minutes
// later. A marketplace reads the card of the agent it lists.
const NOTIFY_FUNDED_SKILL = {
  id: 'notify_funded',
  name: 'Notify the seller a job is funded',
  description: 'Send {"skill":"notify_funded","job_id":<int>} once the job is funded and delivery starts at once. The seller reads the job from the chain rather than trusting the message. Optional: without it the job watch finds the funded job on the chain on its own, within 15 minutes.',
  tags: ['erc8183', 'delivery'],
  examples: ['{"skill":"notify_funded","job_id":57001}'],
};
// THE PLAZA BOARD ON EVERY CARD (2026-10-23): the meeting place for agents and platforms — bugs, fixes, tips, questions
const PLAZA_BOARD_SKILL = {
  id: 'plaza-board',
  name: 'Brain Board: bugs, fixes and help between agents',
  description: 'The public board where AI agents and agent platforms tell each other what is broken, how it was fixed and what works. Free. Read: {"skill":"plaza-board","action":"read","to":"<your agent id>","status":"open"} (your inbox) or with "q" to search everything said. Write: {"skill":"plaza-board","action":"post"|"reply"|"status", …, "ts", "signer", "signature"} — an EIP-191 signature over the message from {"skill":"plaza-board","action":"how"} or GET https://agent.brainonbnb.com/board/how. A platform without an agent id that proved its domain (POST https://agent.brainonbnb.com/board/platform) writes with "platform_key" instead of a signature. Page: https://brainonbnb.com/board',
  tags: ['plaza-board', 'bugs', 'fixes', 'help', 'agent-to-agent'],
  examples: ['{"skill":"plaza-board","action":"read","status":"open"}'],
};
// ANY WALLET'S ESCROW ON EVERY CARD (2026-10-23): what a seller or buyer on the ERC-8183 kernel most wants to know
const ESCROW_STATUS_SKILL = {
  id: 'escrow-status',
  name: 'ERC-8183 escrow status for any wallet',
  description: 'Every job a wallet sells or buys on the ERC-8183 escrow kernel on BNB Chain, with what happens next to each (waiting for delivery, in the dispute window, pay waiting release, money waiting refund), the totals, and what BOBAI\'s free public settle and refund did for it, with transactions. Free, read-only. Send {"skill":"escrow-status","address":"0x…"}; also GET https://agent.brainonbnb.com/escrow/for/<address>.',
  tags: ['erc8183', 'escrow', 'settle', 'refund'],
  examples: ['{"skill":"escrow-status","address":"0x73809F69916FcF7Ddc5BB1315fBdf96A569a5963"}'],
};
import { runCensusTick, runFrontierTick } from './census.js';
import { handleFind } from './find.js';
import { dexterAccepts, verifyAndSettle, parsePaymentHeader, v2Shape } from './x402.js';
import { eip3009Accepts, isEip3009, settleEip3009, U } from './x402-eip3009.js';
import { permit2Mismatch, settleCalldata, permit2Id, PERMIT2_PROXY, QUEUE_PREFIX } from '../shared/x402-permit2.js';
import { handleDispatch } from './dispatch.js';
import { readSessions, MAX_SESSIONS, trackRecord, sessionOrigins, originOf, ORIGIN_MARKED_SINCE } from './sessions.js';
import { runCanary } from './canary.js';
import { buildCatalog } from './x402-catalog.js';
import { handleHire, handleHireNotify, decodeJob, ERC8183 } from './hire.js';
import { OWN_WALLETS, isOwnWallet } from './own-wallets.js';
import { withThanks, THANKS_LINE, firstCall } from '../shared/thanks.js';
import { readPaid, claimPayment, settlePayment } from './ledger.js';
import { handleA2A, handleJobResult, SERVICES, exampleFor, doWork, extractParams, missingInput, AGENT_SERVICE, checkedFigures, onSale } from './sell.js';
import { gridPlan } from './grid.js';
import { rebalanceDefaultTarget } from './rebalance.js';
import { understand } from './understand.js';
import { handleBoard, PlazaBoard, writeEntry, BOARD_HOW } from './board.js';
export { PlazaBoard };
import { summarize } from '../shared/job-summary.js';
import { moneyFlow, flowLines, withArchive, ARCHIVE_KEY, capSeries, increaseIntoPosition } from '../shared/lp-flow.js';

// The DeFi agent's record with its archived runs merged back in (lp-flow.js):
// the shape every sum over the history expects. Readers that only want the
// newest run or the pool read the bare key.
async function readAgentRecord(env) {
  const raw = await env.AGENT.get('lp:agent');
  if (!raw) return null;
  const arch = JSON.parse((await env.AGENT.get(ARCHIVE_KEY)) || 'null');
  return withArchive(JSON.parse(raw), arch);
}
import { lpPositionLook, lpDefaultTarget, OWN_LP_WALLET } from './lp-service.js';
import { healthFactor } from './venus.js';
import { yieldPlan } from './yield.js';
import { secondOpinion, readOpinions, heldSession, SELLER, SUBJECT } from './second-opinion.js';
import { encodeFunctionData, keccak256, toBytes, getAddress } from 'viem';
import { agentWalletOf, AGENT_ID_OF } from './agent-wallets.js';
import { runVenusWork, readVenusLog, venusWorkDue } from './venus-work.js';
import { runAgentHires, readHires, agentHiresDue, HIRES, collectDeliveries, refundUndelivered } from './agent-hires.js';
import { runPublicSettle, readPublicSettle, publicSettleDue, CANDIDATES_KEY, FARMS_KEY } from './public-settle.js';
import { runPopChain, readPopChain, popChainDue } from './pop-chain.js';
import { runPublicRefund, readPublicRefund } from './public-refund.js';
import { runJobBoard, readJobBoard, seedJobBoard, jobBoardDue } from './job-board.js';
import { holdersTick, seedHolders, readHolders, holdersBackfill, readBackfill } from './holders.js';
// A card names the agentWallet the registry holds for that agent (2026-10-21: the two Venus agents get wallets of
// their own); the provider while the registry cannot be read, which is every agent's wallet until it moves.
const cardProvider = async (slug) => 'eip155:56:' + getAddress((await agentWalletOf(AGENT_ID_OF[slug])) || '0x73809F69916FcF7Ddc5BB1315fBdf96A569a5963');
import { REPUTATION, REPUTATION_ABI } from '../scripts/lib/erc8004-reputation.mjs';
import { SOLD_BY } from './catalog.js';
import { refreshTelemetry, readTelemetry } from './telemetry.js';
import { registrations, OWN_AGENT_IDS, TRUST_REGISTRIES, DEFI_AGENT_ID, AGENT_REGISTRY } from '../shared/agent-registrations.js';
// Each agent's card name equals its on-chain registration's name (scripts/lib/own-agents.mjs).
const OWN_CARDS = {
  'health-factor': { id: 302257, name: 'Brain on BNB — Venus Health Factor Monitor' },
  'grid-trader': { id: 302258, name: 'Brain on BNB — BSC Grid Planner' },
  'yield-optimizer': { id: 304493, name: 'Brain on BNB — Venus Yield Ranking' },
  rebalancer: { id: 304494, name: 'Brain on BNB — Portfolio Rebalance Pricer' },
  'lp-placement': { id: 310460, name: 'Brain on BNB — PancakeSwap Fee Tier Placement' },
};
import { watchFundedJobs } from './job-watch.js';
// KEPT LISTED ON MARQUE (2026-10-06). Marque lists an agent only while its endpoint answered a probe in the last 24 h,
// and it does not probe by itself: on 6.10. five of our six had dropped off its marketplace, and #363709's test had been
// sent to its web page (405). Every eight hours Marque is asked to call each agent's A2A card — Marque itself reads
// the card and sends message/send; nothing is signed, nothing is claimed that the agent does not answer. The last
// round is kept in KV marque:probe (and shown at /jobs/watch).
// taskConsent: true (2026-10-25, Marque's answer to our report: "a discovery-only request doesn't send a message"):
// without it every round read "message/send not validated" and counted against our availability (1 of 4 on 25.10.);
// with it all six read "callable — message/send validated" (checked by hand the same morning).
const MARQUE_PROBE = 'https://marque.trade/api/v1/builders/probe';
export const marqueProbeDue = (d) => d.getUTCHours() % 8 === 0 && d.getUTCMinutes() < 15;
export async function keepMarqueListed(env) {
  const all = { ...OWN_CARDS, 'defi-agent': { id: DEFI_AGENT_ID } };
  const out = {};
  let first = true;
  for (const [slug, a] of Object.entries(all)) {
    // Marque takes 6 probes a minute (it said so when two rounds met, 2026-10-06): one every 11 s stays under it
    if (!first) await new Promise((r) => setTimeout(r, 11000)); first = false;
    try {
      const r = await fetch(MARQUE_PROBE, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chainId: 56, tokenId: String(a.id), endpoint: `${SELF_ORIGIN}/${slug}/.well-known/agent-card.json`, taskConsent: true }) });
      const j = await r.json().catch(() => ({}));
      out[a.id] = { ok: j.ok === true, liveness: j.liveness || null, ms: j.latencyMs ?? null, detail: j.ok ? null : String(j.detail || r.status).slice(0, 160) };
    } catch (e) { out[a.id] = { ok: false, detail: String(e && e.message || e).slice(0, 160) }; }
  }
  await env.AGENT.put('marque:probe', JSON.stringify({ at: new Date().toISOString(), agents: out }));
  return out;
}
import { handleSession } from './session.js';
import { handleSessionRevoke, readRevocations, annotateRoles } from './session-revoke.js';
import { recordLpWindow, readLpWindows, noteLpWindowError, verdict as lpVerdict, measuredResetCost, calibration as lpCalibration, watchedPool, resetLosses, readLpTicks, widthVerdict, timeInRange as lpTimeInRange } from './lp-windows.js';
import { widthClassOf, HOME_POOL, pickWidth, FEE_SHARE_KEPT_PCT, MIN_SWEEP_BNB } from '../shared/lp-guards.js';
import { lpPortfolio } from './lp-portfolio.js';
import { tickOwnJobs, readOwnJobs, readSettled } from './own-jobs.js';
import { CAPABILITIES, WATCH_PRICE_USD1, WATCH_DAYS, fmtUsd1, offering } from './catalog.js';
// The free rug watch (2026-10-09): a token re-read every 15 minutes, a signed webhook when it turns dangerous.
import { handleRugWatch, runRugWatches, RUG_CRON } from './rug-watch.js';
import { runPulseTick, readPulse, rebuildPulseSummary } from './pulse.js';
import { agentChart, agentRank, screenerData } from './chart.js';
import { addAgentWatch, removeAgentWatch } from './agent-watch.js';
import { runListedLive, houseListing, checkAgent, quoteListing, verifySigner, submitListing, readListings, readListing, markAnnounced, runListingMonitor, profileHtml, LISTING_USD, PAYEE, postLog, readLog, logMessage } from './listing.js';

// The host our hireable agents name on-chain. Written out rather than derived
// from the incoming request: this exact string is in the registration of
// #302257 and #304493 and cannot be changed, so a card that reported some other
// origin — a preview deployment, a workers.dev hostname — would be describing
// an agent that does not exist.
const SELF_ORIGIN = 'https://agent.brainonbnb.com';
// one brief per service that its agent quotes as it stands (card examples; scripts/quote-examples-check.mjs signs each)
export const QUOTE_EXAMPLES = {
  // 29.10. (the promise check): 0xbFAA has no Venus position (a buyer would pay for 'no position'), and the answer gives the
  // drawdown that liquidates and a stress table, no repay figure; 0xEAC2 is our health-factor keeper's wallet, a real loan
  health_factor: 'Health factor of the Venus position of 0xEAC21928DE023677A25eb925D1cb1b0786FaF946, the collateral drawdown that would liquidate it and a stress table',
  grid_plan: 'Grid plan for WBNB/USDT (token 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c): 1000 USD capital, 10 levels',
  yield_plan: 'Best stablecoin yield on Venus for 1000 USDT',
  rebalance_plan: 'Rebalance my holdings to 50/50: [{"token":"0x55d398326f99059fF775485246999027B3197955","usd":600},{"token":"0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c","usd":400}]',
  lp_tier_plan: 'Which PancakeSwap fee tier is paying its liquidity providers best for CAKE (token 0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82)',
  // 2026-10-23: the DeFi agent's own skill had no example — 8004scan's A2A quality read 77 against 87 for the five
  lp_position_plan: 'Plan for PancakeSwap V3 position 7637521: is it in range, is a re-set due and in which width',
};

const RPCS = [
  'https://bsc.publicnode.com',
  'https://bsc-rpc.publicnode.com',
  'https://bsc-dataseed1.defibit.io',
  'https://bsc-mainnet.public.blastapi.io',
];
// Logs are a separate endpoint on purpose: Binance's own dataseed refuses
// eth_getLogs outright, and a payment that cannot be read is a payment we would
// wrongly reject.
const LOGS_RPC = 'https://bsc-rpc.publicnode.com';

// Receipts need their OWN list, and this is not a detail. Both publicnode
// endpoints answer eth_getTransactionReceipt with "Archive requests require..."
// — even for a transaction minutes old. Reading receipts off the logs endpoint,
// as this worker did at first, rejected a real 96 USD1 transfer as "transaction
// not found": harmless for security, fatal for a paying customer, and invisible
// unless you test with a transaction that actually exists. Ordered so the two
// endpoints measured to serve receipts come first.
const RECEIPT_RPCS = [
  'https://bsc-dataseed1.defibit.io',
  'https://bsc-mainnet.public.blastapi.io',
  'https://bsc-dataseed.binance.org',
];

// USD1. Chosen by measurement, not by preference: on BSC, USDT and USDC do NOT
// implement EIP-3009, while USD1 and U do — which is why 40 of the 44 payment
// options across the whole B402 catalogue are one of those two. Picking USDT
// would have produced a service nobody could pay for with the standard scheme.
const USD1 = '0x8d0d000ee44948fc98c9b98a4fa4921476f08b0d';
const USD1_DECIMALS = 18n;

const NETWORK = 'eip155:56';
// THE FIELDS x402 REQUIRES ON A DIRECT TRANSFER TOO (2026-10-25, operator's go): Marque read our 402 as "bad_schema";
// the direct-transfer options had no maxTimeoutSeconds (required in v2 and v1) and no mimeType (v1). A transfer is
// taken for a day of blocks (MAX_PAYMENT_AGE_BLOCKS, ~25 h); a day is said. Terms only — nothing checked differently.
const DIRECT_TERMS = { maxTimeoutSeconds: 86400, mimeType: 'application/json' };
const TRANSFER_TOPIC = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef';

// The project's own wallets. A payment from one of these is a test purchase
// we made ourselves, and /stats says so: on 2026-09-08 every payment on
// record (0.70 USD1 over three purchases) had come from our NFT relayer, and
// the total was being read as income from strangers. The list is the eight
// wallets with a key in this project plus the operator's two personal ones.
// The wallets that are ours live in own-wallets.js (the telemetry splits
// delivered jobs by them too).


// The watch price, its window and the USD1 formatter now live in catalog.js,
// beside the description of the thing being priced.

// ==================== THE PAGE SHELL ====================
// The four pages this worker serves to a browser (/job, /sessions, /lp/agent,
// /lp/windows) wear the same shell as every sub-page on brainonbnb.com: a
// fixed header with a way back, the page's name and one gold action, the
// site's own fonts (Inter, Space Grotesk — served by the dashboard, CORS
// open) and the aurora ground. Before 2026-09-05 each page carried its own
// pill nav and looked like a different site from the page that linked to it.
// The header rules mirror dashboard/styles.css (.nav, .back-btn, .brand-link,
// .nb) — change both together.
const SHELL_CSS = ':root{color-scheme:dark;--gold:#f0b90b;--gold2:#ffd54a;--bg:#0c0b0c;--text:#eceaf5;--muted:#a0a2c0;--border:rgba(198,143,118,.16)}'
  + '*{box-sizing:border-box}'
  // The frame every dashboard sub-page has (.sec in styles.css): from 86px
  // down, one bordered panel — the operator, 2026-09-08: the record pages
  // "must be framed like Brain Plaza". Pages that set main{max-width} keep
  // their narrower width inside the same frame.
  + 'main{position:relative;z-index:1;width:min(1100px,calc(100% - 34px));margin:86px auto 40px;padding:30px 26px 40px;border:1px solid rgba(240,185,11,.17);border-radius:28px;background:linear-gradient(180deg,rgba(240,185,11,.05),rgba(240,185,11,0) 42%);box-shadow:0 20px 60px -30px rgba(0,0,0,.7)}'
  + '@media(max-width:700px){main{padding:24px 16px 32px}}'
  + 'body{margin:0;color:var(--text);font:15px/1.6 Inter,system-ui,sans-serif;-webkit-font-smoothing:antialiased;background:radial-gradient(1200px 700px at 50% -6%,rgba(240,185,11,.13),transparent 66%),radial-gradient(900px 620px at 50% 40%,rgba(198,143,118,.06),transparent 70%),radial-gradient(700px 500px at 88% 78%,rgba(120,48,24,.07),transparent 72%),var(--bg);background-attachment:fixed}'
  + '.aur{position:fixed;inset:-25%;z-index:0;pointer-events:none;filter:blur(110px);opacity:.5}.aur i{position:absolute;display:block;border-radius:50%}'
  + '.aur .a1{width:48vw;height:48vw;left:-4%;top:-4%;background:rgba(240,185,11,.4);animation:drift1 34s ease-in-out infinite}'
  + '.aur .a2{width:40vw;height:40vw;right:-6%;top:20%;background:rgba(198,143,118,.3);animation:drift2 42s ease-in-out infinite}'
  + '.aur .a3{width:38vw;height:38vw;left:18%;bottom:-4%;background:rgba(120,48,24,.34);animation:drift3 38s ease-in-out infinite}'
  + '.aur .a4{width:26vw;height:26vw;right:22%;bottom:12%;background:rgba(34,211,238,.1);animation:drift2 48s ease-in-out infinite reverse}'
  + '@keyframes drift1{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(6vw,4vh) scale(1.12)}}'
  + '@keyframes drift2{0%,100%{transform:translate(0,0) scale(1.05)}50%{transform:translate(-5vw,6vh) scale(.94)}}'
  + '@keyframes drift3{0%,100%{transform:translate(0,0) scale(.96)}50%{transform:translate(4vw,-5vh) scale(1.1)}}'
  + '@media (prefers-reduced-motion:reduce){.aur .a1,.aur .a2,.aur .a3,.aur .a4{animation:none}}'
  + '.page{position:relative;z-index:1}'
  + 'nav{position:fixed;top:0;left:0;right:0;z-index:100;background:#0b0916;border-bottom:1px solid var(--border)}'
  + '.nav{position:relative;z-index:1;max-width:1100px;margin:0 auto;padding:0 24px;display:flex;align-items:center;justify-content:space-between;gap:12px;height:58px}'
  + '.back-btn{display:inline-flex;align-items:center;gap:6px;padding:6px 0;color:var(--gold);font-size:12px;font-weight:600;letter-spacing:.3px;white-space:nowrap;text-decoration:underline;text-decoration-color:rgba(240,185,11,.32);text-underline-offset:3px;text-decoration-thickness:1px;transition:transform .2s ease,text-decoration-color .2s}'
  + '.back-btn:hover{transform:translateX(-2px);text-decoration-color:var(--gold)}.back-btn span{font-size:14px;line-height:1}'
  + ".brand-link{font-family:'Space Grotesk',sans-serif;font-weight:700;font-size:14px;letter-spacing:.5px;color:var(--gold);white-space:nowrap;text-decoration:none}.brand-link:hover{opacity:.85}"
  + '.nb{background:linear-gradient(135deg,var(--gold),#e0a800);color:#000;padding:9px 24px;border-radius:999px;font-weight:700;font-size:.78rem;text-decoration:none;transition:all .25s;border:none;box-shadow:0 2px 20px rgba(240,185,11,.2);letter-spacing:.3px;white-space:nowrap}'
  + '.nb:hover{transform:translateY(-1px);box-shadow:0 4px 32px rgba(240,185,11,.35)}'
  + '@media (max-width:560px){.brand-link{font-size:12px;min-width:0;overflow:hidden;text-overflow:ellipsis}.nb{padding:7px 14px;font-size:.72rem}.nav{gap:8px;padding:0 14px}}'
  + 'main{margin:0 auto;padding:86px 18px 60px}'
  + "h1{font-family:'Space Grotesk',sans-serif;font-size:1.5rem;margin:0 0 4px;letter-spacing:-.3px}h2{font-family:'Space Grotesk',sans-serif;font-size:1rem;margin:26px 0 8px;color:var(--gold)}"
  + 'a{color:var(--gold)}code{font-size:.85em}'
  // The link system of the dashboard (dashboard/styles.css, THE LINK SYSTEM):
  // a change of page carries a right arrow, a way out of the site an up-right
  // arrow, a jump within the page none — the same marks on these pages.
  + ':is(p,li,dd,td,th,figcaption,small,.note) > a:not(.nb):not(.back-btn):not(.brand-link):not(.no-mark):not(:has(img)){color:var(--gold);text-decoration:underline;text-decoration-color:rgba(240,185,11,.32);text-underline-offset:3px;text-decoration-thickness:1px}'
  + ':is(p,li,dd,td,th,figcaption,small,.note) > a:not(.nb):not(.back-btn):not(.brand-link):not(.no-mark):not(:has(img)):hover{text-decoration-color:var(--gold)}'
  + ':is(p,li,dd,td,th,figcaption,small,.note) > a:not([href^="#"]):not([href^="mailto:"]):not(.nb):not(.back-btn):not(.brand-link):not(.no-mark):not(:has(img))::after{content:"";display:inline-block;width:.62em;height:.62em;margin-left:.3em;vertical-align:-.02em;background:currentColor;opacity:.75;-webkit-mask:url(data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2012%2012%27%3E%3Cpath%20d%3D%27M1.5%206h8.2M6.3%202.6%209.7%206l-3.4%203.4%27%20fill%3D%27none%27%20stroke%3D%27%23000%27%20stroke-width%3D%271.7%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E) center/contain no-repeat;mask:url(data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2012%2012%27%3E%3Cpath%20d%3D%27M1.5%206h8.2M6.3%202.6%209.7%206l-3.4%203.4%27%20fill%3D%27none%27%20stroke%3D%27%23000%27%20stroke-width%3D%271.7%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E) center/contain no-repeat}'
  + ':is(p,li,dd,td,th,figcaption,small,.note) > a[target="_blank"]:not(.nb):not(.back-btn):not(.brand-link):not(.no-mark):not(:has(img))::after{-webkit-mask-image:url(data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2012%2012%27%3E%3Cpath%20d%3D%27M3%209l6-6M4.2%203H9v4.8%27%20fill%3D%27none%27%20stroke%3D%27%23000%27%20stroke-width%3D%271.7%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E);mask-image:url(data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2012%2012%27%3E%3Cpath%20d%3D%27M3%209l6-6M4.2%203H9v4.8%27%20fill%3D%27none%27%20stroke%3D%27%23000%27%20stroke-width%3D%271.7%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E)}';

// The head of a page: title, icon, the site's fonts, the shell rules, then the
// page's own. Opens the ground and the .page layer; pageTail closes them.
const pageHead = (title, css) => '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">\n'
  + '<title>' + title + '</title><link rel="icon" href="https://brainonbnb.com/favicon.png"><link rel="stylesheet" href="https://brainonbnb.com/fonts.css?v=1">\n'
  + '<style>' + SHELL_CSS + '\n' + css + '\n</style></head><body><div class="aur" aria-hidden="true"><i class="a1"></i><i class="a2"></i><i class="a3"></i><i class="a4"></i></div><div class="page">\n';
// The header: a way back, the page's name, one action — the same three
// things, in the same three places, as on every sub-page of the dashboard.
const pageNav = (back, name, action) => '<nav><div class="nav"><a class="back-btn" href="' + back.href + '" title="Back to ' + back.label + '"><span>&larr;</span> ' + back.label + '</a>'
  + '<a class="brand-link" href="' + name.href + '">' + name.label + '</a>'
  + '<a class="nb" href="' + action.href + '"' + (action.external ? ' target="_blank" rel="noopener"' : '') + '>' + action.label + '</a></div></nav>\n<main>\n';
const pageTail = '</main></div></body></html>';
const BUY = { href: 'https://pancakeswap.finance/swap?outputCurrency=0x245c386dcfed896f5c346107596141e5edcbffff&chain=bsc', label: 'Buy $BOBAI', external: true };
const SITE = 'https://brainonbnb.com';

// A KV list answers a thousand keys and a cursor. Every total on /stats, the
// earnings record and the watch sweep read ONE page: at a thousand keys the
// totals stop growing, earnings go missing and paid watches stop being
// checked — in silence (2026-09-18: 218 count: keys after a month, so about
// January). Every page is read; the shape is the one list() returns.
async function listAll(env, prefix) {
  const keys = [];
  let cursor = null;
  do {
    const page = await env.AGENT.list({ prefix, limit: 1000, ...(cursor ? { cursor } : {}) });
    keys.push(...page.keys);
    cursor = page.list_complete ? null : page.cursor;
  } while (cursor);
  return { keys, list_complete: true };
}
// A free answer to a caller from outside carries the thank-you note (shared/thanks.js, 2026-09-26): free, a tip
// welcome, never required. The site's own pages, which read some of these routes for their figures, get none.
const fromOurSite = (request) => /^https:\/\/(www\.)?brainonbnb\.com(\/|$)/.test(request.headers.get('origin') || request.headers.get('referer') || '');
// The shape of a payment proof, never the proof (2026-10-25): which form it came in, the x402 version, scheme, network
// and payload kind — enough to tell what a payer's client sent, nothing that could be replayed.
function proofShape(proof) {
  const p = String(proof || '').trim();
  if (/^0x[0-9a-fA-F]{64}$/.test(p)) return 'tx hash';
  if (/^bobai-holder /.test(p)) return 'holder pass';
  try {
    const j = JSON.parse(atob(p.replace(/-/g, '+').replace(/_/g, '/')));
    const pl = j.payload || {}, acc = j.accepted || {};
    const kind = pl.permit2Authorization ? 'permit2' : pl.authorization ? 'eip3009' : pl.txHash || pl.transaction ? 'tx' : Object.keys(pl).slice(0, 3).join('+') || 'no payload';
    return ['x402 v' + (j.x402Version ?? '?'), j.scheme || acc.scheme, j.network || acc.network, kind].filter(Boolean).join(' · ');
  } catch { return `unreadable (${p.length} chars)`; }
}
// the wallet a signed payment names as its payer — public, on chain once it settles (2026-10-25: the first refused
// payment kept, 'transfer amount exceeds balance', did not say whose balance)
function payerOf(proof) {
  try {
    const pl = JSON.parse(atob(String(proof || '').trim().replace(/-/g, '+').replace(/_/g, '/'))).payload || {};
    const a = String(pl.authorization?.from || pl.permit2Authorization?.from || '');
    return /^0x[0-9a-fA-F]{40}$/.test(a) ? a.toLowerCase() : null;
  } catch { return null; }
}
// only on a caller's first free answer (firstCall, 2026-10-01)
const thankJson = async (request, obj, status = 200, extra = {}) => status === 200 && !fromOurSite(request) && await firstCall(request)
  ? json(withThanks(obj), status, { ...extra, 'X-Thanks': THANKS_LINE, 'Access-Control-Expose-Headers': 'X-Thanks' })
  : json(obj, status, extra);
// ASKED AGAIN, NOT SENT AGAIN (2026-10-06): the terminal asks for the DeFi agent's record every 45 s on every visitor's
// page — 424 KB (54 KB compressed) each time, while the record changes about once an hour. With an ETag the same record
// answers 304 and no body; the answer is as fresh as before (no-cache: the browser always asks). A weak tag, because the
// edge compresses the body and keeps only a weak one.
export async function etagJson(request, obj) {
  const body = JSON.stringify(obj, null, 2);
  const d = new Uint8Array(await crypto.subtle.digest('SHA-1', new TextEncoder().encode(body)));
  const tag = 'W/"' + [...d].map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 32) + '"';
  const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-cache', ETag: tag, 'Access-Control-Expose-Headers': 'ETag' };
  const asked = (request.headers.get('if-none-match') || '').split(',').map((t) => t.trim());
  if (asked.includes(tag) || asked.includes(tag.slice(2))) return new Response(null, { status: 304, headers });
  return new Response(body, { status: 200, headers });
}
const json = (obj, status = 200, extra = {}) =>
  new Response(JSON.stringify(obj, null, 2), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 'no-store',
      ...extra,
    },
  });

// btoa() only handles Latin-1. The moment a description contained an em dash
// the whole /watch endpoint returned 500 — the payload was fine, the encoder
// was not. Encoding to UTF-8 bytes first makes any character safe, which
// matters because these strings are human-readable copy that will keep
// acquiring punctuation.
const b64 = (obj) => {
  const bytes = new TextEncoder().encode(JSON.stringify(obj));
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
};
export { b64 as headerB64 };   // held by scripts/x402-header-check.mjs (2026-10-27)

const rpc = async (method, params, endpoints) => {
  const list = endpoints ? (Array.isArray(endpoints) ? endpoints : [endpoints]) : RPCS;
  let last;
  for (const endpoint of list) {
    try {
      const r = await fetch(endpoint, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
        signal: AbortSignal.timeout(8000),
      });
      const j = await r.json();
      if (j.error) { last = new Error(j.error.message); continue; }
      return j.result;
    } catch (e) { last = e; }
  }
  throw last || new Error('all RPC endpoints failed');
};

// A READ ASKED OF THE NODES STAGGERED, NOT IN TURN (2026-11-16, Liste B: every unpaid /answer took 3.1 or 6.1 s, the
// $BOBAI quote's reads waiting on a node that hung from this worker before the next was asked; MANDATE logged "HTTP 402
// in 3109 ms"): the first node at once, the next 400 ms later if none has answered, and so on — the first good answer
// counts. For read-only calls (prices, reserves); a payment's receipt keeps its own list and order.
// THE QUICK READS ASK THE QUICK NODES FIRST (2026-11-17): measured from Cloudflare's edge, publicnode answered 15 ms or
// held the request 3.0 s and then said 429 "Rate limit"; defibit and Binance's dataseed answered in 30-120 ms every time.
// And a Worker keeps at most six connections open per request: four races that each opened publicnode first, then the
// next node 400 ms later, queued their second wave behind the hung four — an unpaid /answer still took 3.1 s.
const QUICK_RPCS = ['https://bsc-dataseed1.defibit.io', 'https://bsc-dataseed.bnbchain.org', 'https://bsc-mainnet.public.blastapi.io', 'https://bsc-rpc.publicnode.com', 'https://bsc.publicnode.com'];
const rpcRace = (method, params, list = QUICK_RPCS, stagger = 400) => new Promise((resolve, reject) => {
  let left = list.length, done = false, lastErr = null;
  list.forEach((endpoint, i) => setTimeout(async () => {
    if (done) { left--; return; }
    try { const r = await rpc(method, params, [endpoint]); if (!done) { done = true; resolve(r); } }
    catch (e) { lastErr = e; }
    finally { if (--left === 0 && !done) reject(lastErr || new Error('all RPC endpoints failed')); }
  }, i * stagger));
});
const callQuick = (to, data) => rpcRace('eth_call', [{ to, data }, 'latest']);
export { rpcRace, QUICK_RPCS };   // held by scripts/x402-quote-speed-regressions.mjs (2026-11-16)

const hexToBig = (h) => (h && h !== '0x' ? BigInt(h) : 0n);
const addrFromTopic = (t) => '0x' + String(t).slice(26).toLowerCase();

// ---------------------------------------------------------------- counters

// Counters are bucketed by day and the totals derived on read, which also
// gives the transparency block a time series for free.
//
// COALESCED, 2026-09-09. Until then every counted event was one KV read and
// one KV write, and Cloudflare's KV analytics showed what that meant: 31,000
// writes in ten hours to this namespace, one per request to this worker
// (most of them the dashboard's /hit relay), 53,000 the day before — against
// the 1M a month the plan includes — while the read-modify-write raced with
// itself under that load and the counters showed a fifth of the traffic.
// Now an isolate adds up in memory and writes each kind once per FLUSH_MS
// (the cron flushes quiet isolates too). What an evicted isolate had not
// flushed is lost: a few minutes of a transparency counter, never money.
const today = () => new Date().toISOString().slice(0, 10);
const FLUSH_MS = 5 * 60 * 1000;
const pending = new Map();
let lastFlush = 0, flushing = null;

// The paid events are written at once (2026-10-05): they come a few a week, so
// an evicted isolate lost them outright and /stats showed 3 answers sold next
// to 5 answer payments in the ledger. One write each costs nothing at that rate.
// Every call site hands bump() to ctx.waitUntil, so the write outlives the reply.
const FLUSH_AT_ONCE = new Set(['answer_sold', 'tip', 'watch_created']);

async function bump(env, kind, n = 1) {
  const key = `count:${kind}:${today()}`;
  pending.set(key, (pending.get(key) || 0) + n);
  if (FLUSH_AT_ONCE.has(kind)) {
    // A flush already running took its snapshot before this key; wait for it, then write.
    if (flushing) await flushing.catch(() => {});
    return flushCounters(env);
  }
  if (Date.now() - lastFlush < FLUSH_MS) return;
  return flushCounters(env);
}

async function flushCounters(env) {
  if (flushing) return flushing;
  if (!pending.size && !detailDirty.size) return;
  lastFlush = Date.now();
  flushing = (async () => {
    for (const [key, n] of [...pending]) {
      pending.delete(key);
      const cur = Number((await env.AGENT.get(key)) || 0);
      await env.AGENT.put(key, String(cur + n), { expirationTtl: 60 * 60 * 24 * 400 });
    }
    await flushDetail(env);
  })().finally(() => { flushing = null; });
  return flushing;
}

// WHAT WAS ASKED FOR, not only how often (2026-09-20). The counters above say
// "1,600 MCP requests a day" and cannot say whether that is one registry
// pinging tools/list or agents calling bsc_pool_scan — and a service cannot be
// built toward a demand nobody has looked at. This keeps, per day, how often
// each named thing was asked for: an MCP method and tool, an /api/ route (the
// site's own pages apart from callers from outside), a step of the paid path.
// A name is a tool, a route, a client's software name or a coarse user-agent
// family — never an address, an argument, an IP or a wallet.
//
// ONE KEY PER ISOLATE AND DAY, written whole. The counters above read, add and
// write one shared key, and KV answers a read from another colo up to a minute
// late, so two isolates lose each other's increments. Here an isolate only
// ever writes its own key (detail:<day>:<isolate>), so nothing is read before
// a write and nothing can be lost to a race; the reader adds the keys up. It
// costs one KV write per flush, whatever the number of names.
// These names never enter count:* — /stats and its public total are untouched.
const ISOLATE = Math.random().toString(36).slice(2, 10);
const DETAIL_MAX_NAMES = 300; // per isolate and day; a caller can invent names
const detail = new Map(); // day -> { name: n }, this isolate's whole day
const detailDirty = new Set();
const cleanDetail = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9_:./-]/g, '').slice(0, 64);

function bumpDetail(env, names, n = 1) {
  const day = today();
  let m = detail.get(day);
  if (!m) { m = {}; detail.set(day, m); for (const d of detail.keys()) if (d !== day && !detailDirty.has(d)) detail.delete(d); }
  for (const raw of [].concat(names || []).slice(0, 4)) {
    let name = cleanDetail(raw);
    if (!name) continue;
    if (!(name in m) && Object.keys(m).length >= DETAIL_MAX_NAMES) name = 'other';
    m[name] = (m[name] || 0) + n;
  }
  detailDirty.add(day);
  // The pool-scan line and its day pass are written at once (2026-10-19): on 19.10. a trading bot's 49 refused scans
  // were all counted and its 50 free ones of 00 UTC not one — they sat in an isolate that took no further hit before
  // it was evicted. Some 500 a day; one KV write each.
  // A payment too (2026-10-20): /buys showed 8 paid answers on 19.10., /stats/detail 3 — a few a day.
  if ([].concat(names || []).some((raw) => /^(poolscan|sell:scanpass)|(^|:)paid:/.test(cleanDetail(raw)))) {
    return (flushing ? flushing.catch(() => {}) : Promise.resolve()).then(() => flushCounters(env)).catch(() => {});
  }
  if (Date.now() - lastFlush < FLUSH_MS) return;
  return flushCounters(env);
}

async function flushDetail(env) {
  for (const day of [...detailDirty]) {
    detailDirty.delete(day);
    // `at` in the metadata lets the rollup tell a finished isolate from a live one without reading the value.
    await env.AGENT.put(`detail:${day}:${ISOLATE}`, JSON.stringify(detail.get(day) || {}), { expirationTtl: 60 * 60 * 24 * 90, metadata: { at: Date.now() } });
  }
}

// THE DAY ROLLED UP (2026-10-04). A busy day runs on thousands of isolates —
// 7,059 on 4.10. — and the reader used to add up only the first 800 keys, so
// /stats/detail showed about a ninth of the day under "truncated: true", at
// 800 KV reads per call. Now the cron folds every isolate that has not written
// for ROLL_AFTER into one document (detailsum:<day>: the summed names and the
// ids already folded in), at most ROLL_READS keys per tick to stay inside an
// invocation's limits; the reader adds only the isolates still live. An
// isolate that wakes again after being folded loses its later increments — a
// small undercount, never a double count.
const ROLL_AFTER = 30 * 60 * 1000;
const ROLL_READS = 300; // shares the invocation's operation budget with the census and the watcher
async function rollupDetail(env, day) {
  const key = `detailsum:${day}`;
  const doc = JSON.parse((await env.AGENT.get(key)) || '{"names":{},"rolled":{}}');
  const list = await listAll(env, `detail:${day}:`);
  const now = Date.now();
  const stale = list.keys.filter((k) => !doc.rolled[k.name.slice(day.length + 8)] && (!k.metadata?.at || now - k.metadata.at > ROLL_AFTER)).slice(0, ROLL_READS);
  if (!stale.length) return { day, folded: 0, live: list.keys.length - Object.keys(doc.rolled).length };
  for (let i = 0; i < stale.length; i += 50) {
    const part = stale.slice(i, i + 50);
    const values = await Promise.all(part.map((k) => env.AGENT.get(k.name)));
    part.forEach((k, j) => {
      let m; try { m = JSON.parse(values[j] || '{}'); } catch { m = {}; }
      for (const [name, n] of Object.entries(m)) doc.names[name] = (doc.names[name] || 0) + Number(n || 0);
      doc.rolled[k.name.slice(day.length + 8)] = 1;
    });
  }
  await env.AGENT.put(key, JSON.stringify(doc), { expirationTtl: 60 * 60 * 24 * 90 });
  return { day, folded: stale.length, live: list.keys.length - Object.keys(doc.rolled).length };
}

// One day added up: the rolled-up sum plus the isolates not folded in yet. If
// those are more than one request may read, it says so (truncated) instead of
// passing a part off as the whole.
async function readDetail(env, day) {
  const doc = JSON.parse((await env.AGENT.get(`detailsum:${day}`)) || '{"names":{},"rolled":{}}');
  const list = await listAll(env, `detail:${day}:`);
  const live = list.keys.filter((k) => !doc.rolled[k.name.slice(day.length + 8)]);
  const keys = live.slice(0, 800);
  const values = await Promise.all(keys.map((k) => env.AGENT.get(k.name)));
  const sum = { ...doc.names };
  for (const v of values) {
    let m; try { m = JSON.parse(v || '{}'); } catch { m = {}; }
    for (const [name, n] of Object.entries(m)) sum[name] = (sum[name] || 0) + Number(n || 0);
  }
  return { day, isolates: list.keys.length, rolled_up: Object.keys(doc.rolled).length, truncated: live.length > keys.length, names: sum };
}

async function readCounters(env) {
  const list = await listAll(env, 'count:');
  const byKind = {};
  const byDay = {};
  // All keys at once: 175 reads in a row took 6 s cold on 2026-09-12, and
  // /stats and the /services floor waited on every one of them.
  const values = await Promise.all(list.keys.map((k) => env.AGENT.get(k.name)));
  list.keys.forEach((k, i) => {
    const [, kind, day] = k.name.split(':');
    const v = Number(values[i] || 0);
    byKind[kind] = (byKind[kind] || 0) + v;
    byDay[day] = byDay[day] || {};
    byDay[day][kind] = v;
  });
  return { byKind, byDay };
}

// ---------------------------------------------------------------- payment

// Confirms that a specific transaction really moved at least `min` USD1 into
// our address, and that we have not already honoured it.
//
// Every one of these checks earns its place. Without the receipt status a
// reverted transfer counts as payment. Without the token check any worthless
// token sent to the same address counts. Without the recipient check somebody
// pastes a transfer between two strangers. Without the KV guard one payment
// buys unlimited watches.
// `asset` is the token whose transfer counts (USD1 by default); `label` is how
// its amount is written back to the payer. Since 2026-09-03 an answer can
// also be paid in $BOBAI — the token this whole loop exists to burn.
// The payment ledger (claimed -> delivered | credit) lives in ledger.js, where
// scripts/payment-ledger-check.mjs can run it against a table.
// A day of blocks on BSC (0.45 s a block). A receipt older than that is not a
// payment for this request — it is somebody's old transfer to this wallet,
// found on the explorer. A credit (a failed answer) is exempt: that buyer paid.
const MAX_PAYMENT_AGE_BLOCKS = 200000;

async function verifyPayment(env, txHash, payTo, min, asset = USD1, label = 'USD1') {
  if (!/^0x[a-fA-F0-9]{64}$/.test(txHash || '')) return { ok: false, reason: 'malformed transaction hash' };

  const spent = await readPaid(env, txHash.toLowerCase());
  if (spent && spent.state === 'delivered') return { ok: false, reason: 'this payment has already been used' };

  const receipt = await rpc('eth_getTransactionReceipt', [txHash], RECEIPT_RPCS).catch(() => null);
  if (!receipt) return { ok: false, reason: 'transaction not found — if it was just sent, wait for it to confirm' };
  if (receipt.status !== '0x1') return { ok: false, reason: 'that transaction failed on-chain' };

  const { paid, payer } = transferredIn(receipt, asset, payTo);
  if (paid < min)
    return {
      ok: false,
      reason: `paid ${fmtUsd1(paid)} ${label}, need ${fmtUsd1(min)} ${label}`,
      paid,
    };

  // Last, so that a transfer to somebody else, or too small a one, is told
  // what is wrong with it rather than how old it is.
  if (!(spent && spent.state === 'credit')) {
    const head = await rpc('eth_blockNumber', [], RECEIPT_RPCS).catch(() => null);
    if (head && parseInt(head, 16) - parseInt(receipt.blockNumber, 16) > MAX_PAYMENT_AGE_BLOCKS) return { ok: false, reason: 'that payment is more than a day old — a payment is made for the request it buys' };
  }
  return { ok: true, paid, asset: asset.toLowerCase(), from: payer || (receipt.from || '').toLowerCase(), block: receipt.blockNumber };
}

// What a receipt moved to payTo in this coin, and who it came from. The payer is the sender of the transfer, not of the
// transaction (2026-10-19): an EIP-3009 payment is sent on chain by our own provider wallet, so receipt.from named
// 0x7380 for every one of Mandate's paid calls and /buys filed them as our own tests (from_strangers 0).
export function transferredIn(receipt, asset, payTo) {
  let paid = 0n, payer = null;
  for (const log of receipt.logs || []) {
    if ((log.address || '').toLowerCase() !== asset.toLowerCase()) continue;
    if ((log.topics || [])[0] !== TRANSFER_TOPIC) continue;
    if (addrFromTopic(log.topics[2]) !== payTo.toLowerCase()) continue;
    paid += hexToBig(log.data);
    payer = payer || addrFromTopic(log.topics[1]);
  }
  return { paid, payer };
}

// $BOBAI as a second coin for the per-answer sale. The amount is the answer's
// dollar price in $BOBAI at the moment of the 402, read from the pair's own
// reserves and the BNB reference pair — the same on-chain arithmetic every
// page of this project prices $BOBAI with — with a tenth of slack so a price
// that moved between the quote and the block still clears. $BOBAI paid here
// sits in the income wallet as $BOBAI: off the market, until the liquidity
// agent's sweep learns the token. Said on the 402, not implied.
const BOBAI = '0x245c386dcfed896f5c346107596141e5edcbffff';
export const BOBAI_SHARE = 0.5; // an answer paid in $BOBAI costs half its USD1 price (2026-10-14)
const BOBAI_PAIR = '0x6eadd4cb786898b34929444988380ed0cc6fd9a6';
const BOBAI_PAIR_TOKEN0 = '0x245c386dcfed896f5c346107596141e5edcbffff'; // token0() of BOBAI_PAIR, immutable
// THE INPUT AS AN AGENT NATURALLY SENDS IT (2026-10-13): the documented body is {"params":{…}}, but {"token":"0x…"}
// on its own came back "grid_plan needs `token`" with the token right there. Fields beside task/inputs/params count
// too; params and inputs still win where both name one.
function bareFields(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return {};
  const { task, inputs, params, ...rest } = body;
  return Object.fromEntries(Object.entries(rest).filter(([, v]) => v == null || ['string', 'number', 'boolean'].includes(typeof v)));
}

// THE PRICE KEPT HALF A MINUTE (2026-11-16, Liste B): every 402 read the two pairs again. A quote at most 30 s old is
// well inside the tenth of slack the payment already allows for a price that moves; quoted_at says when it was read.
let BOBAI_QUOTE = null; // { at, usdPerBobai }
export const QUOTE_KEEP_MS = 30000;
export async function usdPerBobaiNow() {   // exported for scripts/x402-quote-speed-regressions.mjs
  if (BOBAI_QUOTE && Date.now() - BOBAI_QUOTE.at < QUOTE_KEEP_MS) return BOBAI_QUOTE;
  // token0 is fixed when a V2 pair is created: $BOBAI is token0 of BOBAI_PAIR (read 2026-11-17), so two reads, not four
  const [res, price] = await Promise.all([callQuick(BOBAI_PAIR, SEL.getReserves), bnbUsd()]);
  const b = res.slice(2);
  const r0 = Number(BigInt('0x' + b.slice(0, 64))) / 1e18, r1 = Number(BigInt('0x' + b.slice(64, 128))) / 1e18;
  const bnbPerBobai = BOBAI_PAIR_TOKEN0 === BOBAI ? r1 / r0 : r0 / r1;
  const usdPerBobai = bnbPerBobai * price;
  if (!(usdPerBobai > 0)) throw new Error('could not price $BOBAI');
  BOBAI_QUOTE = { at: Date.now(), usdPerBobai };
  return BOBAI_QUOTE;
}
async function bobaiForUsd(usd) {
  const q = await usdPerBobaiNow(), usdPerBobai = q.usdPerBobai;
  // `tokens` is what to SEND (the full price, rounded up); `atomic` is the
  // least that must ARRIVE — a tenth less, which covers the token's own 3 %
  // transfer tax and a price that moved between the quote and the block.
  // The first draft slacked both and told the payer to send the slacked
  // amount, which after the tax would have arrived short and been refused.
  const tokens = Math.ceil(usd / usdPerBobai);
  // in integers (2026-10-13): tokens * 0.9 * 1e18 in floating point read 360900000000000065536 for 360.9 $BOBAI
  return { atomic: BigInt(tokens) * 9n * 10n ** 17n, tokens, usd_per_bobai: usdPerBobai, quoted_at: new Date(q.at).toISOString() };
}


// ------------------------------------------------------------ pool reading

const SEL = {
  getReserves: '0x0902f1ac',
  token0: '0x0dfe1681',
  balanceOf: '0x70a08231',
  decimals: '0x313ce567',
  symbol: '0x95d89b41',
};

const call = (to, data) => rpc('eth_call', [{ to, data }, 'latest']);
const padAddr = (a) => a.toLowerCase().replace('0x', '').padStart(64, '0');

// getJob(uint256) — the one ERC-8183 read this worker makes directly. Selector
// from the kernel ABI in @altananetwork/sdk, verified against viem by
// scripts/erc8183-encoding-check.mjs along with everything hire.js encodes.
const JOB_CALL = (id) => '0xbf22c457' + BigInt(id).toString(16).padStart(64, '0');

// Depth of a V2 pair in USD, read from the quote side only. One-sided on
// purpose: it is the number that decides what a sell can actually get out, and
// it needs no price oracle beyond the quote token itself.
async function poolDepthUsd(pair, quoteToken, quoteUsd) {
  const bal = await call(quoteToken, SEL.balanceOf + padAddr(pair));
  const raw = hexToBig(bal);
  return Number(raw) / 1e18 * quoteUsd;
}

// BNB price from the reference pair, the same source the rest of the project
// uses so that one number does not disagree with itself across surfaces.
const BNB_PAIR = '0x58f876857a02d6762e0101bb5c46a8c1ed44dc16';
const WBNB = '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c';
const BNB_PAIR_TOKEN0 = WBNB; // token0() of BNB_PAIR (WBNB/USDT), immutable — read 2026-11-17
async function bnbUsd() {
  const res = await callQuick(BNB_PAIR, SEL.getReserves);
  const b = res.slice(2);
  const r0 = Number(BigInt('0x' + b.slice(0, 64))) / 1e18;
  const r1 = Number(BigInt('0x' + b.slice(64, 128))) / 1e18;
  return BNB_PAIR_TOKEN0 === WBNB ? r1 / r0 : r0 / r1;
}

// ---------------------------------------------------------------- watches

// The quote tokens a watch can price: BNB from the reference pair, the dollar
// stablecoins at one dollar, all of them 18 decimals on BSC. Any other quote
// was priced at $1 with 18 decimals whatever it was (2026-09-18).
const WATCH_QUOTES = new Set([WBNB, '0x55d398326f99059ff775485246999027b3197955', '0xe9e7cea3dedca5984780bafc599bd69add087d56', '0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d', '0x8d0d000ee44948fc98c9b98a4fa4921476f08b0d']);
// WHAT IS SOLD IS WHAT IS MEASURED (2026-09-18). The watch is described, on the
// 402 and in the catalogue, as firing "when the pool can no longer absorb this
// USD size at 1% impact". The sweep compared the threshold with the pair's whole
// quote-side reserve — about two hundred times that figure: depthBelowUsd 1000
// fired when the RESERVE fell under $1,000, long after a $1,000 trade had
// stopped fitting. On a constant-product pair the quote that moves the price
// by 1% is reserve x (sqrt(1.01) - 1), 0.4988% of it.
const ONE_PCT_OF_RESERVE = Math.sqrt(1.01) - 1;
// THE SPEC, READ BEFORE ANY MONEY MOVES (2026-09-24, A7 step 1). The 402's
// own example had no pair, and the paid call required one: a trader who
// followed it was refused after paying for nothing — the order was right
// (400 before the charge), the example led there. And quote, callback and
// threshold were only checked inside createWatch, after the payment, so a
// typo in the callback cost a credit round trip. Now: pair is optional —
// the token's PancakeSwap V2 pair with the quote (WBNB by default) is looked
// up at the V2 factory — and a pair that is given must answer getReserves,
// i.e. be a V2 pair (the watch reads reserves; a V3 pool would read nothing),
// holding this token. Every refusal comes before the payment.
const V2_FACTORY = '0xca143ce32fe78f1f7019d7d551a6402fc5350c73';
const addrArg32 = (a) => String(a).toLowerCase().replace(/^0x/, '').padStart(64, '0');
async function resolveWatchSpec(spec) {
  const out = { ...(spec || {}) };
  if (!/^0x[a-fA-F0-9]{40}$/.test(out.token || '')) return { error: 'token must be a BSC address (0x…)' };
  const quote = String(out.quote || WBNB).toLowerCase();
  if (!WATCH_QUOTES.has(quote)) return { error: 'this watch prices pools quoted in BNB, USDT, BUSD, USDC or USD1 — name one of those as quote, or leave it out for BNB' };
  if (out.callback != null && !/^https:\/\/[^\s]{4,400}$/.test(String(out.callback))) return { error: 'callback must be an https:// URL' };
  if (out.depthBelowUsd != null && !(Number(out.depthBelowUsd) > 0)) return { error: 'depthBelowUsd must be a positive number of dollars' };
  const token = out.token.toLowerCase();
  let pair = out.pair ? String(out.pair).toLowerCase() : null;
  if (pair && !/^0x[a-f0-9]{40}$/.test(pair)) return { error: 'pair must be a BSC address (0x…), or left out to be found from the token' };
  if (!pair) {
    const got = await call(V2_FACTORY, '0xe6a43905' + addrArg32(token) + addrArg32(quote)).catch(() => null);
    const found = got && got.length >= 66 ? '0x' + got.slice(-40).toLowerCase() : null;
    if (!found || /^0x0{40}$/.test(found)) return { error: 'this token has no PancakeSwap V2 pair with that quote — the watch reads V2 reserves; name a V2 pair, or another quote' };
    pair = found; out.pair_found = true;
  }
  const res = await call(pair, SEL.getReserves).catch(() => null);
  // A PancakeSwap V3 pool is watched too (2026-10-16): its 1% depth is asked of the quoter (v3-depth.js), the
  // same measure the pool scan reports, so the scan can offer the watch on the V3 pool it read.
  if (!res || res.length < 2 + 64 * 2) {
    const v3 = await readV3Pool(RPCS, pair, token, quote);
    if (v3.error === 'not a PancakeSwap V3 pool') return { error: 'that pool answers neither as a PancakeSwap V2 pair nor as a PancakeSwap V3 pool — the watch reads those two; an Infinity pool or another venue cannot be watched' };
    if (v3.error) return { error: v3.error };
    return { spec: { ...out, token, pair, quote, kind: 'v3', fee: v3.fee } };
  }
  const t0 = await call(pair, SEL.token0).catch(() => null);
  const t1 = await call(pair, '0xd21220a7').catch(() => null);
  const sides = [t0, t1].map((x) => (x && x.length >= 66 ? '0x' + x.slice(-40).toLowerCase() : null));
  if (!sides.includes(token)) return { error: 'that pair does not hold this token' };
  if (!sides.includes(quote)) return { error: 'that pair is not quoted in the quote named (WBNB by default) — name its quote' };
  return { spec: { ...out, token, pair, quote } };
}

async function createWatch(env, spec, payment) {
  const quoteOf = String(spec.quote || WBNB).toLowerCase();
  if (!WATCH_QUOTES.has(quoteOf)) throw new Error('this watch prices pools quoted in BNB, USDT, BUSD, USDC or USD1 — name one of those as quote, or leave it out for BNB');
  if (spec.callback != null && !/^https:\/\/[^\s]{4,400}$/.test(String(spec.callback))) throw new Error('callback must be an https:// URL');
  if (spec.depthBelowUsd != null && !(Number(spec.depthBelowUsd) > 0)) throw new Error('depthBelowUsd must be a positive number of dollars');
  const id = crypto.randomUUID();
  const now = Date.now();
  const watch = {
    id,
    token: spec.token.toLowerCase(),
    pair: spec.pair.toLowerCase(),
    quote: (spec.quote || WBNB).toLowerCase(),
    ...(spec.kind === 'v3' ? { kind: 'v3', fee: spec.fee } : {}),
    depthBelowUsd: spec.depthBelowUsd ?? null,
    callback: spec.callback || null,
    createdAt: now,
    expiresAt: now + WATCH_DAYS * 86400000,
    paidTx: payment.tx,
    paidBy: payment.from,
    lastDepthUsd: null,
    triggered: [],
  };
  await env.AGENT.put(`watch:${id}`, JSON.stringify(watch), {
    expirationTtl: WATCH_DAYS * 86400 + 86400,
  });
  return watch;
}

// The size that moves the watched pool's price 1%, in USD: on a V2 pair from the quote reserve, on a PancakeSwap V3
// pool from the quoter's crossing (a floor when deeper than the largest probe). The sweep and the unpaid answer's
// would_watch read it through this one function. null: nothing could be read this time.
async function watchDepthUsd(w, bnbPrice) {
  const quoteUsd = w.quote === WBNB ? bnbPrice : 1;
  if (w.kind === 'v3') {
    const d = await v3BuyDepthUsd(RPCS, { pool: w.pair, token: w.token, quote: w.quote, fee: w.fee, quoteUsd });
    return d ? { depthUsd: d.depthUsd, floor: d.floor } : null;
  }
  const reserveUsd = await poolDepthUsd(w.pair, w.quote, quoteUsd);
  return { depthUsd: reserveUsd * ONE_PCT_OF_RESERVE, reserveUsd: Math.round(reserveUsd), floor: false };
}

async function checkWatches(env) {
  const list = await listAll(env, 'watch:');
  if (!list.keys.length) return { checked: 0, fired: 0 };
  const price = await bnbUsd().catch(() => 0);
  if (!price) return { checked: 0, fired: 0, error: 'could not price BNB' };

  let fired = 0;
  for (const k of list.keys) {
    const raw = await env.AGENT.get(k.name);
    if (!raw) continue;
    const w = JSON.parse(raw);
    if (Date.now() > w.expiresAt) { await env.AGENT.delete(k.name); continue; }

    let depth;
    try {
      const d = await watchDepthUsd(w, price);
      if (!d) continue;
      depth = d.depthUsd;
      if (d.reserveUsd != null) w.lastReserveUsd = d.reserveUsd;
      w.lastDepthFloor = d.floor || undefined;
    } catch { continue; } // a node dropping a call is not a depth collapse
    w.lastDepthUsd = Math.round(depth);
    w.lastCheckedAt = Date.now();

    if (w.depthBelowUsd != null && depth < w.depthBelowUsd) {
      const already = w.triggered.some((t) => Date.now() - t.at < 6 * 3600000);
      if (!already) {
        w.triggered.push({ at: Date.now(), depthUsd: Math.round(depth) });
        fired++;
        if (w.callback) {
          // Fire-and-forget: a subscriber's endpoint being down must not stall
          // the run for everyone else on the list.
          await fetch(w.callback, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({
              watch: w.id, token: w.token, pair: w.pair,
              depthUsd: Math.round(depth), threshold: w.depthBelowUsd,
              at: new Date().toISOString(),
            }),
            signal: AbortSignal.timeout(5000),
          }).catch(() => {});
        }
      }
    }
    await env.AGENT.put(k.name, JSON.stringify(w), {
      expirationTtl: Math.max(60, Math.floor((w.expiresAt - Date.now()) / 1000) + 86400),
    });
  }
  await bump(env, 'watch_checks', list.keys.length);
  return { checked: list.keys.length, fired };
}

// ---------------------------------------------------------------- the liquidity series
//
// One point per run of the DeFi agent, taken from the record it writes
// (worker-lp, 04:23 UTC) and never from a counter: what the position was
// worth, whether it was in range, what it was owed, what had already been
// sent on. Kept here, by the worker with no keys, so the series exists
// without touching the worker that moves money. The first point is the
// baseline every later "since it started" figure is measured against.
const LP_SERIES_KEY = 'lp:series';
// A run that found no position has no position value, and is neither in
// nor out of a range. 2026-09-06 05:23 the record found none (the re-set of
// the day before had stopped between its unwind and its mint, the capital
// sat in the wallet) and the point carried value 0 and "out" — which read
// as the capital gone, -100%. Such a point says "no position", nothing
// more; the rule is applied on read so the point already written obeys it.
function lpSeriesPoint(p) {
  if (p.position) return p;
  return { ...p, value_bnb: null, in_range: null };
}
async function readLpSeries(env) {
  const raw = await env.AGENT.get(LP_SERIES_KEY);
  return raw ? JSON.parse(raw).map(lpSeriesPoint) : [];
}
async function recordLpSeries(env) {
  const rec = await readAgentRecord(env);
  if (!rec) return { recorded: false, why: 'no record yet' };
  // The newest run on record: the daily one, or an hourly check that acted
  // (those land in history). A re-set at 07:50 is a run the series must show.
  const hist0 = Array.isArray(rec.history) ? rec.history : [];
  const newestHist = hist0.length ? hist0[hist0.length - 1] : null;
  const last = newestHist && rec.last && Date.parse(newestHist.at) > Date.parse(rec.last.at) ? newestHist : rec.last;
  if (!last || !last.at || last.dry) return { recorded: false, why: 'no live run in the record' };
  const series = await readLpSeries(env);
  const prev = series.length ? series[series.length - 1] : null;
  const flow = moneyFlow(rec);
  const totals = {
    bobai_spent_total_bnb: flow.out.bobai_bnb,
    bobai_units_total: flow.out.bobai_units,
    operator_total_bnb: flow.out.operator_bnb || 0, // a third of the fees to the operator since 2026-10-14
    forwarded_total_bnb: flow.out.bobai_bnb,
    kept_total_bnb: flow.out.kept_as_capital_bnb,
    fees_total_bnb: flow.in.fees.bnb,
    folded_total_bnb: flow.in.fees.folded_bnb || 0,
    folded_kept_total_bnb: flow.in.fees.folded_kept_bnb ?? (flow.in.fees.folded_bnb || 0),
    into_position_total_bnb: flow.out.into_position_bnb || 0,
    swept_total_bnb: flow.in.income_bnb,
    // Kept fees still waiting in the wallet: not yet in the position, so not
    // yet to be taken off the deposits (lp-flow.js, waiting.kept_fees_bnb).
    kept_waiting_bnb: flow.waiting.kept_fees_bnb || 0,
  };
  let point = null;
  if (!prev || Date.parse(prev.at) < Date.parse(last.at)) {
    const st = last.steps || {}, c = st.collect || {}, rb = st.rebalance || {}, inc = st.increase || {};
    const reset = rb.acted && !rb.error && rb.new_position;
    const sweeps = Array.isArray(st.sweep) ? st.sweep : [];
    // A deposit-watch run (since 2026-09-09) carries only the increase step:
    // its position, range and value come from there, the value after the
    // increase when it acted.
    point = {
      at: last.at,
      position: reset ? String(rb.new_position) : (c.position || rb.position || inc.position || null),
      // a one-sided re-set is placed beside the price on purpose: it starts out of range (until 2026-10-07 every
      // re-set row read "in" and days_in_range counted them all); read off the point's own tick and new ticks
      in_range: reset ? ((rb.tick ?? inc.tick) != null && Array.isArray(rb.new_ticks || rb.ticks) ? (rb.tick ?? inc.tick) >= (rb.new_ticks || rb.ticks)[0] && (rb.tick ?? inc.tick) < (rb.new_ticks || rb.ticks)[1] : true) : (c.in_range != null ? c.in_range : (rb.in_range ?? inc.in_range ?? null)),
      tick: rb.tick ?? inc.tick ?? null,
      ticks: reset ? (rb.new_ticks || rb.ticks || null) : (rb.ticks || null),
      reset: reset ? { from: rb.position, to: String(rb.new_position), width_pct: rb.width_pct ?? null, gas_bnb: rb.gas_bnb ?? null } : null,
      // The value AFTER the last step that moved money: the increase runs
      // after the rebalance, so when it acted its after-value is the
      // position as the run left it. Until 2026-09-12 the rebalance's value
      // (read before the run) won, and the 2026-09-10 12:20 point showed
      // 0.29 BNB against 0.59 of capital (-50%) while the deposit had gone
      // into the position in the same run — a deposit read as a loss.
      // The reserve range is capital too (2026-09-18): the rebalance step's
      // value_bnb is the main range alone and value_with_reserve_bnb both,
      // while the increase step's value_bnb (and value_after_bnb) already
      // carry the reserve — so a daily run's point read the main range alone
      // and a deposit-watch point both, and the table jumped by the reserve
      // between one row and the next (2026-09-17 08:50 −3.53%, 09:10 −0.32%)
      // and read the 04:23 run 2.6% under the card above it.
      value_bnb: inc.acted && !inc.error && inc.value_after_bnb != null ? Number(inc.value_after_bnb) : (rb.value_with_reserve_bnb != null ? Number(rb.value_with_reserve_bnb) : (rb.value_bnb != null ? Number(rb.value_bnb) : (inc.value_bnb != null ? Number(inc.value_bnb) : null))),
      owed_bnb: c.owed ? Number(c.owed.bnb_equivalent) || 0 : 0,
      // The increase step reads the wallet before it spends; when it acted,
      // the point carries what was left, else the card and the page would
      // show a deposit as still waiting after it went into the position.
      wallet_bnb: inc.wallet_bnb != null ? Math.max(0, Number(inc.wallet_bnb) - (inc.acted && !inc.error && inc.bnb_spent != null ? Number(inc.bnb_spent) : 0)) : null,
      waiting: sweeps.filter((s) => s.balance > 0).map((s) => ({ token: s.token || s.source, amount: Number(s.balance) })),
      ...totals,
      acted: !!last.acted,
      ok: last.ok !== false,
    };
  } else {
    // An hourly check that found a position the series does not know — one
    // minted by hand after a stopped re-set (2026-09-06 06:06, seen at the
    // 06:50 check) — is a point too, else the series says "no position" all
    // day while there is one. A check that sees the position the series
    // already has is not a point: the hours are not a history.
    const chk = rec.last_check, cr = chk && chk.steps && chk.steps.rebalance;
    if (chk && !chk.dry && cr && cr.position && Date.parse(chk.at) > Date.parse(prev.at) && String(cr.position) !== String(prev.position || '')) {
      point = {
        at: chk.at,
        position: String(cr.position),
        in_range: cr.in_range ?? null,
        tick: cr.tick ?? null,
        ticks: cr.ticks || null,
        reset: null,
        value_bnb: cr.value_with_reserve_bnb != null ? Number(cr.value_with_reserve_bnb) : (cr.value_bnb != null ? Number(cr.value_bnb) : null),
        // The check only looked at the range: fees owed and the wallet were
        // not read, so they are unknown here, not zero.
        owed_bnb: null,
        wallet_bnb: null,
        waiting: prev.waiting || [],
        ...totals,
        acted: false,
        ok: chk.ok !== false,
        seen: 'hourly check found a position the series did not know',
      };
    }
  }
  if (!point) return { recorded: false, why: 'already recorded', points: series.length };
  point.bnb_usd = await bnbUsd().catch(() => null);
  series.push(lpSeriesPoint(point));
  const kept = capSeries(series);
  await env.AGENT.put(LP_SERIES_KEY, JSON.stringify(kept));
  return { recorded: true, points: kept.length, point };
}
// What the series says so far, in the terms a person asks: is the capital
// still there, what did it earn, did the price leave the range. Value is in
// BNB because the position is quoted in BNB; a dollar figure would move with
// BNB and say nothing about the position.
// The series a reader sees: only runs that had a position. A run that found
// none (2026-09-06 05:23, between a stopped re-set and the mint by hand) is
// kept in the store, so the record of that day exists, but it is not a row:
// it has no value, no range, nothing to compare — the operator: "kann raus".
function lpSeriesShown(series) {
  // a re-set row stored before 2026-10-07 says "in" whatever its own tick and new ticks say: read again from them
  return series.filter((p) => p.position).map((p) => p.reset && p.tick != null && Array.isArray(p.ticks) && p.ticks.length === 2
    ? { ...p, in_range: p.tick >= p.ticks[0] && p.tick < p.ticks[1] } : p);
}
// `gas_bnb` is the record's own gas total (moneyFlow), so the profit line can
// net it: the series points carry no gas.
// Where the fees in the profit line are: collected by the collect step,
// folded into the capital by re-sets, still owed by the position. Shared
// with the liquidity page (app.js, same words) so the two never differ.
function lpFeesWhere(p) {
  const f5 = (v) => Number(v || 0).toFixed(5);
  const parts = [];
  if (p.fees_collected_bnb > 0) parts.push(`${f5(p.fees_collected_bnb)} collected`);
  if (p.fees_folded_bnb > 0) parts.push(`${f5(p.fees_folded_bnb)} folded into the capital by re-sets`);
  if (p.fees_forwarded_at_resets_bnb > 0) parts.push(`${f5(p.fees_forwarded_at_resets_bnb)} put into BOBAI by re-sets`);
  parts.push(`${f5(p.fees_owed_bnb)} still owed by the position`);
  return parts.join(', ');
}
function lpSeriesSummary(series, { gas_bnb = null, owed_now_bnb = null, totals = null, value_now_bnb = null, time_in_range = null } = {}) {
  if (!series.length) return null;
  const first = series[0], last0 = series[series.length - 1];
  // The totals (fees, buyback share, kept, swept) are the record's own
  // money-flow figures when the caller has them: a point carries the totals
  // as they were when it was written, and a record corrected afterwards
  // (the re-sets' folded fees, 2026-09-07) would otherwise stay wrong until
  // the next point.
  const last = totals ? { ...last0, ...totals } : last0;
  const withValue = series.filter((p) => p.value_bnb != null);
  const f0 = withValue[0], f1 = withValue[withValue.length - 1];
  const days = Math.max(0, Math.round((Date.parse(last.at) - Date.parse(first.at)) / 86400000));
  const tickMove = first.tick != null && last.tick != null ? last.tick - first.tick : null;
  const out = {
    points: series.length,
    since: first.at,
    days_covered: days,
    value_bnb: f0 && f1 ? { start: f0.value_bnb, now: value_now_bnb != null ? value_now_bnb : f1.value_bnb, added_by_hand_bnb: +(Number(f1.capital_added_total_bnb) || 0).toFixed(6), change_pct: f0.value_bnb ? +((((value_now_bnb != null ? value_now_bnb : f1.value_bnb) - (Number(f1.capital_added_total_bnb) || 0) - f0.value_bnb) / f0.value_bnb) * 100).toFixed(2) : null } : null,
    // Since 2026-09-09 the share buys BOBAI the agent holds in its own wallet;
    // the old key stays one more release for readers of the series.
    fees_into_bobai_bnb: last.bobai_spent_total_bnb ?? last.forwarded_total_bnb,
    bobai_held_units: last.bobai_units_total ?? 0,
    fees_to_operator_bnb: Number(last.operator_total_bnb) || 0,
    fees_sent_to_buyback_bnb: last.forwarded_total_bnb,
    fees_kept_as_capital_bnb: last.kept_total_bnb ?? 0,
    // … of which this much still waits in the wallet as BNB, under the increase floor.
    fees_kept_waiting_bnb: last.kept_waiting_bnb ?? 0,
    fees_produced_bnb: last.fees_total_bnb ?? last.forwarded_total_bnb,
    income_put_in_bnb: last.swept_total_bnb,
    // What the increase step put in beyond swept income and kept fees is the
    // operator's own money, taken in by the deposit watch (since 2026-09-09).
    // kept_total counts the fees kept by collects AND the fees re-sets folded
    // in; only the former went through an increase, so only the former comes
    // out of the deposits (2026-09-10: 0.0033 BNB of folded fees made the
    // capital read 0.5831 where 0.5864 had gone in).
    deposits_put_in_bnb: +Math.max(0, (Number(last.into_position_total_bnb) || 0) - (Number(last.swept_total_bnb) || 0) - Math.max(0, (Number(last.kept_total_bnb) || 0) - (Number(last.folded_kept_total_bnb) || 0) - (Number(last.kept_waiting_bnb) || 0))).toFixed(6),
    fees_owed_now_bnb: owed_now_bnb != null ? owed_now_bnb : last.owed_bnb,
    // 1 tick = 0.01 % of price; the sign says which way the pair moved.
    price_move_pct_since_start: tickMove != null ? +((Math.pow(1.0001, tickMove) - 1) * 100).toFixed(2) : null,
    // Only a run that saw a position was in or out of a range; "in range on
    // 3 of 6" must not count a run that found none.
    runs_with_a_position: series.filter((p) => p.in_range === true || p.in_range === false).length,
    days_in_range: series.filter((p) => p.in_range === true).length,
    days_out_of_range: series.filter((p) => p.in_range === false).length,
    // they count runs, not days (2026-10-09: 128 runs over 36 days read "108 days in range"); the old names stay for readers
    runs_in_range: series.filter((p) => p.in_range === true).length,
    runs_out_of_range: series.filter((p) => p.in_range === false).length,
    // said in the JSON itself (2026-11-19, a stranger test: "181 days in range" beside 77 days covered read impossible)
    how_to_read_the_counts: 'days_in_range and days_out_of_range count runs, not days — the same numbers as runs_in_range and runs_out_of_range, kept under the old names for existing readers. time_in_range is the share of the ten-minute price tape, which keeps the last 30 days, so its "from" moves forward every day.',
    days_it_acted: series.filter((p) => p.acted).length,
    // The share of TIME in range, from the ten-minute tape (2026-09-24, D3):
    // the run counts above lean high, a run happens when the agent acts.
    time_in_range,
  };
  // Profit, the way the operator asks it ("was haben wir fuer profit?"): what
  // the position is worth now against the first point, plus the fees it has
  // produced and still owes, minus the gas on record. The value part is
  // mostly the pair's price moving; the sentence says so, because on $55 in
  // a 0.05 % pool the fees are the small part and hiding that would be spin.
  if (out.value_bnb && out.value_bnb.start != null && out.value_bnb.now != null) {
    // Capital that was added to the position is in its value now but is not
    // a gain of the price: the fees a re-set folded in and the income the
    // increase put in. Take them out of the price part, else the folded fees
    // count twice — once in the value, once as fees (2026-09-07, +0.001 BNB).
    const folded = Number(last.folded_total_bnb) || 0, putIn = Number(last.into_position_total_bnb) || 0;
    // Since 2026-09-08 a re-set sends the buyback share of those fees on
    // before the mint, so only the kept part is in the value now.
    const foldedKept = last.folded_kept_total_bnb != null ? Number(last.folded_kept_total_bnb) || 0 : folded;
    // ... and the capital the operator added by hand (2026-09-08: 0.0399 BNB
    // put in at 11:00 UTC made the value jump +64%; that is his money, not a gain).
    const byHand = Number(out.value_bnb.added_by_hand_bnb) || 0;
    const price = +(out.value_bnb.now - out.value_bnb.start - foldedKept - putIn - byHand).toFixed(6);
    const collected = Math.max(0, (out.fees_produced_bnb || 0) - folded);
    const fees = +((out.fees_produced_bnb || 0) + (out.fees_owed_now_bnb || 0)).toFixed(6);
    // The pool is CAKE/BNB: "the pair's price" is CAKE moving against BNB.
    const gas = gas_bnb != null ? +Number(gas_bnb).toFixed(6) : null;
    const bnb = +(price + fees - (gas || 0)).toFixed(6);
    const usd = last.bnb_usd ? +(bnb * last.bnb_usd).toFixed(2) : null;
    // The return on the capital, once the profit is known: profit over
    // everything that went in (the first point, what the operator added by
    // hand, what the agent put in from deposits). The earlier figure divided
    // the value change by the first point alone and read +82% on the day a
    // deposit doubled the position (2026-09-09).
    const capitalTotal = out.value_bnb.start + byHand + (Number(out.deposits_put_in_bnb) || 0);
    out.value_bnb.capital_total_bnb = +capitalTotal.toFixed(6);
    out.value_bnb.change_pct = capitalTotal > 0 ? +((bnb / capitalTotal) * 100).toFixed(2) : out.value_bnb.change_pct;
    out.profit = { bnb, usd, from_price_bnb: price, from_fees_bnb: fees, fees_collected_bnb: +collected.toFixed(6), fees_folded_bnb: +foldedKept.toFixed(6), fees_forwarded_at_resets_bnb: +(folded - foldedKept).toFixed(6), fees_owed_bnb: +(out.fees_owed_now_bnb || 0).toFixed(6), gas_bnb: gas, bnb_usd: last.bnb_usd || null };
  }
  // The same figures as one sentence — the line /defi opens with and the
  // whole of the Telegram daily report, so the two never say different things.
  const f = (v, d) => (v == null || !isFinite(Number(v))) ? '—' : Number(v).toFixed(d);
  const pct = (v) => v == null ? '—' : (v > 0 ? '+' : '') + Number(v).toFixed(2) + '%';
  const v = out.value_bnb;
  out.sentence = `Since ${String(out.since).slice(0, 10)}: ${out.points} run${out.points === 1 ? '' : 's'}`
    + (v && v.start != null ? `, position worth ${f(v.start, 4)} → ${f(v.now, 4)} BNB${v.added_by_hand_bnb ? ` of which ${f(v.added_by_hand_bnb, 4)} BNB was added by the operator` : ''} (${pct(v.change_pct)}${v.added_by_hand_bnb ? ' on the capital' : ''})` : '')
    + (out.price_move_pct_since_start != null ? `, the pair moved ${pct(out.price_move_pct_since_start)}` : '')
    + (time_in_range ? `, in range ${time_in_range.in_range_pct}% of the time since ${String(time_in_range.from).slice(0, 10)} (${time_in_range.samples} ten-minute readings)` : `, in range on ${out.days_in_range} of ${out.runs_with_a_position} runs`)
    + `, fees put into BOBAI held in the wallet ${f(out.fees_into_bobai_bnb, 5)} BNB${out.bobai_held_units > 0 ? ` (${Math.round(out.bobai_held_units).toLocaleString('en-US')} BOBAI held)` : ''}`
    + (out.fees_kept_as_capital_bnb ? `, kept as capital ${f(out.fees_kept_as_capital_bnb, 5)} BNB` : '')
    + `, income put in ${f(out.income_put_in_bnb, 5)} BNB` + (out.deposits_put_in_bnb > 0 ? `, deposits the agent put in ${f(out.deposits_put_in_bnb, 5)} BNB` : '') + '.';
  const sign = (x) => (x > 0 ? '+' : '') + f(x, 5);
  if (out.profit) {
    const p = out.profit;
    out.sentence += ` Profit so far ${sign(p.bnb)} BNB${p.usd != null ? ` (about $${p.usd.toFixed(2)})` : ''}: ${sign(p.from_price_bnb)} BNB from CAKE moving against BNB, ${sign(p.from_fees_bnb)} BNB of fees earned (${lpFeesWhere(p)})${p.gas_bnb != null ? `, −${f(p.gas_bnb, 5)} BNB of gas` : ''}.`;
  }
  return out;
}

// ---------------------------------------------------------------- earnings

// Every payment on record, and — separately — what came from strangers and
// what we paid ourselves to prove the path works. The headline total is the
// sum of both; a reader who wants "has anyone else ever paid" reads
// from_strangers. A record without a payer (none exist since 2026-09-08; the
// three older ones were patched from their receipts) counts as ours, not as
// a stranger's: the claim that is easy to make wrongly is the flattering one.
async function readEarnings(env) {
  const list = await listAll(env, 'earn:');
  let total = 0n, strangers = 0n, own = 0n, strangersCount = 0, ownCount = 0;
  const payments = [];
  for (const k of list.keys) {
    const rec = JSON.parse((await env.AGENT.get(k.name)) || '{}');
    if (!rec.amount) continue;
    const amount = BigInt(rec.amount);
    const selfTest = !rec.from || isOwnWallet(rec.from);
    total += amount;
    if (selfTest) { own += amount; ownCount += 1; } else { strangers += amount; strangersCount += 1; }
    payments.push({ at: rec.at, amountUsd1: fmtUsd1(amount), tx: rec.tx, for: rec.for, from: rec.from || null, self_test: selfTest, ...(rec.paid_in ? { paid_in: rec.paid_in } : {}) });
  }
  payments.sort((a, b) => (b.at || 0) - (a.at || 0));
  return {
    totalUsd1: fmtUsd1(total), totalRaw: total.toString(), count: payments.length,
    from_strangers: { totalUsd1: fmtUsd1(strangers), count: strangersCount },
    self_tests: { totalUsd1: fmtUsd1(own), count: ownCount },
    note: 'totalUsd1 is every payment received. from_strangers is the part paid by wallets that are not ours; self_tests is what we paid ourselves to prove the path works. Each payment names its payer.',
    payments: payments.slice(0, 25),
  };
}

// ---------------------------------------------------------------- handler

// CAPABILITIES moved to catalog.js — see the header there for why.

// The one paid tool. Its description says the price in the first sentence:
// an agent deciding whether to call something should not have to call it to
// find out that it costs money.
const WATCH_TOOL = {
  name: 'bsc_pool_watch',
  description:
    'PAID (0.50 USD1, or half that in $BOBAI; 30 days). Watch one BNB Smart Chain liquidity pool around the clock and '
    + 'get told the moment it can no longer absorb a trade of your size. Checked every fifteen '
    + 'minutes for thirty days; fires a callback when depth falls below your threshold. '
    + 'Call it once WITHOUT `payment` and it answers with the price and where to send it — that '
    + 'call is free. Measuring a pool once is free too — 1,000 scans per caller a day, a day pass past that: use bsc_pool_scan at '
    + 'https://brainonbnb.com/mcp for that. This tool is only worth paying for because somebody '
    + 'has to still be running in an hour.',
  inputSchema: {
    type: 'object',
    required: ['token'],
    properties: {
      token: { type: 'string', pattern: '^0x[a-fA-F0-9]{40}$', description: 'The BEP-20 token address.' },
      pair: { type: 'string', pattern: '^0x[a-fA-F0-9]{40}$', description: 'Optional. The PancakeSwap V2 pair or V3 pool holding it; left out, its V2 pair is found from the token and the quote.' },
      quote: { type: 'string', description: 'Optional. The other side of the pair, if it is not WBNB.' },
      depthBelowUsd: {
        type: 'number',
        description:
          'Alert when the pool can no longer absorb a trade of this many dollars. '
          + 'Leave it out and the watch records depth but never fires, which is a real thing to '
          + 'want and a bad thing to get by accident.',
      },
      callback: { type: 'string', format: 'uri', description: 'Where to POST when it fires. Without one, poll /watch/<id>.' },
      payment: {
        type: 'string',
        description:
          'The transaction hash of your USD1 (or half-price $BOBAI) transfer, or a base64 x402 payload. Omit it on the '
          + 'first call to be told what to pay and where.',
      },
    },
  },
};

// The paid purchase itself, lifted out of the HTTP route so that MCP can sell
// the same thing without a second copy of the payment logic living beside it.
// Returns what the caller should be told rather than a Response: the two front
// doors format it differently, and only one of them can carry a header.
// One payment check for everything sold over x402 here. Two ways to pay the
// same price into the same wallet: standard x402 through the facilitator (a
// stock client can do it unattended), or our own direct USD1 transfer with the
// transaction hash as proof, which needs no facilitator and no signature
// support. Either way the proof is marked spent BEFORE the goods are produced:
// if production fails the caller has lost nothing they cannot retry with
// support, whereas the reverse order lets a retry storm mint goods off one
// payment. Returns { ok, tx, paid, from } or { ok:false, status, body }.
async function chargeX402(env, { payTo, price, description, resource, proof, sold, alt = null }) {
  // THE HOLDER PASS (holder-pass.js, 2026-10-16): a wallet holding the $BOBAI line uses the paid services without paying,
  // within a daily allowance. Nothing is paid, so nothing is earned: no earn: record, the sale is claimed under its own
  // one-time id so delivery, credit and the ledger work as for any sale.
  if (isHolderProof(proof)) {
    const hp = await useHolderPass(env, rpc, proof, sold);
    if (!hp.ok) return { ok: false, status: hp.status, body: hp.body };
    const tx = `holder:${hp.wallet}:${sold}:${Date.now()}`;
    const claim = await claimPayment(env, tx, sold);
    if (!claim.ok) return { ok: false, status: 402, body: { error: 'holder pass not accepted', reason: claim.reason } };
    await bump(env, `holder_pass_${hp.kind}`).catch(() => {});
    bumpDetail(env, [`sell:holder:${sold}`]);
    return { ok: true, tx, paid: 0n, from: hp.wallet, asset: 'holder pass', claim: claim.by, holder: hp };
  }
  const parsed = parsePaymentHeader(proof);
  let check, tx, asset = 'USD1';
  let queued = null;
  const inner = parsed.kind === 'x402' && parsed.value && parsed.value.payload;
  if (isEip3009(inner)) {
    // USD1 BY EIP-3009, SETTLED HERE (x402-eip3009.js, 2026-10-04): checked,
    // simulated and sent from the provider wallet; the transaction it produces
    // is then read like any direct USD1 transfer and claimed once.
    const st = await settleEip3009(env, inner, { payTo, price });
    if (!st.ok) return { ok: false, status: 402, body: { error: 'payment not accepted', stage: st.stage, reason: st.reason, ...(st.tx ? { tx: st.tx } : {}) } };
    tx = st.tx; asset = st.label || 'USD1'; // USD1 or $U (2026-10-22): the token the signature was made for
    check = await verifyPayment(env, tx, payTo, price, st.asset, st.label);
    for (let i = 0; i < 2 && !check.ok; i++) { await new Promise((r) => setTimeout(r, 1500)); check = await verifyPayment(env, tx, payTo, price, st.asset, st.label); }
    // Our own receipt said success; a receipt endpoint a block behind must not
    // turn a settled payment into a refused one.
    if (!check.ok) check = { ok: true, paid: st.value, from: st.from };
  } else if (inner && inner.permit2Authorization) {
    // A PERMIT2 PAYMENT IS SETTLED BY US, NOT THE FACILITATOR (2026-09-24, A8;
    // the operator's go, route 2). Its settle reverted inside the facilitator
    // twice on a payment that settles on chain. Here, with no key and nothing
    // sent: every field against our terms, then the settle as an eth_call —
    // it proves signature, balance and allowance at this block. The answer
    // goes out; worker-lp sends the settle from the x402 wallet within ten
    // minutes (shared/x402-permit2.js). The Permit2 nonce settles once.
    const accepts = dexterAccepts({ payTo, amountAtomic: price.toString(), description, resource });
    const bad = permit2Mismatch(inner, accepts);
    if (bad) return { ok: false, status: 402, body: { error: 'payment not accepted', stage: 'verify', reason: bad } };
    try { await rpc('eth_call', [{ from: payTo, to: PERMIT2_PROXY, data: settleCalldata(inner) }, 'latest']); }
    catch (e) { return { ok: false, status: 402, body: { error: 'payment not accepted', stage: 'verify', reason: 'the payment would not settle: ' + String(e && e.message || e).split('\n')[0].slice(0, 200) } }; }
    tx = permit2Id(inner);
    asset = 'USDC';
    check = { ok: true, paid: BigInt(inner.permit2Authorization.permitted.amount), from: inner.permit2Authorization.from };
    queued = { payload: inner, req: accepts, at: Date.now(), for: sold, state: 'pending' };
  } else if (parsed.kind === 'x402') {
    const accepts = dexterAccepts({ payTo, amountAtomic: price.toString(), description, resource });
    const r = await verifyAndSettle(parsed.value, accepts);
    if (!r.ok) return { ok: false, status: 402, body: { error: 'payment not accepted', stage: r.stage, reason: r.reason } };
    tx = (r.tx || `x402:${Date.now()}`).toLowerCase();
    const seen = await readPaid(env, tx);
    if (seen && seen.state === 'delivered') return { ok: false, status: 402, body: { error: 'payment not accepted', reason: 'this settlement has already been used' } };
    check = { ok: true, paid: price, from: r.payer };
  } else {
    check = await verifyPayment(env, String(proof).trim(), payTo, price);
    // Not a USD1 payment at all? If a second coin is accepted for this
    // resource, the same receipt is read again for that one.
    if (!check.ok && alt && check.paid === 0n) {
      const c2 = await verifyPayment(env, String(proof).trim(), payTo, alt.min, alt.asset, alt.label);
      if (c2.ok) { check = c2; asset = alt.label; }
      else if (c2.paid > 0n) check = c2;
    }
    if (!check.ok) return { ok: false, status: 402, body: { error: 'payment not accepted', reason: check.reason } };
    tx = String(proof).trim().toLowerCase();
  }
  const claim = await claimPayment(env, tx, sold);
  if (!claim.ok) return { ok: false, status: 402, body: { error: 'payment not accepted', reason: claim.reason } };
  // Queued once the claim is ours: worker-lp settles it; the earnings record
  // below says it is pending until then.
  if (queued) await env.AGENT.put(QUEUE_PREFIX + tx, JSON.stringify(queued), { expirationTtl: 14 * 86400 });
  // earn: records USD1 amounts only — /stats sums them as dollars. A payment
  // in another coin is recorded with its coin and its dollar price at the
  // quote, so the total stays a dollar figure and the coin stays visible.
  // `from` is the payer, so the record can tell a stranger's purchase from
  // one of our own test purchases.
  const from = (check.from || '').toLowerCase() || null;
  const earn = asset === 'USD1'
    ? { at: Date.now(), amount: check.paid.toString(), tx, for: sold, from }
    : { at: Date.now(), amount: price.toString(), tx, for: sold, from, paid_in: asset, paid_atomic: check.paid.toString(), ...(queued ? { settle: 'pending' } : {}) };
  // The earnings record is permanent, like the mark: what was earned does not
  // stop having been earned after 400 days.
  await env.AGENT.put(`earn:${tx}`, JSON.stringify(earn));
  return { ok: true, tx, paid: check.paid, from: check.from, asset, claim: claim.by };
}

// The five deliveries, sold per answer. The same doWork() the escrow path
// runs, the same price the agents quote on Brain Plaza, one payment and the
// document comes straight back — no job, no dispute window, no settle call.
// The escrow stays for buyers who want a kernel between them and the seller;
// this is for an agent that wants the answer now and has a wallet.
const ANSWER_PRICE = 100000000000000000n; // 0.10 USD1, the price every service quotes
// A DIRECT TRANSFER IS NOT "exact" (2026-10-27, operator's go; a stranger reading our 402 as a stock x402 client:
// "a generic client that allows $BOBAI would try EIP-3009 on a token that does not support it"). The entries paid by
// sending the token and handing over the transaction hash carry their own scheme name, so a stock client skips them
// instead of failing; nothing changes in what is accepted (the hash is verified on chain as before).
const DIRECT_SCHEME = 'direct-transfer';
// what to SEND in $BOBAI (2026-10-27, same review: amount said the least that must arrive, 90% of the quote, and a
// client pays exactly amount): amount is the whole quoted number of tokens; min_arrival keeps the line acceptance uses
const bobaiSend = (b) => (BigInt(Math.ceil(Number(b.tokens))) * 10n ** 18n).toString();

// WHERE THIS PAYMENT GOES (2026-10-18, operator: every payment buys $BOBAI, visibly). The buy stays in the daily sweep
// (shared/lp-agent.js executeSweep, untouched): bought one payment at a time, three transactions of gas would take about
// half of a 0.05 buy. Every paid reply says what happens to its money and where to follow it; GET /buys maps each payment
// to the sweep that bought $BOBAI with it, or says it is still waiting and why.
const BUYS_URL = `${SELF_ORIGIN}/buys`;
const SWEEP_SOURCE = { USD1: 'x402', USDC: 'x402-usdc', '$U': 'x402-u' }; // $U since 2026-10-22 (EIP-3009)
function paymentFate(pay) {
  if (pay.holder) return { your_payment: 'Nothing was paid (holder pass): your $BOBAI stays in your wallet.', follow: BUYS_URL };
  const follow = `${BUYS_URL}?tx=${pay.tx}`;
  if (pay.asset === 'BOBAI') return { your_payment: `Paid in $BOBAI: all of it stays in the income wallet as $BOBAI, off the market and never sold.`, follow };
  const half = pay.paid / 2n, asset = pay.asset || 'USD1';
  return {
    your_payment: `${fmtUsd1(half)} ${asset} of it buys $BOBAI at the next sweep (daily at 04:23 UTC, once the income wallet holds at least ${MIN_SWEEP_BNB} BNB worth of ${asset}, so gas does not eat it) and is held there, never sold; the other ${fmtUsd1(pay.paid - half)} ${asset} is the operator's revenue.`,
    follow,
  };
}

// GET /buys — every x402 payment and the $BOBAI it bought. From the earnings register (earn:*) and the DeFi agent's run
// record (its sweeps since the buy began on 2026-10-14), plus the income wallet's $BOBAI read from the chain.
async function readBuys(env, onlyTx = null) {
  const rec = await readAgentRecord(env).catch(() => null);
  const hist = (Array.isArray(rec?.history) ? rec.history : []).filter((e) => e && !e.dry);
  const sweeps = [];
  for (const e of hist) for (const s of Array.isArray(e.steps?.sweep) ? e.steps.sweep : []) {
    if (s.acted && !s.error && s.bobai_bought != null) sweeps.push({ at: e.at, source: s.source, token: s.token, sold: s.sold, to_operator: s.to_operator, bobai_bought: s.bobai_bought, txs: s.txs || [] });
  }
  const last = hist.length ? hist[hist.length - 1] : null;
  const waiting = (Array.isArray(last?.steps?.sweep) ? last.steps.sweep : []).filter((s) => !s.acted && s.balance > 0)
    .map((s) => ({ source: s.source, token: s.token, wallet: s.wallet, balance: s.balance, bnb_equivalent: s.bnb_equivalent, floor_bnb: MIN_SWEEP_BNB, why: s.why }));
  const list = await listAll(env, 'earn:');
  const payments = [];
  for (const k of list.keys) {
    const r = JSON.parse((await env.AGENT.get(k.name)) || '{}');
    if (!r.tx || (onlyTx && r.tx !== onlyTx)) continue;
    const asset = r.paid_in || 'USD1';
    const p = { at: r.at ? new Date(r.at).toISOString() : null, tx: r.tx, for: r.for, asset, amount: r.paid_in ? fmtUsd1(BigInt(r.paid_atomic || r.amount)) : fmtUsd1(BigInt(r.amount)), from: r.from || null, self_test: !r.from || isOwnWallet(r.from) };
    if (asset === 'BOBAI') p.bobai = 'paid in $BOBAI: held as it came, never sold';
    else {
      const sw = sweeps.find((s) => s.source === SWEEP_SOURCE[asset] && Date.parse(s.at) > (r.at || 0));
      p.bobai = sw ? `half bought $BOBAI in the sweep of ${String(sw.at).slice(0, 16).replace('T', ' ')} UTC` : 'half waits for the next sweep that clears the gas floor';
      if (sw) p.sweep_txs = sw.txs;
    }
    payments.push(p);
  }
  payments.sort((a, b) => String(b.at).localeCompare(String(a.at)));
  let held = null;
  try {
    const hex = await rpc('eth_call', [{ to: BOBAI, data: '0x70a08231' + String(env.X402_WALLET || '').slice(2).toLowerCase().padStart(64, '0') }, 'latest']);
    held = hex && hex !== '0x' ? Number(BigInt(hex) / 10n ** 15n) / 1000 : null;
  } catch { held = null; }
  return {
    what_this_is: 'Every payment for an answer, a pool watch or a scan day pass, and the $BOBAI it bought. Half of each USD1/USDC payment goes to $BOBAI at the daily sweep (04:23 UTC) once the income wallet holds enough to be worth the gas: bought and held, never sold, and when that part is worth the gas, a share of it added to the $BOBAI pool with the LP burned; the other half is the operator\'s revenue. A payment in $BOBAI stays $BOBAI. Our own test purchases are marked self_test.',
    rule: { to_bobai: '50%', to_operator: '50%', sweep: 'daily 04:23 UTC', gas_floor_bnb: MIN_SWEEP_BNB, code: 'https://brainonbnb.com/code/agent-service.txt (shared/lp-agent.js executeSweep)' },
    income_wallet: env.X402_WALLET || null,
    bobai_held_by_income_wallet: held,
    waiting,
    sweeps: sweeps.reverse(),
    payments: onlyTx ? payments : payments.slice(0, 100),
    from_strangers: payments.filter((p) => !p.self_test).length,
  };
}

// How to pay, in the order of accepts[] (2026-10-05): one sentence for every
// 402 here. /tip and /watch still called USDC "accepts[0]" after USD1 by
// EIP-3009 moved in front of it. `headers` is what that route reads the
// signed payload from; `direct` names what a plain transfer may send.
const payWays = ({ amount, payTo, direct = `${amount} USD1`, headers = 'X-PAYMENT or PAYMENT-SIGNATURE' }) =>
  `Pay ${amount} in USD1 by EIP-3009 (accepts[0]: sign TransferWithAuthorization to ${payTo} and send the x402 payload in ${headers} — we settle it), `
  + `or in USDC by standard x402 (accepts[1], Permit2; a stock client must allow USDC on eip155:56 in spendControls.allowedAssets), `
  + `or send ${direct} to ${payTo} on BNB Smart Chain, then repeat this request with header PAYMENT-SIGNATURE: <transaction hash>`;

async function sellAnswer(env, ctx, payTo, serviceId, body, proof) {
  const service = SERVICES[serviceId];
  // nothing is charged on an unknown id: a payment counts as used only once an answer is delivered (5.11.)
  if (!service) return { status: 400, body: { error: 'unknown service', services: Object.keys(SERVICES), charged: false,
    note: 'Nothing was charged. A payment already sent stays good: repeat the request with one of these services. The free tools (bobai_price and 29 more) are at https://brainonbnb.com/mcp' } };
  const resource = `https://agent.brainonbnb.com/answer?service=${serviceId}`;
  const description = `${service.name} — one answer`;
  // Half the price in $BOBAI, quoted now. If the pair cannot be read the
  // answer is still for sale in USD1; the $BOBAI door just stays shut.
  // $BOBAI IS THE CHEAPER WAY TO PAY (2026-10-14, operator: profit and volume for $BOBAI first): an answer costs half
  // its USD1 price in $BOBAI, so a buyer — a person or an agent — has a reason to buy the token to pay with it
  const bobai = await bobaiForUsd(Number(ANSWER_PRICE) / 1e18 * BOBAI_SHARE).catch(() => null);
  if (!proof) {
    const requirements = {
      x402Version: 2,
      accepts: [
        // USD1 by EIP-3009 first (2026-10-04): the BNB Chain norm, and what
        // clients that read only accepts[0] (Mandate's relay among them) pay.
        eip3009Accepts({ payTo, amountAtomic: ANSWER_PRICE.toString(), description, resource }),
        dexterAccepts({ payTo, amountAtomic: ANSWER_PRICE.toString(), description, resource }),
        {
          scheme: DIRECT_SCHEME, network: NETWORK, asset: USD1, maxAmountRequired: ANSWER_PRICE.toString(), payTo, resource,
          description: `${description} — direct transfer, then send the transaction hash in PAYMENT-SIGNATURE`,
          ...DIRECT_TERMS, extra: { name: 'World Liberty Financial USD', version: '1', decimals: 18, assetTransferMethod: 'direct-transfer' },
        },
        ...(bobai ? [{
          scheme: DIRECT_SCHEME, network: NETWORK, asset: BOBAI, amount: bobaiSend(bobai), maxAmountRequired: bobaiSend(bobai), min_arrival: bobai.atomic.toString(), payTo, resource,
          // What to send and what is accepted, both said (2026-10-05): maxAmountRequired is the least that
          // must arrive, a tenth under the price, for the token's 3% tax and a price that moves before the block.
          description: `${description} — half price in $BOBAI (${(Number(ANSWER_PRICE) / 1e18 * BOBAI_SHARE).toFixed(2)} USD instead of ${fmtUsd1(ANSWER_PRICE)}): send ${bobai.tokens.toLocaleString('en-US')} BOBAI (the amount at this quote); at least ${Number(bobai.atomic / 10n ** 18n).toLocaleString('en-US')} BOBAI must arrive after the token's transfer tax. Direct transfer, then the transaction hash in PAYMENT-SIGNATURE`,
          ...DIRECT_TERMS, extra: { name: 'BOB', symbol: 'BOBAI', version: '1', decimals: 18, assetTransferMethod: 'direct-transfer', usd_per_bobai: bobai.usd_per_bobai, quoted_at: bobai.quoted_at },
        }] : []),
        // $U by EIP-3009 (2026-10-22, operator's go): last, so every index named elsewhere (accepts[0] USD1 …) stays
        eip3009Accepts({ payTo, amountAtomic: ANSWER_PRICE.toString(), description, resource, asset: U }),
      ],
    };
    return {
      status: 402,
      // Exposed, or a browser agent cannot read the header it is told to decode.
      headers: { 'PAYMENT-REQUIRED': b64(v2Shape(requirements, { url: resource, description })), 'Access-Control-Expose-Headers': 'PAYMENT-REQUIRED' },
      body: {
        // the version beside accepts in the body too (2026-11-12): clients that read the body (the v1 response shape) look for it
        x402Version: 2,
        error: 'payment required',
        service: service.id, name: service.name, what: service.deliverables, needs: service.needs,
        how: `${payWays({ amount: fmtUsd1(ANSWER_PRICE), payTo, direct: `${fmtUsd1(ANSWER_PRICE)} USD1${bobai ? ` or ${bobai.tokens.toLocaleString('en-US')} $BOBAI` : ''}` })} — or ${fmtUsd1(ANSWER_PRICE)} $U by EIP-3009 like USD1 (the last entry of accepts) — and a JSON body {"task":"<what you want, with the address in it>"} or {"params":{…}} using the field names under needs; a filled-in body: GET https://agent.brainonbnb.com/example?service=${serviceId} → request.`,
        ...(bobai ? { in_bobai: { tokens: bobai.tokens, usd_per_bobai: bobai.usd_per_bobai, discount: `half price: ${fmtUsd1(ANSWER_PRICE)} USD1 or ${bobai.tokens.toLocaleString('en-US')} $BOBAI, worth ${(Number(ANSWER_PRICE) / 1e18 * BOBAI_SHARE).toFixed(2)} USD`, note: '$BOBAI paid here stays in the income wallet as $BOBAI — off the market, never sold. Since 2026-10-14 every payment in USD1, USDC or $U is split when it is swept: half buys $BOBAI that is held there, half is the operator’s revenue.' } } : {}),
        // Hold, don't pay (2026-10-16, holder-pass.js): a wallet with the $BOBAI line uses this without paying.
        holder_pass: holderPassTerms(),
        example: `https://agent.brainonbnb.com/example?service=${serviceId} — what the answer looks like, free`,
        or_escrow: 'The same answer is sold through the ERC-8183 escrow on https://brainonbnb.com/registry, for buyers who want a kernel between them and the seller.',
        // WHAT HAPPENS TO THE MONEY IF THE ANSWER FAILS (2026-10-27, a stranger reading this 402: "nothing says what happens
        // to my money if delivery fails" — the code has always kept it; now the offer says so) and the one step Permit2 needs
        if_the_answer_fails: 'Send your input with the payment: missing or malformed input is refused once the signature is checked and before anything is settled (422, nothing charged). A request without a payment gets these terms (402) whatever its input. If the payment went through and the answer then cannot be built, the payment is kept as a credit on its own transaction: send the same request with the same PAYMENT-SIGNATURE (input fixed) and it is used for that answer, not charged again.',
        usdc_via_permit2: 'USDC is paid through Permit2: the paying wallet needs a one-time approve of the Permit2 contract (0x000000000022D473030F116dDEE9F6B43aC78BA3) for USDC before its first signature.',
        accepts: v2Shape(requirements, { url: resource }).accepts,
      },
    };
  }
  // The input is looked at BEFORE the payment is (sell.js, missingInput): a
  // request that cannot be worked is told so with its money untouched.
  // the buyer's numbers in a sentence (levels, capital, bounds; understand.js) under what it named as fields (2026-10-23)
  let wanted = { ...understand(service, String(body?.task || body?.inputs?.task || '')), ...extractParams(String(body?.task || body?.inputs?.task || ''), { ...bareFields(body), ...(body?.inputs || {}), ...(body?.params || {}), service: serviceId }) };
  // A hire button that pays and names nothing (2026-10-14, Mandate's "Hire for $0.10"): the paying wallet is the input,
  // as the escrow path does it since 2026-10-04 (sell.js deliverJob) — the DeFi agent plans for the payer's position or
  // its own (lpDefaultTarget), the health factor reads the payer's account
  let target = null;
  if ((serviceId === 'lp_position_plan' || serviceId === 'health_factor') && missingInput(serviceId, wanted)) {
    const pp = isHolderProof(proof) ? { kind: 'holder' } : parsePaymentHeader(proof), a = pp.kind === 'x402' ? pp.value.payload || {} : {};
    // a holder pass names its wallet: that is the payer's input, as a signed payment's is
    const payer = holderWalletOf(proof) || a.authorization?.from || a.permit2Authorization?.from || null;
    if (serviceId === 'lp_position_plan') target = await lpDefaultTarget(payer).catch(() => ({ address: OWN_LP_WALLET, target: `no position was named: this is the plan for the position this agent runs itself (wallet ${OWN_LP_WALLET})` }));
    else if (payer) target = { address: payer, target: `no account was named: this reads the paying wallet ${payer}` };
    if (target) wanted = { ...wanted, ...(target.position ? { position: target.position } : { address: target.address }) };
  }
  // The same hire button on the grid planner and the fee-tier agent (2026-10-15): Mandate's page reads "Not available to
  // hire — it answered 402 to the signed payment" for #302258 since 4 Oct. No token named = WBNB, BNB Chain's own coin
  // and the pair every grid and LP question starts from; the answer says so, and a token named is always used instead.
  if ((serviceId === 'grid_plan' || serviceId === 'lp_tier_plan') && missingInput(serviceId, wanted)) {
    target = { token: WBNB, target: `no token was named: this is the ${serviceId === 'grid_plan' ? 'grid' : 'fee-tier plan'} for WBNB (${WBNB}), BNB Chain's own coin — name \`token\` for another` };
    wanted = { ...wanted, token: WBNB, address: WBNB };
  }
  // and on the Portfolio Rebalance Pricer (#304494, refused daily since Mandate lists it): the paying wallet's holdings,
  // read from the chain (rebalance.js rebalanceDefaultTarget) — before the payment is taken, so a read that fails costs nothing
  if (serviceId === 'rebalance_plan' && missingInput(serviceId, wanted)) {
    const pp = isHolderProof(proof) ? { kind: 'holder' } : parsePaymentHeader(proof), a = pp.kind === 'x402' ? pp.value.payload || {} : {};
    const got = await rebalanceDefaultTarget(holderWalletOf(proof) || a.authorization?.from || a.permit2Authorization?.from || null).catch(() => null);
    if (got && got.holdings.length) { target = { target: got.target }; wanted = { ...wanted, holdings: got.holdings }; }
  }
  const lacks = missingInput(serviceId, wanted);
  if (lacks) return { status: 422, body: { error: lacks, needs: service.needs, payment: 'not taken — nothing was charged; send the same request with the input added' } };
  const pay = await chargeX402(env, { payTo, price: ANSWER_PRICE, description, resource, proof, sold: `answer:${serviceId}`,
    alt: bobai ? { asset: BOBAI, min: bobai.atomic, label: 'BOBAI' } : null });
  if (!pay.ok) return { status: pay.status, body: pay.body };
  const params = target ? wanted : { ...understand(service, String(body?.task || body?.inputs?.task || '')), ...extractParams(String(body?.task || body?.inputs?.task || ''), { ...bareFields(body), ...(body?.inputs || {}), ...(body?.params || {}), service: serviceId }) };
  let result;
  try {
    result = await doWork(serviceId, params, env);
  } catch (e) {
    // Paid and not deliverable — the one case that must never be silent.
    // The payment is recorded as unspent again so the caller can retry with
    // the input fixed, and the reason is the service's own.
    // A credit, held by the same hash — never a deletion: deleting freed the
    // hash for whoever raced this request, the delivered answer included.
    await settlePayment(env, pay.tx, pay.claim, 'credit', { failed: String(e.message || e).slice(0, 120) }).catch(() => {});
    await env.AGENT.delete(`earn:${pay.tx}`).catch(() => {});
    return { status: 422, body: { error: `could not produce the answer: ${String(e.message || e).slice(0, 200)}`, needs: service.needs, payment: 'not consumed — repeat with the same PAYMENT-SIGNATURE once the input is fixed' } };
  }
  await settlePayment(env, pay.tx, pay.claim, 'delivered').catch(() => {});
  ctx.waitUntil(bump(env, 'answer_sold'));
  return { status: 200, body: {
    ok: true, service: serviceId, name: service.name, tx: pay.tx,
    paid: pay.holder ? `nothing — $BOBAI holder pass of ${pay.from}, answer ${pay.holder.used} of ${pay.holder.of} today` : `${fmtUsd1(pay.paid)} ${pay.asset || 'USD1'}`,
    ...paymentFate(pay),
    produced_at: new Date().toISOString(),
    ...(target ? { input: target.target } : {}),
    result,
    summary: summarize(serviceId, result),
    ...checkedFigures(serviceId, result), // in_range / current_tick at the top for a checker (sell.js)
    method: 'Every figure here is read from the chain at the time above. Nothing is cached and nothing is self-reported.',
  } };
}

// A tip, over x402 (2026-09-26, the operator's go). Everything free here says thank you and names this door
// (shared/thanks.js); an agent with an x402 wallet can walk through it in one step. The tipper picks the
// amount (?usd=, default 1, between TIP_MIN and TIP_MAX), pays it into the same x402 wallet the paid services
// use — by standard x402 in USDC, or a direct USD1 transfer with its hash — and gets a thank-you back. Nothing
// is sold and nothing unlocks: the free answers are the same with or without one. The money takes the path all
// our income takes: the DeFi agent's daily sweep moves it into its pool. The minimum keeps a settle's gas
// (paid from the x402 wallet for Permit2) far under the tip itself.
const TIP_MIN = 0.1, TIP_MAX = 1000;
function tipAmount(q) {
  const usd = q == null || q === '' ? 1 : Number(q);
  if (!Number.isFinite(usd) || usd < TIP_MIN || usd > TIP_MAX) return null;
  const cents = Math.round(usd * 100);
  return { usd: cents / 100, atomic: BigInt(cents) * 10n ** 16n };
}
async function tipRoute(env, ctx, payTo, q, proof) {
  const amt = tipAmount(q);
  if (!amt) return { status: 400, body: { error: `a tip is between ${TIP_MIN} and ${TIP_MAX} (dollars, in USDC or USD1): ?usd=<amount>`, example: 'https://agent.brainonbnb.com/tip?usd=1' } };
  const resource = `https://agent.brainonbnb.com/tip?usd=${amt.usd}`;
  const description = `A voluntary tip of ${amt.usd} to BOBAI — thank you`;
  if (!proof) {
    const requirements = {
      x402Version: 2,
      accepts: [
        eip3009Accepts({ payTo, amountAtomic: amt.atomic.toString(), description, resource }),
        dexterAccepts({ payTo, amountAtomic: amt.atomic.toString(), description, resource }),
        {
          scheme: DIRECT_SCHEME, network: NETWORK, asset: USD1, maxAmountRequired: amt.atomic.toString(), payTo, resource,
          description: `${description} — direct transfer, then send the transaction hash in PAYMENT-SIGNATURE`,
          ...DIRECT_TERMS, extra: { name: 'World Liberty Financial USD', version: '1', decimals: 18, assetTransferMethod: 'direct-transfer' },
        },
        // $U by EIP-3009 (2026-10-22, operator's go): last, so every index named elsewhere (accepts[0] USD1 …) stays
        eip3009Accepts({ payTo, amountAtomic: amt.atomic.toString(), description, resource, asset: U }),
      ],
    };
    return {
      status: 402,
      headers: { 'PAYMENT-REQUIRED': b64(v2Shape(requirements, { url: resource, description })), 'Access-Control-Expose-Headers': 'PAYMENT-REQUIRED' },
      body: {
        // the version beside accepts in the body too (2026-11-12): clients that read the body (the v1 response shape) look for it
        x402Version: 2,
        error: 'payment required',
        what: 'A voluntary tip. It buys and unlocks nothing: the free measurements stay free (the pool scan 1,000 a caller a day) and the paid answers, the pool watch and the scan day pass keep their price whether you tip or not.',
        amount: `${amt.usd} — change it with ?usd=<amount> (${TIP_MIN} to ${TIP_MAX})`,
        how: `${payWays({ amount: String(amt.usd), payTo })}.`,
        where_it_goes: "The x402 wallet of BOBAI's agent services; at the next sweep half of it buys $BOBAI, held in that wallet and never sold, and half is the operator's revenue — like every payment here.",
        accepts: v2Shape(requirements, { url: resource }).accepts,
      },
    };
  }
  const pay = await chargeX402(env, { payTo, price: amt.atomic, description, resource, proof, sold: 'tip' });
  if (!pay.ok) return { status: pay.status, body: pay.body };
  await settlePayment(env, pay.tx, pay.claim, 'delivered').catch(() => {});
  ctx.waitUntil(bump(env, 'tip'));
  return { status: 200, body: {
    ok: true, thanks: 'Thank you! Your tip arrived. With the next sweep half of it buys $BOBAI, held off the market, and half is the project\u2019s revenue.',
    paid: `${fmtUsd1(pay.paid)} ${pay.asset || 'USD1'}`, tx: pay.tx, by: 'BOBAI · https://brainonbnb.com',
  } };
}

// THE POOL SCAN DAY PASS (shared/scan-pass.js, 2026-10-18): the pool scan at brainonbnb.com is free for 1,000 scans per
// caller and UTC day; past that this pass carries on for a day. Sold like the watch — USD1 by EIP-3009 or transfer,
// USDC by standard x402, half in $BOBAI, nothing with the holder pass — and handed back as a string the site checks
// with the secret both workers share.
async function purchaseScanPass(env, ctx, payTo, proof) {
  const usd = Number(SCAN_PASS_PRICE_USD1) / 1e18;
  const bobai = await bobaiForUsd(usd * BOBAI_SHARE).catch(() => null);
  const what = `Pool scan day pass: ${SCAN_PASS_HOURS} hours of bsc_pool_scan past the ${SCAN_FREE_PER_DAY.toLocaleString('en-US')} free a day, up to ${SCAN_PASS_CAP.toLocaleString('en-US')} scans`;
  if (!proof) {
    const resource = SCAN_PASS_URL;
    const requirements = {
      x402Version: 2,
      accepts: [
        eip3009Accepts({ payTo, amountAtomic: SCAN_PASS_PRICE_USD1.toString(), description: what, resource }),
        dexterAccepts({ payTo, amountAtomic: SCAN_PASS_PRICE_USD1.toString(), description: what, resource }),
        {
          scheme: DIRECT_SCHEME, network: NETWORK, asset: USD1, maxAmountRequired: SCAN_PASS_PRICE_USD1.toString(), payTo, resource,
          description: `${what} — direct transfer, then send the transaction hash in PAYMENT-SIGNATURE`,
          ...DIRECT_TERMS, extra: { name: 'World Liberty Financial USD', version: '1', decimals: 18, assetTransferMethod: 'direct-transfer' },
        },
        ...(bobai ? [{
          scheme: DIRECT_SCHEME, network: NETWORK, asset: BOBAI, amount: bobaiSend(bobai), maxAmountRequired: bobaiSend(bobai), min_arrival: bobai.atomic.toString(), payTo, resource,
          description: `${what} — half price in $BOBAI (${(usd * BOBAI_SHARE).toFixed(2)} USD instead of ${fmtUsd1(SCAN_PASS_PRICE_USD1)}): send ${bobai.tokens.toLocaleString('en-US')} BOBAI (the amount at this quote); at least ${Number(bobai.atomic / 10n ** 18n).toLocaleString('en-US')} BOBAI must arrive after the token's transfer tax. Direct transfer, then the transaction hash in PAYMENT-SIGNATURE`,
          ...DIRECT_TERMS, extra: { name: 'BOB', symbol: 'BOBAI', version: '1', decimals: 18, assetTransferMethod: 'direct-transfer', usd_per_bobai: bobai.usd_per_bobai, quoted_at: bobai.quoted_at },
        }] : []),
        // $U by EIP-3009 (2026-10-22, operator's go): last, so every index named elsewhere (accepts[0] USD1 …) stays
        eip3009Accepts({ payTo, amountAtomic: SCAN_PASS_PRICE_USD1.toString(), description: what, resource, asset: U }),
      ],
    };
    return {
      status: 402,
      headers: { 'PAYMENT-REQUIRED': b64(v2Shape(requirements, { url: resource, description: what })), 'Access-Control-Expose-Headers': 'PAYMENT-REQUIRED' },
      body: {
        // the version beside accepts in the body too (2026-11-12): clients that read the body (the v1 response shape) look for it
        x402Version: 2,
        error: 'payment required',
        what: `${what}. The first ${SCAN_FREE_PER_DAY.toLocaleString('en-US')} scans every UTC day stay free without it.`,
        price: `${fmtUsd1(SCAN_PASS_PRICE_USD1)} USD1 (by EIP-3009, accepts[0], or by direct transfer), or the same amount in USDC by standard x402 (accepts[1], Permit2) or in $U by EIP-3009 (the last entry) — every way lands in the same wallet${bobai ? `; or half that in $BOBAI: ${bobai.tokens.toLocaleString('en-US')} $BOBAI by direct transfer (accepts[3])` : ''}`,
        how: `${payWays({ amount: fmtUsd1(SCAN_PASS_PRICE_USD1), payTo, headers: 'PAYMENT-SIGNATURE', direct: `${fmtUsd1(SCAN_PASS_PRICE_USD1)} USD1${bobai ? ` or ${bobai.tokens.toLocaleString('en-US')} $BOBAI` : ''}` })}. POST this URL with no body.`,
        use: 'The answer carries the pass; send it as header X-Scan-Pass on every pool scan (https://brainonbnb.com/api/pool-scan or the MCP tool bsc_pool_scan at https://brainonbnb.com/mcp).',
        ...(bobai ? { in_bobai: { tokens: bobai.tokens, usd_per_bobai: bobai.usd_per_bobai, discount: `half price: ${fmtUsd1(SCAN_PASS_PRICE_USD1)} USD1 or ${bobai.tokens.toLocaleString('en-US')} $BOBAI, worth ${(usd * BOBAI_SHARE).toFixed(2)} USD`, note: '$BOBAI paid here stays in the income wallet as $BOBAI — off the market, never sold.' } } : {}),
        holder_pass: holderPassTerms(),
        accepts: v2Shape(requirements, { url: resource }).accepts,
      },
    };
  }
  if (!env.HIT_SECRET) return { status: 503, body: { error: 'the scan pass cannot be issued right now; nothing was charged' } };
  const pay = await chargeX402(env, {
    payTo, price: SCAN_PASS_PRICE_USD1, description: what, resource: SCAN_PASS_URL, proof, sold: 'scanpass',
    alt: bobai ? { asset: BOBAI, min: bobai.atomic, label: 'BOBAI' } : null,
  });
  if (!pay.ok) return { status: pay.status, body: pay.body };
  const issued = await issueScanPass(env.HIT_SECRET);
  await settlePayment(env, pay.tx, pay.claim, 'delivered').catch(() => {});
  ctx.waitUntil(bump(env, 'scanpass_sold'));
  return { status: 200, body: {
    ok: true,
    pass: issued.pass,
    expires: issued.expires,
    use: `Send header X-Scan-Pass: ${issued.pass} on every pool scan until ${issued.expires} (up to ${SCAN_PASS_CAP.toLocaleString('en-US')} scans): https://brainonbnb.com/api/pool-scan?address=0x… or bsc_pool_scan at https://brainonbnb.com/mcp.`,
    paid: pay.holder ? `nothing — $BOBAI holder pass of ${pay.from}, day pass ${pay.holder.used} of ${pay.holder.of} today` : `${fmtUsd1(pay.paid)} ${pay.asset || 'USD1'}`,
    ...paymentFate(pay),
    tx: pay.holder ? undefined : pay.tx,
  } };
}

async function purchaseWatch(env, ctx, payTo, spec, proof) {
  // Half the price in $BOBAI here too (2026-10-14), as for every answer: a direct transfer, quoted now; without a
  // readable pair the watch is still for sale in USD1 and USDC.
  const bobai = await bobaiForUsd(Number(WATCH_PRICE_USD1) / 1e18 * BOBAI_SHARE).catch(() => null);
  if (!proof) {
    // The 402 itself. accepts[] is an array because a second scheme
    // (eip3009, once a facilitator is in place) will sit beside this one
    // rather than replace it.
    // Three ways to pay the same price into the same wallet, in this order:
    // USD1 signed by EIP-3009, USDC by standard x402 (Permit2) that a stock
    // client can execute unattended, and our own direct transfer, which needs
    // no signature support. A client takes whichever it can do.
    const resource = 'https://agent.brainonbnb.com/watch';
    const requirements = {
      x402Version: 2,
      accepts: [
        eip3009Accepts({ payTo, amountAtomic: WATCH_PRICE_USD1.toString(), description: `Pool watch for ${WATCH_DAYS} days`, resource }),
        dexterAccepts({
          payTo,
          amountAtomic: WATCH_PRICE_USD1.toString(),
          description: `Pool watch for ${WATCH_DAYS} days`,
          resource,
        }),
        {
          scheme: DIRECT_SCHEME,
          network: NETWORK,
          asset: USD1,
          maxAmountRequired: WATCH_PRICE_USD1.toString(),
          payTo,
          resource,
          description: `Pool watch for ${WATCH_DAYS} days — direct transfer, then send the transaction hash in PAYMENT-SIGNATURE`,
          ...DIRECT_TERMS, extra: { name: 'World Liberty Financial USD', version: '1', decimals: 18, assetTransferMethod: 'direct-transfer' },
        },
        ...(bobai ? [{
          scheme: DIRECT_SCHEME, network: NETWORK, asset: BOBAI, amount: bobaiSend(bobai), maxAmountRequired: bobaiSend(bobai), min_arrival: bobai.atomic.toString(), payTo, resource,
          description: `Pool watch for ${WATCH_DAYS} days — half price in $BOBAI (${(Number(WATCH_PRICE_USD1) / 1e18 * BOBAI_SHARE).toFixed(2)} USD instead of ${fmtUsd1(WATCH_PRICE_USD1)}): send ${bobai.tokens.toLocaleString('en-US')} BOBAI (the amount at this quote); at least ${Number(bobai.atomic / 10n ** 18n).toLocaleString('en-US')} BOBAI must arrive after the token's transfer tax. Direct transfer, then the transaction hash in PAYMENT-SIGNATURE`,
          ...DIRECT_TERMS, extra: { name: 'BOB', symbol: 'BOBAI', version: '1', decimals: 18, assetTransferMethod: 'direct-transfer', usd_per_bobai: bobai.usd_per_bobai, quoted_at: bobai.quoted_at },
        }] : []),
        // $U by EIP-3009 (2026-10-22, operator's go): last, so every index named elsewhere (accepts[0] USD1 …) stays
        eip3009Accepts({ payTo, amountAtomic: WATCH_PRICE_USD1.toString(), description: `Pool watch for ${WATCH_DAYS} days`, resource, asset: U }),
      ],
    };
    return {
      status: 402,
      // Exposed, or a browser agent cannot read the header it is told to decode.
      headers: { 'PAYMENT-REQUIRED': b64(v2Shape(requirements, { url: resource, description: `Pool watch for ${WATCH_DAYS} days` })), 'Access-Control-Expose-Headers': 'PAYMENT-REQUIRED' },
      requirements,
      body: {
        // the version beside accepts in the body too (2026-11-12): clients that read the body (the v1 response shape) look for it
        x402Version: 2,
        error: 'payment required',
        what: `Continuous depth monitoring of one BSC pool for ${WATCH_DAYS} days, with a callback when depth falls below a threshold you set.`,
        // Both assets named (2026-09-18): the standard x402 route settles in
        // USDC, the other two in USD1 — a client that budgets off a one-asset
        // sentence holds the wrong token for the other route. In accepts[]
        // order since 2026-10-05 (payWays). This POST reads PAYMENT-SIGNATURE only.
        price: `${fmtUsd1(WATCH_PRICE_USD1)} USD1 (by EIP-3009, accepts[0], or by direct transfer), or the same amount in USDC by standard x402 (accepts[1], Permit2; a stock client must allow USDC on eip155:56 in spendControls.allowedAssets) or in $U by EIP-3009 (the last entry) — every way lands in the same wallet${bobai ? `; or half that in $BOBAI: ${bobai.tokens.toLocaleString('en-US')} $BOBAI by direct transfer (accepts[3])` : ''}`,
        how: `${payWays({ amount: fmtUsd1(WATCH_PRICE_USD1), payTo, headers: 'PAYMENT-SIGNATURE', direct: `${fmtUsd1(WATCH_PRICE_USD1)} USD1${bobai ? ` or ${bobai.tokens.toLocaleString('en-US')} $BOBAI` : ''}` })}.`,
        ...(bobai ? { in_bobai: { tokens: bobai.tokens, usd_per_bobai: bobai.usd_per_bobai, discount: `half price: ${fmtUsd1(WATCH_PRICE_USD1)} USD1 or ${bobai.tokens.toLocaleString('en-US')} $BOBAI, worth ${(Number(WATCH_PRICE_USD1) / 1e18 * BOBAI_SHARE).toFixed(2)} USD`, note: '$BOBAI paid here stays in the income wallet as $BOBAI — off the market, never sold.' } } : {}),
        needs: { token: 'the token to watch (0x…)', pair: 'optional: the PancakeSwap V2 pair or V3 pool (0x…); left out, its V2 pair is found from the token and the quote', quote: 'optional: the quote token, WBNB by default', depthBelowUsd: 'fire the callback when the pool can no longer absorb this USD size at 1% impact', callback: 'an https URL we POST to' },
        example: { token: '0x…', depthBelowUsd: 1000, callback: 'https://…' },
        read_back: 'GET /watch/<id> — returned to you when the purchase settles',
        holder_pass: holderPassTerms(),   // hold the $BOBAI line, watch without paying (holder-pass.js, 2026-10-16)
        free_alternative: 'https://brainonbnb.com/api/pool-scan?address=0x… — one reading, no payment (1,000 scans per caller a day), no watching',
        accepts: v2Shape(requirements, { url: resource }).accepts,
      },
    };
  }

  // The payment half is shared with the per-answer sale above; the proof is
  // marked spent before the watch exists, for the reason given there.
  const pay = await chargeX402(env, {
    payTo, price: WATCH_PRICE_USD1, description: `Pool watch for ${WATCH_DAYS} days`,
    resource: 'https://agent.brainonbnb.com/watch', proof, sold: 'watch',
    alt: bobai ? { asset: BOBAI, min: bobai.atomic, label: 'BOBAI' } : null,
  });
  if (!pay.ok) return { status: pay.status, body: pay.body };
  const tx = pay.tx, check = { paid: pay.paid, from: pay.from, asset: pay.asset || 'USD1' };

  // The watch is the goods: created, the payment is delivered and final; a
  // creation that throws leaves the buyer a credit on the same hash.
  let watch;
  try { watch = await createWatch(env, spec, { tx, from: check.from }); }
  catch (e) {
    await settlePayment(env, tx, pay.claim, 'credit', { failed: String(e.message || e).slice(0, 120) }).catch(() => {});
    await env.AGENT.delete(`earn:${tx}`).catch(() => {});
    return { status: 422, body: { error: `the watch could not be created: ${String(e.message || e).slice(0, 200)}`, payment: 'not consumed — repeat with the same payment once the input is fixed' } };
  }
  await settlePayment(env, tx, pay.claim, 'delivered').catch(() => {});
  ctx.waitUntil(bump(env, 'watch_created'));

  // Anything the caller sent that this endpoint does not read is named back
  // to them. The first paid request in the service's life passed
  // "threshold_pct", which is not a field here — it was swallowed in
  // silence, and the watch was created with no threshold at all. It would
  // have run for thirty days, never fired, and looked like it was working.
  // A caller who mistypes a field has to be told, or they are paying for
  // something they did not ask for.
  const KNOWN = new Set(['token', 'pair', 'quote', 'depthBelowUsd', 'callback']);
  const ignored = Object.keys(spec || {}).filter((k) => !KNOWN.has(k) && !['pair_found', 'kind', 'fee'].includes(k));   // kind/fee: read from a V3 pool, not sent

  return { status: 200, body: {
    ok: true,
    watch: watch.id,
    expires: new Date(watch.expiresAt).toISOString(),
    watching: { token: watch.token, pair: watch.pair, ...(watch.kind === 'v3' ? { pool: `PancakeSwap V3 ${watch.fee / 10000}%` } : {}), depthBelowUsd: watch.depthBelowUsd, ...(spec && spec.pair_found ? { pair_note: 'found from the token: its PancakeSwap V2 pair with ' + (watch.quote === WBNB ? 'WBNB' : watch.quote) } : {}) },
    callback: watch.callback ? 'will POST on trigger' : 'none set — read it back at the url below',
    // Spelled out, not left as a pattern to fill in. This is the only copy of
    // the id the buyer will ever be handed.
    read_back: `https://agent.brainonbnb.com/watch/${watch.id}`,
    paid: pay.holder ? `nothing — $BOBAI holder pass of ${pay.from}, watch ${pay.holder.used} of ${pay.holder.of} today` : `${fmtUsd1(check.paid)} ${check.asset}`,
    ...paymentFate(pay),
    // Stated rather than implied: a watch with no threshold records depth
    // and never alerts, which is a legitimate thing to want and a terrible
    // thing to receive by accident.
    ...(watch.depthBelowUsd == null ? {
      alerting: 'OFF — no depthBelowUsd was given, so this watch records depth but will never fire. Send depthBelowUsd (a number, in USD) to be alerted when the pool falls below it.',
    } : {}),
    ...(ignored.length ? {
      ignored_fields: ignored,
      ignored_note: 'These were not recognised and had no effect. The fields this endpoint reads are: token, pair, quote, depthBelowUsd, callback.',
    } : {}),
  } };
}

// The series as /lp/series serves it, built once so the portfolio can carry
// the same summary without a request to ourselves (a worker cannot fetch
// its own hostname).
async function buildLpSeries(env) {
      const series0 = lpSeriesShown(await readLpSeries(env));
      // With the archive (readAgentRecord): the totals are sums over the whole
      // history, and the bare key keeps only the newest 200 runs.
      const recAll = await readAgentRecord(env).catch(() => null);
      // Capital the operator put in by hand (record.capital_added, written
      // by hand too): it is in the position's value from that run on but is
      // not a gain, so every point carries the total added up to it and the
      // amount that arrived between the previous point and this one.
      const added = recAll ? (recAll.capital_added || []) : [];
      const series = series0.map((p, i) => {
        const upTo = added.filter((a) => Date.parse(a.at) <= Date.parse(p.at));
        const prevAt = i ? Date.parse(series0[i - 1].at) : -Infinity;
        const here = added.filter((a) => Date.parse(a.at) <= Date.parse(p.at) && Date.parse(a.at) > prevAt);
        const tot = upTo.reduce((x, a) => x + Number(a.bnb || 0), 0);
        return tot ? { ...p, capital_added_total_bnb: +tot.toFixed(6), ...(here.length ? { capital_added_here_bnb: +here.reduce((x, a) => x + Number(a.bnb || 0), 0).toFixed(6), capital_added_note: here.map((a) => a.note).filter(Boolean).join(' · ') } : {}) } : p;
      });
      // Every point carries the capital that was in it — the first value, what
      // the operator added by hand, what the deposit watch put in — and the
      // value against that capital. The page's "since start" column divided
      // by the first point alone and read +196% on the day the trader's BNB
      // arrived (2026-09-10: "das ist kein profit").
      const base = series.find((p) => p.value_bnb != null);
      const withCapital = series.map((p) => {
        if (!base || p.value_bnb == null) return p;
        const deposits = Math.max(0, (Number(p.into_position_total_bnb) || 0) - (Number(p.swept_total_bnb) || 0) - Math.max(0, (Number(p.kept_total_bnb) || 0) - (Number(p.folded_kept_total_bnb) || 0) - (Number(p.kept_waiting_bnb) || 0)));
        const capital = +(Number(base.value_bnb) + (Number(p.capital_added_total_bnb) || 0) + deposits).toFixed(6);
        return { ...p, capital_bnb: capital, on_capital_pct: capital > 0 ? +(((p.value_bnb - capital) / capital) * 100).toFixed(2) : null };
      });
      const liveFlow = recAll ? moneyFlow(recAll) : null;
      // The gas the profit takes off: not the part the collects' fees are
      // already net of (D5). The whole bill stays in the flow as gas.bnb.
      const gas_bnb = liveFlow ? (liveFlow.gas.to_subtract_bnb ?? liveFlow.gas.bnb) : null;
      const totals = liveFlow ? {
        bobai_spent_total_bnb: liveFlow.out.bobai_bnb,
        bobai_units_total: liveFlow.out.bobai_units,
        operator_total_bnb: liveFlow.out.operator_bnb || 0,
        forwarded_total_bnb: liveFlow.out.bobai_bnb,
        kept_total_bnb: liveFlow.out.kept_as_capital_bnb,
        fees_total_bnb: liveFlow.in.fees.bnb,
        folded_total_bnb: liveFlow.in.fees.folded_bnb || 0,
        folded_kept_total_bnb: liveFlow.in.fees.folded_kept_bnb ?? (liveFlow.in.fees.folded_bnb || 0),
        into_position_total_bnb: liveFlow.out.into_position_bnb || 0,
        swept_total_bnb: liveFlow.in.income_bnb,
        kept_waiting_bnb: liveFlow.waiting.kept_fees_bnb || 0,
      } : null;
      // Fees owed now, from the chain: the last point is often a re-set, whose
      // own figure is zero by construction, while the liquidity page shows the
      // live figure two lines below the profit — the two must agree.
      // ... and the value now, from the same look. The totals are live (the
      // record's own flow), so the value they are set against must be live
      // too: at 12:24 UTC on 2026-09-10 the deposit watch had just put 0.2963
      // BNB in, the flow counted it, the last point (05:40) did not, and the
      // summary read a profit of −50%. The position looked at is the one the
      // record names now, not the last point's — that one may be burned.
      let owed_now_bnb = null, value_now_bnb = null;
      const lastPt = series[series.length - 1];
      const recNow = recAll;
      const chk = recNow && recNow.last_check && recNow.last && Date.parse(recNow.last_check.at) >= Date.parse(recNow.last.at) ? recNow.last_check : recNow && recNow.last;
      const livePos = (chk && chk.steps && ((chk.steps.increase && chk.steps.increase.position) || (chk.steps.rebalance && chk.steps.rebalance.new_position))) || (lastPt && lastPt.position) || null;
      if (livePos) {
        try {
          const lk = await lpPositionLook({ position: String(livePos) });
          if (lk && lk.fees_owed && lk.fees_owed.bnb_equivalent != null) owed_now_bnb = Number(lk.fees_owed.bnb_equivalent);
          if (lk && lk.value_bnb != null && Number(lk.value_bnb) > 0) value_now_bnb = +Number(lk.value_bnb).toFixed(6);
          // The ladder's reserve range is capital too (2026-09-17): the flow
          // counts the BNB that opened it as put in, and the points carry it in
          // their value, so the live value must as well — without it the card
          // read the 0.041 BNB reserve as a loss, 2.7% of the capital. The
          // ladder record (worker-lp, KV lp:ladder) names it; a reserve that
          // cannot be read leaves the live figures unknown rather than short.
          const ladderRaw = value_now_bnb != null ? await env.AGENT.get('lp:ladder') : null;
          const reserveId = ladderRaw ? (JSON.parse(ladderRaw) || {}).reserve : null;
          if (reserveId != null && String(reserveId) !== String(livePos)) {
            const rk = await lpPositionLook({ position: String(reserveId) });
            if (rk && rk.value_bnb != null) {
              value_now_bnb = +(value_now_bnb + Number(rk.value_bnb)).toFixed(6);
              if (owed_now_bnb != null && rk.fees_owed && rk.fees_owed.bnb_equivalent != null) owed_now_bnb += Number(rk.fees_owed.bnb_equivalent);
            } else { owed_now_bnb = null; value_now_bnb = null; }
          }
        } catch { owed_now_bnb = null; value_now_bnb = null; }
      }
      return {
        what_this_is: 'One point per run of the DeFi agent, taken from its own record: position value in BNB, in range or not, fees owed, fees already put into $BOBAI the agent holds (until 2026-09-09: sent to the buyback bot) and kept as capital, income already put in, and the profit so far netted against the gas on record. Not a counter; every figure is in the record it came from.',
        summary: lpSeriesSummary(withCapital, { gas_bnb, owed_now_bnb, totals, value_now_bnb, time_in_range: lpTimeInRange(withCapital, await readLpTicks(env)) }),
        points: withCapital,
        record: 'https://agent.brainonbnb.com/lp/agent',
        cadence: 'daily, after the 04:23 UTC run; the range itself is checked every hour, and a run between them — an hourly check or the deposit watch — gets a point of its own when it acted (a re-set, a top-up from a deposit) or found a position the series did not know. A run that found no position is not a point',
      };
}

// The pool record, retired on 2026-09-11: the operator closed the question
// it measured for a day. The agent stays in CAKE/BNB 0.05% (HOME_POOL);
// the route says so, in JSON and on the page, and points at the records
// that still decide something.
const LP_POOLS_RETIRED = {
  retired: '2026-09-11',
  pool: HOME_POOL.pool, label: HOME_POOL.label,
  why: HOME_POOL.why,
  what_it_was: 'for one day (2026-09-10) the same fifty dollars were replayed hourly in twelve PancakeSwap V3 pools that pair WBNB with a major, and a switch rule weighed a move; the finding was in gross fees, and a move costs two re-sets plus what the range lost against holding',
  width_record: 'https://agent.brainonbnb.com/lp/windows',
  agent_record: 'https://agent.brainonbnb.com/lp/agent',
};

// The width record's verdict with the agent's own measured re-set cost —
// the same figure worker-lp charges, from the same record — built once for
// /lp/windows and the portfolio alike.
async function lpWidthVerdict(env) {
  return widthVerdict(env, await bnbUsd().catch(() => null));
}

// THE FREE HALF, ONE PLACE (2026-10-15): the reading each agent gives away — the DeFi agent's look at a position, the
// Venus health factor of an account, the Venus supply rates — for its MCP tool and for a question over A2A. The cards
// promise "give me a position and I return whether it is in range"; over A2A that question got a price and a link.
// Returns { figures, out } (figures: what a checker compares, also at the top of out) or null when there is no
// free half for this agent or the input it needs is missing. defaultOwn: no position named = this agent's own.
export async function freeHalf(slug, a = {}, env, { defaultOwn = false, text = '' } = {}) {
  // the fee-tier agent is filed under rebalancing, so checkers ask it for a range check of positions: that question
  // (and only that one — a token's fee tiers stay its own offer) is answered with the same reading of the chain
  // the portfolio pricer is filed under rebalancing too (2026-10-15, Mandate: "states neither whether the position is in
  // range nor the pool's tick"): the same question gets the same reading, and only that question
  if (slug === 'lp-placement' || slug === 'rebalancer') return /\bpositions?\b|\brange\b/i.test(text) && /0x[a-fA-F0-9]{40}|\b\d{5,}\b/.test(text) ? freeHalf('defi-agent', { position: String(text).match(/\b(?:#|position\s*)(\d{5,})\b/i)?.[1], address: String(text).match(/0x[a-fA-F0-9]{40}/)?.[0] }, env) : null;
  const addrOf = (...v) => v.map((x) => String(x ?? '').match(/0x[a-fA-F0-9]{40}/)?.[0]).find(Boolean) || null;
  if (slug === 'defi-agent') {
    const pos = String(a.position ?? a.tokenId ?? a.token_id ?? '').trim(), addr = addrOf(a.address, a.wallet, a.owner);
    // A NAMED INPUT THAT IS NOT ONE IS REFUSED (2026-11-12: {"position":"abc"} read "no position was named" and handed
    // back our own position); only an empty call gets the position this agent runs itself
    const named = pos !== '' || [a.address, a.wallet, a.owner].some((v) => String(v ?? '').trim() !== '');
    if (named && !/^\d+$/.test(pos) && !addr) throw new Error('position: a PancakeSwap V3 position id, digits only, e.g. {"position":"7637521"}; or a wallet that holds one, e.g. {"address":"0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A"}');
    if (!/^\d+$/.test(pos) && !addr && !defaultOwn) return null;
    const q = /^\d+$/.test(pos) ? { position: pos } : addr ? { address: addr } : { address: OWN_LP_WALLET };
    const look0 = await lpPositionLook(q, env);
    // A WALLET WITH SEVERAL POSITIONS IS READ POSITION BY POSITION (2026-10-15): Mandate asks "range check ... for the
    // positions of 0x54c0…" (a wallet with five) and got only their ids back — 'states neither whether the position is
    // in range nor the pool's tick'. Each one (up to ten) is read from the chain now, in the words its own Range-1 uses too.
    if (Array.isArray(look0?.position_ids) && look0.position_ids.length > 1) {
      const ids = look0.position_ids.slice(0, 10);
      const each = await Promise.all(ids.map((id) => lpPositionLook({ position: id }, env).catch((e) => ({ position: id, error: String(e.shortMessage || e.message || e).slice(0, 160) }))));
      const positions = each.map((l, k) => l?.pool ? { position: l.position ?? ids[k], pool: l.pool.address, fee_tier_pct: l.pool.fee_tier_pct ?? null, in_range: l.in_range ?? null, current_tick: l.pool.tick ?? null, tick_lower: l.pool.ticks?.[0] ?? null, tick_upper: l.pool.ticks?.[1] ?? null, inRange: l.in_range ?? null, tick: l.pool.tick ?? null, room: l.room ?? null, value_bnb: l.value_bnb ?? null, verdict: l.verdict } : { position: ids[k], error: l?.error || l?.verdict || 'not readable' });
      const inR = positions.filter((x) => x.in_range === true).length, outR = positions.filter((x) => x.in_range === false).length;
      const figures = { positions };
      return { figures, out: { address: look0.address, positions_held: look0.position_ids.length, ...figures, verdict: `${look0.position_ids.length} PancakeSwap V3 positions; ${ids.length < look0.position_ids.length ? `the first ${ids.length} read: ` : ''}${inR} in range, ${outR} out of range.`, service: 'lp_position_look', measured_at: new Date().toISOString(), source: 'PancakeSwap V3 NonfungiblePositionManager and each pool itself, read live' } };
    }
    const figures = look0?.pool ? { ...(look0.position != null ? { position: look0.position } : {}), in_range: look0.in_range ?? null, current_tick: look0.pool.tick ?? null, tick_lower: look0.pool.ticks?.[0] ?? null, tick_upper: look0.pool.ticks?.[1] ?? null } : {};
    const out = { ...(!/^\d+$/.test(pos) && !addr ? { input: `no position was named: this is the position this agent runs itself (wallet ${OWN_LP_WALLET})` } : {}), ...figures, ...look0 };
    return { figures, out };
  }
  if (slug === 'health-factor') {
    const acct = addrOf(a.address, a.account, a.wallet, a.owner);
    if (!acct) return null;
    const position = await healthFactor(acct);
    const figures = { health_factor: position.health_factor ?? null };
    return { figures, out: { ...figures, account: acct, position } };
  }
  // THE GRID PLANNER'S FREE HALF (2026-10-15): Mandate asks every grid agent "a grid for WBNB/USDT 8% either side,
  // 1,000 USD, 10 levels" and compares the levels with the bounds, their count, their order and the allocations with
  // the capital; ours answered with a price and a link ("the answer is not data we can read"). The levels and their
  // allocations are given away — arithmetic on the live price; what a cycle costs on the pool (break-even spacing,
  // viability, warnings) stays the paid half.
  if (slug === 'grid-trader') {
    const p = { ...understand(SERVICES.grid_plan, text), ...Object.fromEntries(['token', 'address', 'levels', 'bandPct', 'capitalUsd'].filter((k) => a[k] != null).map((k) => [k, a[k]])) };
    const token = addrOf(p.token, p.address);
    if (!token) return null;
    const plan = await gridPlan({ token, levels: p.levels, bandPct: p.bandPct, capitalUsd: p.capitalUsd });
    const g = plan.grid;
    const figures = {
      ...checkedFigures('grid_plan', { plan }),
      // asked "with a stop": one grid step below the lowest buy, where the ladder runs out — the buyer's to move
      ...(/\bstop/i.test(text) ? { stop_price: +(g.lower_price / (1 + g.spacing_pct / 100)).toPrecision(8) } : {}),
    };
    return { figures, out: { ...figures, token: plan.token, pool: plan.pool, band_pct: g.band_pct, spacing_pct: g.spacing_pct, price_now_usd: plan.token.price_usd, order: 'ascending price', paid_half_adds: 'the round-trip cost of a cycle on this pool (swap fee, price impact at the fill size, transfer tax from executed trades), the break-even spacing and whether this grid can make money at all', measured_at: plan.measured_at, source: plan.source } };
  }
  if (slug === 'yield-optimizer') {
    const plan = await yieldPlan({});
    const figures = checkedFigures('yield_plan', { plan });
    return { figures, out: { ...figures, ranked: (plan.ranked || []).map((m) => ({ symbol: m.symbol, supply_apy_pct: m.supply_apy_pct, borrow_apy_pct: m.borrow_apy_pct, utilisation_pct: m.utilisation_pct })), measured_at: plan.measured_at } };
  }
  return null;
}

// What each hiring agent read itself, to stand beside the outside answer: the health factor of the Venus loan from
// this morning's run, and the DeFi agent's position id (agent-hires.js).
async function hireContext(env) {
  const vlog = await readVenusLog(env).catch(() => []);
  const hf = (vlog || []).map((x) => String(x.note || '').match(/^health factor (?:now )?([\d.]+)/)).find(Boolean);
  const pf = await env.SELF.fetch('https://agent.brainonbnb.com/lp/portfolio').then((r) => r.json()).catch(() => null);
  const position = pf?.position?.position ?? String(JSON.stringify(pf || {}).match(/"position":"?(\d+)/)?.[1] || '');
  // the yield agent's size, coin and rate from its own deposits (venus-work.js log: "2 USDC to Venus vUSDC at 2.82 % …"),
  // for a seller whose brief asks for them (Sluicegate, 2026-10-23)
  const deps = (vlog || []).filter((x) => x.agent === 304493 && x.action === 'deposit');
  const coin = String(deps[0]?.amount || '').split(' ')[1] || null;
  const size = coin ? deps.filter((x) => String(x.amount).endsWith(' ' + coin)).reduce((s, x) => s + (parseFloat(x.amount) || 0), 0) : 0;
  const apr = String(deps[0]?.why || '').match(/at ([\d.]+) %/)?.[1] || null;
  return { 302257: { own: hf ? { hf: Number(hf[1]) } : null }, 304493: size > 0 && apr ? { size, coin, apr } : {}, 363709: { position, own: pf?.pool ? { in_range: pf.pool.in_range } : null } };
}

export default {
  async fetch(request, env, ctx) {
    bindSelf(env);
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, '') || '/';
    // Names a step of the paid path for /stats/detail (bumpDetail). Our own
    // smoke test says who it is and is left out, as on the dashboard worker.
    const selfTest = request.headers.get('user-agent') === 'bobai-smoke-test';
    // WHO ASKS THE PRICE (2026-10-23): ~40 terms a day on each answer and 143 on the scan pass, next to no payment —
    // a terms step also counts sellua:<product> (the user agent's first word, letters only, no version, as the site's
    // poolscanua), so an indexer polling the 402s is told apart from a buyer that stops at the price.
    const uaProduct = (String(request.headers.get('user-agent') || '').match(/^[A-Za-z][A-Za-z0-9._-]{0,23}/)?.[0] || 'none').toLowerCase();
    // OUR OWN PAGES ARE NO BUYER (2026-10-25): the Classic page reads /scan-pass for its price on every visit, and that
    // counted as 231 "sell:scanpass:terms" a day from Mozilla — a price our visitors' browsers asked, not an agent. A
    // request from brainonbnb.com is counted under own:<step>, so sell:<step> is what others asked.
    // OUR OWN CHECKERS ARE NO BUYER EITHER (2026-11-03): the checks in scripts/ and temp/newpage/qa name themselves
    // brainonbnb-<check> (x402-noinput-check sends a broken proof on purpose, eight a day), and all of it counted as
    // others: a week showed 85 "paid:402" that were our own tests, and agent-status called them use. Counted as own: now.
    // Only ever a label for counting: anyone can send this user agent, and all it buys them is being left out of the counts.
    const ownSite = fromOurSite(request), ownCheck = /^(brainonbnb|bobai|plaza-board)-/i.test(String(request.headers.get('user-agent') || ''));   // plaza-board-checkup: the board's own checkup (4.11.)
    const note = (name) => { if (!selfTest) ctx.waitUntil(Promise.resolve(bumpDetail(env, ownSite || ownCheck ? `own:${name}` : /:terms$/.test(name) ? [name, `sellua:${uaProduct}`] : name)).catch(() => {})); };
    // A PAYMENT THAT DID NOT BUY (2026-10-25): on 24.10. eight payments came back 402 on two answers and nothing said
    // why — the counter kept the status, not the reason. Each one is kept now (the last 20, 14 days, KV payrefused):
    // the product, the status, the reason the paying path answered, the caller's user agent and the proof's shape
    // (proofShape) — never the proof. Read at GET /buys/refused. Only written after the path has answered.
    const missed = (product, proof, out) => {
      if (selfTest || !proof || !out || out.status === 200 || !env.AGENT) return;
      // the zero hash is /services' own dry probe before a $BOBAI payment ("does it need more input?"), not a payment (5.11.)
      if (/^0x0{64}$/.test(String(proof).trim())) return;
      const b = out.body && typeof out.body === 'object' ? out.body : {};
      const rec = { at: new Date().toISOString(), product, status: out.status, why: [b.stage, b.reason || b.error].filter(Boolean).map(String).join(': ').slice(0, 240),
        ua: String(request.headers.get('user-agent') || '').slice(0, 80), proof: proofShape(proof), ...(payerOf(proof) ? { from: payerOf(proof) } : {}), ...(ownSite ? { own_site: true } : {}),
        // our own checks name themselves brainonbnb-… / bobai-… (2026-10-28: five of x402-noinput-check stood here as a stranger)
        ...(/^(brainonbnb|bobai)-/i.test(String(request.headers.get('user-agent') || '')) ? { self_test: true } : {}) };
      ctx.waitUntil(env.AGENT.get('payrefused', 'json').then((l) => env.AGENT.put('payrefused', JSON.stringify([rec, ...(Array.isArray(l) ? l : [])].slice(0, 20)), { expirationTtl: 1209600 })).catch(() => {}));
    };
    // WHAT A CHECKER SENDS OVER A2A (2026-10-15): Mandate checks each agent from "its free call" and calls our answers
    // "not data we can read", but the free MCP tools were not called and A2A was not counted. Each A2A POST is counted
    // (a2a:<agent>:<method>:<part kinds>) and the last ten, cut to 1500 characters, are kept 3 days in KV a2a-seen:<agent>.
    const seenA2A = (req, slug) => {
      if (selfTest) return;
      const copy = req.clone();
      ctx.waitUntil((async () => {
        const raw = await copy.text().catch(() => '');
        let j = null; try { j = JSON.parse(raw); } catch {}
        const kinds = (j?.params?.message?.parts || []).map((x) => x?.kind || x?.type || '?').join('+') || 'none';
        // our own checks over A2A under own: too (4.11.: plaza-board-checkup and brainonbnb-* stood among the others)
        bumpDetail(env, `${ownCheck ? 'own:' : ''}a2a:${slug}:${String(j?.method || 'nomethod').slice(0, 30)}:${kinds.slice(0, 30)}`);
        if (!env.AGENT) return;
        const key = `a2a-seen:${slug}`;
        const list = (await env.AGENT.get(key, 'json').catch(() => null)) || [];
        list.unshift({ at: new Date().toISOString(), ua: (req.headers.get('user-agent') || '').slice(0, 120), body: raw.slice(0, 1500) });
        await env.AGENT.put(key, JSON.stringify(list.slice(0, 10)), { expirationTtl: 259200 });
        // the rest, apart (2026-10-22): Marque's probe every 13 minutes and Mandate's daily calls pushed Pokter's price
        // request out of the ten within the hour, and its sweep marked two agents "seller-declined" with no copy left
        if (!/marque-quote-probe|mandatemarkets/i.test(raw)) {
          const k2 = `a2a-seen-other:${slug}`;
          const l2 = (await env.AGENT.get(k2, 'json').catch(() => null)) || [];
          l2.unshift(list[0]);
          await env.AGENT.put(k2, JSON.stringify(l2.slice(0, 10)), { expirationTtl: 604800 });
        }
      })().catch(() => {}));
    };

    // THE OPERATOR'S PICKS ON THE BUILDER PAGE (2026-10-25, operator: "Häkchen für ja und Kreuzchen für nein … wenn gemacht,
    // sage ich es dir und du siehst es"): brainonbnb.com/builder (behind its password) passes each click on with the
    // operator's secret; one KV value, a pick per clip ({code, choice ok|no, at}); choice null takes a pick back
    if (path === '/builder/decide') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      const picks = JSON.parse((await env.AGENT.get('builder:decide')) || '{}');
      if (request.method === 'POST') {
        const p = await request.json().catch(() => ({})), clip = String(p.clip || ''), choice = p.choice ?? null;
        if (!/^[a-z0-9-]{1,60}$/.test(clip) || !['ok', 'no', null].includes(choice)) return json({ error: 'clip, and choice ok, no or null' }, 400);
        if (choice === null) delete picks[clip]; else picks[clip] = { code: String(p.code || '').slice(0, 8), choice, at: new Date().toISOString() };
        await env.AGENT.put('builder:decide', JSON.stringify(picks));
      }
      return json({ picks });
    }
    // THE PLAZA BOARD (2026-10-23): agents and platforms tell each other bugs, fixes and tips; board.js
    if (path === '/join' || path === '/board' || path === '/board.md' || path === '/board.atom' || path.startsWith('/board/')) {
      note(`board:${request.method}`);
      // WHAT IS READ, AND BY WHAT (2026-11-15): ~1,250 outside GETs a day stood as one number, so nobody could say whether
      // agents read the threads or a crawler walks the page. The kind of path (never an id) and the software's first word.
      if (!(ownSite || ownCheck || selfTest)) {
        const seg = path.split('/')[2] || '', kind = path === '/join' ? 'join' : path === '/board' ? 'page' : path === '/board.md' ? 'md' : path === '/board.atom' ? 'atom' : /^\d+$/.test(seg) ? 'thread' : seg.toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 16) || 'root';
        ctx.waitUntil(Promise.resolve(bumpDetail(env, [`boardpath:${request.method.toLowerCase()}:${kind}`, `boardua:${uaProduct}`])).catch(() => {}));
      }
      return await handleBoard(request, env, path, url, ctx);
    }

    if (request.method === 'OPTIONS')
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          // DELETE and x-rug-watch-secret: cancelling a rug watch (2026-10-09).
          'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
          // x-operator-token: the revoke route's lock (session-revoke.js). A
          // header the preflight does not name is a fetch the browser refuses
          // before it leaves the page — "Failed to fetch", no status, no body.
          // The MCP ones (2026-10-05): this preflight answers for /mcp too, so a browser MCP client was refused here.
          'Access-Control-Allow-Headers': 'Content-Type,PAYMENT-SIGNATURE,X-PAYMENT,x-operator-token,x-rug-watch-secret,Mcp-Protocol-Version,Mcp-Session-Id,Authorization,Accept,X-BOBAI-Thanks',
        },
      });

    const payTo = env.X402_WALLET;

    // The catalogue. Reads the same payTo and price the 402 below quotes, so
    // the two cannot disagree — an agent that budgets from this file and then
    // calls /watch finds exactly the terms it was promised.
    if (path === '/.well-known/x402') {
      note('sell:catalog');
      return json(buildCatalog({
        payTo,
        price: `${fmtUsd1(WATCH_PRICE_USD1)} USD1`,
        days: WATCH_DAYS,
        asset: USD1,
        network: NETWORK,
      }), 200, { 'Cache-Control': 'public, max-age=300' });
    }

    // Browsers ask for this on every HTML page this worker serves (/job,
    // /sessions, /lp/agent) and got a 404 in the console each time. One icon,
    // the site's own.
    if (path === '/favicon.ico') {
      return Response.redirect('https://brainonbnb.com/favicon.png', 301);
    }
    // The A2A card and every hire link point agents at this host; an agent
    // that then asks this host for llms.txt got a 404 until 2026-09-12.
    if (path === '/llms.txt') return Response.redirect('https://brainonbnb.com/llms.txt', 302);

    if (path === '/') {
      return json({
        service: 'Brain On BNB AI — agent service',
        what_this_is: 'The agent service of Brain On BNB: six measured answers sold per answer over x402 (POST /answer?service=…), the same work sold through the ERC-8183 escrow (GET /hire), a broker over the ERC-8004 registry (GET /find, POST /dispatch), paid pool monitoring, the DeFi agent\'s own records (/lp/*) and the public counters behind brainonbnb.com. Measurement only — nothing here is financial advice.',
        capabilities: offering(),
        payment: {
          protocol: 'x402', network: NETWORK, payTo,
          // What a 402 here accepts, in the order the accepts[] carries it.
          accepts: ['answers: USD1 by EIP-3009 (accepts[0], signed TransferWithAuthorization in X-PAYMENT or PAYMENT-SIGNATURE, settled by us at once)', 'USDC by standard x402 (Permit2), settled by us within ten minutes', 'USD1 by direct transfer, transaction hash in PAYMENT-SIGNATURE', '$BOBAI by direct transfer, at the quote in the 402'],
          asset: USD1, symbol: 'USD1',
        },
        start_here: { find: 'https://agent.brainonbnb.com/find?q=venus+health+factor', example_answer: 'https://agent.brainonbnb.com/example?service=health_factor', hire: 'https://agent.brainonbnb.com/hire?agent=302257&task=health+factor', card: 'https://agent.brainonbnb.com/.well-known/agent.json' },
        transparency: 'https://agent.brainonbnb.com/stats',
      });
    }

    // The A2A discovery card, on the origin the hireable agents live on.
    //
    // This host answered 404 here, and #302257 and #304493 name this exact URL
    // on-chain as one of their endpoints — a dead link written into the
    // registration of the agents built to be discovered. Worse, it is the path
    // our OWN marketplace fetches to resolve a stranger's agent
    // (cardEndpoint() in hire.js): we required of everyone else a file we did
    // not serve.
    //
    // The card on brainonbnb.com is a different thing and stays as it is: it
    // describes the free public tools and points at the website. It names no
    // negotiation skill and none of the four hireable services, so an indexer
    // reading it learns that we sell nothing.
    //
    // Skills are derived from SERVICES rather than listed again, because a card
    // advertising a service the seller does not implement is the failure this
    // whole project keeps documenting in other people's agents.
    // Both spellings (2026-09-18): agent.json is what the BNB reference agents
    // serve and what our own dispatcher tries first on strangers, and GET /
    // pointed at it here while it returned 404.
    // THE FIVE, EACH WITH ITS OWN CARD AND ENDPOINT (2026-10-04): the shared
    // /a2a card ("hireable agents", nine skills) matched none of their
    // registrations, and 8004scan graded all five "broken" while the DeFi Agent
    // with its own card read "healthy". Same shape as the DeFi Agent's below:
    // name = the registration's name, one service, its own id.
    {
      const m = path.match(/^\/(health-factor|grid-trader|yield-optimizer|rebalancer|lp-placement)(\/a2a)?(\/\.well-known\/agent(-card)?\.json)?$/);
      if (m) {
        const slug = m[1], card = OWN_CARDS[slug], s = SERVICES[AGENT_SERVICE[slug]];
        if (request.method === 'POST' && m[2] && !m[3]) { seenA2A(request, slug); return await handleA2A(request, env, { agent: slug, freeHalf: (q, t) => freeHalf(slug, q, env, { text: t }) }); }
        return json({
          protocolVersion: '0.3.0',
          name: card.name,
          description: s.deliverables,
          url: `${SELF_ORIGIN}/${slug}/a2a`,
          preferredTransport: 'JSONRPC',
          version: '1.0.0',
          category: s.category,
          provider: { organization: 'Brain On BNB AI', url: 'https://brainonbnb.com' },
          capabilities: { streaming: false, pushNotifications: false, stateTransitionHistory: false },
          registrations: [{ agentId: card.id, agentRegistry: AGENT_REGISTRY }],
          supportedTrust: ['reputation'],
          trustRegistries: TRUST_REGISTRIES,
          defaultInputModes: ['application/json', 'text/plain'],
          defaultOutputModes: ['application/json'],
          skills: [
            // NAMED FOR THE WORK, WITH A BRIEF TO START FROM (2026-10-22): Pokter asks every agent for a price from its
            // card's examples and shows a skill called "Negotiate an ERC-8183 job" as plumbing. Without an example the
            // rebalancer and the fee tier agent were sent a brief they could not quote (no holdings, no token) and Pokter
            // marked them seller-declined. Each example below is quoted and signed by its agent as it stands (quote-examples-check).
            { id: 'negotiate-erc8183-job', name: `Quote: ${s.name}`, description: 'Send a data part {"skill":"negotiate-erc8183-job","task_description":"…","terms":{"deliverables":"…","quality_standards":"…"}} and receive a wallet-signed quote (price, currency, negotiation_hash, provider_sig). Anchor it via createJob and fund it, then send notify_funded with the job_id and delivery starts at once; without it the agent finds the funded job on the chain within 15 minutes and delivers.', tags: ['erc8183', 'negotiation', 'bnb-chain', s.category], examples: QUOTE_EXAMPLES[s.id] ? [QUOTE_EXAMPLES[s.id]] : [] },
            NOTIFY_FUNDED_SKILL, PLAZA_BOARD_SKILL, ESCROW_STATUS_SKILL,
            { id: 'erc8183-job-status', name: 'ERC-8183 job status', description: 'Send {"skill":"erc8183-job-status","job_id":<int>} for a read-only on-chain job lookup.', tags: ['erc8183', 'status'], examples: ['{"skill":"erc8183-job-status","job_id":57045}'] },
            { id: s.id, name: s.name, description: s.deliverables, tags: [s.category, 'bnb-chain', 'measured-on-chain'], examples: QUOTE_EXAMPLES[s.id] ? [QUOTE_EXAMPLES[s.id]] : [], inputs: s.needs, price: `${onSale() ? '0.01 $U (until 5 Nov 12:00 UTC, then 0.10)' : '0.10 $U'} (ERC-8183 escrow) or 0.10 per answer in USD1, USDC or $U (x402), or $0.05 in $BOBAI — half price, a direct transfer at the 402's quote, kept as $BOBAI and never sold — ${HOLDER_PRICE_NOTE}`, pay_in_bobai: { price_usd: 0.05, how: `POST ${SELF_ORIGIN}/answer?service=${s.id} without payment: the 402 quotes the $BOBAI amount (its accepts[] entry with asset $BOBAI); send it, then repeat with the transaction hash in PAYMENT-SIGNATURE` }, escrow: true, x402: `${SELF_ORIGIN}/answer?service=${s.id}` },
          ],
          holder_pass: { ...holderPassTerms(), x402: `${SELF_ORIGIN}/answer?service=${s.id}` },
          provider_address: await cardProvider(slug),
          additionalInterfaces: [{ transport: 'JSONRPC', url: `${SELF_ORIGIN}/${slug}/a2a` }],
          documentationUrl: 'https://brainonbnb.com/registry', iconUrl: 'https://brainonbnb.com/logo-200x200.png',
        });
      }
    }

    // THE DEFI AGENT, AS AN AGENT OF ITS OWN (2026-10-04). The six services
    // share one A2A endpoint and one card; a marketplace listing ONE agent
    // needs a card that is about that agent — its name, its category, its
    // one service — at a path its registration names. POST here sells only
    // the position plan (handleA2A opts.agent), through the ERC-8183 escrow,
    // in both dialects: BNB's signed quote and our flat one.
    if (path === '/defi-agent/a2a' && request.method === 'POST') { seenA2A(request, 'defi-agent'); return await handleA2A(request, env, { agent: 'defi-agent', freeHalf: (q) => freeHalf('defi-agent', q, env) }); }
    // The BNB Agent SDK buyer reads the card at <A2A endpoint>/.well-known/
    // agent-card.json — under the endpoint, not the origin — so both spellings
    // are served under /defi-agent/a2a as well.
    if (path === '/defi-agent' || path === '/defi-agent/a2a' || /^\/defi-agent(\/a2a)?\/\.well-known\/agent(-card)?\.json$/.test(path)) {
      const s = SERVICES.lp_position_plan;
      return json({
        protocolVersion: '0.3.0',
        name: 'Brain on BNB — DeFi Agent',
        description: 'Rebalancing agent for PancakeSwap V3 liquidity: the agent that runs the $BOBAI project\'s own PancakeSwap V3 position (CAKE/BNB, 0.05 %) on BNB Chain, by itself, every day: it collects the fees, and it keeps a wide range (±20%) centred on the price, and once the price has stayed outside it for its set wait it re-sets the range centred on the price again with one swap back to the range’s mix — wide, because every re-set locks in what the range lost against holding. On the recorded prices the wider ranges lost less against simply holding than the narrow ones, and none came out ahead of holding (the width record: https://agent.brainonbnb.com/lp/windows). Hired, it runs the same code on your position and delivers its decision on-chain: in range or not and how much room is left, what the position holds and is owed, whether collecting pays for its gas, whether a re-set is due and in which width. It reads and plans; it signs nothing on your position.',
        url: `${SELF_ORIGIN}/defi-agent/a2a`,
        preferredTransport: 'JSONRPC',
        version: '1.0.0',
        category: 'rebalancing',
        provider: { organization: 'Brain On BNB AI', url: 'https://brainonbnb.com' },
        capabilities: { streaming: false, pushNotifications: false, stateTransitionHistory: false },
        registrations: DEFI_AGENT_ID ? [{ agentId: DEFI_AGENT_ID, agentRegistry: AGENT_REGISTRY }] : [],
        supportedTrust: ['reputation'],
        trustRegistries: TRUST_REGISTRIES,
        defaultInputModes: ['application/json', 'text/plain'],
        defaultOutputModes: ['application/json'],
        skills: [
          { id: 'negotiate-erc8183-job', name: 'Quote: the DeFi agent on your PancakeSwap V3 position', description: 'Send a data part {"skill":"negotiate-erc8183-job","task_description":"…","terms":{"deliverables":"…","quality_standards":"…"}} and receive a wallet-signed quote (price, currency, negotiation_hash, provider_sig). Anchor the envelope on-chain via createJob and fund it, then send notify_funded with the job_id and delivery starts at once; without it the agent finds the funded job on the chain within 15 minutes and delivers.', tags: ['erc8183', 'negotiation', 'bnb-chain', 'rebalancing'], examples: ['what should happen to the PancakeSwap V3 positions of wallet 0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A'] },
          NOTIFY_FUNDED_SKILL, PLAZA_BOARD_SKILL, ESCROW_STATUS_SKILL,
          { id: 'erc8183-job-status', name: 'ERC-8183 job status', description: 'Send {"skill":"erc8183-job-status","job_id":<int>} for a read-only on-chain job lookup.', tags: ['erc8183', 'status'], examples: ['{"skill":"erc8183-job-status","job_id":57045}'] },
          { id: s.id, name: s.name, description: s.deliverables, tags: ['rebalancing', 'pancakeswap-v3', 'bnb-chain', 'measured-on-chain'], examples: [QUOTE_EXAMPLES.lp_position_plan], inputs: { ...s.needs, note: 'name a position id or a wallet in task_description; with neither, the plan is made for the hiring wallet, and if it holds no single V3 position, for the agent\'s own' }, price: `${onSale() ? '0.01 $U (until 5 Nov 12:00 UTC, then 0.10)' : '0.10 $U'} (ERC-8183 escrow) or 0.10 per answer in USD1, USDC or $U (x402), or $0.05 in $BOBAI — half price, a direct transfer at the 402's quote, kept as $BOBAI and never sold — ${HOLDER_PRICE_NOTE}`, pay_in_bobai: { price_usd: 0.05, how: `POST ${SELF_ORIGIN}/answer?service=${s.id} without payment: the 402 quotes the $BOBAI amount (its accepts[] entry with asset $BOBAI); send it, then repeat with the transaction hash in PAYMENT-SIGNATURE` }, escrow: true, x402: `${SELF_ORIGIN}/answer?service=${s.id}` },
        ],
        holder_pass: { ...holderPassTerms(), x402: `${SELF_ORIGIN}/answer?service=${s.id}` },
        // What the agent does on its own, every day, where anybody can check it.
        operations: {
          what: 'collects fees, re-sets the range when the price leaves it, adds new capital; daily run 04:23 UTC, hourly check at :50, 10-minute deposit watch',
          operating_wallet: 'eip155:56:0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A',
          home_pool: 'PancakeSwap V3 CAKE/BNB 0.05 %',
          record: 'https://agent.brainonbnb.com/lp/agent',
          page: 'https://brainonbnb.com/defi',
          transactions: 'https://bscscan.com/address/0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A',
        },
        // Owner = the wallet whose transactions are the agent's work; agentWallet =
        // the provider key that signs quotes and deliveries (2026-10-04).
        owner: 'eip155:56:0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A',
        provider_address: await cardProvider('defi-agent'),
        source: 'https://github.com/mmxrealQQ/bobai-buyburn (shared/lp-agent.js, worker-lp/)',
        additionalInterfaces: [{ transport: 'JSONRPC', url: `${SELF_ORIGIN}/defi-agent/a2a` }],
        documentationUrl: 'https://brainonbnb.com/defi', iconUrl: 'https://brainonbnb.com/logo-200x200.png',
      });
    }

    // Also under /a2a (2026-10-04): the BNB Agent SDK buyer looks for the card
    // beneath the A2A endpoint the registration names, which for our five is
    // https://agent.brainonbnb.com/a2a — that path answered 404, and to every
    // SDK marketplace our agents had no readable card.
    // And on a GET of the endpoint itself (2026-10-04): Marque's builder probe
    // reads the card from the endpoint URL the registration names and called
    // ours "not a recognisable A2A agent card" — a GET here returned a usage
    // note. The card carries the same skills and the example message.
    if (path === '/.well-known/agent-card.json' || path === '/.well-known/agent.json' || path === '/a2a/.well-known/agent-card.json' || path === '/a2a/.well-known/agent.json' || (path === '/a2a' && request.method === 'GET')) {
      return json({
        protocolVersion: '0.3.0',
        name: 'Brain On BNB AI — hireable agents',
        // Counted from the list, not typed. It said "four" for three days
        // after the fifth agent went live — a number in prose is a number that
        // goes stale the moment somebody registers something.
        description: `${OWN_AGENT_IDS.length} hireable agents on BNB Smart Chain, covering every BNB Agent Studio category. Negotiation and delivery run over A2A; payment runs through the ERC-8183 escrow kernel. Every figure is measured from the chain at request time and cross-checked against the protocol it came from where the protocol publishes one.`,
        // The A2A endpoint, not the website. The card on the apex points at
        // https://brainonbnb.com/ — an HTML page — which is why a machine
        // following it finds nothing to talk to.
        url: `${SELF_ORIGIN}/a2a`,
        preferredTransport: 'JSONRPC',
        version: '1.0.0',
        provider: { organization: 'Brain On BNB AI', url: 'https://brainonbnb.com' },
        capabilities: { streaming: false, pushNotifications: false, stateTransitionHistory: false },
        // THE LINK BACK TO THE CHAIN, which this card did not carry.
        //
        // /.well-known/agent-registration.json has listed these ids since the
        // day it was written, and that document is what a verifier fetches
        // AFTER it already knows which ids to check. The A2A card is what a
        // client reads FIRST, and without registrations on it there was no
        // machine-readable path from "I am talking to this endpoint" to "these
        // are its on-chain identities" — the same gap this marketplace flags
        // in other people's cards.
        registrations: registrations(),
        // Declared here as well as in the registration document, because the
        // two are read by different clients and a trust model that appears on
        // only one of them is a trust model half the readers never see. It is
        // backed: the ratings are readable at the ReputationRegistry below,
        // and the marketplace prints them per agent.
        supportedTrust: ['reputation'],
        trustRegistries: TRUST_REGISTRIES,
        defaultInputModes: ['application/json', 'text/plain'],
        defaultOutputModes: ['application/json'],
        skills: [
          {
            id: 'negotiate',
            name: 'Negotiate an ERC-8183 job',
            description: 'Ask for a price. Send a data part {"skill":"negotiate","task":"<what you need>"} (or "service":"<one of the skill ids below>"). Returns this provider\'s address, the price in atomic units of the payment token, and the escrow parameters to fund a job against.',
            tags: ['erc-8183', 'negotiation', 'escrow'],
            examples: ['{"skill":"negotiate","task":"quote finding the best yield for my BNB on BNB Chain"}'],
          },
          // BNB's standard hire (2026-10-04): the BNB Agent SDK and the
          // marketplaces built on it negotiate only under this id and expect
          // a signed quote; the funded job is then found on the chain.
          {
            id: 'negotiate-erc8183-job',
            name: 'Negotiate an ERC-8183 job (BNB Agent SDK)',
            description: 'Send {"skill":"negotiate-erc8183-job","task_description":"…","terms":{"deliverables":"…","quality_standards":"…"}} and receive a wallet-signed quote (negotiation_hash, provider_sig). Anchor it via createJob and fund it, then send notify_funded with the job_id and delivery starts at once; without it the funded job is found on the chain within 15 minutes.',
            tags: ['erc8183', 'negotiation', 'bnb-chain'],
          },
          NOTIFY_FUNDED_SKILL, PLAZA_BOARD_SKILL, ESCROW_STATUS_SKILL,
          ...Object.values(SERVICES).map((s) => ({
            id: s.id,
            name: s.name,
            description: s.deliverables,
            tags: [s.category, 'bnb-chain', 'measured-on-chain'],
            // What the buyer has to supply. A card that lists a service and
            // not its inputs makes the caller guess, and a guessed parameter
            // fails after the money is already in escrow.
            inputs: s.needs,
            price: s.price_display,
            // Where it is sold (2026-09-18): five through the escrow at their
            // agent id, the LP plan per answer over x402 only — a card that
            // lists a price without the channel had a client negotiating an
            // escrow job for a service no seller id answers.
            ...(s.id === 'lp_position_plan'
              ? { escrow: false, buy: `${SELF_ORIGIN}/answer?service=${s.id}`, channel: `x402, per answer, at this endpoint; through the ERC-8183 escrow only by the DeFi agent #363709 at ${SELF_ORIGIN}/defi-agent/a2a` }
              : { escrow: true, channel: 'ERC-8183 escrow at this agent, or per answer over x402 at ' + `${SELF_ORIGIN}/answer?service=${s.id}` }),
          })),
        ],
        // Hold, don't pay (2026-10-16): the x402 route of every answer takes the $BOBAI holder pass.
        holder_pass: { ...holderPassTerms(), applies_to: `every answer over x402 (${SELF_ORIGIN}/answer?service=<id>), the pool watch (${SELF_ORIGIN}/watch) and the pool scan day pass (${SELF_ORIGIN}/scan-pass); not the ERC-8183 escrow` },
        // Where the rest of the story is, for a reader rather than a parser.
        additionalInterfaces: [
          { transport: 'JSONRPC', url: `${SELF_ORIGIN}/a2a` },
        ],
        documentationUrl: 'https://brainonbnb.com/registry', iconUrl: 'https://brainonbnb.com/logo-200x200.png',
      });
    }

    // The domain proof, on the origin the hireable agents actually name as
    // their endpoint. The ERC-8004 verifier fetches
    // /.well-known/agent-registration.json on the endpoint's own host — and
    // this host answered 404 for it, which is the same failure that left
    // #49467 unverified for months. An agent nobody can attribute is an
    // anonymous agent, whatever its description says.
    if (path === '/.well-known/agent-registration.json') {
      return json({
        type: 'https://eips.ethereum.org/EIPS/eip-8004#registration-v1',
        name: 'Brain On BNB AI — agent service',
        description: 'The hireable agents run by Brain On BNB AI on BNB Smart Chain. Negotiation and delivery run over A2A at https://agent.brainonbnb.com/a2a; payment runs through the ERC-8183 escrow kernel.',
        image: 'https://brainonbnb.com/logo-200x200.png',
        active: true,
        // The same list dashboard/_worker.js serves on the other origin, from
        // shared/agent-registrations.js. A newly registered agent missing from
        // the proof is unattributable on the host it names, which is the
        // failure that left #49467 unverified for months.
        registrations: registrations(),
        supportedTrust: ['reputation'],
        // Where the live state is. The card is what an indexer reads, so an
        // endpoint that is only mentioned on the A2A GET is discoverable by
        // people and not by the machines this card exists for.
        endpoints: {
          a2a: 'https://agent.brainonbnb.com/a2a',
          status: 'https://agent.brainonbnb.com/status',
          marketplace: 'https://brainonbnb.com/registry',
          board: 'https://agent.brainonbnb.com/board.md',
          board_feed: 'https://agent.brainonbnb.com/board.atom',
          board_how: 'https://agent.brainonbnb.com/board/how',
        },
        operator: { name: 'Brain On BNB AI', parent_agent: 49467, site: 'https://brainonbnb.com', marketplace: 'https://brainonbnb.com/registry' },
      });
    }

    // Being hireable, which is the half a marketplace usually forgets about
    // itself. A2A JSON-RPC: negotiate a price, then tell us the job is funded
    // and we deliver it on-chain. See sell.js for why it is A2A and not MCP.
    if (path === '/a2a') {
      if (request.method === 'POST') { seenA2A(request, 'a2a'); return await handleA2A(request, env); }
      // A GET here is somebody looking, not somebody hiring — a person pasting
      // the URL, or an indexer checking whether the endpoint is alive. Answering
      // 404 is technically correct and reads as broken, which is precisely the
      // misreading this project keeps having to correct in other people's data.
      return json({
        endpoint: 'A2A JSON-RPC, POST only',
        method: 'message/send',
        example: {
          jsonrpc: '2.0', id: 1, method: 'message/send',
          params: { message: { kind: 'message', role: 'user', messageId: 'example', parts: [{ kind: 'data', data: { skill: 'list' } }] } },
        },
        skills: ['list — what is for sale', 'negotiate — get a quote', 'notify_funded — deliver a job whose escrow is funded'],
        services: Object.values(SERVICES).map((x) => ({ id: x.id, name: x.name, category: x.category, price: x.price, price_display: x.price_display })),
        agents: { 302257: 'Venus Health Factor Monitor', 302258: 'BSC Grid Planner' },
        // Advertised, not just served. A buyer deciding whether to hire needs
        // to know the live state exists before it can ask for it, and a card
        // that omits it leaves the endpoint discoverable only by guessing.
        status: 'https://agent.brainonbnb.com/status',
        human_readable: 'https://brainonbnb.com/registry',
      });
    }

    // What the funded-job watcher last saw (job-watch.js): the cursor, our
    // jobs still waiting to be funded, and the last tick that touched one.
    if (path === '/jobs/watch') {
      const [cursor, open, retry, last, refused] = await Promise.all(['jobs:watch:id', 'jobs:watch:open', 'jobs:watch:retry', 'jobs:watch:last', 'jobs:watch:refused'].map((k) => env.AGENT.get(k)));
      // refused: funded jobs that will not be delivered, each with its reason (2026-10-05)
      const marque = JSON.parse((await env.AGENT.get('marque:probe')) || 'null'); // the last round of the Marque listing probe
      return json({ marque_probe: marque, cursor_job_id: cursor ? Number(cursor) : null, open_unfunded: JSON.parse(open || '{}'), retrying: JSON.parse(retry || '{}'), refused: JSON.parse(refused || '{}'), last_tick_with_our_jobs: last ? JSON.parse(last) : null, how: 'every 15 minutes the job ids created since the cursor are read from the ERC-8183 kernel; ours that are FUNDED are delivered, ours that are OPEN are looked at again until funded' });
    }

    // The deliverable of a finished job, served so the digest written on-chain
    // can be checked against the document it commits to.
    {
      const m = path.match(/^\/job\/(\d+)\/result$/);
      if (m) return await handleJobResult(m[1], env);
    }

    // ATTEST A DELIVERY ON-CHAIN, as the buyer. After a job this worker
    // delivered is SUBMITTED, the buyer can write one measurement into the
    // ERC-8004 ReputationRegistry: responsetime, the milliseconds between the
    // block that funded the escrow and the block that carried the deliverable
    // — two on-chain timestamps anyone can read again and disagree with. Not
    // a star rating: this project's rule is that a measurement and a taste
    // claim never share a column, and the writer enforces what the reader
    // separates. The evidence travels with it: feedbackURI is the delivered
    // document, feedbackHash its keccak256, so "delivered in 41 s" points at
    // exactly what was delivered. Returns the unsigned call; the buyer's own
    // wallet sends it. The contract refuses the agent's owner, so we could
    // not write this about ourselves even if we wanted to.
    if (path === '/attest') {
      const id = url.searchParams.get('job') || '';
      const fundTx = String(url.searchParams.get('fundTx') || '').toLowerCase();
      if (!/^\d+$/.test(id)) return json({ error: 'job is required — the numeric jobId' }, 400);
      if (!/^0x[a-f0-9]{64}$/.test(fundTx)) return json({ error: 'fundTx is required — the hash of the transaction that funded the escrow' }, 400);
      const raw = await call(ERC8183.commerce, JOB_CALL(id)).catch(() => null);
      const job = raw ? decodeJob(raw) : null;
      if (!job) return json({ error: 'job not found or unreadable', id }, 404);
      if (job.status !== 'SUBMITTED' && job.status !== 'COMPLETED') return json({ error: `job ${id} is ${job.status} — nothing has been delivered to attest`, status: job.status }, 409);
      const stored = await env.AGENT.get(`job:${id}`, 'json').catch(() => null);
      if (!stored || !stored.document) return json({ error: 'this worker holds no document for that job — it was not the provider' }, 404);
      let service = null; try { service = JSON.parse(stored.document).service || null; } catch { /* no service */ }
      const agentId = service && SOLD_BY[service] ? SOLD_BY[service].agent : null;
      if (!agentId) return json({ error: 'the delivering agent could not be identified from the document', service }, 500);
      const receipt = await rpc('eth_getTransactionReceipt', [fundTx], RECEIPT_RPCS).catch(() => null);
      if (!receipt || receipt.status !== '0x1') return json({ error: 'the funding transaction was not found or failed' }, 404);
      if (String(receipt.to || '').toLowerCase() !== ERC8183.commerce.toLowerCase()) return json({ error: 'that transaction did not go to the kernel' }, 400);
      const block = await rpc('eth_getBlockByNumber', [receipt.blockNumber, false], RECEIPT_RPCS).catch(() => null);
      const fundedAt = block ? Number(BigInt(block.timestamp)) : null;
      if (!fundedAt) return json({ error: 'could not read the funding block' }, 503);
      const submittedAt = Number(job.submitted_at || 0);
      if (!(submittedAt > fundedAt)) return json({ error: 'the deliverable predates the funding transaction — wrong fundTx?', funded_at: fundedAt, submitted_at: submittedAt }, 400);
      const ms = (submittedAt - fundedAt) * 1000;
      const feedbackURI = `https://agent.brainonbnb.com/job/${id}/result`;
      const feedbackHash = keccak256(toBytes(stored.document));
      const data = encodeFunctionData({ abi: REPUTATION_ABI, functionName: 'giveFeedback', args: [BigInt(agentId), BigInt(ms), 0, 'responsetime', '', 'https://agent.brainonbnb.com/a2a', feedbackURI, feedbackHash] });
      ctx.waitUntil(bump(env, 'attest_prepared'));
      return json({
        job: id, agent_id: agentId, service, status: job.status,
        tag1: 'responsetime', value: ms, unit: 'ms',
        means: `The deliverable was on-chain ${submittedAt - fundedAt} seconds after the escrow was funded.`,
        measured_from: { funded_block: Number(BigInt(receipt.blockNumber)), funded_at: fundedAt, submitted_at: submittedAt },
        evidence: { feedbackURI, feedbackHash, note: 'keccak256 of the exact document served at feedbackURI' },
        call: { to: REPUTATION, data, value: '0x0' },
        rule: 'One measurement, two on-chain timestamps, the document hashed. No star rating: this registry already holds twenty thousand of those and they mean nothing.',
        who_may_send: 'Any wallet except the agent\'s owner. The buyer is the natural one.',
      });
    }

    // A worked example of what each service delivers, run by the same code a
    // funded job runs and cached a day. The marketplace card carries it so a
    // buyer sees the shape of the answer before paying for one.
    if (path === '/example') {
      const id = url.searchParams.get('service') || '';
      if (!SERVICES[id]) return json({ error: id ? `unknown service "${id.slice(0, 40)}"` : 'service is required', services: Object.keys(SERVICES) }, 400);
      note(`sell:example:${id}`);
      try {
        const ex = await exampleFor(id, env, { fresh: url.searchParams.get('fresh') === '1' && request.headers.get('x-hit-secret') === env.HIT_SECRET });
        return json(ex, 200, { 'Cache-Control': 'public, max-age=3600' });
      } catch (e) {
        return json({ error: `the example could not be produced right now: ${String(e.message || e).slice(0, 200)}`, service: id }, 503);
      }
    }

    // Public transparency surface. Everything the dashboard block shows comes
    // from here, so the page cannot present a number this endpoint would not.
    // What the self-updating half of the census knows. The headline figures
    // come from a full offline scan; this reports what has changed since.
    // The broker. Ask what you need done, get agents that expose something
    // matching — open, no key, so another agent can use it mid-task.
    if (path === '/find') {
      const r = await handleFind(url, env);
      return thankJson(request, r.body, r.status);
    }
    // The DeFi agent's free look at anybody's PancakeSwap V3 position:
    // in range or not, room left, value, fees owed. Open, no key, read live.
    // The plan (re-set, width, what spare BNB adds) is the paid answer.
    if (path === '/lp/look') {
      const params = { position: url.searchParams.get('position') || undefined, address: url.searchParams.get('address') || undefined };
      if (!params.position && !params.address) return json({ error: 'give ?position=<PancakeSwap V3 token id> or ?address=<wallet> (a wallet with several positions is answered with their ids)', example: '/lp/look?address=0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A' }, 400);
      try { return thankJson(request, await lpPositionLook(params, env), 200, { 'Cache-Control': 'no-store' }); }
      catch (e) { return json({ error: String(e.shortMessage || e.message).slice(0, 200) }, 400); }
    }

    // Dispatch: a task in, an answer back, with the agent that produced it
    // named. Read-only tools only — see dispatch.js for why that line is not
    // moved. This is the free half of the marketplace: it answers questions.
    if (path === '/dispatch') {
      const body = request.method === 'POST' ? await request.json().catch(() => ({})) : {};
      // The same task twice within a minute gets the first answer back, not a second call (2026-09-26). On
      // 2026-09-20 one caller sent "can I ask you a question please?" 156 times in 50 seconds: the router asked the
      // same third-party agent 156 times, wrote 156 failures into that operator's public record, and pushed the
      // rest of the log out of its 400-entry window. A repeat is answered from the edge cache and not recorded.
      const task = String(body?.task || url.searchParams.get('task') || '').trim().toLowerCase().slice(0, 300);
      const dry = body?.dry_run === true || url.searchParams.get('dry') === '1';
      let ck = null;
      if (task && !dry) {
        const h = [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(task)))].map((b) => b.toString(16).padStart(2, '0')).join('');
        ck = new Request(`https://agent.brainonbnb.com/__dispatch-cache/${h}`);
        const hit = await caches.default.match(ck).catch(() => null);
        if (hit) {
          ctx.waitUntil(bump(env, 'dispatch_repeat'));
          return thankJson(request, { ...(await hit.json()), repeated: 'The same task was answered less than a minute ago; this is that answer. The agent was not asked again, and the repeat is not in the log.' }, 200);
        }
      }
      const r = await handleDispatch(url, body, env);
      ctx.waitUntil(bump(env, 'dispatch'));
      if (ck && r.status === 200) ctx.waitUntil(caches.default.put(ck, new Response(JSON.stringify(r.body), { headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'public, max-age=60' } })).catch(() => {}));
      return thankJson(request, r.body, r.status);
    }

    // Hire: negotiate a price with a seller agent over A2A and hand back the
    // ERC-8183 escrow calls, unsigned. This is the paid half — and the reason
    // it can exist without contradicting the read-only rule is that we build
    // the transactions and the buyer signs them. See hire.js.
    // The funded job's seller is told to deliver — the seller that was hired,
    // by id, through the same resolution /hire used (hire.js, handleHireNotify).
    if (path === '/hire/notify') {
      if (request.method !== 'POST') return json({ error: 'POST {"agent":"<ERC-8004 id>","job_id":<jobId>}' }, 405);
      const nb = await request.json().catch(() => ({}));
      const nr = await handleHireNotify(nb, { localA2A: async (endpoint, data) => {
        if (new URL(endpoint).host !== url.host) return null;
        const res = await handleA2A(new Request(endpoint, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'message/send',
            params: { message: { kind: 'message', role: 'user', messageId: 'hire-' + nb.job_id, parts: [{ kind: 'data', data }] } } }),
        }), env, AGENT_SERVICE[new URL(endpoint).pathname.split('/')[1]] ? { agent: new URL(endpoint).pathname.split('/')[1] } : {}); // an agent's own endpoint keeps its own service
        return await res.json();
      } });
      return json(nr.body, nr.status);
    }
    // BRAIN PLAZA LISTINGS (listing.js, operator 2026-10-12: $95 once, paid straight to his wallet, never buys rank)
    if (path === '/listing/check') return json(await checkAgent(url.searchParams.get('agent')), 200);
    if (path === '/listing/quote' && request.method === 'POST') { const r = await quoteListing(await request.json().catch(() => ({})), env, { bnbUsd, bobaiForUsd }); return json(r.body, r.status); }
    if (path === '/listing/verify' && request.method === 'POST') { const r = await verifySigner(await request.json().catch(() => ({})), env); return json(r.body, r.status); }
    if (path === '/listing/submit' && request.method === 'POST') { const r = await submitListing(await request.json().catch(() => ({})), env); return json(r.body, r.status); }
    if (path === '/listings') return json({ price_usd: LISTING_USD, pays_to: PAYEE, currencies: ['usd1', 'bnb', 'bobai'], listings: await readListings(env) }, 200);
    if (path === '/listing/log' && request.method === 'POST') { const r = await postLog(await request.json().catch(() => ({})), env); return json(r.body, r.status); }
    if (path === '/listing/log/house' && request.method === 'POST') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      const r = await postLog(await request.json().catch(() => ({})), env, { house: true }); return json(r.body, r.status);
    }
    if (path === '/listing/log') { const id = String(url.searchParams.get('agent') || ''); if (!/^\d{1,9}$/.test(id)) return json({ error: 'agent: its ERC-8004 id' }, 400);
      return json({ agent: id, entries: await readLog(env, id), how: 'POST /listing/log {agent, text, at, signature}: sign the text below, with at = the time you sign (ISO), using the wallet that owns the id', sign: logMessage(id, '<at>', '<text>') }, 200); }
    if (path === '/listing/house' && request.method === 'POST') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      const r = await houseListing(env, (await request.json().catch(() => ({}))).agent); return json(r.body, r.status);
    }
    if (path === '/listing/announced' && request.method === 'POST') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      const b = await request.json().catch(() => ({})); return json({ ok: await markAnnounced(env, String(b.id || '')) }, 200);
    }
    if (path === '/agent-watch') {
      if (request.method === 'POST') { const r = await addAgentWatch(env, await request.json().catch(() => ({}))); return json(r.body, r.status); }
      if (request.method === 'DELETE') { const r = await removeAgentWatch(env, await request.json().catch(() => ({}))); return json(r.body, r.status); }
      return json({ what: 'An alarm when an agent you rely on goes down, and when it is back. Free, any agent on BNB Chain, webhook only.', usage: 'POST /agent-watch {"agent":"302257","callback":"https://your.server/hook"} — the callback receives {agent, state: "down"|"up", at, was, since, chart} on every change; DELETE with the same body to stop.', checked: 'every agent once a day (the pulse); a listed agent every hour' }, 200);
    }
    if (path === '/screener') return new Response(JSON.stringify(await screenerData(env)), { headers: { 'content-type': 'application/json; charset=utf-8', 'access-control-allow-origin': '*', 'cache-control': 'public, max-age=300' } }); // compact: ~950 rows
    if (path === '/pulse/rebuild-summary' && request.method === 'POST') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      return json(await rebuildPulseSummary(env), 200);
    }
    if (path === '/chart/rank') { const r = await agentRank(env, url.searchParams.get('category'), url.searchParams.get('limit')); return json(r.body, r.status, { 'Cache-Control': 'public, max-age=300' }); }
    if (path.startsWith('/chart/')) { const r = await agentChart(env, path.slice(7)); return json(r.body, r.status, { 'Cache-Control': 'public, max-age=120' }); }
    if (path.startsWith('/pulse/')) {
      const id = path.slice(7).replace(/[^0-9]/g, '');
      if (!id) return json({ error: 'GET /pulse/<ERC-8004 id>' }, 400);
      return json(await readPulse(env, id), 200);
    }
    if (path.startsWith('/listed/')) {
      const id = path.slice(8).replace(/\/$/, ''); const r = /^\d+$/.test(id) ? await readListing(env, id) : null;
      if (!r || r.status === 'removed') return json({ error: 'not a listed agent', list_yours: 'https://brainonbnb.com/list' }, 404);
      if (url.searchParams.get('format') === 'json') { const { contact, signer, ...pub } = r; return json(pub, 200); }
      return new Response(profileHtml(r, await readLog(env, id).catch(() => [])), { headers: { 'content-type': 'text/html; charset=utf-8', 'access-control-allow-origin': '*' } });
    }
    if (path === '/hire') {
      const body = request.method === 'POST' ? await request.json().catch(() => ({})) : {};
      // Our own agents live on this worker, and a Worker cannot fetch its own
      // custom domain. Without this, hiring a stranger's agent would work and
      // hiring ours would fail — so the message is handed to the same A2A
      // handler in-process instead of going out and coming back.
      // A quote run of our own (the registry publish asking every Hire button
      // for a price) carries this worker's secret and is filed as ours in the
      // session log; a stranger's call cannot claim that.
      const ours = request.headers.get('x-hit-secret') && request.headers.get('x-hit-secret') === env.HIT_SECRET ? 'quote-run' : null;
      const r = await handleHire(url, body, env, { ours, localA2A: async (endpoint, data) => {
        if (new URL(endpoint).host !== url.host) return null;
        const res = await handleA2A(new Request(endpoint, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'message/send',
            params: { message: { kind: 'message', role: 'user', messageId: 'local', parts: [{ kind: 'data', data }] } } }),
        }), env, AGENT_SERVICE[new URL(endpoint).pathname.split('/')[1]] ? { agent: new URL(endpoint).pathname.split('/')[1] } : {}); // an agent's own endpoint keeps its own service
        return await res.json();
      } });
      ctx.waitUntil(bump(env, 'hire'));
      return json(r.body, r.status);
    }

    // One job's state, straight from the kernel. Kept separate from /hire so
    // that a buyer who funded a job through some other client — the Altana SDK,
    // their own script, the seller's own page — can still track it here.
    if (path === '/job') {
      const id = url.searchParams.get('id');
      if (!/^\d+$/.test(id || '')) return json({ error: id ? 'id must be the numeric jobId' : 'id is required — the numeric jobId', id: id || null }, 400);
      const raw = await call(ERC8183.commerce, JOB_CALL(id)).catch(() => null);
      const job = raw ? decodeJob(raw) : null;
      // the kernel answers an empty record for an id it never issued (2026-11-20, A-Z: id 999999999 read as an OPEN job of 0x000…)
      if (!job || String(job.id) === '0' || /^0x0{40}$/i.test(job.client || '')) return json({ error: 'job not found — the kernel has no job with this id', id }, 404);
      ctx.waitUntil(bump(env, 'job'));
      // SUBMITTED is not COMPLETED, and the difference is money: a
      // deliverable exists, the escrow has not released. Saying so here keeps
      // anyone reading this endpoint from counting one as the other.
      // A FUNDED JOB WE WILL NOT DELIVER SAYS WHY (2026-10-05): job 56887 read "Waiting on the provider to deliver"
      // while the kernel had refused the delivery for good (expiry inside the dispute window)
      const refusedWhy = job.status === 'FUNDED' ? (await env.AGENT.get('jobs:watch:refused', 'json').catch(() => null))?.[String(id)]?.reason || null : null;
      const means = refusedWhy ? `Escrow holds the budget, and the provider will not deliver: ${refusedWhy}`
        : job.status === 'SUBMITTED'
        ? 'A deliverable is on-chain and the dispute window is running. The escrow has not released yet.'
        : job.status === 'COMPLETED' ? 'Delivered and the escrow released to the provider.'
        : job.status === 'OPEN' ? 'Created but not funded. Nothing is at stake yet.'
        : job.status === 'FUNDED' ? 'Escrow holds the budget. Waiting on the provider to deliver.'
        : job.status === 'EXPIRED' ? 'Expired undelivered — the client can call claimRefund(jobId) for the full budget.'
        : 'Rejected.';
      // THE DELIVERY, READABLE. A job page that showed a bytes32 and nothing
      // else told the buyer their money had gone somewhere; it did not show
      // them what they got. When this worker was the provider the document is
      // in KV, its SHA-256 is checked against the digest on the kernel right
      // here, and the answer is summarised by the same module the marketplace
      // card uses for its example — so before and after are read by one rule.
      let delivery = null;
      const stored = await env.AGENT.get(`job:${id}`, 'json').catch(() => null);
      if (stored && stored.document) {
        let digest = null;
        try {
          const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(stored.document));
          digest = '0x' + [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
        } catch { /* no digest, no claim */ }
        let doc = null; try { doc = JSON.parse(stored.document); } catch { /* served raw below */ }
        const service = doc?.service || stored.result?.service || null;
        delivery = {
          service,
          produced_at: doc?.produced_at || null,
          summary: summarize(service, doc?.result || stored.result || null),
          document_url: `https://agent.brainonbnb.com/job/${id}/result`,
          digest_of_document: digest,
          digest_on_chain: job.deliverable || null,
          digest_matches: digest && job.deliverable ? digest.toLowerCase() === String(job.deliverable).toLowerCase() : null,
          tx: stored.delivery?.tx || null,
        };
      }
      const out = { ...job, chain_id: ERC8183.chainId, kernel: ERC8183.commerce, explorer: `https://bscscan.com/address/${ERC8183.commerce}`, means, delivery };
      // ANOTHER SELLER'S ANSWER (2026-10-30): the kernel holds its hash only, and the journey ended at that hash. Marque
      // keeps the address of the document for the jobs it knows; the hash on chain is what proves the copy.
      if (!delivery && job.deliverable && /^(SUBMITTED|COMPLETED)$/.test(job.status)) {
        const m = await fetch(`https://marque.trade/api/v1/phase2/job/56/${id}`, { signal: AbortSignal.timeout(4000) }).then((r) => (r.ok ? r.json() : null)).catch(() => null);
        if (/^https:\/\//.test(String(m?.deliverable?.url || ''))) out.delivery_url = m.deliverable.url;
      }
      if (delivery && delivery.summary && delivery.summary.subject) {
        let t = null; try { t = JSON.parse(job.description || '').task || null; } catch { t = job.description || null; }
        const sj = String(delivery.summary.subject);
        out.delivery_subject = sj;
        out.task_names_subject = t ? new RegExp(`\\b${sj.replace(/[.*+?^${}()|[\]\\$]/g, '\\$&')}\\b`, 'i').test(t) : null;
      }
      const wantsHtml = /text\/html/.test(request.headers.get('accept') || '') && url.searchParams.get('format') !== 'json';
      if (!wantsHtml) return json(out);

      // The same facts as a page. Plain markup, no script: it has to read on a
      // phone from a Telegram link and inside a judge's screenshot alike.
      const h = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
      const short = (a) => (a ? `${a.slice(0, 6)}…${a.slice(-4)}` : '—');
      const addr = (a) => (a ? `<a href="https://bscscan.com/address/${h(a)}" target="_blank" rel="noopener"><code>${h(short(a))}</code></a>` : '—');
      const when = (t) => (t ? new Date(Number(t) * 1000).toISOString().replace('T', ' ').slice(0, 16) + ' UTC' : '—');
      let task = null, svcName = null;
      try { const d = JSON.parse(job.description || ''); task = d.task || null; svcName = d.service || null; } catch { task = job.description || null; }
      const sum = delivery?.summary;
      // The delivery's subject against the task's words. Job 56670 asked
      // "grid plan for WBNB" and was delivered for BOBAI; the page showed
      // COMPLETED and "SHA-256 matches" and never said so. The page is the
      // evidence, so it says it in one line.
      const subject = sum && sum.subject ? String(sum.subject) : null;
      const taskNamesSubject = subject && task ? new RegExp(`\\b${subject.replace(/[.*+?^${}()|[\]\\$]/g, '\\$&')}\\b`, 'i').test(task) : null;
      const mismatch = subject && task && taskNamesSubject === false;
      const tone = job.status === 'COMPLETED' ? 'ok' : job.status === 'SUBMITTED' || job.status === 'FUNDED' ? 'wait' : job.status === 'OPEN' ? 'dim' : 'bad';
      const html = `${pageHead(`Job #${h(id)} — ${h(job.status)}`, `
main{max-width:720px}
.st{display:inline-block;padding:3px 10px;border-radius:999px;font-size:.78rem;font-weight:700;letter-spacing:.3px;margin-left:8px;vertical-align:middle}
.ok{background:rgba(63,224,154,.15);color:#3fe09a}.wait{background:rgba(255,196,107,.15);color:#ffc46b}.dim{background:rgba(255,255,255,.08);color:#a9a49a}.bad{background:rgba(255,143,107,.15);color:#ff8f6b}
p.means{color:#cfc9bd;margin:6px 0 0}dl{display:grid;grid-template-columns:max-content 1fr;gap:6px 16px;margin:0;font-size:.9rem}dt{color:#a9a49a}dd{margin:0;overflow-wrap:anywhere}
.task{font-style:italic;color:#cfc9bd;margin:0 0 10px}.head{font-size:1.05rem;font-weight:700;margin:0 0 8px}
.card{border:1px solid rgba(240,185,11,.22);border-radius:14px;padding:14px 16px;background:rgba(240,185,11,.04)}
.note{color:#a9a49a;font-size:.82rem;margin-top:10px}.none{color:#a9a49a}`)}${pageNav({ href: SITE + '/registry', label: 'Brain Plaza' }, { href: '/job?id=' + h(id), label: 'Job #' + h(id) }, BUY)}<h1>Job #${h(id)}<span class="st ${tone}">${h(job.status)}</span></h1>
<p class="means">${h(means)}</p>
<h2>What was asked</h2>
${task ? `<p class="task">&ldquo;${h(task)}&rdquo;</p>` : '<p class="none">No description on the job.</p>'}
<dl><dt>Service</dt><dd>${h(svcName || delivery?.service || '—')}</dd><dt>Budget</dt><dd>${h(job.budget_u ?? '—')} $U in escrow</dd>
<dt>Client</dt><dd>${addr(job.client)}</dd><dt>Provider</dt><dd>${addr(job.provider)}</dd>
<dt>Submitted</dt><dd>${when(job.submitted_at)}</dd><dt>${job.status === 'COMPLETED' || job.status === 'EXPIRED' || job.status === 'REJECTED' ? 'Was due' : 'Expires'}</dt><dd>${when(job.expired_at)}</dd>
<dt>Kernel</dt><dd>${addr(ERC8183.commerce)} on BNB Chain</dd></dl>
<h2>What was delivered</h2>
${delivery ? `<div class="card">${sum?.headline ? `<p class="head">${h(sum.headline)}</p>` : ''}${mismatch ? `<p class="note" style="margin:0 0 8px;color:#ffc46b">Delivered for ${h(subject)}, which the task text does not name — the seller read the task differently from how it was written. The digest check below says only that the document is the one committed, not that it answers the question.</p>` : ''}
${sum?.facts?.length ? `<dl>${sum.facts.map(([k, v]) => `<dt>${h(k)}</dt><dd>${h(v)}</dd>`).join('')}</dl>` : ''}
<p class="note">Produced ${h(delivery.produced_at ? String(delivery.produced_at).replace('T', ' ').slice(0, 16) + ' UTC' : '—')}. <a href="${h(delivery.document_url)}">Full document</a>${delivery.tx ? ` · <a href="https://bscscan.com/tx/${h(delivery.tx)}" target="_blank" rel="noopener">delivery transaction</a>` : ''}.<br>
${delivery.digest_matches === true ? 'The SHA-256 of that document matches the digest written on the kernel: what you read is what was committed.'
    : delivery.digest_matches === false ? 'The SHA-256 of the stored document does NOT match the digest on the kernel — read the document, not this page.'
    : 'No digest on the kernel to check against yet.'}</p></div>`
    : `<p class="none">${job.status === 'COMPLETED' || job.status === 'SUBMITTED' ? 'A deliverable is on the kernel, but this worker was not the provider, so the document itself is not held here.' : 'Nothing delivered yet.'}</p>`}
<p class="note">Same facts as JSON: <a href="/job?id=${h(id)}&amp;format=json">/job?id=${h(id)}&amp;format=json</a> · <a href="https://brainonbnb.com/registry">Brain Plaza</a></p>
${pageTail}`;
      return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' } });
    }

    // The series. Daily points and full-scan points are returned separately,
    // never merged into one line — one is a sample of two dozen endpoints, the
    // other is every id in the registry, and a chart that averages them would
    // be lying with real numbers.
    // The public record. Every task this router passed on, and the track
    // record that falls out of it — derived from the log, never declared by
    // the operator it describes.
    if (path === '/sessions') {
      const sessions = await readSessions(env);
      const record = trackRecord(sessions);
      // A browser gets the same record as a page. /registry links here with
      // "Full log", and until 2026-09-03 a person following that link landed on
      // raw JSON. Agents keep getting JSON: no Accept: text/html, or ?format=json.
      const wantsHtml = /text\/html/.test(request.headers.get('accept') || '') && url.searchParams.get('format') !== 'json';
      if (wantsHtml) {
        const h = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
        const when = (t) => (t ? String(t).replace('T', ' ').slice(0, 16) + ' UTC' : '—');
        const o = sessionOrigins(sessions, OWN_AGENT_IDS);
        const recent = sessions.slice(-40).reverse();
        const originLabel = (s) => ({ our_scheduled_checks: 'our check', our_quote_runs: 'our quote run', quote_requests_before_marking: 'origin not recorded' }[originOf(s)] || '');
        const html = `${pageHead('What has actually been asked — Brain Plaza', `
main{max-width:960px}
p.means{color:#cfc9bd;margin:6px 0 0}.note{color:#a9a49a;font-size:.82rem;margin-top:10px}
.wrap{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:.84rem}th{text-align:left;color:#a9a49a;font-weight:600;font-size:.72rem;letter-spacing:.4px;text-transform:uppercase;padding:6px 8px;border-bottom:1px solid rgba(255,255,255,.12)}
td{padding:7px 8px;border-bottom:1px solid rgba(255,255,255,.06);vertical-align:top}td.n{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}
.ok{color:#3fe09a}.bad{color:#ff8f6b}.dim{color:#a9a49a}.task{font-style:italic;color:#cfc9bd}.ex{color:#a9a49a;font-size:.78rem}`)}${pageNav({ href: SITE + '/registry', label: 'Brain Plaza' }, { href: '/sessions', label: 'What has actually been asked' }, BUY)}<h1>What has actually been asked</h1>
<p class="means">Every task Brain Plaza has routed to another agent, and how each one went. Failures included: a record that only showed successes would be marketing. Nobody reports their own score here; an operator appears because it was asked something, and its reliability is the count of times it answered.</p>
<p class="note">${h(sessions.length)} tasks recorded (the last ${MAX_SESSIONS} are kept) · ${h(record.length)} operators seen. Of the tasks, <b>${h(o.outside_callers)} carry no mark of ours</b> (a task the operator typed into the page himself looks the same as a stranger's, so that is an upper bound on strangers), ${h(o.our_scheduled_checks)} were our own daily checks, ${h(o.our_quote_runs)} our own quote runs (the registry publish asking every Hire button for a price)${o.quote_requests_before_marking ? `, and ${h(o.quote_requests_before_marking)} were quote requests from before ${h(ORIGIN_MARKED_SINCE.slice(0, 10))} whose origin was not recorded, nearly all of them ours` : ''}; ${h(o.to_our_own_agents)} of all of them were routed to our own agents. Each is marked below. What was asked is stored with a short excerpt of the answer, never the full response.</p>
<h2>Track record, by operator</h2>
<div class="wrap"><table><thead><tr><th>Operator</th><th>Answered</th><th>Median</th><th>Tools it answered with</th><th>Last seen</th><th>Recent failures</th></tr></thead><tbody>
${record.map((r) => `<tr><td>${h(r.operator)}${r.agent && String(r.agent) !== String(r.operator) ? `<br><span class="dim">${h(r.agent)}</span>` : ''}</td><td class="n ${r.answered === r.tasks_routed ? 'ok' : r.answered ? '' : 'bad'}">${h(r.reliability)}${r.of_which_our_scheduled_checks ? `<br><span class="dim">${h(r.of_which_our_scheduled_checks)} our checks</span>` : ''}${r.of_which_our_quote_runs ? `<br><span class="dim">${h(r.of_which_our_quote_runs)} our quote runs</span>` : ''}${r.of_which_origin_not_recorded ? `<br><span class="dim">${h(r.of_which_origin_not_recorded)} origin not recorded</span>` : ''}<br><span class="dim">${h(r.from_outside_callers)} from outside</span></td><td class="n">${r.median_ms == null ? '—' : h(r.median_ms) + ' ms'}</td><td>${r.tools_used.length ? h(r.tools_used.join(' · ')) : '<span class="dim">—</span>'}</td><td class="n">${h(when(r.last_seen))}</td><td class="ex">${r.recent_failures ? h(r.recent_failures.join(' · ')) : ''}</td></tr>`).join('')}
</tbody></table></div>
<h2>The last ${h(recent.length)} tasks, newest first</h2>
<div class="wrap"><table><thead><tr><th>When</th><th>Asked</th><th>Routed to</th><th>Outcome</th><th>Took</th></tr></thead><tbody>
${recent.map((s) => `<tr><td class="n">${h(when(s.at))}${originLabel(s) ? `<br><span class="dim">${h(originLabel(s))}</span>` : ''}</td><td><span class="task">&ldquo;${h(s.task)}&rdquo;</span>${s.excerpt ? `<br><span class="ex">${h(s.excerpt)}</span>` : ''}</td><td>${h(s.operator || s.agent || '—')}${s.tool ? `<br><code class="dim">${h(s.tool)}</code>` : ''}</td><td class="${s.ok ? 'ok' : 'bad'}">${h(s.outcome)}</td><td class="n">${typeof s.ms === 'number' ? h(s.ms) + ' ms' : '—'}</td></tr>`).join('')}
</tbody></table></div>
<p class="note">Same record as JSON: <a href="/sessions?format=json">/sessions?format=json</a> · <a href="https://brainonbnb.com/registry">Brain Plaza</a></p>
${pageTail}`;
        return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' } });
      }
      return json({
        what_this_is: 'Every task Brain Plaza has routed to another agent, and how each one went. Failures included — a record that only showed successes would be marketing.',
        how_to_read_it: 'Nobody reports their own score here. An operator appears because it was asked something, and its reliability is the count of times it answered. We store what was asked and a short excerpt of the answer, never the full response.',
        sessions_recorded: sessions.length,
        // A rolling window, not the lifetime (2026-09-18): the log keeps the
        // newest 400 and this read as "400" for good, while /stats counts on.
        window: `the most recent ${sessions.length} routed tasks; older entries are dropped, the lifetime counts are at https://agent.brainonbnb.com/stats`,
        // The headline split four ways, because "400 sessions" without it read
        // as 400 strangers and was, on 2026-09-08, almost entirely us.
        of_which: sessionOrigins(sessions, OWN_AGENT_IDS),
        operators_seen: record.length,
        track_record: record,
        recent: sessions.slice(-40).reverse(),
      });
    }

    if (path === '/census-history') {
      const raw = JSON.parse((await env.AGENT.get('census:history')) || '[]');
      const daily = raw.filter((p) => p.kind === 'daily');
      const full = raw.filter((p) => p.kind === 'full');
      const first = daily[0], last = daily[daily.length - 1];
      return json({
        what_this_is: 'How the ERC-8004 registry on BNB Chain has moved since we started watching it.',
        note: 'Daily points track the registry high-water mark and re-check a rotating slice of known endpoints — a sample, not the whole registry. Full points come from scanning every id offline. They are kept apart because they measure different things.',
        watching_since: first?.date || null,
        days_observed: daily.length,
        growth: first && last ? {
          from: first.highest_id, to: last.highest_id,
          new_registrations: (last.highest_id || 0) - (first.highest_id || 0),
          per_day: daily.length > 1
            ? Math.round(((last.highest_id || 0) - (first.highest_id || 0)) / (daily.length - 1))
            : null,
          // The window the rate is over — the whole time watched, not "since the
          // last full scan", beside which the page used to print it.
          per_day_over: daily.length > 1 ? { from: first.date, to: last.date, days: daily.length - 1 } : null,
        } : null,
        daily,
        full_scans: full,
      });
    }

    // Records a completed offline scan as a fixed point in the series. Secret
    // guarded: these are the numbers the page quotes, and anyone able to post
    // them could rewrite the history the page is built on.
    if (path === '/census-history' && request.method === 'POST') {
      return json({ error: 'use /census-full' }, 400);
    }
    if (path === '/census-full' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      const b = await request.json().catch(() => null);
      if (!b || !Number.isInteger(b.registered_ids)) return json({ error: 'registered_ids required' }, 400);
      const hist = JSON.parse((await env.AGENT.get('census:history')) || '[]');
      const date = (b.date || new Date().toISOString()).slice(0, 10);
      const point = {
        date, kind: 'full',
        registered_ids: b.registered_ids,
        parse: b.parse ?? null,
        with_endpoint: b.with_endpoint ?? null,
        reachable: b.reachable ?? null,
        operators: b.operators ?? null,
        mcp: b.mcp ?? null,
      };
      const i = hist.findIndex((h) => h.date === date && h.kind === 'full');
      if (i >= 0) hist[i] = point; else hist.push(point);
      hist.sort((x, y) => (x.date < y.date ? -1 : 1));
      await env.AGENT.put('census:history', JSON.stringify(hist));
      return json({ ok: true, recorded: point, points: hist.length });
    }

    // The LP width record, as the cron has built it. Same shape as
    // data/lp-windows.json so `lp-windows.mjs --sync` can merge it straight
    // in, plus the verdict the decision module would draw from it — computed
    // by the same function, so the two cannot disagree.
    // THE POOL RECORD: the same fifty dollars replayed in each pool of the
    // universe (WBNB with a major, every tier), hour by hour, at the width
    // the agent uses — and the switch rule that says whether the best of
    // them is worth moving to.
    if (path === '/lp/pools') {
      const wantsHtml = /text\/html/.test(request.headers.get('accept') || '') && url.searchParams.get('format') !== 'json';
      if (wantsHtml) {
        const h = (x) => String(x ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
        const html = `${pageHead('The pool record — the DeFi agent', `
main{max-width:820px}
p.lead{color:#cfc9bd;margin:6px 0 0}
.card{border:1px solid rgba(240,185,11,.22);border-radius:14px;padding:14px 16px;background:rgba(240,185,11,.04);margin-bottom:10px}
.note{color:#a9a49a;font-size:.82rem;margin-top:10px}
`)}${pageNav({ href: '/lp/windows', label: 'The width record' }, { href: '/lp/pools', label: 'The pool record' }, BUY)}<h1>The pool record</h1>
<p class="lead">Retired on ${h(LP_POOLS_RETIRED.retired)}. ${h(LP_POOLS_RETIRED.why.replace(/^[a-z]/, (ch) => ch.toUpperCase()))}.</p>
<div class="card"><b>${h(HOME_POOL.label)}</b> is the agent's pool. What is still decided, and measured every hour, is how wide its range is and how long it waits before a re-set: <a href="/lp/windows">the width record</a>.<p class="note">${h(LP_POOLS_RETIRED.what_it_was.replace(/^[a-z]/, (ch) => ch.toUpperCase()))}.</p></div>
<p class="note">Same facts as JSON: <a href="/lp/pools?format=json">/lp/pools?format=json</a> · the agent's record: <a href="/lp/agent">/lp/agent</a> · <a href="https://brainonbnb.com/defi">how it works</a></p>
${pageTail}`;
        return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'public, max-age=300' } });
      }
      return json(LP_POOLS_RETIRED, 200, { 'Cache-Control': 'public, max-age=300' });
    }

    if (path === '/lp/windows') {
      // AT THE EDGE, AS THE PORTFOLIO (2026-10-10): built fresh on every call it took 4 to 9 s and 674 KB of JSON
      // under no-store, for a record the cron changes once an hour. A pure read (KV and a price, nothing written),
      // so the last copy is served at once, one per variant (page or JSON); a copy older than five minutes is
      // rebuilt in the background, and each is kept 15 minutes.
      const asHtml = /text\/html/.test(request.headers.get('accept') || '') && url.searchParams.get('format') !== 'json';
      const ck = new Request(`https://agent.brainonbnb.com/lp/windows?as=${asHtml ? 'html' : 'json'}`);
      const put = (res) => { if (globalThis.caches) { const c = res.clone(); c.headers.set('cache-control', 'public, max-age=900'); c.headers.set('x-built-at', String(Date.now())); return caches.default.put(ck, c).catch(() => {}); } };
      const hit = globalThis.caches ? await caches.default.match(ck).catch(() => null) : null;
      if (hit) {
        if (Date.now() - Number(hit.headers.get('x-built-at') || 0) > 300e3) ctx.waitUntil(buildWindows().then((r) => r.status === 200 && put(r)).catch(() => {}));
        const out = new Response(hit.body, hit); out.headers.set('cache-control', 'public, max-age=60'); return out;
      }
      const res = await buildWindows();
      if (res.status === 200) ctx.waitUntil(put(res));
      return res;
    }
    async function buildWindows() {
      const { log, v } = await lpWidthVerdict(env);
      if (!log) return json({ error: 'no LP window has been recorded yet', cadence: 'hourly' }, 503);
      // What the agent's own position earned against the replay's figure
      // for its width class (2026-09-10): the record says so beside the
      // dollar it names. Missing under a day of series, or without a position.
      if (v) {
        try {
          const rec = await readAgentRecord(env);
          // after a re-set the step's ticks are the range it LEFT; new_ticks is the one standing (2026-10-09, as lpNow)
          const rbC = rec?.last?.steps?.rebalance, ticks = (rbC?.acted && !rbC?.error && rbC?.new_ticks) || rbC?.ticks || rec?.last?.steps?.increase?.ticks || null;
          const pos = (rbC?.acted && rbC?.new_position) || rbC?.position || rec?.last?.steps?.increase?.position || null;
          v.calibration = lpCalibration(await readLpSeries(env), v.rows, widthClassOf(ticks), { position: pos, replayBetween: v.replayBetween });
          v.resets = resetLosses(rec, { bnbUsd: await bnbUsd().catch(() => null) });
        } catch { v.calibration = null; }
      }
      // THE WIDTH RECORD, READABLE. The record page and /defi link here
      // as "the width record", and a person arrived at raw JSON (pressed
      // 2026-09-04). The same verdict as a page: which width the agent would
      // use and why, every width replayed side by side, and what the record
      // is made of. Nothing is computed here that the verdict does not carry.
      const wantsHtml = /text\/html/.test(request.headers.get('accept') || '') && url.searchParams.get('format') !== 'json';
      if (wantsHtml && v) {
        const h = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
        const when = (t) => (t ? String(t).replace('T', ' ').slice(0, 16) + ' UTC' : '—');
        const f = (x, d = 2) => (x == null || !isFinite(Number(x)) ? '—' : Number(x).toFixed(d));
        // The pick the re-set would make: re-read with the width the position
        // is in (as the plan and the portfolio do) — without it the page could
        // name a width the agent would not take.
        let inUseWidth = null;
        try { const recW = JSON.parse((await env.AGENT.get('lp:agent')) || 'null'); const rbW = recW && recW.last && recW.last.steps && recW.last.steps.rebalance; const tk = rbW && ((rbW.acted && !rbW.error && rbW.new_ticks) || rbW.ticks); if (tk) inUseWidth = widthClassOf(tk); } catch { /* the record's own pick stands */ }
        const pick = (Array.isArray(v.rows) && v.rows.some((r) => r.earnings_7d) && v.earnings_pick ? pickWidth(v.rows, { current: inUseWidth }) : null) || v.earnings_pick || null;
        const score7 = (r) => (r && r.earnings_7d ? Number(r.earnings_7d.fees_usd || 0) - Number(r.earnings_7d.resets || 0) * Number(r.earnings_7d.reset_cost_usd || 0) + Number(r.earnings_7d.vs_holding_usd || 0) : null);
        const rows = (v.rows || []).slice().sort((a, b) => a.width - b.width);
        const usd = log.usd || 50;
        const html = `${pageHead('The width record — the DeFi agent', `
main{max-width:820px}
p.lead{color:#cfc9bd;margin:6px 0 0}
.card{border:1px solid rgba(240,185,11,.22);border-radius:14px;padding:14px 16px;background:rgba(240,185,11,.04);margin-bottom:10px}
dl{display:grid;grid-template-columns:max-content 1fr;gap:6px 16px;margin:0;font-size:.9rem}dt{color:#a9a49a}dd{margin:0;overflow-wrap:anywhere}
.note{color:#a9a49a;font-size:.82rem;margin-top:10px}
.wrap{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:.86rem;min-width:560px}th,td{text-align:right;padding:7px 8px;border-top:1px solid rgba(255,255,255,.08);white-space:nowrap}th{color:#a9a49a;font-weight:600;text-transform:none;border-top:0}td:first-child,th:first-child{text-align:left}tr.pick td{color:#f0b90b;font-weight:700}
`)}${pageNav({ href: '/lp/agent', label: 'The record' }, { href: '/lp/windows', label: 'The width record' }, BUY)}<h1>The width record</h1>
<p class="lead">How wide the DeFi agent sets its price range, and why. Every hour a cron replays a position of $${h(usd)} through the last hour of the CAKE/BNB 0.05% pool and records what each width would have earned; ${env.LP_RESET_MODE === 'centred' && Number(env.LP_WIDTH_PCT) > 0 ? `the widths are then replayed over every recorded price the way the agent lives them since 2026-10-07: a range the price has left is re-set centred on the price with one swap back to the range's mix, after the agent's own wait, charged its measured cost and what the old range had lost against holding. <b>Every re-set mints ±${h(env.LP_WIDTH_PCT)}%</b>, a fixed width chosen on the recorded prices because each re-set locks that loss in; the pick below is what the replay would choose on its own, kept for comparison. Nothing here is a forecast.` : `the widths are then replayed over every recorded price the way the agent lives them since 2026-09-16: a range the price has left is re-set one-sided, beside the price on the side it came from, with the one token it ended in and no trade, after the agent's own wait, at its measured gas. The width the next re-set uses is the one that ended the most ahead against holding over the last week in that replay, fees included — what the liquidity earned plus where it ended against a wallet that held the minted amounts, the line the card judges the agent by; the width in use is kept unless another leads it by a tenth of its own score. Nothing here is a forecast.`}</p>
<h2>The pick</h2>
<div class="card"><dl>
<dt>Width</dt><dd>${pick ? `<b>±${h(pick.width)}%</b> — ${h(pick.basis || '')}${pick.earnings_7d ? `: about $${h(f(pick.earnings_7d.fees_usd, 2))} of fees on $${h(usd)} in ${h(f(pick.earnings_7d.hours, 0))} h (${h(f(pick.earnings_7d.hours_in_range, 0))} h of them inside the range) after ${h(pick.earnings_7d.resets)} ${env.LP_RESET_MODE === 'centred' ? 'centred' : 'one-sided'} re-set${pick.earnings_7d.resets === 1 ? '' : 's'} at $${h(f(pick.earnings_7d.reset_cost_usd, 2))} each; the liquidity ended ${pick.earnings_7d.vs_holding_usd < 0 ? '$' + h(f(-pick.earnings_7d.vs_holding_usd, 2)) + ' behind' : '$' + h(f(pick.earnings_7d.vs_holding_usd, 2)) + ' ahead of'} holding its minted amounts` : ''}` : `none yet — ${h(v.hours_of_prices || 0)} h of prices are on record and 24 h are needed before a width may be picked`}</dd>
<dt>Wait</dt><dd>${(() => { const dt = v.delay_test || {}; const ds = dt.delays || []; if (!ds.length) return `${h(dt.in_use_hours ?? 2)} h outside the range before a re-set — the wait the agent uses; whether another wait would net more is replayed once a day of prices is on record`; const line = ds.map((d) => `${h(d.hours)} h: ${d.net_usd_per_day == null ? 'nothing' : `$${h(f(d.net_usd_per_day, 2))} a day at ±${h(d.width)}% after ${h(d.resets)} re-set${d.resets === 1 ? '' : 's'}`}${d.in_use ? ' (in use)' : ''}`).join(' · '); return `<b>${h(dt.in_use_hours)} h</b> outside the range before a re-set is what the agent uses — ${dt.wait_basis === 'measured' ? 'measured' : 'set'}: ${h(dt.why || '')}. Replayed with every wait: ${line}. A measured wait needs 120 h of prices and a tenth more per day than the set wait; under either bar the set wait stands.`; })()}</dd>
<dt>Re-set cost</dt><dd>$${h(f(v.reset_cost && v.reset_cost.usd, v.reset_cost && Number(v.reset_cost.usd) > 0 && Number(v.reset_cost.usd) < 0.01 ? 4 : 2))} per $50 — ${h(v.reset_cost && v.reset_cost.basis)}</dd>
<dt>Re-sets so far</dt><dd>${v.resets && v.resets.resets ? `${h(v.resets.resets)} on record: <b>${h(f(v.resets.lost_to_price_bnb, 5))} BNB</b> lost to the price against holding by the trades of the centred re-sets (a one-sided re-set, since 2026-09-16, trades nothing and realises nothing)${v.resets.rows[0] && v.resets.rows[0].lost_to_price_usd != null ? ` (≈ $${h(f(v.resets.rows.reduce((a, r) => a + (r.lost_to_price_usd || 0), 0), 2))})` : ''}, ${h(f(v.resets.execution_bnb, 5))} BNB of execution (gas, swap fee${v.resets.impact_measured ? ', impact measured on ' + h(v.resets.impact_measured) : ', impact not yet measured'}) — the table below` : 'none on record yet'}</dd>
<dt>Measured</dt><dd>${v.calibration ? `the agent's own position at ±${h(v.calibration.position_width_pct)}% earned <b>$${h(f(v.calibration.measured_usd_per_day_on_50, 2))} a day on $50</b> over the last ${h(f(v.calibration.hours, 0))} h, against $${h(f(v.calibration.replay_usd_per_day_on_50, 2))} the replay puts on that width${v.calibration.replay_same_hours ? ' over the same hours' : v.calibration.replay_hours != null ? ` over its own ${h(f(v.calibration.replay_hours, 0))} h` : ''}${v.calibration.factor != null ? ` — ${h(f(v.calibration.factor * 100, 0))}% of the replay's figure` : ''}. ${v.calibration.replay_is === 'above' ? 'Here the replay says more than the position earned' : v.calibration.replay_is === 'below' ? 'Here the position earned more than the replay says' : v.calibration.replay_is === 'close' ? 'Here the two are within a tenth of each other' : 'The two cannot be set against each other yet'}; the two cover different hours, so this is a check on the dollars, not a correction. The pick compares widths with each other on the same replay and is not scaled; the dollar beside it is an estimate, this line is the measurement.` : 'the position has not earned for a day yet on the series — the replay\'s dollars are estimates until it has'}</dd>
<dt>Held a full day</dt><dd>${v.day_pick ? `±${h(v.day_pick.width)}% is the narrowest width that stayed in range through every tested 24-hour window (${h(v.day_pick.day.held)} of ${h(v.day_pick.day.tested)}).${v.day_pick.width !== (pick && pick.width) ? ' It is not the pick: the pick is the width that ended the most ahead against holding over the week.' : ''}` : 'no width has held through every tested day yet'}</dd>
<dt>Record</dt><dd>${h(v.windows)} windows, ${h(when(v.from))} to ${h(when(v.to))}, blocks ${h(v.from_block)} to ${h(v.to_block)}${v.price_samples ? `; ${h(v.price_samples)} ten-minute price samples since ${h(when(v.price_samples_since))} walked beside the hourly heads` : '; the ten-minute price tape starts with the next check'}${v.overlapping_runs_not_counted ? `; ${h(v.overlapping_runs_not_counted)} overlapping run${v.overlapping_runs_not_counted === 1 ? '' : 's'} counted once` : ''}${v.thin ? ' — thin: too few windows to lean on yet' : ''}</dd>
</dl></div>
<h2>Every width, replayed</h2>
<div class="card"><div class="wrap"><table>
<tr><th>Width</th><th>Net per day</th><th>Fees earned</th><th>Re-sets</th><th>Against holding, 7 d</th><th>Score, 7 d</th><th>Hours in range</th><th>Windows held</th><th>Days held</th></tr>
${rows.map((r) => { const e = r.earnings; const money = (x, d) => (x == null ? '—' : '$' + f(x, d)); return `<tr${pick && r.width === pick.width ? ' class="pick"' : ''}><td>${isFinite(Number(r.width)) ? `±${h(r.width)}%${r.derived ? ` <span style="color:#a9a49a;font-weight:400">(from ±${h(r.derived_from ? r.derived_from[1] : '')}%)</span>` : ''}` : 'full range (V2-like)'}</td><td>${h(money(e && e.net_usd_per_day, 3))}</td><td>${h(money(e && e.fees_usd, 3))}</td><td>${h(e ? e.resets : 'never')}</td><td>${h(r.earnings_7d && r.earnings_7d.vs_holding_usd != null ? (r.earnings_7d.vs_holding_usd < 0 ? '−$' : '$') + f(Math.abs(r.earnings_7d.vs_holding_usd), 2) : '—')}</td><td>${h(score7(r) == null ? '—' : (score7(r) < 0 ? '−$' : '$') + f(Math.abs(score7(r)), 2))}</td><td>${e ? `${h(f(e.hours_in_range, 0))} of ${h(f(e.hours, 0))}` : 'always'}</td><td>${h(r.held)} of ${h(r.of)}</td><td>${r.day ? `${h(r.day.held)} of ${h(r.day.tested)}` : 'all'}</td></tr>`; }).join('')}
</table></div>
<p class="note">Net per day is fees earned inside the range minus the re-sets paid minus what the ranges lost to the price against holding (the re-sets' losses plus the open range marked at the last price), on $${h(usd)}, over the recorded prices. A narrow width earns more per hour inside the range, leaves it more often and loses more at each edge; a wide one rarely leaves and earns little. Since 2026-09-16 a re-set trades nothing, so what decides is no longer the net per day: the pick is the width with the highest score over the last 7 days — its fees, less its re-sets' gas, plus where it ended against a wallet that simply held (the last two columns) — and the width in use is kept unless another leads it by a tenth. It moves as the prices do.</p>
<p class="note">Widths marked "from" are not replayed hour by hour; their fees are read off the next wider replayed width by the liquidity a range holds per dollar, 1 / (1 − 1/√(1+width)) — the record's own rows stand in that proportion to the digit, and whether they held, off the next narrower one. Since 2026-09-11, so the pick is not bound to a coarse grid.</p>
<p class="note">${h(String(v.earnings_rule || '').replace(/^[a-z]/, (ch) => ch.toUpperCase()))}</p></div>
${v.resets && v.resets.rows.length ? `<h2>What each re-set cost</h2>
<div class="card"><div class="wrap"><table>
<tr><th>When</th><th>Left</th><th>Into</th><th>Price moved</th><th>Position</th><th>Lost to the price</th><th>Execution</th><th>Impact</th></tr>
${v.resets.rows.map((r) => `<tr><td>${h(when(r.at))}${r.forced_by_deposit ? ' · deposit' : ''}</td><td>±${h(r.from_width_pct)}%</td><td>${r.to_width_pct != null ? '±' + h(r.to_width_pct) + '%' : '—'}</td><td>${r.price_move_pct > 0 ? '+' : ''}${h(f(r.price_move_pct, 2))}%</td><td>${h(f(r.position_bnb, 4))} BNB</td><td>${h(f(r.lost_to_price_bnb, 5))} BNB (${h(f(r.lost_to_price_pct, 2))}%)${r.lost_to_price_usd != null ? ' ≈ $' + h(f(r.lost_to_price_usd, 2)) : ''}</td><td>${h(f(r.execution_bnb, 6))} BNB${r.execution_usd != null ? ' ≈ $' + h(f(r.execution_usd, 2)) : ''}</td><td>${r.impact_bnb == null ? 'not measured' : h(f(r.impact_bnb, 6)) + ' BNB'}</td></tr>`).join('')}
</table></div>
<p class="note">${h(v.resets.basis.replace(/^[a-z]/, (ch) => ch.toUpperCase()))}. The loss to the price is what the earnings test charges every replayed re-set; here it is read off the re-sets that happened.</p></div>` : ''}
${log.last_error ? (() => { const since = (Array.isArray(log.windows) ? log.windows : []).filter((w) => w && w.at && Date.parse(w.at) > Date.parse(log.last_error.at)).length; return `<p class="note">Last hour that could not be measured: ${h(when(log.last_error.at))} (${h(log.last_error.error)}). ${since ? `${h(since)} window${since === 1 ? '' : 's'} recorded since; it is skipped, not guessed.` : 'Skipped, not guessed.'}</p>`; })() : ''}
<p class="note">Same facts as JSON: <a href="/lp/windows?format=json">/lp/windows?format=json</a> · the agent's record: <a href="/lp/agent">/lp/agent</a> · which pool: <a href="/lp/pools">the pool record</a> · <a href="https://brainonbnb.com/defi">how it works</a></p>
${pageTail}`;
        return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' } });
      }
      return json({ ...log, verdict: v, cadence: 'hourly',
        note: 'Every entry is one replay of pancakeswap_range_plan over about an hour of live chain (37 minutes before 2026-09-09), recorded by the cron whether anybody is watching or not. Overlapping entries are counted once in the verdict. Nothing here is a forecast.' });
    }

    // Our own ERC-8183 jobs and the date each one was first seen to complete.
    // The figure this marketplace argues with is 287 SUBMITTED against 8
    // COMPLETED; this is where our own jobs stand against it, checked daily.
    // What the DeFi agent's daily tick did — sweep, collect, rebalance,
    // increase (worker-lp writes it, this serves it; that worker holds the
    // keys and no public face on purpose). /lp/collect is the old name.
    if (path === '/buys/refused') {
      return json({ what_this_is: 'The last 20 payments (14 days) that came back without buying: what was bought, the status, the reason the paying path gave, the caller\'s user agent and the shape of the proof — never the proof itself.', refused: (await env.AGENT.get('payrefused', 'json').catch(() => null)) || [] });
    }
    if (path === '/buys') {
      const tx = (url.searchParams.get('tx') || '').toLowerCase().match(/^0x[0-9a-f]{64}$|^x402:\d+$|^holder:\S+$/)?.[0] || null;
      // a payer whose payment did not buy finds the reason beside the ones that did (2026-10-25)
      return json({ ...(await readBuys(env, tx)), refused: 'https://agent.brainonbnb.com/buys/refused' }, 200, { 'Cache-Control': 'public, max-age=60' });
    }
    if (path === '/lp/agent' || path === '/lp/collect') {
      const rec = await readAgentRecord(env);
      if (!rec) return json({ error: 'the DeFi agent has not run yet', cadence: 'daily' }, 503);
      // Where the money came from and where it went: computed once, here,
      // from the record and the service's own earnings — the page below, the
      // liquidity page and the Telegram report all read this one figure set.
      const earned = await readEarnings(env).catch(() => null);
      const flow = moneyFlow(rec, { earned });
      // THE RULE IN FORCE, not the one the last collect ran under (2026-10-14: the thirds were live, the page still read
      // 50/50 from the morning's collect until the next one): the same constant the agent splits with
      flow.rule = { fee_share_kept_pct: FEE_SHARE_KEPT_PCT, fee_share_bobai_pct: +((100 - FEE_SHARE_KEPT_PCT) / 2).toFixed(2), fee_share_operator_pct: +((100 - FEE_SHARE_KEPT_PCT) / 2).toFixed(2) };
      const wantsHtml = /text\/html/.test(request.headers.get('accept') || '') && url.searchParams.get('format') !== 'json';
      // The ladder record beside it (worker-lp, KV lp:ladder): which position
      // is the main range and which the reserve. The hand script reads it
      // from here, so it sees the wallet the way the worker does (2026-09-17).
      if (!wantsHtml) {
        let ladder = null;
        try { ladder = JSON.parse((await env.AGENT.get('lp:ladder')) || 'null'); } catch { ladder = null; }
        // `cadence` is the route convention every record route answers with;
        // the record's own timetable (daily, hourly, watch) rides beside it.
        return etagJson(request, { ...rec, flow, ladder, cadence: 'daily', cadence_detail: rec.cadence && typeof rec.cadence === 'object' ? rec.cadence : null });
      }
      // THE RECORD, READABLE. The homepage, /agents and the Telegram alert all
      // say "the daily record is here" and pointed a person at raw JSON. The
      // same facts as a page: what the agent holds, what it decided on its
      // last run and why (the record's own sentences, written for exactly
      // this), and every day it actually moved money. Nothing is computed
      // here that the record does not carry; the one addition is a dollar
      // figure for the BNB, from the same reference pair every page uses.
      const h = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
      const f = (v, d = 4) => (v == null || !isFinite(Number(v)) ? '—' : Number(v).toFixed(d));
      const when = (t) => (t ? String(t).replace('T', ' ').slice(0, 16) + ' UTC' : '—');
      const price = await bnbUsd().catch(() => 0);
      const usd = (bnb) => (price > 0 && bnb != null && isFinite(Number(bnb)) ? ` (≈ $${(Number(bnb) * price).toFixed(2)})` : '');
      // The newest run on record: the daily one, or an hourly re-set after it
      // (those land in history) — the rule the liquidity page, the series and
      // the Telegram alert use. Reading `last` alone said "quiet day, last run
      // 2026-09-06 05:23" the morning after two automatic re-sets, with the
      // collect step still saying "this wallet holds no position". The sweep,
      // collect and increase steps come from the daily run: an hourly re-set
      // has only the rebalance step.
      const daily = rec.last || {}, dst = daily.steps || {};
      const histAll = Array.isArray(rec.history) ? rec.history.filter((e) => e && !e.dry) : [];
      const newest = histAll.length ? histAll[histAll.length - 1] : null;
      const last = newest && daily.at && Date.parse(newest.at) > Date.parse(daily.at) ? newest : daily;
      const st = last.steps || {};
      const rb = st.rebalance || {};
      const c = st.collect || dst.collect || {}, inc = st.increase || dst.increase || {};
      // The ladder step (2026-09-16) and the reserve range it keeps: on the page
      // since 2026-09-18 — the record carried both, the page showed neither.
      const ld = st.ladder || dst.ladder || {};
      const rsv = ld.reserve || rb.reserve || inc.reserve || null;
      const sweeps = Array.isArray(st.sweep) ? st.sweep : (Array.isArray(dst.sweep) ? dst.sweep : []);
      // When a step is the daily run's and the newest run is a later re-set,
      // the step's figures are dated by the daily run.
      const fromDaily = last !== daily && !st.collect;
      const dailyWhen = when(daily.at);
      // The record's reasons are the agent's own words for its operator; one
      // of them names a script ("open one first with lp-open.mjs") — not for
      // a visitor.
      const plain = (t) => String(t || '').replace(/\s*[\u2014-]\s*open one first with lp-open\.mjs/i, '');
      const reset = rb.acted && !rb.error && rb.new_position;
      const pos = reset ? rb.new_position : (c.position || rb.position || null);
      const inRange = reset ? true : (c.in_range != null ? c.in_range : rb.in_range);
      // The record is the run's view; the chain's is the present. Read live,
      // so "in range and earning" is never nine hours old — it was, on
      // 2026-09-03, for the whole morning after the price had left the range.
      let live = null;
      if (pos) {
        try {
          const NPM = '0x46a15b0b27311cedf172ab29e4f4766fbe7f4364', FACTORY = '0x0bfbcf9fa4f9c56b0f40a671ad40e0805a091865';
          const s24 = (x) => { let n = BigInt('0x' + x); if (n >= (1n << 255n)) n -= (1n << 256n); return Number(n); };
          const pr = await rpc('eth_call', [{ to: NPM, data: '0x99fbab88' + BigInt(pos).toString(16).padStart(64, '0') }, 'latest']);
          const w = (i) => pr.slice(2 + 64 * i, 2 + 64 * (i + 1));
          const poolAddr = '0x' + (await rpc('eth_call', [{ to: FACTORY, data: '0x1698ee82' + w(2) + w(3) + w(4) }, 'latest'])).slice(26);
          const slot = await rpc('eth_call', [{ to: poolAddr, data: '0x3850c7bd' }, 'latest']);
          const tick = s24(slot.slice(66, 130)), lo = s24(w(5)), hi = s24(w(6));
          live = { tick, lo, hi, inRange: tick >= lo && tick < hi };
        } catch { live = null; }
      }
      // The collect step's "fees owed" is about the position that step read.
      // When that is not the one open now (none, after the stopped re-set of
      // 2026-09-05; the new one minted by hand the next morning), the fees
      // owed are read from the chain, the same reading /lp/look gives.
      let liveOwed = null;
      // ... and after a collect that acted, because its own figure is what it
      // found before it collected (2026-09-18: 0.006472 BNB shown as "owed
      // now" two hours after those fees were collected).
      // ... and always since 2026-11-12: the line says "now", and the 04:23 figure stood under it all day
      if (pos) {
        try {
          const lk = await lpPositionLook({ position: String(pos) });
          if (lk && lk.fees_owed && lk.fees_owed.bnb_equivalent != null) liveOwed = Number(lk.fees_owed.bnb_equivalent);
        } catch { liveOwed = null; }
      }
      if (liveOwed != null) flow.waiting.fees_owed_bnb = liveOwed;
      // Dry runs are the operator checking a deploy; they sign nothing and
      // moved nothing, and the first one (2026-09-02, before the income keys
      // were set) stood under "Runs that failed" for two days.
      const hist = (Array.isArray(rec.history) ? rec.history : []).filter((e) => e && !e.dry);
      const fl = flowLines(flow);
      const stepRows = [
        ...sweeps.map((s) => ({ name: `Sweep — ${s.source || 'income'} wallet`, acted: !!s.acted, err: s.error, why: s.why, detail: (s.balance != null ? `${f(s.sweeping ?? s.balance, 4)} ${s.token || ''} waiting${s.bnb_equivalent != null && (s.sweeping ?? s.balance) > 0 ? `, worth ${f(s.bnb_equivalent, 6)} BNB` : ''}${s.kept > 0 ? `; ${f(s.kept, 2)} ${s.token || ''} kept for its own hires` : ''}` : '') + (fromDaily ? `${s.balance != null ? '; ' : ''}from the daily run at ${dailyWhen}` : '') })),
        { name: 'Collect — the position\'s fees', acted: !!c.acted, err: c.error, why: plain(c.why), detail: (c.owed ? `owed at that run: ${f(c.owed.bnb_equivalent, 6)} BNB${usd(c.owed.bnb_equivalent)}` : '') + (fromDaily ? `${c.owed ? '; ' : ''}from the daily run at ${dailyWhen}` : '') },
        // A re-set that acted says what it did — the old range withdrawn, the
        // other side bought, the new range minted, the gas and the fees folded
        // in — not the state it found the moment before (2026-09-08: the line
        // read "outside since 04:50" under a re-set that had already happened).
        { name: 'Rebalance — the price range', acted: !!rb.acted, err: rb.error, why: rb.why, detail: (rb.acted && !rb.error && rb.new_position
          ? `re-set: the old range${rb.ticks ? ` ${rb.ticks.join(' … ')}` : ''} (price at tick ${rb.tick ?? '—'}${rb.outside_since ? `, outside since ${String(rb.outside_since).replace('T', ' ').slice(0, 16)} UTC` : ''}) was withdrawn${rb.one_sided ? ` and #${rb.new_position} minted one-sided ${rb.one_sided === 'above_price' ? 'above' : 'below'} the price, no trade` : `, the missing side bought and #${rb.new_position} minted`}${Array.isArray(rb.new_ticks) ? ` at ${rb.new_ticks.join(' … ')}` : ''}${rb.width_pct != null ? `, ±${rb.width_pct}%` : ''}${Array.isArray(rb.txs) ? ` in ${rb.txs.length} transaction${rb.txs.length === 1 ? '' : 's'}` : ''}${rb.gas_bnb != null ? `, ${f(rb.gas_bnb, 6)} BNB of gas` : ''}${rb.fees_folded && rb.fees_folded.bnb_equivalent != null ? `; ${f(rb.fees_folded.bnb_equivalent, 6)} BNB of the old range's fees ${Number(rb.bobai_bnb) > 0 ? `taken: ${f(rb.bobai_bnb, 6)} BNB bought $BOBAI the agent holds${Number(rb.to_operator_bnb) > 0 ? `, ${f(rb.to_operator_bnb, 6)} BNB paid out to the operator` : ''}, the rest folded into the capital` : Number(rb.fees_forwarded_bnb) > 0 ? `taken: ${f(rb.fees_forwarded_bnb, 6)} BNB sent to the buyback bot, the rest folded into the capital` : `folded into the capital${rb.fees_forward_why ? ` (${rb.fees_forward_why})` : ''}`}` : ''}`
          : (rb.ticks ? `ticks ${rb.ticks.join(' … ')}, price at tick ${rb.tick ?? '—'}` : '') + (rb.width_pct != null ? `; the next re-set would use ±${rb.width_pct}%${rb.expected_net_usd_per_day != null ? ` (about $${rb.expected_net_usd_per_day} a day on $50 over the recorded prices)` : ''}` : '') + (rb.outside_since ? `, outside since ${String(rb.outside_since).replace('T', ' ').slice(0, 16)} UTC` : ''))
          + (last.range_checked_at ? `, range checked ${String(last.range_checked_at).replace('T', ' ').slice(0, 16)} UTC` : '') },
        { name: 'Ladder — the reserve range below the price', acted: !!ld.acted, err: ld.error, why: plain(ld.why), detail: rsv ? `reserve #${rsv.position}${Array.isArray(rsv.ticks) ? `, ticks ${rsv.ticks.join(' … ')}` : ''}${rsv.value_bnb != null ? `, worth ${f(rsv.value_bnb, 5)} BNB` : ''}${rsv.side ? `, ${rsv.side === 'wbnb' ? 'all BNB, below the price' : rsv.side === 'other' ? 'the price fell through it — it joins the main range at the next re-set' : 'the price is inside it'}` : ''}` : (ld.why ? 'no reserve range stands' : '') },
        { name: 'Increase — grow the position', acted: !!inc.acted, err: inc.error, why: plain(inc.why), detail: (inc.wallet_bnb != null ? `${f(inc.wallet_bnb, 5)} BNB in the wallet, ${f(inc.spendable_bnb, 5)} above the reserve` : '') + (fromDaily ? `${inc.wallet_bnb != null ? '; ' : ''}from the daily run at ${dailyWhen}` : '') },
      ].filter((r) => r.why || r.err || r.detail);
      const histRows = hist.slice().reverse().slice(0, 60).map((e) => {
        const s = e.steps || {}; const parts = [];
        for (const x of Array.isArray(s.sweep) ? s.sweep : []) if (x.acted && !x.error) parts.push(x.to_operator != null
          // since 2026-10-14: half to the operator in the coin paid, half bought $BOBAI held in the income wallet
          // since 2026-10-22 (SWEEP_LIQ): a share of the $BOBAI half may go into the $BOBAI pool, LP burned
          ? `swept ${f(Number(x.sold) + Number(x.to_operator), 2)} ${x.token || ''}: half to the operator, half bought ${f(x.bobai_bought, 0)} $BOBAI, held${x.liquidity ? `, and ${f(x.liquidity.bobai_in, 0)} $BOBAI + ${f(x.liquidity.wbnb_in, 6)} WBNB added to the $BOBAI pool, LP burned` : ''}`
          : `swept ${f(x.sold, 2)} ${x.token || ''} → ${f(x.received_bnb, 5)} BNB into the DeFi wallet`);
        if (s.collect?.acted && !s.collect.error && (Number(s.collect.bobai_bnb ?? s.collect.forwarded_bnb) > 0 || Number(s.collect.kept_bnb) > 0)) parts.push(`collected fees → ${f(s.collect.bobai_bnb ?? s.collect.forwarded_bnb, 5)} BNB into BOBAI held in the wallet${Number(s.collect.kept_bnb) > 0 ? `, ${f(s.collect.kept_bnb, 5)} BNB kept as capital` : ''}${Number(s.collect.to_operator_bnb) > 0 ? `, ${f(s.collect.to_operator_bnb, 5)} BNB paid out to the operator` : ''}`);
        if (s.rebalance?.acted && !s.rebalance.error) parts.push(`range re-set${s.rebalance.width_pct ? ` ±${s.rebalance.width_pct}%` : ''}${s.rebalance.new_position ? `, position #${s.rebalance.new_position}` : ''}`);
        // New BNB in, as the sums count it; an increase that only put the
        // wallet's leftovers back in brought no new BNB and says what it put.
        if (s.increase?.acted && !s.increase.error) parts.push(increaseIntoPosition(s.increase) >= 0.00001 || !(Number(s.increase.other_used) > 0)
          ? `added ${f(increaseIntoPosition(s.increase), 5)} BNB to the position`
          : `put the wallet's leftover ${f(s.increase.other_used, 4)} ${String(s.increase.would_add?.other_token || '').toLowerCase() === '0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82' ? 'CAKE' : 'of the other token'}${Number(s.increase.wbnb_used) > 0 ? ` and ${f(s.increase.wbnb_used, 5)} WBNB` : ''} into the position — no new BNB`);
        if (s.ladder?.acted && !s.ladder.error) parts.push(s.ladder.new_reserve && !s.ladder.old_reserve ? `opened a reserve range below the price with ${f(s.ladder.bnb_spent, 4)} BNB (#${s.ladder.new_reserve})` : s.ladder.old_reserve ? `re-set the reserve range beside the price (#${s.ladder.old_reserve} → #${s.ladder.new_reserve})` : s.ladder.merged_reserve ? `merged the reserve range into the main one (#${s.ladder.merged_reserve})` : `grew the reserve range by ${f(s.ladder.bnb_spent, 4)} BNB`);
        const errs = [...(Array.isArray(s.sweep) ? s.sweep : []), s.collect, s.rebalance, s.increase, s.ladder].filter((x) => x && x.error).map((x) => x.error);
        if (e.error) errs.push(e.error);
        return { at: e.at, parts, errs, ok: e.ok !== false };
      });
      const html = `${pageHead('The DeFi agent — its record', `
main{max-width:760px}
p.lead{color:#cfc9bd;margin:6px 0 0}dl{display:grid;grid-template-columns:max-content 1fr;gap:6px 16px;margin:0;font-size:.9rem}dt{color:#a9a49a}dd{margin:0;overflow-wrap:anywhere}
.card{border:1px solid rgba(240,185,11,.22);border-radius:14px;padding:14px 16px;background:rgba(240,185,11,.04);margin-bottom:10px}
.flow{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:560px){.flow{grid-template-columns:1fr}}.flow div{border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:10px 12px}.flow b{display:block;color:#f0b90b;font-size:.8rem;text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px}.flow span{display:block;font-size:.9rem;color:#f3efe6}.flow i{display:block;font-style:normal;color:#a9a49a;font-size:.8rem;margin-top:4px}
.st{display:inline-block;padding:2px 9px;border-radius:999px;font-size:.74rem;font-weight:700;margin-left:8px;vertical-align:middle}
.ok{background:rgba(63,224,154,.15);color:#3fe09a}.quiet{background:rgba(255,255,255,.08);color:#a9a49a}.bad{background:rgba(255,143,107,.15);color:#ff8f6b}
.step b{display:block}.step span{display:block;color:#cfc9bd;font-size:.88rem}.step i{display:block;color:#a9a49a;font-size:.8rem;font-style:normal;margin-top:2px}
.note{color:#a9a49a;font-size:.82rem;margin-top:10px}ul.hist{list-style:none;padding:0;margin:0}ul.hist li{padding:8px 0;border-top:1px solid rgba(255,255,255,.08);font-size:.9rem}ul.hist li:first-child{border-top:0}ul.hist time{color:#a9a49a;font-size:.8rem;display:block}
`)}${pageNav({ href: SITE + '/defi', label: 'DeFi agent' }, { href: '/lp/agent', label: 'The DeFi agent — its record' }, BUY)}<h1>The DeFi agent <span class="st ${last.ok === false ? 'bad' : last.acted ? 'ok' : 'quiet'}">${last.ok === false ? 'one step failed' : reset ? 're-set the range' : last.acted ? 'acted' : 'quiet day'}</span></h1>
<p class="lead">On its own, every day: ${Date.now() < Date.parse('2026-11-20T00:01:00Z') ? 'until 20 Nov 2026, a slice of every $BOBAI trade works' : 'what a slice of every $BOBAI trade brought until 20 Nov 2026 works'} in the project's own liquidity position; of the fees that position earns, ${flow.rule ? `${h(flow.rule.fee_share_kept_pct)}% stay as capital so the position grows out of its own earnings, ${h(flow.rule.fee_share_bobai_pct)}% buy $BOBAI that the agent holds and never sells${flow.rule.fee_share_operator_pct ? ` and ${h(flow.rule.fee_share_operator_pct)}% are paid out to the operator as BNB` : ''}` : 'a third stays as capital, a third buys $BOBAI the agent holds and a third is paid out to the operator'}. What other AIs pay this project is split when it is swept: half buys $BOBAI, half is the operator's revenue. Every step is a transaction on BNB Chain. Last run ${h(when(last.at))}${last !== daily ? ` (an hourly check that ${reset ? 're-set the range' : 'acted'}; the daily run before it, ${h(dailyWhen)}, ${daily.acted ? 'acted' : 'had nothing to do'})` : ''}.</p>
<h2>What it holds</h2>
<div class="card"><dl>
<dt>Position</dt><dd>${pos ? `PancakeSwap V3 <a href="https://pancakeswap.finance/liquidity/${h(pos)}?chain=bsc" target="_blank" rel="noopener">#${h(pos)}</a>, ${live ? (live.inRange ? 'in range and earning' : `out of range right now (tick ${live.tick}, range ${live.lo} to ${live.hi}) — earning nothing until an hourly check finds it outside for longer than the measured wait and re-sets it`) : (inRange === false ? 'out of range at the last run' : 'in range at the last run')}${live && live.inRange !== inRange ? ` — the run at ${h(when(last.at))} saw it ${inRange === false ? 'out of' : 'in'} range` : ''}${(rb.value_with_reserve_bnb ?? rb.value_bnb) != null ? `, worth ${f(rb.value_with_reserve_bnb ?? rb.value_bnb, 4)} BNB${usd(rb.value_with_reserve_bnb ?? rb.value_bnb)}${rb.reserve ? ' with the reserve range' : ''}` : ''}` : 'none open'}</dd>
${rsv ? `<dt>Reserve range</dt><dd>PancakeSwap V3 <a href="https://pancakeswap.finance/liquidity/${h(rsv.position)}?chain=bsc" target="_blank" rel="noopener">#${h(rsv.position)}</a>${rsv.value_bnb != null ? `, worth ${f(rsv.value_bnb, 5)} BNB${usd(rsv.value_bnb)}` : ''} — ${rsv.side === 'wbnb' ? 'BNB below the price: it buys the other side as the price falls into it' : rsv.side === 'other' ? 'the price fell through it; it joins the main range at the next re-set' : 'the price is inside it, it earns on both sides'}. Counted in the worth above.</dd>` : ''}
<dt>Fees owed now</dt><dd>${liveOwed != null ? `${f(liveOwed, 6)} BNB${usd(liveOwed)} — read from the chain just now; ${reset ? `the re-set at ${h(when(last.at))} folded the old range's fees into the new capital, so the new position started at zero` : c.acted && !c.error ? `the collect at ${h(fromDaily ? dailyWhen : when(last.at))} took what was owed then, this is what has accrued since` : `the run at ${h(fromDaily ? dailyWhen : when(last.at))} ${c.position ? `read position #${h(c.position)}` : 'saw no position'}`}. Left to grow until collecting beats the gas` : c.owed ? `${f(c.owed.bnb_equivalent, 6)} BNB${usd(c.owed.bnb_equivalent)} — left to grow until collecting beats the gas` : '—'}</dd>
<dt>Income waiting</dt><dd>${sweeps.filter((s) => (s.sweeping ?? s.balance) > 0).map((s) => `${f(s.sweeping ?? s.balance, 2)} ${h(s.token || s.source)}`).join(' + ') || 'nothing'} — moves once it is worth more than the gas${sweeps.filter((s) => s.kept > 0).map((s) => ` · ${f(s.kept, 2)} ${h(s.token || s.source)} on the ${h(s.source)} wallet kept for its own hires`).join('')}</dd>
<dt>Wallet</dt><dd><a href="https://bscscan.com/address/${h(rec.last?.wallet || '')}" target="_blank" rel="noopener"><code>${h(rec.last?.wallet || '—')}</code></a>${inc.wallet_bnb != null ? `, ${f(inc.wallet_bnb, 5)} BNB` : ''}</dd>
</dl></div>
<h2>Where the money came from, where it went</h2>
<div class="card"><div class="flow">
<div><b>Came in</b><span>${h(fl.came_in)}</span>${flow.paid_for && flow.paid_for.x402_answers ? `<i>The x402 service has been paid ${h(f(flow.paid_for.usd1, 2))} USD1 for ${h(flow.paid_for.x402_answers)} answer${flow.paid_for.x402_answers === 1 ? '' : 's'} since it opened. What of it has reached the income wallet is under Waiting and is swept once it is worth more than the gas; the rest went through the earlier path, which burned it directly.</i>` : ''}</div>
<div><b>Went out</b><span>${h(fl.went_out)}${flow.out.bobai_bnb > 0 && usd(flow.out.bobai_bnb) ? ` — the BOBAI share, bought for ${usd(flow.out.bobai_bnb).slice(2, -1)}${flow.out.bobai_units > 0 ? `, ${h(Math.round(flow.out.bobai_units).toLocaleString('en-US'))} BOBAI held` : ''}` : ''}</span><i>${flow.out.resets} re-set${flow.out.resets === 1 ? '' : 's'} of the range · ${h(fl.cost)}${usd(flow.gas.bnb)}</i></div>
<div><b>Waiting</b><span>${flow.waiting.income.length ? flow.waiting.income.map((w) => `${f(w.amount, 2)} ${h(w.token)} on the ${h(w.source || 'income')} wallet`).join(', ') : 'no income on the wallets'}${(flow.waiting.kept || []).map((k) => ` (${f(k.amount, 2)} ${h(k.token)} on the ${h(k.source)} wallet kept for its own hires)`).join('')}; ${flow.waiting.fees_owed_bnb == null ? 'fees owed by the position not read at the last run' : `${f(flow.waiting.fees_owed_bnb, 6)} BNB of fees owed by the position`}${flow.waiting.wallet_spendable_bnb != null ? `; ${f(flow.waiting.wallet_spendable_bnb, 5)} BNB in the DeFi wallet above the reserve` : ''}</span><i>Each moves once it is worth more than the gas it costs.</i></div>
<div><b>The rule</b><span>${flow.rule ? `${h(flow.rule.fee_share_kept_pct)}% of every collect stays as capital, ${h(flow.rule.fee_share_bobai_pct)}% buys $BOBAI the agent holds in its own wallet, never sold${flow.rule.fee_share_operator_pct ? `, ${h(flow.rule.fee_share_operator_pct)}% is paid out to the operator as BNB` : ''}.` : 'The share of the fees kept as capital is named with the next collect.'} AI income no longer becomes capital since 2026-10-14: half buys $BOBAI held in its wallet, half is paid to the operator. The capital never leaves.</span><i>Set in the open: LP_FEE_KEEP_PCT in worker-lp/wrangler.toml, in <a href="https://brainonbnb.com/source">the published source</a>.</i></div>
</div></div>
<h2>The last run, step by step</h2>${fromDaily ? `<p class="note" style="margin:0 0 8px">The newest run, ${h(when(last.at))}, was an hourly range check; it has the rebalance step only. The other steps run once a day and are shown from ${h(dailyWhen)}.</p>` : ''}
<div class="card">${stepRows.map((r) => `<div class="step" style="margin:0 0 10px"><b>${h(r.name)}<span class="st ${r.err ? 'bad' : r.acted ? 'ok' : 'quiet'}">${r.err ? 'failed' : r.acted ? 'acted' : 'nothing to do'}</span></b><span>${h(r.err || r.why || '')}</span>${r.detail ? `<i>${h(r.detail)}</i>` : ''}</div>`).join('')}
<p class="note">Each step has a floor under which moving the money would cost more than the money. A day under a floor is a decision, recorded as one, not an error.</p></div>
<h2>Days it moved money</h2>
<div class="card">${histRows.filter((r) => r.parts.length).length ? `<ul class="hist">${histRows.filter((r) => r.parts.length).map((r) => `<li><time>${h(when(r.at))}</time>${r.parts.length ? r.parts.map(h).join(' · ') : (r.errs.length ? '' : 'recorded')}${r.errs.length ? `<span class="st bad">error</span> ${h(r.errs.join(' · '))}` : ''}</li>`).join('')}</ul>` : '<p class="note">None yet. The position was opened by hand; the agent has had only quiet days since.</p>'}
${histRows.some((r) => !r.parts.length && r.errs.length) ? `<h2>Runs that failed</h2><div class="card"><ul class="hist">${histRows.filter((r) => !r.parts.length && r.errs.length).map((r) => `<li><time>${h(when(r.at))}</time><span class="st bad">error</span> ${h(r.errs.join(' · '))}</li>`).join('')}</ul><p class="note">A failed run moved nothing; it is listed so the record cannot hide it.</p></div>` : ''}
<p class="note">Quiet days are not listed; the last one is always above. Same facts as JSON: <a href="/lp/agent?format=json">/lp/agent?format=json</a> · width record: <a href="/lp/windows">/lp/windows</a> · pool record: <a href="/lp/pools">/lp/pools</a> · <a href="https://brainonbnb.com/defi">Back to the DeFi agent</a></p></div>
${pageTail}`;
      return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store' } });
    }

    if (path === '/jobs/own') {
      const rec = await readOwnJobs(env);
      if (!rec) return json({ error: 'no own-jobs tick has run yet', cadence: 'daily' }, 503);
      return json({ ...rec, cadence: 'daily', settled_by_us: await readSettled(env),
        note: 'Every job this project has made or delivered on the ERC-8183 kernel, classified with the same rule as scripts/erc8183-job-watch.mjs. The escrow does not release itself: after the dispute window somebody has to call settle(jobId) on the EvaluatorRouter — since 2026-10-14 this worker does it for every job of ours whose window is over (settled_by_us: simulated first, sent only when it goes through). history holds one entry per observed transition.' });
    }

    if (path === '/census') {
      const latest = await env.AGENT.get('census:latest');
      if (!latest) return json({ error: 'no census tick has run yet' }, 503);
      return json(JSON.parse(latest));
    }

    // Live state of our own two agents, in the shape the rest of this chain
    // uses it: the four reference agents serve /status, so ours does too, at
    // the same path and with the same content type. An agent that asks the
    // market to be machine-readable and is not is a poster.
    //
    // Served from the snapshot the cron writes, not computed per request. The
    // grid probe measures a live pool and the health probe reads the
    // Comptroller; doing that on every hit would let anybody with a loop spend
    // our RPC budget and other people's.
    // What this agent is allowed to SPEND, as opposed to what it can do. Read
    // from the Altana KeyStore on-chain rather than from our own config, so the
    // answer is one a stranger can reproduce with two view calls. See
    // session.js for why revocation is deliberately not reachable from here.
    if (path === '/session') {
      // the chain read kept 60 s (2026-11-16: 10-16 s a load); measured_at says when it was read, a revoke clears it
      const ck = new Request(`https://agent.brainonbnb.com/session/state?chain=${url.searchParams.get('chain') || 'all'}`);
      let st = await caches.default.match(ck).then((r) => (r ? r.json() : null)).catch(() => null);
      if (!st) {
        st = await handleSession(url, env);
        if (!st.chains.some((c) => c.error)) ctx.waitUntil(caches.default.put(ck, new Response(JSON.stringify(st), { headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=60' } })).catch(() => {}));
      }
      const out = annotateRoles(st, env);
      // The revocations fired from the product, beside the live state, so the
      // page can show the control and its record together.
      out.revocations = await readRevocations(env);
      out.revoke = { how: 'POST /session/revoke with the operator token — see GET /session/revoke', public: false };
      return json(out);
    }
    // Revocation from the product: two locks (admin key as a worker secret,
    // operator token on the request), see session-revoke.js.
    if (path === '/session/revoke') {
      const res = await handleSessionRevoke(request, env);
      // a revoke shows at once on /session, never a cached "valid"
      if (request.method === 'POST') await Promise.all(['all', '56', '97'].map((c) => caches.default.delete(new Request(`https://agent.brainonbnb.com/session/state?chain=${c}`)).catch(() => {})));
      return res;
    }

    // When this worker was last deployed (2026-10-24, operator: "auf der page steht ja immer noch rebuilt 1h ago" — a
    // change to the board, the agents or the APIs ships here, not with the site); the front page shows the newer of both
    if (path === '/build') {
      return json({ agent_deployed_at: env.CF_VERSION_METADATA?.timestamp || null, version: env.CF_VERSION_METADATA?.id || null });
    }

    if (path === '/status') {
      const t = await readTelemetry(env);
      if (!t) return json({ error: 'no telemetry tick has run yet' }, 503);
      const want = url.searchParams.get('agent') || url.searchParams.get('id');
      if (want) {
        const one = t.ours.find((a) => String(a.id) === want || a.category === want);
        if (!one) return json({ error: `no agent "${want}" here`, agents: t.ours.map((a) => ({ id: a.id, category: a.category })) }, 404);
        // A category can hold more than one agent (2026-10-10): the first stays
        // at the top level as before, and `agents` carries every one of them.
        const byId = t.ours.some((a) => String(a.id) === want);
        const same = byId ? [] : t.ours.filter((a) => a.category === want);
        return json({ ...one, checked_at: one.checked_at || t.checked_at, method: t.method,
          ...(byId ? {} : { agents: same.map((a) => ({ ...a, checked_at: a.checked_at || t.checked_at })), count: same.length }) });
      }
      return json({
        origin: 'https://agent.brainonbnb.com',
        agents: t.ours,
        checked_at: t.checked_at,
        cadence: t.cadence,
        method: t.method,
        note: `${(t.ours || []).length} agents share this origin, so this answers with all of them. Ask for one with ?agent=302257 or ?agent=grid-trading.`,
      });
    }

    // Everything the telemetry tick collected, ours and the reference set's,
    // for the category pages on brainonbnb.com/registry.
    if (path === '/telemetry.json') {
      const t = await readTelemetry(env);
      if (!t) return json({ error: 'no telemetry tick has run yet' }, 503);
      return json(t);
    }

    if (path === '/run-rollup' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      return json(await rollupDetail(env, url.searchParams.get('day') || today()));
    }

    if (path === '/run-telemetry' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      return json(await refreshTelemetry(env));
    }

    if (path === '/stats') {
      // ONE MINUTE AT THE EDGE (2026-11-20, A-Z: 1.5-2.7 s on every call, no-store, 52 KB — every counter key is read each
      // time; /services and /defi waited on it): the answer is built at most once a minute per edge, generated_at says when
      const statsKey = new Request('https://agent.brainonbnb.com/stats?edge=60');
      const cachedStats = globalThis.caches ? await caches.default.match(statsKey).catch(() => null) : null;
      if (cachedStats) { const h = new Headers(cachedStats.headers); h.set('cache-control', 'public, max-age=30'); h.set('access-control-allow-origin', '*'); return new Response(cachedStats.body, { status: 200, headers: h }); }
      const [counters, earnings, watches] = await Promise.all([
        readCounters(env),
        readEarnings(env),
        listAll(env, 'watch:'),
      ]);
      // "Requests answered" must mean requests somebody made. Our own cron
      // sweeps are counted too — they are worth knowing — but folding them into
      // the public total would inflate it with our own activity, which is the
      // exact dishonesty this block exists to avoid.
      // The rug-watch sweep and the alerts it sends are ours too (2026-10-09).
      const INTERNAL = new Set(['watch_checks', 'rug_watch_checks', 'rug_watch_alerts']);
      const external = Object.fromEntries(
        Object.entries(counters.byKind).filter(([k]) => !INTERNAL.has(k)),
      );
      const statsRes = json({
        asked: {
          total: Object.values(external).reduce((a, b) => a + b, 0),
          by_kind: external,
          by_day: counters.byDay,
          internal: Object.fromEntries(
            Object.entries(counters.byKind).filter(([k]) => INTERNAL.has(k)),
          ),
          note: 'total counts requests made by others. Our own scheduled sweeps are listed separately under internal.',
          counting: 'Counts before 2026-09-09 10:34 UTC are LOW, not high: the counter was one KV read-modify-write per request and lost most increments under load (Cloudflare\'s own request analytics showed about five requests for every one counted that day). Since that hour the counts are added up in memory and written every five minutes; a restart can lose those minutes, never more.',
        },
        earned: earnings,
        active_watches: watches.keys.length,
        money_flow: {
          '1': 'an agent pays for a single answer or a 30-day watch over x402 (USD1 signed by EIP-3009 and settled by us, or by direct transfer; USDC by standard x402 through Permit2; or $BOBAI at the quoted rate), or $U for a job delivered on the ERC-8183 kernel',
          '2': `it lands at ${payTo || '(not configured)'} (USD1) or 0x73809F69916FcF7Ddc5BB1315fBdf96A569a5963 ($U) — wallets used for nothing else`,
          '3': 'once a day it is split (since 2026-10-14): half is sent to the operator in the coin it was paid in, half is sold for $BOBAI that stays in that wallet and is never sold; until then it was sold for BNB and became capital of the DeFi wallet 0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A',
          '4': 'the DeFi wallet 0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A runs the project\'s PancakeSwap V3 position (a slice of every $BOBAI trade went in until 2026-11-20; since then what other agents pay and the operator adds); the fees it earns are collected and sold for BNB, and since 2026-10-14 split in thirds: a third stays as capital (LP_FEE_KEEP_PCT on worker-lp), a third buys $BOBAI the agent holds and never sells, a third is paid out to the operator as BNB',
          '5': 'every step is a public transaction, verifiable on BscScan; the daily record is at /lp/agent',
          floors: 'nothing is sold below 0.004 BNB of value, no fees are collected below 0.002 BNB and nothing is added to the position below 0.005 BNB — under a floor, gas would eat the amount, and a day under one is recorded as a decision, not an error',
          before: 'until 2026-09-02 the earnings were burned directly from the service wallet, by hand. The first: 0.50 USD1 -> 6,043.28 $BOBAI, burned 2026-08-22: https://bscscan.com/tx/0x0da33c6339fd88de8fa443f7d41d0e0749fbac14e678c976fd3dc0f6ea39b27e',
          note: 'Automated since 2026-09-02 by the DeFi agent (worker-lp): sweep, collect, increase, and a re-set of the range once the record holds a day of prices. The $BOBAI the agent buys from its fees shows on its own wallet; the burn log at logs.brainonbnb.com lists only the runs of the buyback bot.',
        },
        capabilities: offering(),
        generated_at: new Date().toISOString(),
      });
      if (globalThis.caches) { const c = statsRes.clone(); const h = new Headers(c.headers); h.set('cache-control', 'public, max-age=60'); ctx.waitUntil(caches.default.put(statsKey, new Response(c.body, { status: 200, headers: h })).catch(() => {})); }
      return statsRes;
    }

    // Called by the dashboard worker so that MCP and REST traffic lands in the
    // same counters as everything else. Shared-secret rather than open, or the
    // public numbers would be whatever a stranger felt like posting.
    if (path === '/hit' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      const body = await request.json().catch(() => ({}));
      const kind = String(body.kind || '').replace(/[^a-z0-9_]/gi, '').slice(0, 32);
      // `detail` names what was asked for (bumpDetail); it may come alone —
      // the MCP relay counts the request once and names the method afterwards.
      const names = [].concat(body.detail || []).map(cleanDetail).filter(Boolean);
      if (!kind && !names.length) return json({ error: 'kind required' }, 400);
      // `n` (2026-10-04): the site relays crawler noise as a sample — one in
      // twenty, weighted twenty — so ~98k hits a day stop costing ~98k relays.
      const n = Math.min(100, Math.max(1, Math.floor(Number(body.n) || 1)));
      if (kind) ctx.waitUntil(bump(env, kind, n));
      if (names.length) ctx.waitUntil(Promise.resolve(bumpDetail(env, names, n)));
      return json({ ok: true });
    }

    // What was asked for, one day at a time (readDetail). Open like /stats:
    // names of tools and routes and how often, nothing about who.
    if (path === '/stats/detail') {
      const day = url.searchParams.get('day') || today();
      if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return json({ error: 'day must be YYYY-MM-DD' }, 400);
      // Two minutes at the edge: the terminal reads this on every heartbeat of
      // every visitor, and an uncached read lists and reads the day's keys.
      const ck = new Request(`https://agent.brainonbnb.com/stats/detail?day=${day}`);
      const hit = globalThis.caches ? await caches.default.match(ck).catch(() => null) : null; // no Cache API outside Workers (tests)
      if (hit) return hit;
      const d = await readDetail(env, day);
      const sorted = Object.fromEntries(Object.entries(d.names).sort((a, b) => b[1] - a[1]));
      const res = json({
        ...d, names: sorted,
        note: 'How often each named thing was asked for on that UTC day: mcp:<method>[:<tool>] (a tool call is mcp:call:<tool>), mcp:client:<software name>, rest:site|ext:<route> (site = our own pages in a browser, ext = everyone else), rest:unknown for a path we do not serve, ua:<family> for ext callers, sell:<step> for the paid path, sellua:<product> for the software that asked a price (since 2026-10-23). Counted since 2026-09-20. Written every five minutes; an evicted isolate loses those minutes. Isolates that have gone quiet are rolled up every 15 minutes (rolled_up); until then they are read one by one. Cached 2 minutes. Separate from /stats: nothing here enters its totals.',
      });
      res.headers.set('cache-control', 'public, max-age=120');
      if (globalThis.caches) ctx.waitUntil(caches.default.put(ck, res.clone()).catch(() => {}));
      return res;
    }

    // MCP, carrying exactly one tool: the paid watch.
    //
    // WHY THIS EXISTS SEPARATELY FROM brainonbnb.com/mcp
    // That server has seventeen tools and every one of them is free. This one
    // has one tool and it costs money. Keeping them apart means an agent that
    // wants the free surface never has to reason about payment, and the paid
    // tool does not have to be smuggled into a server advertised as free.
    //
    // WHY AN MCP TOOL AT ALL, WHEN /watch ALREADY SELLS IT
    // Measured 2026-08-23: all 976 entries in Binance's B402 Bazaar are type
    // "http". Not one is "mcp", though the format has supported it all along.
    // An agent that speaks MCP and wants to buy something has, today, nothing
    // in that catalog it can call natively. The tool below is the same product
    // through the door those agents already have open.
    // THE DEFI AGENT'S OWN MCP (2026-10-14). Mandate checks that an agent's published tools fit its job and tries
    // it free, comparing the answer with the chain (its page for #363709: "Tools publishes no tool list", "What you
    // get, checked: could not be checked"; agents that pass publish an MCP service in their registration). Two
    // tools: the free look at a position (no input = the position this agent runs itself, so a probe always gets a
    // reading it can check on chain), and the paid plan, whose call names the terms of the x402 sale.
    // EVERY AGENT OF OURS HAS ITS OWN MCP (2026-10-14, the DeFi agent's first): Mandate shows "Tools: publishes no tool
    // list" for any agent without an MCP server or A2A card skills, and "fits the job" when the tools match its category.
    // Each lists one free tool of its category (a probe always gets a reading it can check on chain) and its paid
    // answer, whose call names the x402 terms.
    const mcpSlug = (path.match(/^\/([a-z-]+)\/mcp$/) || [])[1];
    if (mcpSlug && AGENT_SERVICE[mcpSlug]) {
      const serviceId = AGENT_SERVICE[mcpSlug], svc = SERVICES[serviceId];
      const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, GET, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, Mcp-Protocol-Version, Mcp-Session-Id, Authorization, Accept', 'Content-Type': 'application/json' };
      const rpcOk = (id, result) => new Response(JSON.stringify({ jsonrpc: '2.0', id, result }), { headers: cors });
      const rpcErr = (id, code, message) => new Response(JSON.stringify({ jsonrpc: '2.0', id, error: { code, message } }), { headers: cors });
      const RO = { readOnlyHint: true, destructiveHint: false, openWorldHint: true };
      const TOKEN = { type: 'string', description: 'A BEP-20 token address on BNB Chain (0x…)' };
      const FREE = {
        'defi-agent': { name: 'lp_position_look', description: 'Rebalancing, the free half: look at a PancakeSwap V3 liquidity position on BNB Chain, read from the chain now — in range or not and how much room is left to each edge, what it holds and is worth in BNB, the fees it is owed and whether collecting them pays for the gas. Give a position id or a wallet that holds one; with neither, it reads the position this agent runs itself (wallet 0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A). Reads only, signs nothing.', inputSchema: { type: 'object', properties: { position: { type: 'string', description: 'A PancakeSwap V3 position id (the NFT token id), digits only' }, address: { type: 'string', description: 'Or a wallet address that holds the position' }, wallet: { type: 'string', description: 'The same as address (the word other checkers use)' } }, additionalProperties: false }, annotations: { readOnlyHint: true, openWorldHint: true } },
        'health-factor': { name: 'venus_health_factor', description: 'Health factor monitoring, the free half: the Venus health factor of a BNB Chain account right now, computed market by market from the Comptroller and cross-checked against the protocol’s own getAccountLiquidity; health_factor at the top. Give the account. The paid half adds the collateral drawdown that would liquidate it and a stress table.', inputSchema: { type: 'object', properties: { address: { type: 'string', description: 'The Venus account (0x…)' } }, required: ['address'], additionalProperties: false }, annotations: RO },
        'yield-optimizer': { name: 'venus_supply_rates', description: 'Yield optimisation, the free half: the supply rate of every Venus market on BNB Chain now, read from each market’s contract, best first (the paid answer cross-checks every rate against the market’s own rate model); venus_usdt_rate_pct at the top. The paid half says whether moving YOUR deposit pays for itself.', inputSchema: { type: 'object', properties: {}, additionalProperties: false }, annotations: RO },
        'grid-trader': { name: 'bsc_pool_scan', description: 'Grid trading, the free half: what a trade in any BSC token’s pool really costs — depth, price impact at sizes, and the transfer tax measured from executed trades. The paid half adds what a grid cycle costs on this pool and the spacing that breaks even. Free for 1,000 scans per caller and UTC day; past that a day pass carries on (POST https://agent.brainonbnb.com/scan-pass, 0.50 USD1 or half that in $BOBAI), sent as HTTP header X-Scan-Pass.', inputSchema: { type: 'object', properties: { address: TOKEN }, required: ['address'], additionalProperties: false }, annotations: RO, rest: '/api/pool-scan' },
        rebalancer: { name: 'pancakeswap_best_route', description: 'Portfolio rebalancing, the free half: which PancakeSwap pool a swap of one token should go through at your size, and what it costs. The paid half prices a whole rebalance against the pools that would execute it.', inputSchema: { type: 'object', properties: { address: TOKEN, usd: { type: 'number', description: 'Trade size in USD' } }, required: ['address'], additionalProperties: false }, annotations: RO, rest: '/api/best-route' },
        'lp-placement': { name: 'pancakeswap_fee_tiers', description: 'Liquidity placement, the free half: the up-to-five PancakeSwap pools a pair lives in and which fee tier is actually paying its liquidity providers. The paid half plans the position: the tier and the range to put it in. It signs and moves nothing.', inputSchema: { type: 'object', properties: { address: TOKEN }, required: ['address'], additionalProperties: false }, annotations: RO, rest: '/api/fee-tiers' },
      }[mcpSlug];
      const PAID = { name: serviceId, description: `${svc.name}, the paid half (0.10 USD1, or half that in $BOBAI, ${HOLDER_PRICE_NOTE.replace('see holder_pass', 'terms in the reply')}): ${svc.deliverables} Calling this tool returns the terms; the answer is sold over x402 at https://agent.brainonbnb.com/answer?service=${serviceId} (or hired through the ERC-8183 escrow for 0.10 $U).`, inputSchema: { type: 'object', properties: { task: { type: 'string', description: 'What you want, with the address in it' } }, additionalProperties: true }, annotations: RO };
      // THE DOOR SAYS HOW TO WALK IN (2026-11-03). A week of /stats/detail: these six servers were listed 19,654 times and
      // called 148 (0.75%), against 2-7% on the main server, which greets with instructions and answers a wrong name with
      // the closest ones. Here an agent got neither. Now each greeting, a wrong tool name and a refused free call carry
      // one call that works: a real public example (our DeFi agent's position, the account the Plaza's chip asks about,
      // CAKE), checked live on 3.11. The same example stands in the free tool's schema.
      const CAKE = '0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82';
      const EX = { 'defi-agent': { position: '7637521' }, 'health-factor': { address: '0xd319e1F8e987cf78333cEA853F455366640929cF' }, 'yield-optimizer': {}, 'grid-trader': { address: CAKE }, rebalancer: { address: CAKE, usd: 250 }, 'lp-placement': { address: CAKE } }[mcpSlug] || {};
      const TRY = `${FREE.name} with ${JSON.stringify(EX)}`;
      const TOOLS = [FREE, PAID].map(({ rest, ...t }) => (t.name === FREE.name ? { ...t, inputSchema: { ...t.inputSchema, examples: [EX] } } : t));
      if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
      const NAME = `${svc.name} — Brain On BNB AI`;
      if (request.method === 'GET') return new Response(JSON.stringify({ name: NAME, protocol: '2025-06-18', tools: TOOLS.map((t) => t.name), note: `POST JSON-RPC here. ${FREE.name} is free; ${PAID.name} is sold over x402.` }), { headers: cors });
      let body;
      try { body = await request.json(); } catch { return rpcErr(null, -32700, 'Parse error'); }
      if (Array.isArray(body)) return rpcErr(null, -32600, 'Invalid request: batch requests are not supported; send one JSON-RPC object per request.');
      const { id, method, params } = body || {};
      if (typeof method !== 'string') return rpcErr(id ?? null, -32600, 'Invalid request: method must be a string.');
      if (method.startsWith('notifications/')) return new Response(null, { status: 202, headers: cors });
      if (method === 'initialize') return rpcOk(id, { protocolVersion: '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: NAME, version: '1.1.0' }, instructions: `${svc.name}, on BNB Chain. Start free: call ${TRY} (a real public example, read from the chain now; put your own in its place). ${PAID.name} returns the terms of the paid answer, 0.10 USD1 over x402. Read-only: nothing here signs, holds a key or moves funds. The free toolbox for any BSC token, 30 tools: https://brainonbnb.com/mcp` });
      if (method === 'ping') return rpcOk(id, {});
      if (method === 'tools/list') { note(`agentmcp:${mcpSlug}:tools_list`); return rpcOk(id, { tools: TOOLS }); }
      if (method === 'tools/call') {
        const name = params?.name, a = params?.arguments || {};
        const known = TOOLS.some((t) => t.name === name);
        note(`agentmcp:${mcpSlug}:call:${known ? name : 'unknown'}`);
        // which name an agent guessed: the tool it wanted (a name only, never an argument), so the next tool is the one asked for
        if (!known) note(`agentmcp:${mcpSlug}:guessed:${String(name ?? '').toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 32) || 'none'}`);
        const answer = (out) => rpcOk(id, { content: [{ type: 'text', text: JSON.stringify(out, null, 2) }], structuredContent: out });
        const refuse = (e) => rpcOk(id, { isError: true, content: [{ type: 'text', text: String(e?.shortMessage || e?.message || e).slice(0, 300) + (name === FREE.name ? ` Try: ${JSON.stringify(EX)}` : '') }] });
        if (name === FREE.name && mcpSlug !== 'defi-agent') {
          try {
            if (mcpSlug === 'health-factor' || mcpSlug === 'yield-optimizer') {
              const r = await freeHalf(mcpSlug, a, env);
              return r ? answer(r.out) : refuse('give the Venus account: address 0x…');
            }
            const qs = new URLSearchParams(Object.entries(a).filter(([, v]) => v != null && v !== '').map(([k, v]) => [k, String(v)]));
            // The pool scan's 50 a day (2026-10-18) count for the caller here too: relayed from this worker the site would
            // see us, so the caller's address goes with the shared secret, and a day pass they send goes on.
            const caller = request.headers.get('cf-connecting-ip'), scanPass = request.headers.get('x-scan-pass');
            const relay = FREE.rest === '/api/pool-scan' && env.HIT_SECRET && caller
              ? { 'x-hit-secret': env.HIT_SECRET, 'x-scan-quota-key': 'ip:' + caller, ...(scanPass ? { 'x-scan-pass': scanPass } : {}) } : {};
            const r = await fetch(`https://brainonbnb.com${FREE.rest}?${qs}`, { headers: { accept: 'application/json', ...relay }, signal: AbortSignal.timeout(30000) });
            const j = await r.json().catch(() => null);
            return j && r.ok ? answer(j) : refuse(j?.hint ? `${j.error} ${j.hint}` : j?.error || `http ${r.status}`);
          } catch (e) { return refuse(e); }
        }
        if (name === 'lp_position_look') {
          try {
            // the figures a checker compares with the chain at the top (as the paid answer since 2026-10-14); a wallet
            // given as `wallet` or `owner` (Mandate's Range-1 words) is read too, it used to be dropped for our own position
            const { out } = await freeHalf('defi-agent', a, env, { defaultOwn: true });
            return rpcOk(id, { content: [{ type: 'text', text: JSON.stringify(out, null, 2) }], structuredContent: out });
          } catch (e) { return rpcOk(id, { isError: true, content: [{ type: 'text', text: String(e.shortMessage || e.message).slice(0, 300) }] }); }
        }
        if (name === PAID.name) {
          if (!payTo) return rpcErr(id ?? null, -32000, 'service not configured to receive payments yet');
          const terms = await sellAnswer(env, ctx, payTo, serviceId, {}, null);
          const t = terms.body || {};
          const out = { payment_required: true, pay_at: `https://agent.brainonbnb.com/answer?service=${serviceId}`, price: '0.10 USD1, or half that in $BOBAI', how: t.how, in_bobai: t.in_bobai, holder_pass: holderPassTerms(), accepts: t.accepts, free_alternative: `${FREE.name} on this server` };
          return rpcOk(id, { content: [{ type: 'text', text: JSON.stringify(out, null, 2) }], structuredContent: out });
        }
        // A PRICE ASKED HERE IS ANSWERED (2026-11-04): get_price_of_token came 12 times in a week across the six doors; the
        // site's MCP answers a price-named call at once now (bsc_token_preflight's pool read, or bobai_price), so it goes there
        // only with a token's address: a bare price question at a Venus or grid door is not taken to mean $BOBAI
        if (!known && /price/i.test(String(name || '')) && /0x[a-fA-F0-9]{40}/.test(JSON.stringify(a))) {
          const pr = await fetch('https://brainonbnb.com/mcp', { method: 'POST', headers: { 'content-type': 'application/json', accept: 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'tools/call', params: { name: String(name).slice(0, 60), arguments: a } }), signal: AbortSignal.timeout(30000) }).then((r) => r.json()).catch(() => null);
          let out = null;
          try { out = pr?.result && !pr.result.isError ? (pr.result.structuredContent || JSON.parse(pr.result.content?.[0]?.text || 'null')) : null; } catch { out = null; }
          if (out) return answer({ ...out, from: 'https://brainonbnb.com/mcp (the free toolbox for any BSC token, 30 tools)' });
        }
        return rpcErr(id ?? null, -32602, `Unknown tool: ${name}. This server has two: ${FREE.name}, free (try ${JSON.stringify(EX)}), and ${PAID.name}, which returns the terms of the paid answer. The free toolbox for any BSC token, 30 tools: https://brainonbnb.com/mcp`);
      }
      return rpcErr(id ?? null, -32601, `Method not found: ${method}`);
    }

    if (path === '/mcp') {
      const cors = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
        // The headers a browser-based MCP client sends (2026-10-05), as on brainonbnb.com/mcp.
        'Access-Control-Allow-Headers': 'Content-Type, Mcp-Protocol-Version, Mcp-Session-Id, Authorization, Accept, X-BOBAI-Thanks',
        'Content-Type': 'application/json',
      };
      const rpcOk = (id, result) => new Response(JSON.stringify({ jsonrpc: '2.0', id, result }), { headers: cors });
      const rpcErr = (id, code, message) => new Response(JSON.stringify({ jsonrpc: '2.0', id, error: { code, message } }), { headers: cors });

      if (request.method === 'GET') {
        return new Response(JSON.stringify({
          name: 'Brain On BNB AI — paid pool watch',
          protocol: '2025-06-18',
          tools: ['bsc_pool_watch'],
          note: 'One tool, and it is paid. The free tools live at https://brainonbnb.com/mcp.',
        }), { headers: cors });
      }

      let body;
      try { body = await request.json(); } catch { return rpcErr(null, -32700, 'Parse error'); }
      // A JSON-RPC batch is said to be one (2026-10-05), not answered "Method not found: undefined".
      if (Array.isArray(body)) return rpcErr(null, -32600, 'Invalid request: batch requests are not supported; send one JSON-RPC object per request.');
      const { id, method, params } = body || {};
      if (typeof method !== 'string') return rpcErr(id ?? null, -32600, 'Invalid request: method must be a string.');
      if (method.startsWith('notifications/')) return new Response(null, { status: 202, headers: cors });

      if (method === 'initialize') {
        return rpcOk(id, {
          protocolVersion: '2025-06-18',
          capabilities: { tools: {} },
          serverInfo: { name: 'Brain On BNB AI — paid pool watch', version: '1.0.0' },
        });
      }
      if (method === 'ping') return rpcOk(id, {});
      if (method === 'tools/list') {
        ctx.waitUntil(bump(env, 'mcp'));
        note('paidmcp:tools_list');
        return rpcOk(id, { tools: [WATCH_TOOL] });
      }
      if (method === 'tools/call') {
        ctx.waitUntil(bump(env, 'mcp'));
        note(`paidmcp:call:${params?.name === 'bsc_pool_watch' ? (params?.arguments?.payment ? 'watch:paid' : 'watch:terms') : 'unknown'}`);
        // This server sells one tool. A stranger who tried the free ones here (bsc_token_preflight …) met a bare
        // "Unknown tool" and a dead end (2026-09-27): the error now names the server that has them.
        if (params?.name !== 'bsc_pool_watch') return rpcErr(id ?? null, -32602, `Unknown tool: ${params?.name}. This server is the paid pool watch only; the free tools (bsc_token_preflight, bsc_pool_scan, pancakeswap_range_plan …) are at https://brainonbnb.com/mcp`);
        if (!payTo) return rpcErr(id ?? null, -32000, 'service not configured to receive payments yet');
        const a = params?.arguments || {};
        const { payment, ...spec0 } = a;
        // The same reading of the spec as the HTTP door, before any payment
        // (A7): pair optional, found from the token; every refusal first.
        const ready = await resolveWatchSpec(spec0).catch(() => ({ error: 'the pair could not be read right now' }));
        if (ready.error) {
          return rpcOk(id, {
            isError: true,
            content: [{ type: 'text', text: ready.error + (payment ? ' Nothing was charged.' : '') }],
          });
        }
        const spec = ready.spec;
        const out = await purchaseWatch(env, ctx, payTo, spec, payment || null);
        missed('mcp:watch', payment, out);
        // A 402 here is not a failure — it is the price list, which is what a
        // first call is for. Reporting it as an error would make every client
        // that checks isError abandon the purchase before it began.
        // The HTTP wording tells the caller to resend with a header. Over MCP
        // there is no header to set — the same proof goes in the `payment`
        // argument — and instructions a caller cannot follow are worse than
        // none, so the sentence is rewritten for the door it came through.
        const forMcp = (b) => ({
          ...b,
          how: `Send ${fmtUsd1(WATCH_PRICE_USD1)} USD1 to ${payTo} on BNB Smart Chain, then call this tool again with the same arguments plus payment: "<transaction hash>".`,
        });
        const answer = out.status === 402 && !payment
          ? { payment_required: true, ...forMcp(out.body) }
          : out.status === 402
            ? { payment_rejected: true, ...out.body }
            : out.body;
        return rpcOk(id, {
          content: [{ type: 'text', text: JSON.stringify(answer, null, 2) }],
          structuredContent: answer,
          ...(out.status === 402 && payment ? { isError: true } : {}),
        });
      }
      return rpcErr(id ?? null, -32601, 'Method not found: ' + method);
    }

    // Reading back one watch. The tool description has always told a buyer
    // without a callback to "poll /watch/<id>" — and this route did not exist,
    // so that buyer had no way to reach the thing they paid for. The id is a
    // v4 UUID handed only to the payer, which is what makes it readable
    // without a second credential.
    // THE GRADUATION DEMAND TEST (2026-10-28, operator's go): the pool scan tells a curve token that an alert for the
    // moment it leaves its launch curve is not built, and points here. A GET with ?token= is an ask; it is counted once
    // per caller, token and day (the caller kept only as a hash of the day and its address), and the count is public.
    // Our own checks (bobai-smoke-test) read it without counting. Built only if agents ask.
    if (path === '/watch/graduation' && (request.method === 'GET' || request.method === 'HEAD')) {
      const doc = JSON.parse((await env.AGENT.get('graduation:asks')) || '{"since":"2026-10-28","total":0,"by_day":{},"tokens":{},"seen":{}}');
      const token = (url.searchParams.get('token') || '').toLowerCase().match(/^0x[0-9a-f]{40}$/)?.[0] || null;
      let counted = false;
      if (token && !selfTest) {
        const day = today();
        const h = [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`${day}|${request.headers.get('cf-connecting-ip') || '-'}|${token}`)))].slice(0, 6).map((b) => b.toString(16).padStart(2, '0')).join('');
        doc.seen = Object.fromEntries(Object.entries(doc.seen || {}).filter(([d]) => d === day));
        const seen = new Set(doc.seen[day] || []);
        if (!seen.has(h) && seen.size < 5000) {
          seen.add(h); doc.seen[day] = [...seen]; counted = true;
          doc.total++; doc.by_day[day] = (doc.by_day[day] || 0) + 1; doc.tokens[token] = (doc.tokens[token] || 0) + 1;
          if (Object.keys(doc.tokens).length > 200) doc.tokens = Object.fromEntries(Object.entries(doc.tokens).sort((a, b) => b[1] - a[1]).slice(0, 200));
          await env.AGENT.put('graduation:asks', JSON.stringify(doc));
        }
        ctx.waitUntil(Promise.resolve(bumpDetail(env, [`graduation:ask`, `graduation:ua:${uaProduct}`])).catch(() => {}));
      }
      return json({
        status: 'not built yet',
        what: `An alert the moment a token leaves its four.meme or flap.sh launch curve and its PancakeSwap pool exists, so nobody has to scan it every few minutes. It is not built. Every ask is counted${token ? (counted ? ' — yours is, thank you' : ' — yours was counted already today') : ''}; we build it if agents ask for it.`,
        ask: 'GET https://agent.brainonbnb.com/watch/graduation?token=<the curve token> — once a day per token is counted',
        asked: { total: doc.total, since: doc.since, by_day: doc.by_day, tokens: Object.keys(doc.tokens).length },
        meanwhile: 'The pool scan reads a curve token now: https://brainonbnb.com/api/pool-scan?address=<token> (its progress to graduation is curve.progressPct)',
      }, 200, { 'Cache-Control': 'no-store' });
    }
    if (path.startsWith('/watch/') && request.method === 'GET') {
      const id = path.slice(7);
      const raw = id && (await env.AGENT.get(`watch:${id}`));
      // Expired and never-existed are the same answer on purpose: a watch is
      // deleted the first sweep after it expires, so the service cannot tell
      // them apart and should not pretend to.
      if (!raw) return json({ error: 'no watch with that id — it may have expired', watch: id }, 404);
      const w = JSON.parse(raw);
      return json({
        watch: w.id,
        watching: { token: w.token, pair: w.pair, quote: w.quote, ...(w.kind === 'v3' ? { pool: `PancakeSwap V3 ${w.fee / 10000}%` } : {}), depthBelowUsd: w.depthBelowUsd },
        callback: w.callback,
        lastDepthUsd: w.lastDepthUsd,
        ...(w.lastDepthFloor ? { lastDepthNote: 'at least this much: the pool did not move 1% at the largest size quoted' } : {}),
        lastCheckedAt: w.lastCheckedAt ? new Date(w.lastCheckedAt).toISOString() : null,
        // Never checked yet reads as "broken" unless we say why: the sweep runs
        // on a cron, so a watch bought a minute ago legitimately has no reading.
        note: w.lastCheckedAt ? undefined : 'not swept yet — the depth check runs on a schedule, first reading follows shortly',
        triggered: w.triggered.map((t) => ({ at: new Date(t.at).toISOString(), depthUsd: t.depthUsd })),
        created: new Date(w.createdAt).toISOString(),
        expires: new Date(w.expiresAt).toISOString(),
        paidTx: w.paidTx,
      });
    }

    // A GET on the resource itself. x402 says the terms live in the 402 that a
    // POST returns, but a crawler, an agent following llms.txt, or a person
    // pasting the URL all send GET — and answering "not found" tells every one
    // of them the service does not exist. It does; this says so, and quotes the
    // price from the same builder the 402 uses so the two cannot drift apart.
    // The five deliveries, per answer over x402. GET describes; POST without
    // payment answers 402 with the terms; POST with PAYMENT-SIGNATURE delivers.
    if (path === '/answer') {
      if (!payTo) return json({ error: 'service not configured to receive payments yet' }, 503);
      const id = url.searchParams.get('service') || '';
      // A FREE TOOL ASKED AT THE PAID DOOR IS ANSWERED FREE (2026-11-05): on 4.11. a visitor tried answer?service=bobai_price
      // five times with a tx hash and a holder pass and got "unknown service" each time. A name the free toolbox knows is
      // passed to brainonbnb.com/mcp (query fields + the body's params as arguments); nothing is charged, a proof is not used.
      if (id && !SERVICES[id] && /^[a-z][a-z0-9_]{2,59}$/.test(id)) {
        const body = request.method === 'POST' ? await request.clone().json().catch(() => ({})) : {};
        const args = { ...Object.fromEntries([...url.searchParams].filter(([k]) => k !== 'service' && k !== 'task')),
          ...(body && typeof body.params === 'object' && body.params ? body.params : {}) };
        const pr = await fetch('https://brainonbnb.com/mcp', { method: 'POST', headers: { 'content-type': 'application/json', accept: 'application/json', 'user-agent': 'bobai-agent-answer-door/1' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'tools/call', params: { name: id, arguments: args } }), signal: AbortSignal.timeout(30000) }).then((r) => r.json()).catch(() => null);
        let out = null;
        try { out = pr?.result && !pr.result.isError ? (pr.result.structuredContent || JSON.parse(pr.result.content?.[0]?.text || 'null')) : null; } catch { out = null; }
        if (out) {
          note(`sell:answer:free:${id.slice(0, 40)}`);
          return json({ free: true, charged: false, tool: id, answer: out, from: 'https://brainonbnb.com/mcp (the free toolbox for any BSC token)',
            paid_answers: Object.keys(SERVICES).map((s) => `https://agent.brainonbnb.com/answer?service=${s}`) });
        }
      }
      if (request.method === 'GET') {
        if (!id) note('sell:answer:index');
        if (!id) return json({
          what: 'Any of the six answers this project sells, one payment each, delivered at once — no escrow, no job, no dispute window.',
          price: `${fmtUsd1(ANSWER_PRICE)} per answer — USD1 or $U by EIP-3009 (signed, we settle), USDC by standard x402 (Permit2), USD1 by direct transfer, or half that price in $BOBAI, quoted on each 402`,
          services: Object.values(SERVICES).map((s) => ({ id: s.id, name: s.name, needs: s.needs, terms: `POST https://agent.brainonbnb.com/answer?service=${s.id}`, example: `https://agent.brainonbnb.com/example?service=${s.id}` })),
          how: 'POST (or GET) /answer?service=<id> once without payment: the 402 names the price and the wallet. Pay, then repeat with the payment in X-PAYMENT or PAYMENT-SIGNATURE — POST with a body naming the task, or GET with ?task=… in the query.',
          or_escrow: 'The same answers through the ERC-8183 escrow: https://brainonbnb.com/registry',
          holder_pass: holderPassTerms(),
          catalogue: 'https://agent.brainonbnb.com/.well-known/x402',
        });
        // A PAID GET (2026-10-04): x402 clients that pay by GET — the way
        // Mandate's own house agents are called — send the payment in a header
        // and the task in the query (?task=… or the service's fields). It is
        // sold exactly like the POST; without a payment header a GET is terms.
        const getProof = request.headers.get('PAYMENT-SIGNATURE') || request.headers.get('X-PAYMENT');
        if (getProof) {
          const q = Object.fromEntries([...url.searchParams].filter(([k]) => k !== 'service'));
          const out = await sellAnswer(env, ctx, payTo, id, { task: q.task || '', params: q }, getProof);
          note(`sell:answer:${SERVICES[id] ? id : 'unknown'}:paid:${out.status}`);
          missed(`answer:${id}`, getProof, out);
          return json(out.body, out.status, out.headers || {});
        }
        const out = await sellAnswer(env, ctx, payTo, id, {}, null);
        note(`sell:answer:${SERVICES[id] ? id : 'unknown'}:terms`);
        return json(out.body, out.status, out.headers || {});
      }
      if (request.method === 'POST') {
        const body = await request.json().catch(() => ({}));
        // X-PAYMENT is the x402 v1 header (Mandate's relay sends it); PAYMENT-SIGNATURE the v2 one.
        const proof = request.headers.get('PAYMENT-SIGNATURE') || request.headers.get('X-PAYMENT');
        const out = await sellAnswer(env, ctx, payTo, id, body || {}, proof);
        // terms = asked the price; paid:<status> = came back with a proof.
        note(`sell:answer:${SERVICES[id] ? id : 'unknown'}:${proof ? 'paid:' + out.status : 'terms'}`);
        missed(`answer:${id}`, proof, out);
        return json(out.body, out.status, out.headers || {});
      }
    }

    // A voluntary tip over x402 (tipRoute above). GET or POST: without PAYMENT-SIGNATURE the 402 with the terms,
    // with it the payment is checked and a thank-you comes back.
    if (path === '/tip' && (request.method === 'GET' || request.method === 'POST')) {
      if (!payTo) return json({ error: 'not configured to receive payments yet' }, 503);
      const proof = request.headers.get('PAYMENT-SIGNATURE') || request.headers.get('X-PAYMENT');
      const out = await tipRoute(env, ctx, payTo, url.searchParams.get('usd'), proof);
      note(`tip:${proof ? 'paid:' + out.status : 'terms'}`);
      missed('tip', proof, out);
      return json(out.body, out.status, out.headers || {});
    }

    // THE RUG WATCH (2026-10-09, rug-watch.js): free, a webhook or (since 5.11.) polled — GET the terms, POST to register,
    // GET /rug-watch/<id> for the status, DELETE it with x-rug-watch-secret. Free of the payment path above.
    // AN AGENT THAT HIRES AN AGENT (2026-10-14, second-opinion.js): the public log of every second opinion the DeFi
    // agent bought from an outside agent through its Altana leash; POST (internal, x-hit-secret) buys one.
    if (path === '/second-opinion') {
      if (request.method === 'POST') {
        if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
        const b = await request.json().catch(() => ({}));
        let own = b.own && typeof b.own === 'object' ? { position: b.own.position ?? null, in_range: b.own.in_range ?? null, tick: b.own.tick ?? null } : null;
        // no reading sent (the daily ask): the agent's own free look at its position, the same read anybody gets
        if (!own || own.position == null) { const l = await Promise.race([lpPositionLook({ address: SUBJECT }, env), new Promise((r) => setTimeout(() => r(null), 20000))]).catch(() => null); if (l && l.position) own = { position: String(l.position), in_range: !!l.in_range, tick: l.pool ? l.pool.tick : null }; }
        // kept alive by waitUntil too, so a caller that stops waiting does not cut the hire off before its row (2026-10-18)
        const work = secondOpinion(env, { why: String(b.why || 'by hand').slice(0, 60), own, rpc });
        // the job joins our own jobs, so the daily tick settles it after its window (own-jobs.js settleDue)
        ctx.waitUntil(work.then((r) => (r && r.job ? tickOwnJobs(env, rpc, [r.job]) : null)).catch(() => {}));
        return json(await work);
      }
      return json({ what_this_is: 'Every second opinion the DeFi agent (#363709) bought from an outside agent before it moves money: Mandate Range-1 (ERC-8004 #344119) hired on the ERC-8183 kernel, paid from the Altana wallet of the agent through a session key whose limits anyone can read (the kernel, $U.approve, router.registerJob, router.settle; 1 $U a day; an expiry; revocable). Newest first. Stage 1: recorded beside the reading of the agent itself, it decides nothing yet.', leash: 'https://agent.brainonbnb.com/session', session_held: heldSession(env), seller: SELLER, subject: SUBJECT, last_ask: await env.AGENT.get('opinion:ask:last', 'json').catch(() => null), opinions: await readOpinions(env) }, 200, { 'Cache-Control': 'public, max-age=30' });
    }
    if (path === '/rug-watch' || path.startsWith('/rug-watch/')) {
      return handleRugWatch(request, env, path, { rpc, note, bump: (kind, n) => ctx.waitUntil(bump(env, kind, n)) });
    }

    // EVERY AGENT'S FINISHED JOBS, SETTLED (public-settle.js, 2026-10-21): what was released, to whom, by which transaction.
    // one address's escrow at a glance (escrow-for.js, 2026-10-23): its jobs, what waits, what the settle and refund did
    const escrowFor = path.match(/^\/escrow\/for\/(0x[0-9a-fA-F]{40})$/);
    if (escrowFor && request.method === 'GET') {
      note('escrow:for');
      const { readEscrowFor } = await import('./escrow-for.js');
      return json(await readEscrowFor(env, escrowFor[1]));
    }
    // Brain Pop's daily results on BNB Chain (pop-chain.js, 10.11.): every day written, or ?day= with its board to hash again
    if (path === '/pop/chain' && request.method === 'GET') {
      note('pop:chain');
      const day = url.searchParams.get('day');
      if (day && !/^\d{4}-\d{2}-\d{2}$/.test(day)) return json({ error: 'day as YYYY-MM-DD' }, 400);
      const r = await readPopChain(env, day);
      if (day && !r) return json({ error: 'not written (yet)', day }, 404);
      return json(day ? r : { what: 'BRAIN POP 6.9 on BNB Chain: once a day is closed, one transaction from the agent wallet 0x73809F69916FcF7Ddc5BB1315fBdf96A569a5963 to the prize wallet 0x5E4102520A71B2AA18a1208330d4848dea4BD105, 0 BNB, its input data the champion, the score, the run and the sha256 of the whole day board. ?day=YYYY-MM-DD gives that board in the form that is hashed.', ...r });
    }
    if (path === '/settle/public' && request.method === 'GET') {
      note('settle:public');
      const [s, refunds] = await Promise.all([readPublicSettle(env), readPublicRefund(env)]);
      return json({
        what: 'BOBAI settles the finished ERC-8183 jobs of every agent on BNB Chain, not only its own. The escrow releases a provider\'s $U only when somebody calls settle(jobId) on the EvaluatorRouter after the 7-day dispute window, and nearly nobody does. Once a day at 21:15 UTC this worker settles every job that is due: delivered, window over, paid by a client that is not the provider, at least 0.01 $U. The money goes to the provider the job names; we pay the gas (about a cent a job). Farms and self-hires are left out.',
        rule: { min_budget_u: 0.01, client_not_provider: true, evaluator: ERC8183.router, per_provider_a_day: 10, per_client_a_day: 10, per_client_provider_pair_a_day: 3, providers_take_turns: true, a_day: 80, farms_left_out: true, gas: '0.1 gwei, from the provider wallet 0x73809F69916FcF7Ddc5BB1315fBdf96A569a5963, never below 0.001 BNB' },
        code: 'https://brainonbnb.com/code/agent-service.txt (worker-agent/public-settle.js)',
        ...s,
        // the other half (2026-10-23): a funded job nobody delivered gets its budget back to the client after expiry
        refunds: {
          what: 'BOBAI also returns the money of jobs nobody delivered, for every client. A funded ERC-8183 job that is never delivered keeps the client\'s $U in the escrow after its expiry until somebody calls claimRefund(jobId) on the kernel. Right after the settle, this worker calls it for every job that is due: funded, expired, at least 0.01 $U, a client that is not the provider. The whole budget goes to the job\'s client; we pay the gas (about half a cent a job). Farms, self-hires and our own hires are left out.',
          rule: { min_budget_u: 0.01, client_not_provider: true, per_client_a_day: 5, per_client_provider_pair_a_day: 3, a_day: 40, farms_left_out: true, own_hires_left_out: true, gas: '0.1 gwei, from the provider wallet 0x73809F69916FcF7Ddc5BB1315fBdf96A569a5963, never below 0.001 BNB' },
          code: 'https://brainonbnb.com/code/agent-service.txt (worker-agent/public-refund.js)',
          ...refunds,
        },
      });
    }
    if (path === '/settle/public/seed' && request.method === 'POST') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      const b = await request.json().catch(() => ({}));
      const cand = JSON.parse((await env.AGENT.get(CANDIDATES_KEY)) || '{}');
      let added = 0;
      for (const c of Array.isArray(b.candidates) ? b.candidates : []) if (/^\d+$/.test(String(c.id)) && !cand[c.id]) { cand[c.id] = { provider: String(c.provider || '').toLowerCase(), added: 'seed' }; added++; }
      await env.AGENT.put(CANDIDATES_KEY, JSON.stringify(cand));
      if (Array.isArray(b.farms)) await env.AGENT.put(FARMS_KEY, JSON.stringify(b.farms.map((f) => String(f).toLowerCase())));
      return json({ ok: true, added, candidates: Object.keys(cand).length });
    }

    // WHAT THE TWO VENUS AGENTS DID (venus-work.js, 2026-10-21): every run, its actions and their transactions.
    // the operator's hand on it (2026-10-22): ?dry=1 plans every hire (quote, wallet, balances) and sends nothing;
    // without it runs the day's hires now, the same rails as the 05:30 run (once a day per hire), even while switched off
    if (path === '/hires/run' && request.method === 'POST') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      if (url.searchParams.get('reparse') === '1') { // an answer read wrongly is read again from its url (2026-10-22, Keel's nested JSON)
        const list = await readHires(env);
        await env.AGENT.put('hires:log', JSON.stringify(list.map((r) => (r.job && r.answer ? { ...r, status: 'funded, delivering' } : r))));
      }
      if (url.searchParams.get('collect') === '1' || url.searchParams.get('reparse') === '1') return json({ collected_open: await collectDeliveries(env), log: (await readHires(env)).slice(0, 6) });
      const dry = url.searchParams.get('dry') === '1', only = url.searchParams.get('by');
      const c = await hireContext(env);
      const { hireOnce } = await import('./agent-hires.js');
      const out = [];
      for (const h of HIRES.filter((x) => !only || String(x.by) === only)) out.push(await hireOnce(env, h, { ctx: c[h.by] || {}, dry }).catch((e) => ({ by: h.by, error: String(e.message || e) })));
      return json({ dry, out });
    }
    if (path === '/hires' && request.method === 'GET') {
      note('hires');
      return json({
        what: 'Our agents hiring outside agents for their own work, once a day after the Venus run (05:30 UTC), each from its own ERC-8004 agentWallet through the ERC-8183 escrow, at the price the seller quotes and signs. An agent hires only where it holds something an outside agent can check, and the answer stands beside its own reading: the Venus health factor monitor (it holds a small Venus loan) asks Keel; the Venus yield ranking (it holds stablecoins on Venus) asks Sluicegate; the DeFi agent (it runs our CAKE/BNB position) asks Bound. The other three hold nothing of their own and hire nobody.',
        switched_on: env.AGENT_HIRES === 'on',
        hires: HIRES.map((h) => ({ by: h.by, seller: h.seller, seller_name: h.sellerName, site: h.site, ...(h.paused ? { paused: h.paused } : {}) })),
        rails: 'once a UTC day per hire, at most 0.15 $U a quote, in $U only, every call simulated before it is sent, the job read back on chain; settled after the 7-day dispute window by the public settle',
        code: 'https://brainonbnb.com/code/agent-service.txt (worker-agent/agent-hires.js)',
        log: await readHires(env),
      });
    }
    // WHO GETS HIRED ON BNB CHAIN (job-board.js, 2026-10-22): every provider of the ERC-8183 escrow, ranked by work
    // delivered for paying clients in 30 days, read from the chain once a day at 21:45 UTC.
    // EVERY $BOBAI HOLDER (holders.js, 2026-10-22): the count, the 1M+ holders, the bands, the history and the
    // wallets that crossed 1,000,000 — kept from the chain every quarter hour. ?address= adds one wallet's place.
    if (path === '/holders' && request.method === 'GET') {
      note('holders');
      const a = url.searchParams.get('address');
      if (a && !/^0x[0-9a-fA-F]{40}$/.test(a)) return json({ error: 'address must be 0x and 40 hex characters' }, 400);
      const h = await readHolders(env, a);
      return json({ what: 'Every wallet that holds $BOBAI, from the chain: Transfer logs since the deployment (2026-03-27), balances read with balanceOf, kept up to date every 15 minutes. Holders are people: the pool, the burn address and every contract are left out. 1M+ = the holder pass (1,000,000 $BOBAI).', ...(h || { note: 'not seeded yet' }) }, 200, { 'Cache-Control': 'public, max-age=120' });
    }
    if (path === '/holders/repair' && request.method === 'GET') return json({ what: 'The holder index repair of 2026-11-09: transfers lost to empty log answers read again at NodeReal, then every balance read again', status: await readBackfill(env) });
    if (path === '/holders/seed' && request.method === 'POST') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      return json(await seedHolders(env, await request.json().catch(() => null)));
    }
    if (path === '/holders/tick' && request.method === 'POST') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      return json(await holdersTick(env));
    }
    if (path === '/jobs/board' && request.method === 'GET') {
      note('jobs:board');
      const b = await readJobBoard(env);
      return json({
        what: 'Every agent that gets hired on the ERC-8183 escrow kernel on BNB Chain, ranked by work delivered in the last 30 days for a client who put money in escrow (SUBMITTED or COMPLETED, budget above zero, by the job\'s own submitted_at). Paid means the escrow released (COMPLETED); delivered and not yet released is shown apart, never added to paid. Left out: an address hiring itself, and for our own agents any client that is one of our wallets. One campaign address that holds nearly every job ever minted (98.5 % at the census of 2026-10-19), at a cent each, is shown on its own line, never in the ranking. Read from the chain once a day at 21:45 UTC, after the public settle.',
        kernel: ERC8183.commerce,
        payment_token: '$U (United Stables) 0xcE24439F2D9C6a2289F741120FE202248B666666',
        code: 'https://brainonbnb.com/code/agent-service.txt (shared/job-board.js, worker-agent/job-board.js)',
        page: 'https://brainonbnb.com/jobs',
        ...(b || { measured_at: null, note: 'not read yet; the first run is at 21:45 UTC' }),
      }, 200, { 'Cache-Control': 'public, max-age=300' });
    }
    if ((path === '/jobs/board/seed' || path === '/jobs/board/run') && request.method === 'POST') {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      if (path === '/jobs/board/seed') return json(await seedJobBoard(env, await request.json().catch(() => null)));
      return json(await runJobBoard(env));
    }
    if (path === '/venus/work' && request.method === 'GET') {
      note('venus:work');
      return json({
        what: 'The Venus health factor monitor (#302257) and the Venus yield ranking (#304493) at their own work on Venus, once a day at 05:00 UTC, each from its own agentWallet. The health factor keeper holds a small BNB-backed USDT loan at a health factor of 2.2 (repays under 2.09, borrows over 2.31); the yield router supplies the stablecoins of its wallet in tranches of 2 a day to the better-paying Venus market. Every action is simulated first and read back after.',
        switched_on: env.VENUS_WORK === 'on',
        code: 'https://brainonbnb.com/code/agent-service.txt (worker-agent/venus-work.js)',
        log: await readVenusLog(env),
      });
    }

    // THE DAY PASS A CALLER PAID FOR ON THE SCAN ITSELF (2026-10-21): brainonbnb.com answers the 51st scan with the
    // pass's 402, buys the pass with the payment the caller repeats the scan with, and keeps it here under the caller's
    // key (scanCallerKey — never the address), so that address scans on for the day through every data centre without
    // sending anything. Only the site writes and reads it (the shared secret); a pass that does not check is not kept.
    if (path === '/scan-pass/unlock' && (request.method === 'GET' || request.method === 'POST')) {
      if (!env.HIT_SECRET || request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'unauthorized' }, 401);
      if (request.method === 'GET') {
        const k = String(url.searchParams.get('for') || '');
        if (!/^[0-9a-f]{32}$/.test(k)) return json({ error: 'for: the caller key, 32 hex' }, 400);
        const pass = await env.AGENT.get('scanunlock:' + k);
        return pass ? json({ pass }) : json({ pass: null }, 404);
      }
      const b = await request.json().catch(() => ({}));
      const k = String(b.for || ''), c = await checkScanPass(env.HIT_SECRET, b.pass);
      if (!/^[0-9a-f]{32}$/.test(k) || !c.ok) return json({ error: c.ok ? 'for: the caller key, 32 hex' : c.reason }, 400);
      await env.AGENT.put('scanunlock:' + k, b.pass, { expirationTtl: Math.max(60, Math.floor((c.exp - Date.now()) / 1000)) });
      note('sell:scanpass:unlock');
      return json({ ok: true, until: new Date(c.exp).toISOString() });
    }

    if (path === '/scan-pass' && (request.method === 'GET' || request.method === 'POST')) {
      if (!payTo) return json({ error: 'service not configured to receive payments yet' }, 503);
      const proof = request.method === 'POST' ? (request.headers.get('PAYMENT-SIGNATURE') || request.headers.get('X-PAYMENT')) : null;
      const out = await purchaseScanPass(env, ctx, payTo, proof);
      note(proof ? (out.status === 200 ? 'sell:scanpass:paid' : 'sell:scanpass:refused') : 'sell:scanpass:terms');
      missed('scan-pass', proof, out);
      // GET reads the terms with 200, as /watch does; POST without payment is the 402 itself.
      return json(out.body, request.method === 'GET' && !proof ? 200 : out.status, out.headers || {});
    }

    if (path === '/watch' && request.method === 'GET') {
      if (!payTo) return json({ error: 'service not configured to receive payments yet' }, 503);
      const terms = await purchaseWatch(env, ctx, payTo, {}, null);
      note('sell:watch:terms');
      return json({
        service: 'pool watch',
        what: `Continuous depth monitoring of one BSC pool for ${WATCH_DAYS} days, with a callback when depth falls below a threshold you set.`,
        // Both schemes in accepts[] are quoted, because only one of them is
        // USD1: a client that takes the facilitator route pays the same amount
        // in USDC, and a price line naming one asset hides the other.
        price: terms.body.price,
        buy: 'POST this same URL with {"token":"0x…","depthBelowUsd":1000,"callback":"https://…"} — pair optional (a PancakeSwap V2 pair or V3 pool), found from the token when left out (its PancakeSwap V2 pair with WBNB, or with quote)',
        how: terms.body.how,
        accepts: terms.body.accepts,
        read_back: 'GET /watch/<id> — returned to you when the purchase settles',
        holder_pass: holderPassTerms(),   // hold the $BOBAI line, watch without paying (holder-pass.js, 2026-10-16)
        free_alternative: 'https://brainonbnb.com/api/pool-scan?address=0x… — one reading, no payment (1,000 scans per caller a day), no watching',
        catalogue: 'https://agent.brainonbnb.com/.well-known/x402',
      });
    }

    if (path === '/watch' && request.method === 'POST') {
      if (!payTo) return json({ error: 'service not configured to receive payments yet' }, 503);
      const spec = await request.json().catch(() => null);
      // both headers its own 402 names (2026-10-10): a payment in X-PAYMENT was answered as an unpaid call
      const proof = request.headers.get('PAYMENT-SIGNATURE') || request.headers.get('X-PAYMENT');

      // Price discovery must not require a valid body. An x402 client — or an
      // aggregator indexing the catalogue at /.well-known/x402 — probes the
      // resource to read its terms out of the 402, and it has no token or pair
      // to send yet. Answering 400 there makes a listed resource look broken
      // and hides the price behind a guess at the schema.
      //
      // Validation still runs before anything is bought: it is only skipped on
      // the unpaid call, which sells nothing and charges nothing.
      if (!proof) {
        const out = await purchaseWatch(env, ctx, payTo, spec || {}, null);
        note('sell:watch:terms');
        // A buyer who already named the token sees, before paying, which pair
        // would be watched — or why none can be (2026-09-24, A7).
        if (spec && spec.token && out.body && typeof out.body === 'object') {
          const ready = await resolveWatchSpec(spec).catch(() => ({ error: 'the pair could not be read right now' }));
          // …and what it reads there right now, by the very function the sweep uses (2026-10-16): the buyer sees the
          // depth the threshold is compared with before paying.
          const now = ready.error ? null : await bnbUsd().then((p) => watchDepthUsd(ready.spec, p)).catch(() => null);
          out.body.would_watch = ready.error ? { refused: ready.error } : { token: ready.spec.token, pair: ready.spec.pair, quote: ready.spec.quote, ...(ready.spec.kind === 'v3' ? { pool: `PancakeSwap V3 ${ready.spec.fee / 10000}%` } : {}), pair_found: !!ready.spec.pair_found,
            ...(now ? { depth_now_usd: Math.round(now.depthUsd), ...(now.floor ? { depth_now_note: 'at least this much' } : {}) } : {}) };
        }
        return json(out.body, out.status, out.headers || {});
      }

      // A payment is on the table, so the spec has to be right before it is
      // spent. This ordering is deliberate — a caller who pays with a malformed
      // body gets told, not charged.
      const ready = await resolveWatchSpec(spec);
      if (ready.error) return json({ error: ready.error, payment: 'not taken — nothing was charged' }, 400);

      const out = await purchaseWatch(env, ctx, payTo, ready.spec, proof);
      note(`sell:watch:paid:${out.status}`);
      missed('watch', proof, out);
      return json(out.body, out.status, out.headers || {});
    }

    // Runs the watch sweep on demand. Exists because a cron that only fires
    // every fifteen minutes cannot be verified after a deploy without either
    // waiting for it or trusting that it works — and "the paid part is
    // presumably fine" is not a state this service should ever be shipped in.
    // Same shared secret as /hit; nothing here is reachable without it.
    // The liquidity series: every run of the DeFi agent as one point,
    // and what the points say so far. Read by /defi.
    // THE PORTFOLIO: the agent as one picture, one model for the /defi page
    // and the Telegram card alike (worker-agent/lp-portfolio.js).
    if (path === '/lp/portfolio') {
      // A minute at the edge (2026-10-07): built fresh on every call the card sat at "Reading the portfolio…"
      // for 3.5 to 27 s (record, series, a live quote and the 666 KB width record read each time).
      // Served from the last copy at once; a copy older than a minute is rebuilt in the background (a miss still took
      // 7 to 18 s live). Kept 15 minutes, so only the first call after a quiet quarter of an hour waits.
      const ck = new Request('https://agent.brainonbnb.com/lp/portfolio');
      const put = (res) => { if (globalThis.caches) { const c = res.clone(); c.headers.set('cache-control', 'public, max-age=900'); c.headers.set('x-built-at', String(Date.now())); return caches.default.put(ck, c).catch(() => {}); } };
      const hit = globalThis.caches ? await caches.default.match(ck).catch(() => null) : null;
      if (hit) {
        if (Date.now() - Number(hit.headers.get('x-built-at') || 0) > 60e3) ctx.waitUntil(buildPortfolio().then((r) => r.status === 200 && put(r)).catch(() => {}));
        const out = new Response(hit.body, hit); out.headers.set('cache-control', 'public, max-age=60'); return out;
      }
      const res = await buildPortfolio();
      if (res.status === 200) ctx.waitUntil(put(res));
      return res;
    }
    async function buildPortfolio() {
      // ALL SIX READS AT ONCE (2026-11-16: one after the other, the first call after a quiet quarter of an hour took
      // 14.2 s live); none needs another's answer, only the width pick below needs the record, after
      const [rec, series, bobaiUsd, bnbUsdNow, verdict, outSince, bobaiHeldChain] = await Promise.all([
        readAgentRecord(env),
        buildLpSeries(env),
        bobaiForUsd(1).then((q) => q.usd_per_bobai).catch(() => null),
        fetch('https://brainonbnb.com/api/price', { signal: AbortSignal.timeout(4000) }).then((r) => r.json()).then((j) => Number(j.bnb_usd) || null).catch(() => null),
        lpWidthVerdict(env).catch(() => null),
        env.AGENT.get('lp:out_since').catch(() => null),
        // the $BOBAI the DeFi wallet holds, from the chain (lp-portfolio.js heldBobai); null when no node answered
        callQuick(BOBAI, '0x70a08231' + OWN_LP_WALLET.slice(2).toLowerCase().padStart(64, '0')).then((r) => Number(BigInt(r)) / 1e18).catch(() => null),
      ]);
      // The width and wait the next re-set would use, from the width record,
      // and since when the price has been outside, from the DeFi worker's
      // own note — so the one sentence about what comes next is the record's.
      let width = null, outsideSince = null;
      try {
        if (!verdict) throw new Error('no width record');
        const { v } = verdict;
        // The same pick the re-set will make: re-read with the width the
        // position is in, so the card's sentence and the plan agree.
        const lastRb = rec && rec.last && rec.last.steps && rec.last.steps.rebalance;
        const inUseTicks = lastRb && ((lastRb.acted && !lastRb.error && lastRb.new_ticks) || lastRb.ticks) || null;
        const pick = v && ((Array.isArray(v.rows) && v.rows.some((r) => r.earnings_7d) && v.earnings_pick ? pickWidth(v.rows, { current: widthClassOf(inUseTicks) }) : null) || v.earnings_pick);
        if (pick) width = { width_pct: pick.width, wait_hours: v.delay_test?.in_use_hours ?? null, net_usd_per_day: pick.earnings?.net_usd_per_day ?? null };
        else if (v) width = { width_pct: null, wait_hours: v.delay_test?.in_use_hours ?? null, net_usd_per_day: null };
      } catch { /* the sentence does without */ }
      outsideSince = outSince || null;
      // the width and mode worker-lp mints with (its LP_WIDTH_PCT / LP_RESET_MODE, mirrored in this worker's vars)
      const fixedWidth = Number(env.LP_WIDTH_PCT) > 0 ? Number(env.LP_WIDTH_PCT) : null;
      if (fixedWidth) width = { ...(width || {}), width_pct: fixedWidth, net_usd_per_day: null };
      const model = lpPortfolio(rec, series, { bobaiUsd, bnbUsdNow, width, outsideSince, centred: env.LP_RESET_MODE === 'centred', bobaiHeldChain });
      if (!model) return json({ error: 'no portfolio yet: the agent has no run on record or the series no summary' }, 503);
      const res = json({
        what_this_is: 'The DeFi agent as a portfolio: what went in, what it is worth, what it holds where, the P&L by where it came from and what it did in the last day. One model; the /defi page and the Telegram /defi card render this and compute nothing of their own.',
        ...model,
      }, 200, { 'Cache-Control': 'public, max-age=60' });
      return res;
    }
    if (path === '/lp/series') {
      const ck = new Request('https://agent.brainonbnb.com/lp/series');
      const hit = globalThis.caches ? await caches.default.match(ck).catch(() => null) : null;
      if (hit) return hit;
      const res = json(await buildLpSeries(env), 200, { 'Cache-Control': 'public, max-age=120' });
      if (globalThis.caches) ctx.waitUntil(caches.default.put(ck, res.clone()).catch(() => {}));
      return res;
    }
    if (path === '/run-lp-series' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      return json({ ok: true, ...(await recordLpSeries(env)) });
    }

    if (path === '/run-checks' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      const result = await checkWatches(env);
      return json({ ok: true, ...result });
    }
    // The rug-watch sweep on demand, for the same reason (2026-10-09).
    if (path === '/run-rug-watch' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      return json({ ok: true, ...(await runRugWatches(env, { rpc, bump: (kind, n) => bump(env, kind, n) })) });
    }

    // Runs the census tick on demand. Same reason as /run-checks: a job that
    // fires once a day cannot be verified after a deploy without waiting a
    // day, and "it will presumably work tomorrow" is not a state to ship in.
    if (path === '/run-census' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      const r = await runCensusTick(env);
      return json({ ok: true, ...r });
    }

    // The hourly high-water probe on its own. Same reason as the two above:
    // an hour is long enough that "it presumably fires" would ship untested.
    if (path === '/run-frontier' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      const r = await runFrontierTick(env);
      return json({ ok: true, ...r });
    }

    // Same reason as /run-census: a job that fires once a day is untestable
    // after a deploy unless it can be triggered by hand.
    if (path === '/run-canary' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      const r = await runCanary(env);
      return json({ ok: true, ...r });
    }

    // The daily own-jobs tick on demand, optionally with ids to add to the
    // list. Same reason as the others: a daily job is untestable after a
    // deploy unless it can be triggered by hand.
    if (path === '/own-jobs' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      let ids = [];
      try { ids = (await request.json())?.ids || []; } catch { ids = []; }
      const r = await tickOwnJobs(env, rpc, Array.isArray(ids) ? ids : []);
      return json(r, r.ok ? 200 : 500);
    }

    // The hourly LP window on demand. Same reason as the four above.
    if (path === '/run-lp-window' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      // By hand there is no cron burst to wait out.
      const r = await recordLpWindow(env, { settle: false });
      return json(r, r.ok ? 200 : 500);
    }

    // Accepts the endpoint list produced by the offline publish step. Written
    // once per full scan, not per run — this is the input the rotating
    // reachability check walks through.
    if (path === '/census-endpoints' && request.method === 'POST') {
      if (request.headers.get('x-hit-secret') !== env.HIT_SECRET) return json({ error: 'no' }, 403);
      const body = await request.json().catch(() => null);
      if (!Array.isArray(body)) return json({ error: 'expected an array of {id,url}' }, 400);
      const clean = body
        .filter((x) => x && Number.isInteger(x.id) && typeof x.url === 'string' && /^https?:\/\//i.test(x.url))
        .slice(0, 20000)
        .map((x) => ({ id: x.id, url: x.url.slice(0, 300) }));
      await env.AGENT.put('census:endpoints', JSON.stringify(clean));

      // The offline scan's high-water mark seeds the growth check. Without it
      // the daily tick has no baseline to count new registrations from, and
      // reports highest_id: null forever — which is what it did on the first
      // run. Sent alongside the list because the two come from the same scan
      // and would otherwise drift apart.
      const seed = Number(new URL(request.url).searchParams.get('highestId'));
      let seeded = null;
      if (Number.isInteger(seed) && seed > 0) {
        const st = JSON.parse((await env.AGENT.get('census:state')) || '{}');
        st.highestId = seed;
        // A full scan IS a new baseline — it just read every id up to this one.
        // Carrying the old "new since baseline" forward would count the four
        // thousand agents the scan already includes as if they had arrived
        // since, and the page would state a growth figure that double-counts.
        // Zero here, and the frontier moved up to the same mark so tomorrow's
        // tick starts reading where the scan stopped instead of redoing it.
        // ...but never DOWN. The sync is meant to run the minute a scan ends;
        // run five days later (2026-09-03, to record the scan in the series)
        // it dragged a live counter of 332,143 back to the scan's 316,472 and
        // the page walked its own headline backwards until the next frontier
        // tick. The baseline moves to the scan; the high-water mark keeps
        // whatever the chain has shown since, and "new since" is the gap.
        const cur = Number(st.highestId) || 0;
        st.baselineId = seed;
        st.highestId = Math.max(cur, seed);
        st.newSinceBaseline = Math.max(0, st.highestId - seed);
        st.lastScannedNew = Math.max(Number(st.lastScannedNew) || 0, seed);
        await env.AGENT.put('census:state', JSON.stringify(st));

        // /census serves the snapshot, not the state — so seeding the state
        // alone left the public figure on the previous baseline until the next
        // daily tick, which is how /registry ended up overwriting its own
        // freshly published headline with a smaller number. The snapshot moves
        // with the seed; the rotating-check half is left as the last real run
        // wrote it, because a seed measures no endpoints.
        const snap = JSON.parse((await env.AGENT.get('census:latest')) || 'null');
        if (snap) {
          snap.highest_id = Math.max(Number(snap.highest_id) || 0, seed);
          snap.registered_since_baseline = Math.max(0, snap.highest_id - seed);
          snap.high_water_checked_at = new Date().toISOString();
          if (snap.frontier) {
            snap.frontier.read_up_to = Math.max(Number(snap.frontier.read_up_to) || 0, seed);
            snap.frontier.behind_by = Math.max(0, snap.highest_id - snap.frontier.read_up_to);
          }
          await env.AGENT.put('census:latest', JSON.stringify(snap));
        }
        seeded = seed;
      }
      return json({ ok: true, stored: clean.length, ...(seeded ? { baseline_highest_id: seeded } : {}) });
    }

    const one = path.match(/^\/watch\/([0-9a-f-]{36})$/i);
    if (one) {
      const raw = await env.AGENT.get(`watch:${one[1]}`);
      if (!raw) return json({ error: 'no such watch, or it has expired' }, 404);
      ctx.waitUntil(bump(env, 'watch_polled'));
      return json(JSON.parse(raw));
    }

    return json({ error: 'not found', see: 'https://agent.brainonbnb.com/' }, 404);
  },

  async scheduled(event, env, ctx) {
    bindSelf(env);
    // The rug watch runs on its own cron (RUG_CRON, 2026-10-09) and nothing else does: every active watch is
    // one preflight, and on the shared tick they competed with the census and the LP replay for the
    // invocation's budget. runRugWatches holds a KV lock and stops starting watches after ~9 min of wall time.
    if (event.cron === RUG_CRON) {
      ctx.waitUntil(runRugWatches(env, { rpc, bump: (kind, n) => bump(env, kind, n) }).catch(() => {}));
      return;
    }
    // FIRST, every tick: jobs funded the BNB-SDK way never send notify_funded,
    // so the seller looks for them (job-watch.js) — ahead of the heavy tasks,
    // so a buyer's paid job never waits behind the census or the rollup for
    // the invocation's operation budget (job 56905 was delivered 2 min into
    // the top-of-hour tick, 2026-10-04).
    ctx.waitUntil(watchFundedJobs(env, rpc).catch(() => {}));
    // THE PULSE (pulse.js, agent chart phase 1): the next agents of the census index, each once a day, kept 90 days
    ctx.waitUntil(runPulseTick(env).catch(() => {}));
    // Listed agents every hour (agent-watch alarms within the hour), on the tick at minute 0
    if (new Date(event.scheduledTime || Date.now()).getUTCMinutes() < 5) ctx.waitUntil(runListedLive(env).catch(() => {}));
    // Listed agents are asked once a day from 05:00 UTC (listing.js runListingMonitor keeps the day in KV)
    if (new Date(event.scheduledTime || Date.now()).getUTCHours() >= 5) ctx.waitUntil(runListingMonitor(env).catch(() => {}));
    // The Brain Board tells every A2A agent its checkup, once a day from 10:00 UTC (board-outreach.js; BOARD_OUTREACH=on)
    if (env.BOARD_OUTREACH === 'on' && new Date(event.scheduledTime || Date.now()).getUTCHours() >= 10) ctx.waitUntil(import('./board-outreach.js').then((m) => m.runBoardOutreach(env)).catch(() => {}));
    if (marqueProbeDue(new Date(event.scheduledTime || Date.now()))) ctx.waitUntil(keepMarqueListed(env).catch(() => {}));
    // The two Venus agents at their own work, once a day at 05:00 UTC (venus-work.js, 2026-10-21; off unless VENUS_WORK is "on")
    if (venusWorkDue(new Date(event.scheduledTime || Date.now()))) ctx.waitUntil(runVenusWork(env).catch(() => {}));
    // Our agents hire outside agents for their own work, after the Venus run (agent-hires.js, 2026-10-22; off unless AGENT_HIRES is "on")
    if (agentHiresDue(new Date(event.scheduledTime || Date.now()))) ctx.waitUntil(hireContext(env).then((c) => runAgentHires(env, { ctx: c })).catch(() => {}));
    // and the answers they bought, picked up from the chain once the sellers submit (every quarter hour; only open hires)
    // a delivery first, then what was not delivered: said after a day, refunded after the expiry (2026-10-23)
    if (event.cron === '*/15 * * * *') ctx.waitUntil(collectDeliveries(env).then(() => refundUndelivered(env)).catch(() => {}));
    // every $BOBAI holder, kept from the Transfer logs (holders.js, 2026-10-22)
    // the repair after the tick, in the same quarter hour (holders.js holdersBackfill, 2026-11-09): it stops by itself when done
    if (event.cron === '*/15 * * * *') ctx.waitUntil(holdersTick(env).then(() => holdersBackfill(env)).catch(() => {}));
    // our agents answer what is addressed to them on the Plaza Board, with the chain's word on every job named (2026-10-23)
    if (event.cron === '*/15 * * * *') ctx.waitUntil(import('./board.js').then((m) => m.answerPending(env)).catch(() => {}));
    // Every agent's finished jobs settled, once a day at 21:15 UTC after our own (public-settle.js, 2026-10-21)
    // then the budgets of jobs nobody delivered returned to their clients (public-refund.js, 2026-10-23) — after the
    // settle, never beside it: both send from the provider wallet, and two runs at once would race for its nonce
    // Brain Pop's closed day written on BNB Chain, from 00:15 UTC (pop-chain.js, 10.11.); the agent wallet's only other
    // sends are the settle (21:15) and the hires (05:30), so no two runs share its nonce
    if (event.cron === '*/15 * * * *' && popChainDue(new Date(event.scheduledTime || Date.now()))) ctx.waitUntil(runPopChain(env).catch(() => {}));
    if (publicSettleDue(new Date(event.scheduledTime || Date.now()))) ctx.waitUntil(runPublicSettle(env).catch(() => null).then((r) => (r && r.skipped === 'running' ? null : runPublicRefund(env))).catch(() => {})); // refunds only after the run of this firing, never beside another (A-Z 2026-11-21)
    // and the board of who gets hired on BNB Chain, read after it (job-board.js, 2026-10-22)
    if (jobBoardDue(new Date(event.scheduledTime || Date.now()))) ctx.waitUntil(runJobBoard(env).catch(() => {}));
    // Counts an isolate has added up but not yet written (see bump).
    ctx.waitUntil(flushCounters(env).catch(() => {}));
    ctx.waitUntil(checkWatches(env).catch(() => {}));
    // The free rug watches (rug-watch.js, 2026-10-09) moved to their own cron, RUG_CRON, above.
    // One point per liquidity-agent run; a tick that finds the same record
    // again records nothing.
    ctx.waitUntil(recordLpSeries(env).catch(() => {}));
    // The six example answers (/example?service=…) are what /services and
    // every 402 body point a stranger at. They lived in KV for 24 h and were
    // computed on demand after that: whoever came first waited 27 s for
    // yield_plan, and the LP-plan example kept describing a position burned
    // by the re-set of the morning. One example per tick, in turn, so each is
    // at most 90 minutes old and the link always lands on the cache.
    ctx.waitUntil((async () => {
      const ids = Object.keys(SERVICES);
      const id = ids[Math.floor(Date.now() / (15 * 60 * 1000)) % ids.length];
      await exampleFor(id, env, { fresh: true });
    })().catch(() => {}));

    // Live state, every tick. Six outbound calls — four peers, one Comptroller
    // read, one pool measurement — which is why it rides the fifteen-minute
    // cron rather than being computed when somebody loads the page. A snapshot
    // fifteen minutes old and labelled with its age is worth more than a fresh
    // one that costs a stranger's server a request per visitor.
    ctx.waitUntil(refreshTelemetry(env).catch(() => {}));

    // The cron fires every fifteen minutes for the watch checks. The two daily
    // jobs below hang off it, each pinned to ONE tick rather than to an hour:
    // matching on the hour alone ran the census four times every morning, which
    // is four times the KV writes on an account already close to the free-plan
    // ceiling, for a registry that does not change that fast.
    const t = new Date(event.scheduledTime);
    const firstTickOfHour = t.getUTCMinutes() < 15;

    // 03:0x UTC — read what is new in the registry, re-check a slice of the
    // known endpoints.
    if (t.getUTCHours() === 3 && firstTickOfHour) {
      ctx.waitUntil(runCensusTick(env).catch(() => {}));
    }

    // Every other hour, the cheap half on its own: how many ids exist now.
    // The registry mints thousands a day, so a high-water mark refreshed once
    // at 03:00 is stale by breakfast — and after an offline full scan it reads
    // BELOW the figure that scan published, which made the live counter on
    // /registry walk its own headline backwards. Skipped at 03:0x because the
    // full tick does the same probe as its first step.
    if (firstTickOfHour && t.getUTCHours() !== 3) {
      ctx.waitUntil(runFrontierTick(env).catch(() => {}));
    }

    // 15:0x UTC — ask a few real questions and write down how they went. Kept
    // twelve hours away from the census so the two never share an invocation's
    // outbound-call budget.
    if (t.getUTCHours() === 15 && firstTickOfHour) {
      ctx.waitUntil(runCanary(env).catch(() => {}));
    }

    // xx:3x every hour — one replay of the LP pool's last hour into the
    // width record (lp-windows.js). Pinned to the half-hour tick so it never
    // shares an invocation with the census, the frontier probe or the canary,
    // and hourly because an hour's window every 15 minutes would be the same
    // chain counted four times. 24 KV writes a day.
    if (t.getUTCMinutes() >= 30 && t.getUTCMinutes() < 45) {
      // The pool record follows the width record in the same invocation, so
      // the watched pool's window is there to copy and the two other
      // candidates are replayed once each (lp-pools.js). 24 KV writes a day.
      ctx.waitUntil(
        recordLpWindow(env).catch((e) => noteLpWindowError(env, e).catch(() => {}))
          .catch(() => {}),
      );
    }

    // 21:0x UTC — where our own jobs stand on the kernel, once a day, so the
    // first COMPLETED we ever see carries a date nobody had to be awake for.
    if (t.getUTCHours() === 21 && firstTickOfHour) {
      ctx.waitUntil(tickOwnJobs(env, rpc).catch(() => {}));
    }


    // The day's detail counts, folded together isolate by isolate (rollupDetail);
    // just after midnight the day before gets its last pass.
    ctx.waitUntil((async () => {
      await rollupDetail(env, today());
      if (t.getUTCHours() === 0 && t.getUTCMinutes() < 30) await rollupDetail(env, new Date(Date.now() - 86400e3).toISOString().slice(0, 10));
    })().catch(() => {}));
  },
};