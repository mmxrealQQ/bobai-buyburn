// THE PORTFOLIO: the DeFi agent as one picture — what went in, what it is
// worth, what it holds where, the P&L by where it came from, the pool
// record's verdict, and what it did in the last day.
//
// One model, built here from the three records (the agent's own, the series,
// the pool record) and served at agent.brainonbnb.com/lp/portfolio. The
// /defi page and the Telegram card (/defi, and the 05:00 UTC post) render
// this JSON and compute nothing of their own — the operator's rule since
// 2026-09-07: a number the page shows and a number the bot posts come from
// one function, or one of them is wrong.
//
// Pure. Pinned by scripts/lp-portfolio.mjs --self-test.
import { CANDIDATES } from './lp-pools.js';
import { HOME_POOL, rangeLeft } from '../shared/lp-guards.js';
import { resetLosses } from './lp-windows.js';

const n = (x) => Number(x || 0);
const r4 = (x) => Math.round(n(x) * 1e4) / 1e4;
const r5 = (x) => Math.round(n(x) * 1e5) / 1e5;

const labelOf = (pool) => (CANDIDATES.find((c) => c.pool === String(pool || '').toLowerCase()) || {}).label || null;

// What one recorded step did, in a few words, or null when it did nothing.
export function stepWords(name, s) {
  if (!s || typeof s !== 'object') return null;
  if (s.error) return { what: `${name}: ${s.error}`, error: true };
  if (!s.acted) return null;
  switch (name) {
    case 'sweep': return { what: s.to_operator != null
      // since 2026-10-14 a sweep no longer feeds the position: half to the operator, half buys $BOBAI held where it was earned
      ? `swept income: half to the operator, half bought ${Math.round(n(s.bobai_bought)).toLocaleString('en-US')} $BOBAI, held${s.liquidity ? `, and $${n(s.liquidity.usd).toFixed(2)} added to the $BOBAI pool, LP burned` : ''}`
      : `swept ${s.bnb_out != null ? r5(s.bnb_out) + ' BNB of ' : ''}income into the DeFi wallet` };
    case 'collect': return { what: `collected ${s.produced_bnb != null ? r5(s.produced_bnb) + ' BNB of ' : ''}fees${s.bobai_units ? `, ${Math.round(n(s.bobai_units)).toLocaleString('en-US')} $BOBAI bought and held` : ''}${n(s.to_operator_bnb) > 0 ? `, ${r5(s.to_operator_bnb)} BNB paid out to the operator` : ''}` };
    case 'relocate': return { what: `moved the position to ${s.to_label || labelOf(s.new_pool) || s.new_pool || 'another pool'}${s.new_position ? ` (#${s.new_position})` : ''}` };
    case 'rebalance': return { what: s.upgraded_to_pct != null
      ? `re-set the range wider/narrower: ±${s.upgraded_from_pct}% → ±${s.upgraded_to_pct}%${s.new_position ? ` (#${s.new_position})` : ''}`
      : `re-set the range ${s.one_sided ? `one-sided ${s.one_sided === 'above_price' ? 'above' : 'below'} the price, no trade` : 'around the price'}${s.new_position ? ` (#${s.new_position})` : ''}${n(s.bobai_bnb) > 0 ? `, ${r5(s.bobai_bnb)} BNB of its fees into $BOBAI` : ''}` };
    case 'increase': return { what: `grew the position${n(s.bnb_spent) > 0 ? ` by ${r4(s.bnb_spent)} BNB` : ''}` };
    case 'ladder': return { what: s.new_reserve && !s.old_reserve ? `opened a reserve range below the price with ${r4(s.bnb_spent)} BNB, no trade (#${s.new_reserve})`
      : s.old_reserve ? `re-set the reserve range beside the price, no trade (#${s.old_reserve} → #${s.new_reserve})`
      : s.merged_reserve ? `merged the reserve range into the main one (#${s.merged_reserve})`
      : `grew the reserve range by ${r4(s.bnb_spent)} BNB${s.swap && n(s.swap.notional_bnb) > 0 ? `, the missing side bought first (${r5(s.swap.notional_bnb)} BNB, fee ${r5(s.swap.fee_bnb)})` : ', no trade'}` };
    default: return { what: `${name} acted` };
  }
}

// Every action in the last day, newest first (the operator, 2026-09-10:
// "das erste zuoberst"): the daily run and every hourly check that moved
// something, from the record's own history (only runs that acted or failed
// are kept there).
export function lastDay(rec, now = Date.now()) {
  const since = now - 24 * 3600e3;
  const runs = (Array.isArray(rec?.history) ? rec.history : []).filter((h) => h && h.at && Date.parse(h.at) >= since);
  const out = [];
  for (const h of runs) {
    const steps = h.steps && typeof h.steps === 'object' ? h.steps : {};
    for (const [name, v] of Object.entries(steps)) {
      for (const s of Array.isArray(v) ? v : [v]) {
        const w = stepWords(name, s);
        if (w) out.push({ at: h.at, step: name, ...w, ...(w.error ? { sent: Array.isArray(s && s.txs) && s.txs.length > 0 } : {}) });
      }
    }
  }
  return out.sort((a, b) => Date.parse(b.at) - Date.parse(a.at));
}

// AGAINST HOLDING (2026-09-16). The one question a liquidity position has
// to answer: is the money better off here than in a wallet? The wallet it
// is measured against holds, from the moment each piece of capital arrived,
// half of it as BNB and half as the other side at that day's price — the
// mix a centred range is minted in. Its worth now is what the agent has to
// beat: worth + the fees that left the position (into $BOBAI) + fees still
// owed − gas. `points` is the series (capital_bnb, tick per run); each rise
// in capital is an arrival at that run's price. Pure; pinned.
export function holdingBenchmark(points, { valueNow, tickNow, wbnbIs0 = false, bobaiBnb = 0, owedBnb = 0, gasBnb = 0, waitingBnb = 0 } = {}) {
  const pts = (points || []).filter((p) => p && p.tick != null && Number(p.capital_bnb) > 0);
  if (!pts.length || tickNow == null || !(Number(valueNow) > 0)) return null;
  const priceAt = (tick) => { const raw = Math.pow(1.0001, Number(tick)); return wbnbIs0 ? 1 / raw : raw; };
  const pNow = priceAt(tickNow);
  let holding = 0, prevCap = 0;
  const arrivals = [];
  for (const p of pts) {
    const cap = Number(p.capital_bnb);
    const d = cap - prevCap;
    if (d > 1e-9) { arrivals.push({ at: p.at, bnb: +d.toFixed(6), price: priceAt(p.tick) }); holding += d * (0.5 + 0.5 * (pNow / priceAt(p.tick))); }
    prevCap = Math.max(prevCap, cap);
  }
  if (!(holding > 0)) return null;
  // waitingBnb: fees a collect kept that still wait in the wallet as BNB —
  // the agent's, outside the position, until the next increase takes them.
  const lp = Number(valueNow) + n(bobaiBnb) + n(owedBnb) + n(waitingBnb) - n(gasBnb);
  const vs = lp - holding;
  return {
    holding_bnb: r5(holding), lp_bnb: r5(lp), vs_holding_bnb: r5(vs),
    // What the market alone did to the capital: the holding wallet now against what arrived (2026-10-09). The price
    // line put the whole price part on "the market"; most of it was the ranges and their re-sets.
    capital_in_bnb: r5(prevCap), market_bnb: r5(holding - prevCap),
    vs_holding_pct: prevCap > 0 ? Math.round((vs / prevCap) * 10000) / 100 : null,
    arrivals: arrivals.length,
    basis: "a wallet that held each arrival half as BNB, half as the other side at that run's price, against the position now plus the fees that left it as $BOBAI, the fees still owed and the kept fees that wait in the wallet, less gas",
  };
}

// SINCE THIS RANGE (operator, 2026-10-13: "build the line"). The line against holding runs since 3 Sep and carries
// every range the agent ever had — most of its loss came from the ±10% weeks (CAKE −18% against BNB, 27 Sep–7 Oct).
// This is the same comparison for the position standing now alone: what was in play when it was minted (its worth, the
// fees it owed, the kept fees waiting) held half as BNB and half as the other side at that run's price, plus each later
// arrival of capital at its own run's price — against the position now, its fees owed and waiting, and the fees that
// left it as $BOBAI since. Gas inside the period is left out and said so. Points of one position, oldest first. Pure; pinned.
export function sinceRange(points, { position, wbnbIs0 = false } = {}) {
  const pts = (points || []).filter((p) => p && position != null && String(p.position) === String(position) && p.tick != null && Number(p.value_bnb) > 0);
  if (pts.length < 2) return null;
  const priceAt = (tick) => { const raw = Math.pow(1.0001, Number(tick)); return wbnbIs0 ? 1 / raw : raw; };
  const a = pts[0], b = pts[pts.length - 1], pNow = priceAt(b.tick);
  const inPlay = (p) => n(p.value_bnb) + n(p.owed_bnb) + n(p.kept_waiting_bnb);
  const start = inPlay(a);
  let holding = start * (0.5 + 0.5 * (pNow / priceAt(a.tick))), arrived = 0, prevCap = n(a.capital_bnb);
  for (const p of pts.slice(1)) { const d = n(p.capital_bnb) - prevCap; if (d > 1e-9) { arrived += d; holding += d * (0.5 + 0.5 * (pNow / priceAt(p.tick))); } prevCap = Math.max(prevCap, n(p.capital_bnb)); }
  const lp = inPlay(b) + (n(b.bobai_spent_total_bnb) - n(a.bobai_spent_total_bnb));
  const fees = (n(b.fees_total_bnb) + n(b.owed_bnb)) - (n(a.fees_total_bnb) + n(a.owed_bnb));
  const vs = lp - holding, base = start + arrived;
  return {
    position: String(position), since: a.at, to: b.at, days: Math.round(((Date.parse(b.at) - Date.parse(a.at)) / 864e5) * 10) / 10,
    price_move_pct: Math.round((pNow / priceAt(a.tick) - 1) * 1000) / 10,
    fees_bnb: r5(fees), price_bnb: r5(vs - fees), vs_holding_bnb: r5(vs), vs_holding_pct: base > 0 ? Math.round((vs / base) * 10000) / 100 : null,
    basis: 'what was in play at the mint and each later arrival, held half as BNB and half as the other side at its run\'s price, against the position now with its fees owed and waiting and the fees that left it as $BOBAI; gas inside the period left out',
  };
}

// The return in words, ONE wording for every surface (2026-09-19): the card
// said '-1.2% since 3 Sep' and the page '-1.2% on the capital' of the same
// figure — one named the period, the other the base, neither both. It is the
// profit over all the capital put in, since the first run with a position.
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export function changeText(changePct, since) {
  const v = Math.round(n(changePct) * 10) / 10;
  const pct = (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(1) + '%';
  const s = String(since || ''), dd = Number(s.slice(8, 10)), mm = Number(s.slice(5, 7));
  return `${pct} on the capital${dd && mm ? ` since ${dd} ${MONTHS[mm - 1]}` : ''}`;
}

// WHAT IT HOLDS IS WHAT THE CHAIN HOLDS (2026-11-16, Liste B): "BOBAI it holds" read the record's sum of the fee share's
// buys (218,227) while the wallet held 220,273.5 — the 2,046.485 bought on 14.10. by hand (scripts/sweep-dormant.mjs,
// the Set and Earn $U) never were in a run's record. bobaiHeldChain: the wallet's balanceOf, read beside; holdings say
// that, the fee share's own figure stays as bobai_from_fees_units, and the rest is named. Unread: the record's, as before.
export const HAND_BOBAI = { units: 2046.485, why: 'bought on 2026-10-14 by hand from the Set and Earn $U that lay in the wallet (scripts/sweep-dormant.mjs, tx 0xa07e6597…)' };
export function heldBobai(feesUnits, chainUnits) {
  const fees = n(feesUnits);
  if (!(chainUnits != null && Number.isFinite(Number(chainUnits)))) return { units: fees, source: 'record', from_fees: fees, other: null };
  const chain = Number(chainUnits), other = chain - fees;
  return { units: chain, source: 'chain', from_fees: fees, other: Math.abs(other) < 0.5 ? null : { units: Math.round(other * 1000) / 1000, why: Math.abs(other - HAND_BOBAI.units) < 1 ? HAND_BOBAI.why : 'not bought by a run of the agent (a transfer in or out, or a run not on record)' } };
}
export function lpPortfolio(rec, series, { now = Date.now(), bobaiUsd = null, bnbUsdNow = null, width = null, outsideSince = null, centred = false, bobaiHeldChain = null } = {}) {
  const last = rec && rec.last;
  const sum = series && series.summary;
  if (!last || !last.at || !sum || !sum.profit) return null;
  const held = heldBobai(sum.bobai_held_units, bobaiHeldChain);
  const pts = Array.isArray(series.points) ? series.points : [];
  const pt = pts.length ? pts[pts.length - 1] : null;
  const bnbUsd = n(sum.profit.bnb_usd) || null;
  // one price for every tile (2026-11-01): put in and result at the last run's, worth at today's did not add up by $22
  const usd = (bnb) => { const p = bnbUsdNow > 0 ? bnbUsdNow : bnbUsd; return p ? Math.round(n(bnb) * p * 100) / 100 : null; };
  const value = sum.value_bnb || {};
  const putIn = n(value.capital_total_bnb) || (n(value.start) + n(value.added_by_hand_bnb) + n(sum.deposits_put_in_bnb) + n(sum.income_put_in_bnb));
  const sources = [{ label: 'start', bnb: r4(value.start) }];
  if (n(value.added_by_hand_bnb) > 0) sources.push({ label: 'by hand', bnb: r4(value.added_by_hand_bnb) });
  if (n(sum.deposits_put_in_bnb) > 0) sources.push({ label: 'deposited', bnb: r4(sum.deposits_put_in_bnb) });
  if (n(sum.income_put_in_bnb) > 0) sources.push({ label: 'from AI income', bnb: r4(sum.income_put_in_bnb) });

  // The range as it stands: the newest check, not the series' last point —
  // on 2026-09-10 the card said "in range" from the 05:40 point while the
  // 11:30 check had the price outside for two hours.
  const chk = rec.last_check && rec.last_check.at && Date.parse(rec.last_check.at) >= Date.parse(last.at) ? rec.last_check : last;
  const inc = (chk.steps && chk.steps.increase) || (last.steps && last.steps.increase) || {};
  const rb = (chk.steps && chk.steps.rebalance) || {};
  const position = (inc.position != null ? String(inc.position) : null) || (pt && pt.position != null ? String(pt.position) : null) || (rb.new_position != null ? String(rb.new_position) : null);
  // after a re-set the rebalance step's in_range is the range it LEFT (2026-10-07): without a newer increase step the
  // flag is read off the range it moved to (new_ticks) and the newest tick
  const rbNow = (rb.acted && !rb.error && rb.new_ticks) || null, rbTick = inc.tick ?? rb.tick ?? null;
  const inRange = inc.in_range != null ? !!inc.in_range : rbNow && rbTick != null ? rbTick >= rbNow[0] && rbTick < rbNow[1] : rb.in_range != null ? !!rb.in_range : pt ? !!pt.in_range : null;
  const poolAddr = String(rec.pool || HOME_POOL.pool).toLowerCase();
  const poolLabel = labelOf(poolAddr) || (poolAddr === HOME_POOL.pool ? HOME_POOL.label : null);
  const walletBnb = inc.wallet_bnb != null ? n(inc.wallet_bnb) : pt ? n(pt.wallet_bnb) : 0;
  const reserve = inc.reserve || rb.reserve || null;

  const p = sum.profit;
  const feeParts = [];
  if (n(p.fees_collected_bnb) > 0) feeParts.push({ label: 'collected', bnb: r5(p.fees_collected_bnb) });
  if (n(p.fees_folded_bnb) > 0) feeParts.push({ label: 'folded into the position', bnb: r5(p.fees_folded_bnb) });
  if (n(p.fees_forwarded_at_resets_bnb) > 0) feeParts.push({ label: 'into $BOBAI', bnb: r5(p.fees_forwarded_at_resets_bnb) });
  if (n(p.fees_owed_bnb) > 0) feeParts.push({ label: 'still owed by the position', bnb: r5(p.fees_owed_bnb) });

  const day = lastDay(rec, now);
  // The range as a person asks about it: how wide, in or out, and what the
  // agent does next — one sentence, from the record's own width and wait.
  const hist = Array.isArray(rec.history) ? rec.history : [];
  let widthPct = null;
  for (let i = hist.length - 1; i >= 0 && widthPct == null; i--) { const r = hist[i]?.steps?.rebalance; if (r && r.acted && !r.error && n(r.width_pct) > 0) widthPct = n(r.width_pct); }
  if (widthPct == null && n(rb.width_pct) > 0) widthPct = n(rb.width_pct);
  const pick = width && n(width.width_pct) > 0 ? width : null;
  const waitH = width && width.wait_hours != null ? n(width.wait_hours) : null;
  const outH = outsideSince ? Math.max(0, (now - Date.parse(outsideSince)) / 36e5) : null;
  const hm = (h) => (h == null ? '' : h < 1 ? `${Math.round(h * 60)} min` : `${h.toFixed(1)} h`);
  // Two short sentences, no figures the card does not need (the operator,
  // 2026-09-12: "einfacher, uebersichtlicher, klarer"). What the pick nets
  // a day stays in the record (/lp/windows), not on the card.
  let next;
  // (2026-09-24, D7) "after 0 h out of range" read as nonsense: a wait of
  // zero is the first hourly check that finds the price outside.
  const waitText = waitH === 0 ? 'at the first hourly check that finds it out of range' : `after ${waitH ?? 2} h out of range`;
  // At the edge is read off the ticks, not off a flag: the ten-minute watch
  // keeps no rebalance step when it did nothing, so the flag would only be
  // there after the hourly check; the position's own ticks are always there.
  const posTicks = (rb.acted && !rb.error && rb.new_ticks) || rb.ticks || (pt && pt.ticks) || null;
  const tickSeen = inc.tick ?? rb.tick ?? (pt ? pt.tick : null);
  const edgeRead = Array.isArray(posTicks) && posTicks.length === 2 && tickSeen != null ? rangeLeft(tickSeen, posTicks[0], posTicks[1]) : null;
  const atEdge = rb.at_edge === true || inc.at_edge === true || !!(edgeRead && edgeRead.outside && !edgeRead.left);
  // Where the range lies against the price (2026-10-07): a one-sided range sits wholly above or below it, and
  // "±0.25%" read as a range centred on the price; the page writes "0.5% wide, above the price" instead.
  const side = Array.isArray(posTicks) && posTicks.length === 2 && tickSeen != null ? (tickSeen < posTicks[0] ? 'above' : tickSeen >= posTicks[1] ? 'below' : null) : null;
  // what the next re-set mints, as worker-lp will mint it (LP_RESET_MODE): centred = around the price, one trade
  const newRange = (w) => centred ? `the new range centred on the price, ±${w}%, one trade back to the range's mix` : `the new range one-sided beside the price, ${+(2 * w).toFixed(2)}% wide, no trade`;
  if (!position) next = 'No position yet. The first deposit above the floor opens one.';
  else if (inRange) next = pick
    ? `Holds and earns. A re-set only ${waitText}: ${newRange(pick.width_pct)}.`
    : 'Holds and earns. A re-set only after the wait out of range; the width record has no day of prices yet.';
  else if (atEdge) next = 'At the edge of its range, not left. Earns again from the first tick back inside.';
  else next = pick
    ? `Out of range${outH != null ? ` for ${hm(outH)}` : ''}. Re-set ${waitText}: ${newRange(pick.width_pct)}.`
    : `Out of range${outH != null ? ` for ${hm(outH)}` : ''}. Re-set after the wait; the width record has no day of prices yet.`;
  const losses = resetLosses(rec);
  // Where the position was left: the newest tick the record saw.
  const tickNow = inc.tick ?? rb.tick ?? (pt ? pt.tick : null);
  const wbnbIs0 = rb.wbnb_is0 === true || (hist.slice().reverse().find((x) => x?.steps?.rebalance?.wbnb_is0 != null)?.steps.rebalance.wbnb_is0 === true);
  const vsHold = holdingBenchmark(pts, { valueNow: value.now, tickNow, wbnbIs0, bobaiBnb: n(sum.fees_into_bobai_bnb ?? sum.fees_sent_to_buyback_bnb) + n(sum.fees_to_operator_bnb), owedBnb: sum.fees_owed_now_bnb, gasBnb: p.gas_bnb, waitingBnb: sum.fees_kept_waiting_bnb });
  // WHAT THE AGENT HOLDS BESIDE THE POSITION (2026-09-18). "Worth now" is the
  // position; the result above it also counts what the position produced and
  // no longer holds — $BOBAI bought (at what it cost), fees still owed, kept
  // fees waiting in the wallet. Without this line worth − put in was a
  // tenth of the result shown beside it. worth + beside − put in − gas = result.
  const besideParts = [
    { label: '$BOBAI held, at cost', bnb: r5(sum.fees_into_bobai_bnb ?? sum.fees_sent_to_buyback_bnb) },
    // a third of the fees since 2026-10-14: earned by the position, paid out to the operator as BNB
    { label: 'paid out to the operator', bnb: r5(sum.fees_to_operator_bnb) },
    { label: 'fees owed by the position', bnb: r5(sum.fees_owed_now_bnb) },
    { label: 'kept fees waiting in the wallet', bnb: r5(sum.fees_kept_waiting_bnb) },
  ].filter((x) => n(x.bnb) > 0);
  const besideBnb = besideParts.reduce((a, x) => a + n(x.bnb), 0);
  const dayCount = (step) => day.filter((d) => d.step === step && !d.error).length;
  const daySummary = {
    resets: dayCount('rebalance'), top_ups: dayCount('increase'), collects: dayCount('collect'), sweeps: dayCount('sweep'), reserve_moves: dayCount('ladder'),
    // FAILED RUNS, NOT FAILED STEPS (2026-10-14): one node timeout at 20:40 failed the re-set check and the ladder check
    // of the same run and the card read "2 failed"; it is one run, and nothing was sent — said so
    errors: new Set(day.filter((d) => d.error).map((d) => d.at)).size,
    errors_sent_nothing: day.some((d) => d.error) && !day.some((d) => d.error && d.sent),
    last: day.length ? { at: day[0].at, what: day[0].what, error: !!day[0].error } : null,
  };
  return {
    at: last.at, date: String(last.at).slice(0, 10), checked_at: chk.at || last.at, bnb_usd: bnbUsdNow > 0 ? bnbUsdNow : bnbUsd, bnb_usd_at_run: bnbUsd,
    pool: { address: poolAddr, label: poolLabel, position, reserve_position: reserve ? String(reserve.position) : null, in_range: inRange, range_checked_at: last.range_checked_at || chk.at || null, width_pct: widthPct, outside_since: outsideSince || null, outside_hours: outH == null ? null : Math.round(outH * 10) / 10, at_edge: !inRange && atEdge, side },
    next,
    day: daySummary,
    put_in: { bnb: r4(putIn), usd: usd(putIn), sources },
    // at the BNB price of now (2026-10-30): at the last run's price /defi read $1,539 beside the front page's $1,502
    worth: { bnb: r4(value.now), usd: bnbUsdNow > 0 ? Math.round(n(value.now) * bnbUsdNow * 100) / 100 : usd(value.now), beside_bnb: r4(besideBnb), beside_usd: bnbUsdNow > 0 ? Math.round(n(besideBnb) * bnbUsdNow * 100) / 100 : usd(besideBnb), beside_parts: besideParts, all_in_bnb: r4(n(value.now) + besideBnb) },
    holdings: {
      position_bnb: r4(value.now), fees_owed_bnb: sum.fees_owed_now_bnb == null ? null : r5(sum.fees_owed_now_bnb),
      bobai_units: Math.round(held.units), bobai_source: held.source, bobai_from_fees_units: Math.round(held.from_fees), ...(held.other ? { bobai_other: held.other } : {}), bobai_bnb: r5(sum.fees_into_bobai_bnb ?? sum.fees_sent_to_buyback_bnb),
      // What the held $BOBAI is worth now, at the pair's own price — read by
      // the route, so the model can say "3,895 $BOBAI (≈ $x)" beside the
      // BNB it cost.
      bobai_usd: bobaiUsd > 0 ? Math.round(held.units * bobaiUsd * 100) / 100 : null,
      bobai_usd_price: bobaiUsd > 0 ? bobaiUsd : null,
      wallet_bnb: r4(walletBnb), kept_waiting_bnb: r5(sum.fees_kept_waiting_bnb),
      // The ladder's reserve range (2026-09-16), when one stands: BNB below
      // the price, waiting to buy the other side through fees.
      // Where the reserve stands: 'wbnb' = below the price (a buy ladder), 'other' = the price fell through it (it waits to merge), 'both' = the price is inside it.
      reserve: reserve ? { position: String(reserve.position), ticks: reserve.ticks || null, bnb: r4(reserve.value_bnb), side: reserve.side || null } : null,
    },
    pnl: {
      // Where the profit went, the operator's two halves: the fees kept as
      // capital (collected and kept, or folded in by a re-set) keep working;
      // the other half became $BOBAI the agent holds.
      kept_working_bnb: r5(sum.fees_kept_as_capital_bnb),
      into_bobai_bnb: r5(sum.fees_into_bobai_bnb ?? sum.fees_sent_to_buyback_bnb),
      bobai_units: Math.round(n(sum.bobai_held_units)),
      profit_bnb: r5(p.bnb), profit_usd: usd(p.bnb), change_pct: Math.round(n(value.change_pct) * 100) / 100,
      change_text: changeText(value.change_pct, sum.since),
      from_price_bnb: r5(p.from_price_bnb), from_fees_bnb: r5(p.from_fees_bnb), fee_parts: feeParts, gas_bnb: r5(p.gas_bnb),
      // The price part in its two causes (2026-10-09): the market (a wallet that held each arrival 50/50) and the
      // ranges against that wallet (their re-sets included). market + range = price.
      from_market_bnb: vsHold && vsHold.market_bnb != null ? vsHold.market_bnb : null,
      from_range_bnb: vsHold && vsHold.market_bnb != null ? r5(n(p.from_price_bnb) - vsHold.market_bnb) : null,
      // What the re-sets themselves cost, from the record's ticks: the loss
      // against holding each re-set realised, and its execution.
      at_resets: { count: losses.resets, valued: losses.valued, lost_to_price_bnb: r5(losses.lost_to_price_bnb), execution_bnb: r5(losses.execution_bnb) },
      // The line the whole thing is judged by: the position, with everything
      // it produced, against a wallet that simply held (holdingBenchmark).
      vs_holding: vsHold,
      // the same line for the range standing now alone (sinceRange), with its width
      since_range: (() => { const s = sinceRange(pts, { position, wbnbIs0 }); return s ? { ...s, width_pct: widthPct } : null; })(),
      in_range_runs: n(sum.days_in_range), runs: n(sum.runs_with_a_position), since: String(sum.since || '').slice(0, 10),
      // The share of time, from the ten-minute tape; the run counts beside it lean high (D3).
      time_in_range_pct: sum.time_in_range ? sum.time_in_range.in_range_pct : null,
      // the tape began after `since` (2026-11-12: 100 % read as "in range since 3 Sep"), so the share names its own start
      time_in_range_from: sum.time_in_range && sum.time_in_range.from ? String(sum.time_in_range.from).slice(0, 10) : null, time_in_range_samples: sum.time_in_range ? sum.time_in_range.samples ?? null : null,
      other_token: poolLabel ? poolLabel.split('/')[0] : 'the other side',
    },
    last_24h: day,
    last_run_ok: last.ok !== false,
    links: { page: 'https://brainonbnb.com/defi', record: 'https://agent.brainonbnb.com/lp/agent', series: 'https://agent.brainonbnb.com/lp/series' },
  };
}