# brainScreener

Thirteen self-tests. No accounts, no tracking, no backend.

ADHD, IQ, depression, anxiety, trauma, personality and more — each an established instrument with its scoring implemented in the page itself. Nothing is sent anywhere: the answers never leave the browser, which is also why there is no server here to speak of.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A static host**
    ours: Cloudflare Pages
    also: any of them. There is no build step and no framework
- **Nothing else**
    ours: no database, no accounts, no analytics, no cookies
    also: the answers never leave the browser, which is a design decision rather than a shortcut

## Run it

    serve the folder

## What is in here

- `dashboard/brainscreener/404.html`  (57 lines)
- `dashboard/brainscreener/adhd-result.html`  (142 lines)
- `dashboard/brainscreener/adhd.html`  (161 lines)
- `dashboard/brainscreener/aq50-result.html`  (134 lines)
- `dashboard/brainscreener/aq50.html`  (126 lines)
- `dashboard/brainscreener/assets/css/main.css`  (1035 lines)
- `dashboard/brainscreener/assets/js/adhs.js`  (355 lines)
- `dashboard/brainscreener/assets/js/charakter-result.js`  (180 lines)
- `dashboard/brainscreener/assets/js/i18n/en/adhs-data.js`  (158 lines)
- `dashboard/brainscreener/assets/js/i18n/en/adhs-result.js`  (193 lines)
- `dashboard/brainscreener/assets/js/i18n/en/aq50-data.js`  (228 lines)
- `dashboard/brainscreener/assets/js/i18n/en/audit-data.js`  (185 lines)
- `dashboard/brainscreener/assets/js/i18n/en/bfi2-data.js`  (314 lines)
- `dashboard/brainscreener/assets/js/i18n/en/charakter-data.js`  (261 lines)
- `dashboard/brainscreener/assets/js/i18n/en/eat26-data.js`  (219 lines)
- `dashboard/brainscreener/assets/js/i18n/en/gad7-data.js`  (159 lines)
- `dashboard/brainscreener/assets/js/i18n/en/iq-data.js`  (473 lines)
- `dashboard/brainscreener/assets/js/i18n/en/iq-result.js`  (205 lines)
- `dashboard/brainscreener/assets/js/i18n/en/mdq-data.js`  (178 lines)
- `dashboard/brainscreener/assets/js/i18n/en/ocir-data.js`  (188 lines)
- `dashboard/brainscreener/assets/js/i18n/en/pcl5-data.js`  (218 lines)
- `dashboard/brainscreener/assets/js/i18n/en/phq9-data.js`  (229 lines)
- `dashboard/brainscreener/assets/js/i18n/en/whodas36-data.js`  (295 lines)
- `dashboard/brainscreener/assets/js/iq.js`  (342 lines)
- `dashboard/brainscreener/assets/js/print-fallback.js`  (228 lines)
- `dashboard/brainscreener/assets/js/result-engine.js`  (193 lines)
- `dashboard/brainscreener/assets/js/test-engine.js`  (468 lines)
- `dashboard/brainscreener/assets/js/year.js`  (6 lines)
- `dashboard/brainscreener/audit-result.html`  (134 lines)
- `dashboard/brainscreener/audit.html`  (126 lines)
- `dashboard/brainscreener/bfi2-result.html`  (134 lines)
- `dashboard/brainscreener/bfi2.html`  (126 lines)
- `dashboard/brainscreener/character-result.html`  (175 lines)
- `dashboard/brainscreener/character.html`  (126 lines)
- `dashboard/brainscreener/eat26-result.html`  (134 lines)
- `dashboard/brainscreener/eat26.html`  (126 lines)
- `dashboard/brainscreener/gad7-result.html`  (134 lines)
- `dashboard/brainscreener/gad7.html`  (126 lines)
- `dashboard/brainscreener/index.html`  (453 lines)
- `dashboard/brainscreener/iq-result.html`  (137 lines)
- `dashboard/brainscreener/iq.html`  (152 lines)
- `dashboard/brainscreener/mdq-result.html`  (134 lines)
- `dashboard/brainscreener/mdq.html`  (126 lines)
- `dashboard/brainscreener/ocir-result.html`  (134 lines)
- `dashboard/brainscreener/ocir.html`  (126 lines)
- `dashboard/brainscreener/pcl5-result.html`  (134 lines)
- `dashboard/brainscreener/pcl5.html`  (126 lines)
- `dashboard/brainscreener/phq9-result.html`  (134 lines)
- `dashboard/brainscreener/phq9.html`  (126 lines)
- `dashboard/brainscreener/whodas36-result.html`  (134 lines)
- `dashboard/brainscreener/whodas36.html`  (126 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/brainscreener.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/brainscreener.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
