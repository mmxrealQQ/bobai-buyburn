# Dev Sweep Bot

The hourly one that empties the tax wallet.

Sweeps the creator share out of the tax wallet on its own schedule and unwraps WBNB back to native BNB so the buyback bot always finds spendable gas. Small on purpose — it is the piece that keeps the big bot from starving.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A wallet that receives the tax**
    ours: the same wallet the buyback bot spends from
    also: any wallet — it only needs to be the one your token routes its fee to
- **Somewhere that runs code hourly**
    ours: a Cloudflare Worker on a cron trigger
    also: crontab, systemd timer, GitHub Actions, or any scheduler you already run
- **Somewhere to keep a cursor**
    ours: one KV namespace, shared with the buyback bot
    also: a file, a Redis key, a single database row — it stores very little
- **One secret at runtime: PRIVATE_KEY**
    ours: wrangler secret put
    also: a .env file or your host's secret store

## Run it

    npx wrangler deploy
    or locally: node -r dotenv/config dev-buyback.js

## What is in here

- `dev-buyback.js`  (157 lines)
- `worker-dev-buyback/index.js`  (170 lines)
- `worker-dev-buyback/wrangler.toml`  (10 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/dev-sweep-bot.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/dev-sweep-bot.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
