# Burn & Add Liq — Browser Game

One HTML file. Jump, burn, dodge the dumps.

A side-scrolling browser game in a single document — canvas rendering, its own sprite work, touch and keyboard controls, and a public highscore board. The only moving part outside the file is the score table.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A static host**
    ours: Cloudflare Pages
    also: anything that can serve one HTML file. Open it from disk and it plays
- **A score table, only if you want the board**
    ours: one Supabase table; the SQL is in the bundle
    also: any database with an HTTP API, or leave it out — the game runs fine and keeps scores locally
- **To know what a public score table means**
    ours: anyone holding the browser key can post a score
    also: put the insert behind your own endpoint, or add an upper bound, if the board is meant to be competitive

## Run it

    open index.html

## What is in here

- `dashboard/game/index.html`  (1181 lines)
- `game/bobai_scores_setup.sql`  (17 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/browser-game.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/browser-game.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
