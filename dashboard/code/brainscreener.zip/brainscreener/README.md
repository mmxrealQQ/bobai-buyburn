# brainScreener

Thirteen self-tests. No accounts, no tracking, no backend.

ADHD, IQ, depression, anxiety, trauma, personality and more — each an established instrument with its scoring implemented in the page itself. Nothing is sent anywhere: the answers never leave the browser, which is also why there is no server here to speak of.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A static host**
    ours: Cloudflare Pages
    also: any of them. There is no build step and no framework
- **Nothing else**
    ours: no database, no accounts, no analytics, no cookies
    also: the answers never leave the browser, which is a design decision rather than a shortcut

## Run it

    serve the folder

## What is in here

- `dashboard/brainscreener/404.html`  (57 lines)
- `dashboard/brainscreener/adhd-result.html`  (141 lines)
- `dashboard/brainscreener/adhd.html`  (145 lines)
- `dashboard/brainscreener/aq50-result.html`  (133 lines)
- `dashboard/brainscreener/aq50.html`  (110 lines)
- `dashboard/brainscreener/assets/css/main.css`  (1010 lines)
- `dashboard/brainscreener/assets/js/adhs.js`  (326 lines)
- `dashboard/brainscreener/assets/js/charakter-result.js`  (180 lines)
- `dashboard/brainscreener/assets/js/i18n/en/adhs-data.js`  (153 lines)
- `dashboard/brainscreener/assets/js/i18n/en/adhs-result.js`  (190 lines)
- `dashboard/brainscreener/assets/js/i18n/en/aq50-data.js`  (228 lines)
- `dashboard/brainscreener/assets/js/i18n/en/audit-data.js`  (180 lines)
- `dashboard/brainscreener/assets/js/i18n/en/bfi2-data.js`  (314 lines)
- `dashboard/brainscreener/assets/js/i18n/en/charakter-data.js`  (261 lines)
- `dashboard/brainscreener/assets/js/i18n/en/eat26-data.js`  (211 lines)
- `dashboard/brainscreener/assets/js/i18n/en/gad7-data.js`  (158 lines)
- `dashboard/brainscreener/assets/js/i18n/en/iq-data.js`  (473 lines)
- `dashboard/brainscreener/assets/js/i18n/en/iq-result.js`  (206 lines)
- `dashboard/brainscreener/assets/js/i18n/en/mdq-data.js`  (178 lines)
- `dashboard/brainscreener/assets/js/i18n/en/ocir-data.js`  (188 lines)
- `dashboard/brainscreener/assets/js/i18n/en/pcl5-data.js`  (218 lines)
- `dashboard/brainscreener/assets/js/i18n/en/phq9-data.js`  (210 lines)
- `dashboard/brainscreener/assets/js/i18n/en/whodas36-data.js`  (296 lines)
- `dashboard/brainscreener/assets/js/iq.js`  (326 lines)
- `dashboard/brainscreener/assets/js/print-fallback.js`  (212 lines)
- `dashboard/brainscreener/assets/js/result-engine.js`  (193 lines)
- `dashboard/brainscreener/assets/js/test-engine.js`  (400 lines)
- `dashboard/brainscreener/assets/js/year.js`  (6 lines)
- `dashboard/brainscreener/audit-result.html`  (133 lines)
- `dashboard/brainscreener/audit.html`  (110 lines)
- `dashboard/brainscreener/bfi2-result.html`  (133 lines)
- `dashboard/brainscreener/bfi2.html`  (110 lines)
- `dashboard/brainscreener/character-result.html`  (175 lines)
- `dashboard/brainscreener/character.html`  (110 lines)
- `dashboard/brainscreener/debug-ua.html`  (76 lines)
- `dashboard/brainscreener/eat26-result.html`  (133 lines)
- `dashboard/brainscreener/eat26.html`  (110 lines)
- `dashboard/brainscreener/gad7-result.html`  (133 lines)
- `dashboard/brainscreener/gad7.html`  (110 lines)
- `dashboard/brainscreener/index.html`  (452 lines)
- `dashboard/brainscreener/iq-result.html`  (137 lines)
- `dashboard/brainscreener/iq.html`  (136 lines)
- `dashboard/brainscreener/mdq-result.html`  (133 lines)
- `dashboard/brainscreener/mdq.html`  (110 lines)
- `dashboard/brainscreener/ocir-result.html`  (133 lines)
- `dashboard/brainscreener/ocir.html`  (110 lines)
- `dashboard/brainscreener/pcl5-result.html`  (133 lines)
- `dashboard/brainscreener/pcl5.html`  (110 lines)
- `dashboard/brainscreener/phq9-result.html`  (133 lines)
- `dashboard/brainscreener/phq9.html`  (110 lines)
- `dashboard/brainscreener/whodas36-result.html`  (133 lines)
- `dashboard/brainscreener/whodas36.html`  (110 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/brainscreener.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/brainscreener.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
