# Pool Scanner

Reads any BNB Chain pool, the measurement in your browser.

Paste a token, a pool or a DexScreener link and it measures what a trader actually meets: price impact and real cost per trade size, the transfer tax derived from executed trades rather than from a label, and whether the LP is burned, locked or withdrawable. The measurement runs in the visitor's browser against public RPC endpoints. Four panels ask the site's own free API (the best route, the fee tiers, the range plan, the server-side scan), and DexScreener and GoPlus are read for the pair list and a second opinion on the contract — the bundle carries that worker code too (2026-11-22: it said "no backend at all", which stopped being true when those panels came).

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A static host**
    ours: Cloudflare Pages
    also: GitHub Pages, Netlify, Vercel, S3, nginx, or python -m http.server on your laptop
- **Public RPC endpoints**
    ours: six, with failover, all free
    also: your own node if you expect traffic. Note the requests leave from the visitor's browser, not your server — which is why this costs nothing to run
- **For four panels: a small API**
    ours: the site worker (/api/pool-scan, /api/best-route, /api/fee-tiers, /api/range-plan)
    also: leave those panels out and the page still measures everything in the browser; no database, no API key, no build step

## Run it

    drop the files on any static host, or: python -m http.server

## What is in here

- `dashboard/scanner-chain.js`  (2720 lines)
- `dashboard/scanner-scan.js`  (928 lines)
- `dashboard/scanner.html`  (499 lines)
- `dashboard/scanner.js`  (1987 lines)
- `dashboard/styles.css`  (1387 lines)
- `dashboard/tier-scan.js`  (467 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/pool-scanner.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/pool-scanner.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
