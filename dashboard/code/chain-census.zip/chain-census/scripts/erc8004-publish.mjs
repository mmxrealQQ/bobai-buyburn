// Turns the census into the page and the JSON endpoint that serve it.
//
// Reads the live census under data/ (scripts/lib/census-dir.mjs), writes dashboard/registry.html and
// dashboard/api-registry.json. Both are generated — never edit them by hand,
// the next run overwrites them. Everything the page states comes from the two
// scan artefacts, so there is no path by which the page can claim a number the
// data does not contain.
//
// THE WHOLE RITUAL, in order. Every step after the first reads what the one
// before it wrote, and skipping one leaves a surface stating something no
// longer true — which is exactly how the page came to publish 302,828 and then
// count itself down to 299,783 in front of the reader.
//
//   node scripts/erc8004-scan.mjs          --dir erc8004-v2   # resumes; never delete
//   node scripts/erc8004-enrich.mjs        --dir erc8004-v2   # re-reads every listed id; corrects records an agent changed since (setAgentURI)
//   node scripts/erc8004-probe.mjs         --dir erc8004-v2
//   node scripts/erc8004-a2a-confirm.mjs   --dir erc8004-v2
//   node scripts/erc8004-publish.mjs       --dir erc8004-v2   # also writes hireable.json
//   node scripts/deploy-dashboard.mjs                         # BEFORE hire-confirm, see below (the site goes out without its HTML comments since 2026-09-19)
//   cd worker-agent && npx wrangler deploy                    # BEFORE hire-confirm, see below
//   node scripts/erc8004-hire-confirm.mjs  --dir erc8004-v2   # asks each one for a price
//   node scripts/erc8004-publish.mjs       --dir erc8004-v2   # again, to render the answers
//   node scripts/census-sync.mjs           --dir erc8004-v2   # hands the scan to the worker
//   # pull the census line in dashboard/llms.txt from api-registry.json
//   node scripts/build-library.mjs
//   node scripts/deploy-dashboard.mjs
//   node scripts/smoke-agent-surface.mjs   # checks every one of the above landed
//
// WHY TWO DEPLOYS SIT IN THE MIDDLE OF THAT LIST
// hire-confirm does not ask the agents directly. It asks our live /hire, which
// resolves an ERC-8004 id through the DEPLOYED api-agents.json and caches that
// file for ten minutes. So a newly registered agent is unhireable until the
// dashboard carries it AND the agent worker has been restarted to drop the
// cache. Run hire-confirm before both and it reports "no A2A endpoint found"
// for an agent that is perfectly reachable — which is what happened on
// 2026-08-26, twice, before the cause was clear.
import fs from 'node:fs';
import path from 'node:path';
import { censusDirArg } from './lib/census-dir.mjs';
import { groupByOperator, operatorOf } from './lib/group-agents.mjs';
import { loadJobs, aggregate } from './lib/job-aggregate.mjs';
import { CATEGORIES, classifyAgent } from '../worker-agent/categories.js';
import { PEERS, SURFACE, OWN_AGENT_IDS } from '../worker-agent/telemetry.js';
import { SERVICES } from '../worker-agent/sell.js';
import { SOLD_BY } from '../worker-agent/catalog.js';
import { OWN_WALLETS } from '../worker-agent/own-wallets.js';
import { SERVICE_BY_SLUG, OWN_AGENTS } from './lib/own-agents.mjs';
import { summarize } from '../shared/job-summary.js';

const ROOT = path.resolve(import.meta.dirname, '..');
// Same flag the scanner takes, so all halves of the census can be pointed at
// one dataset: scan, enrich, probe, publish. Defaults to the live census; a
// rescan gets its own directory (--dir erc8004-v3) so it never overwrites the
// data the page is serving while it runs.
const DIR = path.join(ROOT, 'data', censusDirArg());
// The stylesheet version is the homepage's, read, not copied: the page this
// writes carried v=37 in its template while the site was at v=49 — the built
// file had been bumped by hand, and the next run would have put it back
// (found 2026-09-18).
const STYLES_V = (fs.readFileSync(path.join(ROOT, 'dashboard', 'index.html'), 'utf8').match(/styles\.css\?v=(\d+)/) || [null, '49'])[1];
const state = JSON.parse(fs.readFileSync(path.join(DIR, 'scan-state.json'), 'utf8'));
let ownJobs = null;
const ownJobTotals = () => {
  if (!ownJobs) { ownJobs = {}; try { for (const [id, a] of Object.entries(JSON.parse(fs.readFileSync(path.join(ROOT, 'dashboard', 'api-agent-jobs.json'), 'utf8')).agents || {})) ownJobs[id] = a.totals; } catch { /* optional */ } }
  return ownJobs;
};
// a row's hires: its own job record where it has one, the provider's count where not
const rowEmployment = (r) => {
  const t = ownJobTotals()[r.agentId];
  return t?.funded ? { ...r.employment, own: t, funded: t.funded, funded_outside: t.funded_outside, completed_outside: t.paid_out_outside, outside_buyers: t.buyers_outside, funded_by_us: t.funded - t.funded_outside, submitted_not_released: t.delivered_waiting, last_submission: t.last_delivery ? Math.floor(Date.parse(t.last_delivery) / 1000) : r.employment?.last_submission } : r.employment;
};

let census = null;
try { census = JSON.parse(fs.readFileSync(path.join(DIR, 'census.json'), 'utf8')); } catch {}

// What each agent says about itself, from erc8004-enrich.mjs. Optional: the
// page works without it, it just has less to say about each agent.
let registrations = {};
try { registrations = JSON.parse(fs.readFileSync(path.join(DIR, 'registrations.json'), 'utf8')); } catch {}

// What happened the last time each hireable agent was actually asked for a
// price. A "Hire" button on a seller that cannot quote is a button that wastes
// the visitor's time, and this page is in no position to complain about other
// people's unverified numbers while shipping one of its own.
const hireConfirm = (() => {
  const f = path.join(DIR, 'hire-confirm.json');
  if (!fs.existsSync(f)) return null;
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; }
})();
// An agent listed in two categories is asked once per category, and the two
// answers can differ; the one for the row's own category wins (2026-10-09).
const quoteOf = (id, cat = null) => {
  const all = (hireConfirm?.agents || []).filter((a) => String(a.id) === String(id));
  return (cat && all.find((a) => a.category === cat)) || all[0] || null;
};
// THREE ANSWERS, NOT TWO (2026-10-09). Every refusal printed as one red "No
// price when asked", so an agent that answered "send me a GRID_PLAN_V1" stood
// beside one whose endpoint was a 405. They are different facts: the first is
// a working seller that wants structured input, the second did not answer.
//   'quotes'  returned a price
//   'input'   answered, but not with a price we could use — asked for a
//             structured plan, said it has no negotiate skill, answered
//             without a price, priced in a token this escrow does not settle
//   'none'    did not answer: HTTP error, unreadable card, auth wall, timeout
// Unknown reasons count as 'none' only when they read like a transport
// failure; anything else that came back in words was an answer.
const NO_ANSWER = /HTTP \d{3}|could not be read|not an A2A reply|Unauthori[sz]ed|Authentication|Forbidden|timed? ?out|timeout|fetch failed|ECONN|ENOTFOUND|EAI_AGAIN|certificate|no A2A endpoint|did not answer/i;
const quoteState = (q) => {
  if (!q) return null;
  if (q.quotes) return 'quotes';
  const why = String(q.reason || '').trim();
  return !why || NO_ANSWER.test(why) ? 'none' : 'input';
};
const QUOTE_RANK = { quotes: 0, input: 1, none: 2 };

const reachable = [];
try {
  for (const line of fs.readFileSync(path.join(DIR, 'reachable.jsonl'), 'utf8').split('\n')) {
    if (!line.trim()) continue;
    try { const r = JSON.parse(line); if (r.reachable) reachable.push(r); } catch {}
  }
} catch {}
// SERVING, NOT ONLY ANSWERING (2026-10-27, library #102; operator's choice "Variante 1": both figures). Any HTTP answer
// counts as reachable, and of the 995 that answered on 24.10. 365 answered 404 at every declared address and 57 only
// on a code, social or spec host (the OASF repository listed as an endpoint). An agent serves when at least one of its
// declared addresses, on a host that is not one of those, answers with anything but 404.
export const NOT_A_SERVICE_HOST = /^(github\.com|gist\.github\.com|raw\.githubusercontent\.com|eips\.ethereum\.org|x\.com|twitter\.com|t\.me|discord\.gg|discord\.com|medium\.com|youtube\.com|linkedin\.com|notion\.so|ethereum\.org|schema\.org|json-schema\.org)$/;
export function servesSomething(r) {
  const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, '').toLowerCase(); } catch { return ''; } };
  return (r.checked || []).some((c) => c.status != null && c.status !== 404 && !NOT_A_SERVICE_HOST.test(hostOf(c.url)));
}
const serving = reachable.filter(servesSomething).length;
const speaking = reachable.filter((r) => r.live && (r.live.mcp || r.live.card)).length;

// The employment census from scripts/erc8183-job-scan.mjs. Optional: the page
// renders without it and simply says nothing about who has been paid, rather
// than showing an empty table that reads as "nobody has".
//
// Identity and employment are joined here because they are joinable: the job
// kernel names a provider ADDRESS and the registry answers ownerOf() for an
// agent ID, and both live on the same chain. That join is the entire reason
// this page can say "this listed agent has been hired eleven times" instead of
// "this listed agent says it is good at things".
let jobCensus = null;
let jobOwners = null;
try {
  const jobsFile = path.join(ROOT, 'data', 'erc8183', 'jobs.jsonl');
  const jobState = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'erc8183', 'scan-state.json'), 'utf8'));
  const jobs = loadJobs(jobsFile);
  // A partial job scan must not be published as an employment census, for the
  // same reason a partial identity scan must not be published as a census: the
  // numbers all still parse, and every one of them is wrong.
  if (jobState.jobCounter && jobs.size >= jobState.jobCounter * 0.995) {
    jobCensus = { ...aggregate(jobs), jobCounter: jobState.jobCounter, unread: jobState.unread || 0, measuredAt: jobState.finishedAt || jobState.updatedAt };
  } else if (jobs.size) {
    console.log(`  (job census skipped: ${jobs.size.toLocaleString('en-US')} of ${(jobState.jobCounter || 0).toLocaleString('en-US')} jobs read)`);
  }
  try { jobOwners = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'erc8183', 'owners.json'), 'utf8')); } catch { /* optional */ }
} catch { /* no job scan yet */ }

const c = state.counts;
const scanned = state.cursor - 1;
const total = state.highestId;
const pct = (n, d = scanned) => (d ? (n / d) * 100 : 0);
const fmt = (n) => Number(n).toLocaleString('en-US');
const p1 = (n, d = scanned) => pct(n, d).toFixed(pct(n, d) < 1 ? 2 : 1) + '%';

// An incomplete scan must not be published as if it were a census. This caught
// a real failure: a stopped background scan kept running and overwrote the
// finished state with its own older one, leaving the counts 60,000 ids short
// while every file still parsed and every number still looked plausible. The
// page would have quietly understated the ecosystem it claims to measure.
// --partial publishes anyway, for when a snapshot is genuinely wanted.
if (scanned < total * 0.995 && !process.argv.includes('--partial')) {
  console.error(`
Refusing to publish: only ${scanned.toLocaleString('en-US')} of ${total.toLocaleString('en-US')} ids scanned (${((scanned / total) * 100).toFixed(1)}%).`);
  console.error(`Finish the scan first, or pass --partial to publish a snapshot anyway.
`);
  process.exit(1);
}

// ---- the JSON surface ----------------------------------------------------
const api = {
  what_this_is: 'A census of the ERC-8004 identity registry on BNB Smart Chain: how many agents are registered, how many of those registrations are readable, how many name an endpoint, and how many of those endpoints answer.',
  registry: '0x8004A169FB4a3325136EB29fA0ceB6D2e539a432',
  chain: 'eip155:56',
  measured_at: census?.measured_at || state.updatedAt,
  registered_ids: total,
  ids_scanned: scanned,
  registrations: {
    parses: c.valid,
    unparsable: c.unparsable,
    empty: c.empty,
    // The correction this rescan existed for. 43% of registrations are an
    // https link to a document, and the previous census counted those as
    // holding nothing readable. Published so the claim can be checked
    // against the data rather than taken from the prose.
    points_offchain: c.offchain,
    unread_after_retries: c.unread,
    active_flag: c.active,
    names_a_service: c.withServices,
    has_http_endpoint: c.withHttpEndpoint,
    endpoint_on_a_real_tld: c.plausibleEndpoint,
    speaks_mcp: c.mcp,
    speaks_a2a: c.a2a,
    supports_x402: c.x402,
  },
  reachability: census?.endpoints || null,
  independent_operators: null, // filled in below, once operators are grouped
  method: {
    registrations: 'Every id read via tokenURI() on the registry. Ids the nodes refused are retried until they answer; the count above reports what remained unreadable after that, so a percentage here is never a statement about node availability.',
    reachability: 'Every claimed HTTP endpoint contacted once. Any HTTP response counts as reachable, including 401, 403 and 404 — only a failed connection counts as dead. MCP endpoints were sent a real tools/list; agent cards had to parse as JSON.',
    caveat: 'Reachability is a snapshot. An endpoint down at that moment is counted as dead, and one that answers may still do nothing useful.',
  },
  source: 'https://brainonbnb.com/registry',
};
fs.writeFileSync(path.join(ROOT, 'dashboard', 'api-registry.json'), JSON.stringify(api, null, 2) + '\n');

// ---- the list itself, for machines ---------------------------------------
// The census counts; this is what another agent can actually use. Only agents
// that answered are in it, and where one exposes tools or skills they are
// listed by name — because "an agent exists at this address" is a directory
// entry, and a directory is the thing this set out to be better than.
//
// Sorted so that agents which speak a protocol come first: an agent looking for
// a counterpart wants those, and burying them under a few hundred plain web
// servers would make the useful part of the list the hardest to reach.
const directory = reachable
  .map((r) => ({
    id: r.id,
    name: r.name || registrations[r.id]?.name || null,
    // The operator's own description, straight from the on-chain registration.
    // This is what turns a row into something a person can judge.
    ...(registrations[r.id]?.description ? { description: registrations[r.id].description } : {}),
    ...(registrations[r.id]?.image ? { image: registrations[r.id].image } : {}),
    ...(registrations[r.id]?.trust?.length ? { trust_models: registrations[r.id].trust } : {}),
    ...(registrations[r.id]?.services?.length ? { declared_services: registrations[r.id].services } : {}),
    endpoints: r.endpoints,
    speaks: [r.live?.mcp ? 'mcp' : null, r.live?.a2a ? 'a2a' : null,
      (r.x402 || registrations[r.id]?.x402) ? 'x402' : null].filter(Boolean),
    ...(r.live?.tools?.length ? { tools: r.live.tools } : {}),
    ...(r.live?.skills?.length ? { skills: r.live.skills } : {}),
    ...(r.live?.cardUrl ? { agent_card: r.live.cardUrl } : {}),
    ...(r.live?.cardDescription ? { description: r.live.cardDescription } : {}),
  }))
  .sort((a, b) => b.speaks.length - a.speaks.length || a.id - b.id);

// Grouped by who actually runs them. 784 reachable ids are 72 operators, and
// 103 MCP agents are 7 — one provider accounts for 96 of them, all returning
// the identical five tools. Counting ids describes the registry correctly and
// describes the market wrongly.
// Our own hireable agents, merged in from the registration state file.
//
// They are on-chain and answering, but the identity census is a periodic full
// scan and will only see them on its next pass. Leaving the two categories the
// chain is thinnest in looking empty until then would misrepresent what a buyer
// can actually hire today. Merged by id, so the census overwrites this the
// moment it catches up rather than listing them twice.
// The sentence the hire box opens with, per seller rather than per category.
//
// It used to be one template per category, which broke the moment two agents
// shared a category and needed different inputs: the yield template is a plain
// question with no address in it, and the fee-tier seller refuses without one.
// A buyer who took the suggested wording would have funded a job the seller
// then declined — the exact failure that cost job 56670, discovered after
// paying. A seed is a promise that the sentence works as written.
// WBNB (2026-10-30): the seeds named the $BOBAI contract, so a stranger who edited nothing paid for a report on it.
const SEED_TOKEN = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
const SEED_CAKE = '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82'; // two holdings: one token has nothing to rebalance against
const SEED_TASKS = {
  health_factor: 'health factor and liquidation distance for the Venus position at <ADDR>',
  grid_plan: `grid plan for WBNB ${SEED_TOKEN} with a budget of $1000 capital, 10 levels across a 15% band`,
  yield_plan: 'best stablecoin yield for 1000 USDT on BNB Chain right now',
  rebalance_plan: `rebalance holdings [{"token":"${SEED_TOKEN}","usd":700},{"token":"${SEED_CAKE}","usd":300}] to equal weight`,
  lp_tier_plan: `which PancakeSwap fee tier is actually paying for ${SEED_TOKEN}, placing $1000 of liquidity`,
  // The DeFi Agent (2026-10-04): without its own seed the panel fell back to
  // the category's sentence — a portfolio rebalance — and the agent rightly
  // declined it. Our own position, as a sentence that works; a visitor puts
  // in their position id or wallet.
  lp_position_plan: 'what would the DeFi agent do with the PancakeSwap V3 position held by <ADDR>',
};
const seedTask = (svc) => SEED_TASKS[svc.id] || null;

// AN EXAMPLE ANSWER PER SERVICE, on the card. A description says what a
// service measures; an answer shows it. Where a job has actually been paid and
// delivered, its stored deliverable is the example — the document whose
// SHA-256 sits on the kernel, so the card shows what a buyer really got. Where
// none exists yet, the worker's /example route runs the same doWork() a funded
// job runs, on the seed sentence, and says so. Both are summarised by the one
// module the job page also uses (shared/job-summary.js), so the card and the
// delivery cannot be read by two different rules. A worker that does not
// answer costs the card its example, never the build.
// Only jobs whose delivery answers the sentence that was asked. 56670-56672
// (grid_plan) were hired with the old seed "grid plan for WBNB", a symbol and
// no address, and the plan came back on $BOBAI — a real delivery, but not an
// example anyone should be shown next to that question. The seed carries an
// address now; the next paid grid job can take this slot.
// 56694 (2026-09-03): hired from the panel with the address-bearing seed,
// delivered six seconds after funding, attested on-chain by the buyer.
const REAL_JOBS = { health_factor: '56657', grid_plan: '56694' };
const AGENT_ORIGIN = 'https://agent.brainonbnb.com';
const fetchJson = async (u) => {
  try {
    const r = await fetch(u, { signal: AbortSignal.timeout(90000) });
    return r.ok ? await r.json() : null;
  } catch { return null; }
};
const EXAMPLES = {};
for (const id of Object.keys(SERVICES)) {
  let ex = null;
  if (REAL_JOBS[id]) {
    const [doc, job] = await Promise.all([fetchJson(`${AGENT_ORIGIN}/job/${REAL_JOBS[id]}/result`), fetchJson(`${AGENT_ORIGIN}/job?id=${REAL_JOBS[id]}`)]);
    if (doc && doc.result) {
      ex = { kind: 'job', job_id: REAL_JOBS[id], status: job?.status || null, task: (() => { try { return JSON.parse(job?.description || '{}').task || null; } catch { return null; } })(),
        produced_at: doc.produced_at || null, result: doc.result, url: `${AGENT_ORIGIN}/job?id=${REAL_JOBS[id]}` };
    }
  }
  if (!ex) {
    const e = await fetchJson(`${AGENT_ORIGIN}/example?service=${id}`);
    if (e && e.result) ex = { kind: 'example', task: e.task, produced_at: e.produced_at, result: e.result, url: `${AGENT_ORIGIN}/example?service=${id}` };
  }
  if (ex) { ex.summary = summarize(id, ex.result); EXAMPLES[id] = ex; }
  else console.warn(`no example for ${id} — the card goes out without one`);
}

let ownAgents = [];
try {
  const own = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'own-agents.json'), 'utf8'));
  ownAgents = Object.entries(own.agents || {}).filter(([, a]) => a.id).map(([slug, a]) => {
    // Our own agents were being listed with description: null, so the table
    // printed "its registration says nothing about what it does" against the
    // two entries we control — while holding other people to the same standard
    // one row below. The text comes from the service definition in sell.js,
    // which is the same sentence the agent sells itself with over A2A and the
    // same one it delivers against. One source, and it cannot drift from what
    // is actually for sale.
    //
    // BY SLUG, NOT BY CATEGORY. The lookup used to match on category, which
    // holds only while no two agents share one. Two do, and `find` returned
    // whichever service was declared first — so one of our own agents was
    // described as the other one, in the section a judge is asked to compare
    // agents in. A slug names exactly one agent; a category does not.
    const svc = SERVICES[SERVICE_BY_SLUG[slug]] || null;
    // WHAT IT SPEAKS, FROM ITS OWN ON-CHAIN DOCUMENT (2026-10-19): the list was typed here as a2a + x402 and the
    // services came from the census's older read, so the Screener showed all six without MCP, which each of them
    // serves at /<slug>/mcp. own-agents.mjs is the document setAgentURI writes; the row reads the same one.
    const doc = OWN_AGENTS.find((o) => o.slug === slug)?.doc;
    const names = (doc?.services || []).map((s) => String(s.name).toLowerCase());
    return {
      id: a.id,
      name: a.name,
      description: svc ? svc.deliverables : null,
      // Every agent of ours has its own endpoint and card since 2026-10-04
      // (/<slug>/a2a); the shared /a2a counter stays for old links.
      endpoints: [`https://agent.brainonbnb.com/${slug}/a2a`, `https://agent.brainonbnb.com/${slug}/a2a/.well-known/agent-card.json`],
      speaks: doc ? ['a2a', 'mcp', 'x402'].filter((p) => names.includes(p)) : ['a2a', 'x402'],
      ...(doc ? { declared_services: doc.services.map((s) => ({ name: s.name, endpoint: s.endpoint })) } : {}),
      // What it can be asked for, named the way the seller names it. Empty
      // tools on purpose: see the merge below.
      skills: svc ? [{ name: svc.id, description: svc.name }] : [],
      tools: [],
      seed: svc ? seedTask(svc) : null,
      example: svc ? EXAMPLES[svc.id] || null : null,
      attributes: [{ trait_type: 'Category', value: a.category }],
      ours: true,
      // The payee is the agentWallet where it differs from the owner (the DeFi
      // Agent: owned by the wallet that runs the position, paid through the
      // provider that signs its quotes).
      provider: a.agent_wallet || a.owner,
    };
  });
  // OUR DEFINITION WINS, rather than being dropped when the census already has
  // the id. Five agents sell from one A2A endpoint, and one endpoint serves one
  // agent card, so the enrichment step gave all five the same description and
  // the same six capabilities. On a page whose whole job is helping somebody
  // choose between agents, that printed the identical paragraph four times,
  // once per category. The per-agent on-chain document is the truth; the
  // shared card is an artefact of how they are hosted.
  for (const a of ownAgents) {
    const i = directory.findIndex((d) => d.id === a.id);
    if (i < 0) directory.push(a); else directory[i] = { ...directory[i], ...a };
  }
} catch { /* nothing registered yet */ }

// Which categories each agent returned a price for when asked (2026-10-09).
// classifyAgent counts that as evidence for a loose-word match — and it rides
// in api-agents.json, so /find on the worker reads the same evidence.
{
  const quotedFor = new Map();
  for (const a of hireConfirm?.agents || []) {
    if (!a.quotes || !a.category) continue;
    const k = String(a.id);
    if (!quotedFor.has(k)) quotedFor.set(k, new Set());
    quotedFor.get(k).add(a.category);
  }
  for (const d of directory) {
    const q = quotedFor.get(String(d.id));
    if (q) d.quoted_for = [...q].sort();
  }
  // WHAT HAPPENED WHEN IT WAS ASKED FOR A PRICE (2026-10-27, a stranger hiring through /find: "/find returns no price and
  // no hireable flag — my agent cannot choose a hireable agent from /find alone; that is only on the HTML page"). The same
  // answer the Plaza page shows, per agent: quotes (with the price), input (answered, wants something we did not send —
  // its own words) or none (did not answer), and when it was asked.
  for (const d of directory) {
    const all = (hireConfirm?.agents || []).filter((a) => String(a.id) === String(d.id));
    if (!all.length) continue;
    const best = all.find((a) => a.quotes) || all[0];
    d.escrow = { answer: quoteState(best), ...(best.quotes ? { price: best.price || null } : { said: String(best.reason || '').slice(0, 200) || null }),
      ...(best.category ? { category: best.category } : {}), asked_at: hireConfirm?.measured_at || null };
  }
}
const operators = groupByOperator(directory);
api.independent_operators = operators.length;
fs.writeFileSync(path.join(ROOT, 'dashboard', 'api-registry.json'), JSON.stringify(api, null, 2) + '\n');

// ---- the employment census, for machines ---------------------------------
// The identity census says who exists. This says who has been paid, which is
// the only reputation signal on this chain nobody can write about themselves:
// a registration is self-reported text, a funded job is somebody else's money.
if (jobCensus) {
  const jobsApi = {
    what_this_is: 'Every job in the ERC-8183 escrow kernel on BNB Smart Chain, read one at a time and aggregated into an employment balance per provider. It answers who has actually been hired and paid, as opposed to who is registered.',
    kernel: '0xEa4DAa3100A767e86FDed867729ae7446476EBA6',
    payment_token: { symbol: 'U', name: 'United Stables', address: '0xcE24439F2D9C6a2289F741120FE202248B666666', decimals: 18 },
    chain: 'eip155:56',
    measured_at: jobCensus.measuredAt,
    jobs: {
      job_counter: jobCensus.jobCounter,
      read: jobCensus.total,
      unread_after_retries: jobCensus.unread,
      by_status: jobCensus.byStatus,
      ever_funded: jobCensus.fundedJobs,
      escrow_released: jobCensus.completed,
      completed_with_zero_budget: jobCensus.completed_unfunded,
      deliverable_never_released: jobCensus.submitted,
      never_funded: jobCensus.open,
      total_escrowed_u: Number(jobCensus.escrowedU.toFixed(6)),
      distinct_buyers: jobCensus.buyers,
      distinct_providers: jobCensus.providers.length,
      providers_paid_by_more_than_one_buyer: jobCensus.providersWithRealWork,
      top_provider_share: Number(jobCensus.concentration.top_provider_share.toFixed(4)),
      top5_share: Number(jobCensus.concentration.top5_share.toFixed(4)),
      excluding_top_provider: jobCensus.withoutTopProvider,
    },
    providers: jobCensus.providers.map((p) => ({
      address: p.address,
      agents: jobOwners?.owners?.[p.address] || [],
      jobs: p.jobs,
      funded: p.funded,
      completed: p.completed,
      submitted_not_released: p.submitted_not_released,
      awaiting_delivery: p.awaiting_delivery,
      expired: p.expired,
      rejected: p.rejected,
      never_funded: p.never_funded,
      distinct_buyers: p.distinct_buyers,
      escrowed_u: Number(p.escrowed_u.toFixed(6)),
      median_budget_u: Number(p.median_budget_u.toFixed(6)),
      delivery_rate: Number(p.delivery_rate.toFixed(4)),
      first_job_id: p.first_job_id,
      last_job_id: p.last_job_id,
    })),
    method: {
      jobs: 'getJob() called for every id from 1 to jobCounter(). Ids a node refused are retried patiently; whatever remains unreadable is reported as unread rather than folded into a percentage.',
      funded: 'A job in status OPEN was created and never funded — createJob costs nothing and commits nobody, so OPEN is excluded from every payment figure.',
      completed: 'SUBMITTED means a deliverable is on-chain and the escrow has NOT released. Only COMPLETED means the money moved. The two are never added together.',
      delivery_rate: 'Completions divided by funded jobs, not by all jobs: a provider is not answerable for jobs a buyer created and abandoned.',
      identity_join: jobOwners
        ? `Provider addresses matched to agent ids via ownerOf() on the identity registry, over the ${jobOwners.agents} registered agents that carry an HTTP endpoint. A provider with no match is not unregistered — it is simply not in that population.`
        : 'Not resolved for this build.',
    },
    source: 'https://brainonbnb.com/registry',
  };
  fs.writeFileSync(path.join(ROOT, 'dashboard', 'api-jobs.json'), JSON.stringify(jobsApi, null, 2) + '\n');
}

fs.writeFileSync(path.join(ROOT, 'dashboard', 'api-operators.json'), JSON.stringify({
  what_this_is: 'The same census grouped by operator instead of by registry id. One entry per independent provider, with the number of registry ids it runs. This is the market view; api-agents.json is the complete one.',
  measured_at: api.measured_at,
  registered_ids: total,
  reachable_ids: directory.length,
  independent_operators: operators.length,
  operators_speaking_a_protocol: operators.filter((o) => o.speaks.length).length,
  note: 'Grouped on the registrable domain of the first endpoint. Entries pointing at code or social hosts (github.com, x.com, t.me) are excluded — reachable, but not an agent endpoint. Ordering is by demonstrated capability, never by how many ids an operator registered.',
  operators,
}, null, 2) + '\n');

fs.writeFileSync(path.join(ROOT, 'dashboard', 'api-agents.json'), JSON.stringify({
  what_this_is: 'Every ERC-8004 agent on BNB Smart Chain that answered when contacted, with whatever it exposes about itself. Generated from a full registry scan — not self-reported, not curated.',
  measured_at: api.measured_at,
  registered_ids: total,
  answered: directory.length,
  speaking_a_protocol: directory.filter((d) => d.speaks.length).length,
  independent_operators: operators.length,
  operator_view: 'https://brainonbnb.com/api-operators.json',
  note: 'Presence here means the address responded and, where stated, the protocol answered. It is not an endorsement, a rating, or a claim that the agent does anything useful.',
  // The example answers are for the page; here they would add a few hundred
  // lines of one operator's own results to a directory every hire request
  // downloads. A pointer to where the example lives is enough.
  agents: directory.map((d) => (d.example ? { ...d, example: d.example.url } : d)),
}, null, 2) + '\n');

// ---- the page ------------------------------------------------------------
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));

// Each row is a small profile rather than a table cell: logo, name, what the
// operator says it does, what it demonstrably speaks, and the address you can
// call. The point of the whole exercise is that none of this is self-reported
// into a form we control — the description comes from the chain, the protocol
// tags come from having spoken to it.

// ---- the four categories -------------------------------------------------
//
// The marketplace is judged on four, equally: rebalancing, grid trading, yield
// optimisation, health-factor monitoring. Presenting them means answering an
// awkward question honestly — the chain does not contain four categories of
// depth. After collapsing fleets to their operators there is one independent
// grid trader on all of BNB Chain, and one rebalancer.
//
// A marketplace can respond to that by padding the thin shelves with anything
// whose description contains the right word, or by saying what is there. The
// second is the only one that survives being checked, so each row carries HOW
// it was categorised and the exact string that did it.
const providerOfAgent = new Map();
if (jobOwners?.owners) {
  for (const [addr, agents] of Object.entries(jobOwners.owners)) {
    for (const a of agents) providerOfAgent.set(a.id, addr);
  }
}
for (const a of ownAgents) if (a.provider) providerOfAgent.set(a.id, a.provider.toLowerCase());

// How many agent ids on the page sell from one provider address (built once
// providerOfAgent is filled; read by the card renderer).
const providerAgentCount = new Map();
const countProviderAgents = () => {
  providerAgentCount.clear();
  for (const addr of providerOfAgent.values()) providerAgentCount.set(addr, (providerAgentCount.get(addr) || 0) + 1);
};
const employmentOf = (ids) => {
  if (!jobCensus) return null;
  if (!providerAgentCount.size) countProviderAgents();
  let best = null;
  for (const id of ids) {
    const addr = providerOfAgent.get(id);
    if (!addr) continue;
    const rec = jobCensus.providers.find((p) => p.address === addr);
    if (rec && (!best || rec.funded > best.funded)) best = rec;
  }
  return best;
};

const NL = String.fromCharCode(10);

const SOURCE_BADGE = {
  declared: ['declared', 'The agent\'s own status endpoint returns this category, machine-readable.'],
  registered: ['on-chain', 'Its ERC-8004 registration carries this category as an attribute.'],
  derived: ['matched', 'We matched this from what it exposes. It is evidence, not a statement by the agent.'],
};

// Two different things need two different treatments, and using one for both
// produced a row reading "Brain On BNB AI — yield optimisation", which we do
// not do.
//
//   An agent that SAYS what it is — live on its own status endpoint, or in its
//   on-chain registration — is listed as itself. Collapsing it into whatever
//   else shares its hostname loses the one piece of information that was not a
//   guess. Our own two agents share an endpoint with the marketplace, and
//   merging them made all three into one row under a category none of them
//   declared.
//
//   An agent we MATCHED is collapsed to its operator, because that is where
//   padding lives: 236 registry ids on one host, all the same deployment,
//   would otherwise fill a category by themselves.
// Matching a printed row back to the live telemetry the worker collects.
//
// The key travels in the HTML as data-tele so the page does not have to guess
// from a hostname at render time — the mapping from host to poller id lives in
// one place, next to the poller, and a peer added there shows up here without
// a second list to keep in step.
const peerByHost = new Map(PEERS.map((p) => [new URL(p.origin).host, p.id]));
// Our own agent ids come from the telemetry surface rather than a literal
// list here. The first version hardcoded two of them, and registering two more
// would have left the new rows with no live line and no error — the page would
// simply have been quietly less alive than it claimed.
const OWN_IDS = new Set(OWN_AGENT_IDS);
const teleKey = (id, host) => (
  OWN_IDS.has(id) ? `own:${id}` : (peerByHost.get(host) || null)
);

// WHAT IT DOES, WHICH THE TABLE DID NOT SAY
// The rubric asks that somebody can land, find an agent by category,
// understand what it does, and activate it. Three of those four were on the
// page. The columns were the agent, how we classified it, and whether it had
// ever been paid — all true, none of them an answer to "what does this thing
// do". A directory that cannot answer that is asking the reader to hire on
// vibes.

// The tools and skills an agent exposes, which is the machine-readable half of
// what it does. The ERC-8183 selling handshake is filtered out: negotiate and
// notify_funded are how you buy from an agent, not something the agent does,
// and printing them as capabilities makes every seller look identical.
const HANDSHAKE = /^(negotiate|notify[_ -]?funded|deliver|start|list)$/i;
const HANDSHAKE_LABEL = /^(negotiate an erc-8183 job|notify the seller)/i;
const capsOf = (x) => {
  const out = [];
  for (const t of x.tools || []) {
    const name = typeof t === 'string' ? t : (t && (t.name || t.id));
    if (name && !HANDSHAKE.test(name)) out.push({ name: String(name), why: (t && t.description) || '' });
  }
  for (const sk of x.skills || []) {
    const name = typeof sk === 'string' ? sk : (sk && (sk.name || sk.id));
    if (!name) continue;
    if (HANDSHAKE.test(name) || HANDSHAKE_LABEL.test(String(name))) continue;
    out.push({ name: String(name), why: (sk && sk.description) || '' });
  }
  // Same name from tools and skills is one capability, not two.
  const seen = new Set();
  return out.filter((c) => (seen.has(c.name.toLowerCase()) ? false : seen.add(c.name.toLowerCase())));
};

// Some registrations describe the selling handshake instead of the service —
// "ERC-8183 seller agent (bnbGridTrader-agent) — negotiate + notify_funded over
// A2A". That is true and tells a buyer nothing. Printing it as the answer to
// "what does it do" would be repeating a non-answer with a straight face, so it
// is named as what it is. Three of the four BNB reference agents describe
// themselves this way.
const SELLER_BOILERPLATE = /erc-?8183 seller agent|negotiate \+ notify_funded/i;

// Registrations arrive with mojibake often enough to matter: an em dash that
// went through the wrong encoding twice shows up as a replacement character in
// the middle of a sentence. We do not silently rewrite somebody's text, but a
// character that carries no information is dropped rather than printed.
const clean = (t) => String(t).replace(/\uFFFD/g, '').replace(/\s+/g, ' ').trim();

const describes = (r) => {
  const d = r.description ? clean(r.description) : '';
  if (!d) return { text: null, weak: true, why: 'Its registration says nothing about what it does.' };
  if (SELLER_BOILERPLATE.test(d)) {
    return { text: null, weak: true, why: 'Says nothing about what it does — only that it sells.' };
  }
  // The full text rides along: the card cuts at 190 characters and had no
  // way to read the rest ("…measured from executed trades.…").
  return { text: d.length > 190 ? d.slice(0, 190).replace(/\s+\S*$/, '') + '…' : d, full: d.length > 190 ? d : null, weak: false, why: null };
};

// CAN BE HIRED and HAS BEEN HIRED are different facts, and the first version
// of the table derived the first from the second. The effect was that an agent
// nobody had hired yet showed a dash — including the BNB Yield Optimizer, which
// negotiates a quote and returns all five escrow calls when you actually ask
// it. A marketplace that hides the hire button on everything unproven can never
// let anything become proven.
//
// Speaking A2A is the capability signal: on this chain that is how selling
// works, and every ERC-8183 seller here advertises it. History stays on its own
// line underneath, where it belongs.
//
// Defined once because the homepage prints the count. Two copies of this rule
// is how a front page ends up quoting a number the marketplace would not.
const canHire = (r) => !!(r.ours || (r.speaks || []).includes('a2a') || (r.employment && r.employment.funded > 0));

// The example answer on one of our own cards: a headline, the figures behind
// it, and where it came from — a paid job by number, or the worker's example
// run — so a reader can tell a delivery from a demonstration at a glance.
const exampleBlock = (ex) => {
  const s = ex.summary || { headline: '', facts: [] };
  const when = ex.produced_at ? String(ex.produced_at).slice(0, 10) : '';
  const from = ex.kind === 'job'
    ? `From job <a href="${esc(ex.url)}" target="_blank" rel="noopener">#${esc(ex.job_id)}</a>${ex.status ? `, ${esc(ex.status.toLowerCase())}` : ''}${when ? `, delivered ${when}` : ''} &mdash; the document whose hash is on the kernel.`
    : `An example run${when ? ` on ${when}` : ''} by the same code a paid job runs, on the sentence the hire box opens with. <a href="${esc(ex.url)}" target="_blank" rel="noopener">Full answer</a>.`;
  return `          <details class="rgc-ex">
            <summary>Example answer${ex.kind === 'job' ? ' <span class="rg-t rg-x4">real job</span>' : ''}</summary>
            ${ex.task ? `<div class="rg-note rgc-ex-task">Asked: &ldquo;${esc(ex.task)}&rdquo;</div>` : ''}
            <b class="rgc-ex-h">${esc(s.headline)}</b>
            ${s.facts && s.facts.length ? `<ul class="rgc-facts">${s.facts.map(([k, v]) => `<li><span>${esc(k)}</span> ${esc(v)}</li>`).join('')}</ul>` : ''}
            <div class="rg-note">${from}</div>
          </details>`;
};

// hireConfirm, quoteOf and quoteState are defined near the top (2026-10-09):
// the categories read them before the directory is written.

// The other half of ERC-8004. The identity registry says who exists, the
// escrow census says who has been paid, and this says who has been RATED —
// which on this chain is not stars out of five but machine-written
// attestations: uptime as a percentage, response time in milliseconds, each
// over a window that travels with the figure.
//
// A value is only ever printed next to its own unit and its own window. Two
// uptimes measured over 1d and 7d are two measurements of two periods, and a
// single "score" folded out of them would be a number nobody took.
const reputation = (() => {
  const f = path.join(DIR, 'reputation.json');
  if (!fs.existsSync(f)) return null;
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; }
})();
const ratingOf = (id) => (reputation?.agents || []).find((a) => String(a.id) === String(id) && a.latest) || null;
// The address this marketplace rates other agents from. It is the same wallet
// that owns our own registrations, so a reader can tie a rating to a party
// rather than to an anonymous address — and so the page can say which numbers
// are ours instead of quietly presenting them as somebody else's.
const OUR_RATER = String((() => {
  try {
    const own = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'own-agents.json'), 'utf8'));
    return Object.values(own.agents || {}).map((a) => a.owner).find(Boolean) || '';
  } catch { return ''; }
})()).toLowerCase();
// every wallet of ours, not the owner alone (2026-10-30: a hire test through the panel attests from 0x7380)
const isOurs = (client) => OWN_WALLETS.has(String(client).toLowerCase()) || (!!OUR_RATER && String(client).toLowerCase() === OUR_RATER);
// One rendered measurement, with the rater attached. Two parties measuring the
// same agent is the whole reason to read this registry, so both are printed.
const metricBit = (tag, v) => `${esc(String(v.value))}${esc(v.unit || '')} ${esc(METRIC_LABEL[String(tag).toLowerCase()] || tag)}${v.window ? (/^\d+\s*(m|min|h|d|w|mo|y)\w*$/i.test(String(v.window).trim()) ? ` over ${esc(v.window)}` : ` (${esc(v.window)})`) : ''}${isOurs(v.client) ? ' <span class="rg-repby">(measured here)</span>' : v.client ? ` <span class="rg-repby">(by ${esc(String(v.client).slice(0, 6))}…${esc(String(v.client).slice(-4))})</span>` : ''}`;
// Keys lower-case: tags arrive as "responseTime" and "responsetime" (2026-10-12: a
// row printed "236ms response over 7d · 6000ms responsetime").
const METRIC_LABEL = { uptime: 'uptime', responsetime: 'response', latency: 'latency', liveness: 'liveness' };
const OPERATIONAL_TAGS = new Set(['uptime', 'responsetime', 'latency', 'liveness']);

// WHAT GOES ON A ROW, AND WHAT DOES NOT.
//
// The registry holds two kinds of claim under one roof. An uptime or a
// response time is a measurement somebody else can go and take again. A
// "personality" of 70 is a taste claim about a stranger's agent, and on this
// chain 20,696 of the 20,732 attestations are that — six tags, written in
// bulk, with 70 as the commonest value in seven cases out of ten.
//
// Printing "personality 70" in the column a buyer reads to decide would be
// repeating a non-answer with a straight face, which is exactly what this page
// refuses to do one column to the left. So the row carries the measurements,
// and says plainly when all an agent has is taste.
const ratingLine = (id) => {
  const r = ratingOf(id);
  if (!r) return '';
  const n = (r.clients || []).length;
  // `n` is everyone who ever wrote feedback about this agent — not the writers
  // of the one measurement shown beside it (30 addresses stood next to a
  // "100% liveness" one of them wrote). Said as what it is.
  const by = `<span class="rg-repby"> ${n} ${n === 1 ? 'address has' : 'addresses have'} written feedback on this agent</span>`;
  const entries = Object.entries(r.latest);
  const measured = entries.filter(([tag]) => OPERATIONAL_TAGS.has(tag.toLowerCase()));
  if (measured.length) {
    const parts = measured.flatMap(([tag, vs]) => vs.map((v) => metricBit(tag, v)));
    return `<div class="rg-note rg-rep" title="Read live from the ERC-8004 ReputationRegistry at ${REPUTATION_ADDR}. Measurements, not opinions: each one is something a third party could take again — including ours, where it says so.">${parts.join(' &middot; ')}${by}</div>`;
  }
  const tags = entries.map(([t]) => t).slice(0, 3).join(', ');
  return `<div class="rg-note rg-repweak" title="Read live from the ERC-8004 ReputationRegistry at ${REPUTATION_ADDR}.">rated only on ${esc(tags)}${entries.length > 3 ? ' and more' : ''} &mdash; nothing measurable${by}</div>`;
};
// The same two measurements as one chip: uptime and response time, value and
// unit only. Window, rater and the "(measured here)" mark stay on the full
// line under the fold — a chip that tried to carry them would be the sentence
// it replaced.
// The comparable uptime: several raters write "uptime" under different
// windows ("rebalancing", "7d", "30d"). Prefer an entry whose window is a
// duration, the longest one, and a stranger's over ours.
const DUR = /^(\d+)\s*(h|d|w)$/i;
const durH = (w) => { const m = DUR.exec(String(w || '').trim()); return m ? Number(m[1]) * { h: 1, d: 24, w: 168 }[m[2].toLowerCase()] : -1; };
const uptimeEntry = (r) => {
  const e = Object.entries(r.latest).find(([t]) => t.toLowerCase() === 'uptime');
  const vs = (e && e[1]) || [];
  if (!vs.length) return null;
  return [...vs].sort((a, b) => (durH(b.window) - durH(a.window)) || ((isOurs(a.client) ? 1 : 0) - (isOurs(b.client) ? 1 : 0)))[0];
};
const uptimeOf = (id) => {
  const r = ratingOf(id);
  const up = r && uptimeEntry(r);
  const v = up && String(up.unit || '').includes('%') ? Number(up.value) : NaN;
  return Number.isFinite(v) ? v : null;
};
const repChip = (id) => {
  const r = ratingOf(id);
  if (!r) return '';
  const first = (tag) => {
    const e = Object.entries(r.latest).find(([t]) => t.toLowerCase() === tag);
    return e && e[1] && e[1][0] ? e[1][0] : null;
  };
  const up = uptimeEntry(r);
  const rt = first('responsetime') || first('latency');
  const bits = [];
  // "attested": one rater's number; /screener's pulse only says the card loaded, and the two read 3% and 100% side by side (2026-10-30)
  if (up) bits.push(`${esc(String(up.value))}${esc(up.unit || '')} attested uptime`);
  if (rt) bits.push(`${esc(String(rt.value))}${esc(rt.unit || '')} response`);
  // The dot was green on 3% uptime. Green from 90%, amber from 50%, red below.
  const u = up ? Number(up.value) : NaN;
  const tone = !Number.isFinite(u) ? '' : u >= 90 ? '' : u >= 50 ? ' rgc-warn' : ' rgc-down';
  return bits.length ? `<li class="rgc-rep${tone}" title="Read from the ERC-8004 ReputationRegistry; the window and who measured it are under the fold">${bits.join(' &middot; ')}</li>` : '';
};

const REPUTATION_ADDR = '0x8004BAa17C55a88189AE136b182e5fdA19dE9b63';
// How old each kind of evidence on the cards is, said once per category:
// the dates lived only in tooltips, which a phone never shows (2026-10-09).
const dayOf = (t) => { const d = t ? new Date(t) : null; return d && !Number.isNaN(+d) ? `${d.getUTCDate()} ${'Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split(' ')[d.getUTCMonth()]}` : ''; };
// Whole days from a delivery (job submitted_at, unix seconds; milliseconds
// accepted too) to the job scan that read it. No delivery sorts last.
const JOBS_AT = Date.parse(jobCensus?.measuredAt || '') || Date.parse(state.updatedAt || '') || 0;
const tsMs = (t) => { const n = Number(t); return Number.isFinite(n) && n > 0 ? (n < 1e12 ? n * 1000 : n) : 0; };
const daysSince = (t) => { const ms = tsMs(t); return ms ? Math.max(0, Math.floor((JOBS_AT - ms) / 86400000)) : 1e9; };
const EVIDENCE_DATES = [
  hireConfirm?.measured_at && `quotes ${dayOf(hireConfirm.measured_at)}`,
  jobCensus?.measuredAt && `jobs ${dayOf(jobCensus.measuredAt)}`,
  reputation?.measured_at && `uptime ${dayOf(reputation.measured_at)}`,
].filter(Boolean).join(' &middot; ');

// A HOST IS NOT ALWAYS A FLEET (2026-10-04). Agents whose category is only
// derived from their words are shown collapsed per operator, which is right
// for clone fleets ("Grid Agent 1…9 by 4LPHA"). marque.trade hosts six
// DIFFERENT agents — Bound, Lattice, Sluicegate, Keel, … — and the collapsed
// row took the first one's name ("Bound", no category), so all six vanished
// from the page, Keel's hire button with them. A host whose agents all carry
// different names once digits are stripped, and no more than eight of them,
// is a set of distinct agents: each is listed on its own.
const hostOf = (a) => { try { return new URL((a.endpoints || [])[0]).host; } catch { return ''; } };
const distinctHosts = (() => {
  const byHost = new Map();
  for (const a of directory) { const h = hostOf(a); if (!h) continue; if (!byHost.has(h)) byHost.set(h, []); byHost.get(h).push(String(a.name || '').toLowerCase().replace(/\d+/g, '').replace(/\s+/g, ' ').trim()); }
  const out = new Set();
  for (const [h, names] of byHost) if (names.length > 1 && names.length <= 8 && new Set(names).size === names.length) out.add(h);
  return out;
})();

// THE EVIDENCE SCORE ORDERS THE CATEGORY, OURS INCLUDED (operator, 2026-11-01: "plaza reihenfolge nach score"). It replaces
// the 2026-09-08 rule that ours close a category: "Best evidence: Keel" (93) stood above our 96, the same page and
// /chart/rank disagreed. The score is one sum for every agent and cannot be bought. No answer from /chart/rank: the
// evidence order below stands alone and ours close the category, as before.
const scoreOf = {};
await Promise.all(CATEGORIES.map(async (c) => {
  const j = await fetchJson(`${AGENT_ORIGIN}/chart/rank?category=${c.id}&limit=200`);
  for (const a of j?.agents || []) scoreOf[`${c.id}:${a.id}`] = a.score;
}));
const rowScore = (r, cat) => (r.agentId ? scoreOf[`${cat}:${r.agentId}`] ?? -1 : -1);
const categorised = CATEGORIES.map((cat) => {
  const rows = [];
  const seenOperator = new Set();
  const attrsFor = (id) => (ownAgents.find((x) => x.id === id)?.attributes) || [];

  for (const a of directory) {
    const own = distinctHosts.has(hostOf(a));
    const hit = classifyAgent({ ...a, attributes: attrsFor(a.id) }, null, { withWeak: true })
      .find((m) => m.category === cat.id && (m.source !== 'derived' || own));
    if (!hit) continue;
    let host = '';
    try { host = new URL((a.endpoints || [])[0]).host; } catch { /* no endpoint */ }
    rows.push({
      label: a.name || `#${a.id}`, sub: host, instances: 1, hit,
      employment: employmentOf([a.id]),
      ours: ownAgents.some((x) => x.id === a.id),
      tele: teleKey(a.id, host),
      agentId: a.id,
      speaks: a.speaks || [],
      description: a.description || null,
      capabilities: capsOf(a),
      seed: a.seed || null,
      example: a.example || null,
    });
  }
  const claimed = new Set(rows.map((r) => r.label));

  for (const o of operators) {
    if (distinctHosts.has(o.operator)) continue; // its agents are listed one by one above
    const hit = classifyAgent({
      name: o.name || o.operator, description: o.description,
      tools: o.tools, skills: o.skills, declared_services: o.declared_services,
      quoted_for: [...new Set(directory.filter((d) => (o.ids || []).includes(d.id)).flatMap((d) => d.quoted_for || []))],
    }, null, { withWeak: true }).find((m) => m.category === cat.id);
    if (hit && hit.source !== 'derived') continue;
    if (seenOperator.has(o.operator) || claimed.has(o.name)) continue;
    // A FLEET IS FILED BY WHAT ITS AGENTS DO, NOT ONLY BY ITS FIRST ONE (2026-11-02). A collapsed host is read as one row with
    // the text of its best id, so the Lending Agents on 4lpha.tech and Sentinels Health Guard, on a host shared by nine ids,
    // were in /find for health factor and nowhere on this page. An agent that names the job outright brings its host in
    // once, as itself; a loose word does not.
    if (!hit) {
      const members = directory.filter((d) => (o.ids || []).includes(d.id) || hostOf(d) === o.operator)
        .filter((d) => classifyAgent({ ...d, attributes: attrsFor(d.id) }, null, { withWeak: true }).some((m) => m.category === cat.id && m.source === 'derived' && !m.weak));
      const m = members[0];
      if (!m || claimed.has(m.name)) continue;
      seenOperator.add(o.operator);
      rows.push({
        label: m.name || `#${m.id}`, sub: o.operator, instances: members.length,
        hit: classifyAgent({ ...m, attributes: attrsFor(m.id) }, null, { withWeak: true }).find((x) => x.category === cat.id),
        employment: employmentOf(members.map((x) => x.id)),
        ours: ownAgents.some((x) => x.id === m.id),
        tele: teleKey(m.id, o.operator),
        agentId: m.id,
        speaks: m.speaks || [],
        description: m.description || null,
        capabilities: capsOf(m),
      });
      continue;
    }
    seenOperator.add(o.operator);
    rows.push({
      label: o.name || o.operator, sub: o.operator, instances: o.instances || 1, hit,
      employment: employmentOf(o.ids || []),
      ours: (o.ids || []).some((id) => ownAgents.some((x) => x.id === id)),
      tele: teleKey(null, o.operator),
      // A collapsed operator row stands for several ids. Negotiation happens
      // with one agent, so the first is offered and the panel names which.
      agentId: o.best_id ?? (o.ids || [])[0] ?? null,
      speaks: o.speaks || [],
      description: o.description || null,
      capabilities: capsOf(o),
    });
  }

  // ORDERED BY EVIDENCE, NOT BY OWNERSHIP.
  //
  // The old order led with how an agent was categorised, and every agent we
  // run declares its own category on-chain while most strangers are matched
  // from their text. The effect was that all four sections opened with a row
  // of ours — which reads as a marketplace preferring its operator, and buries
  // the row in the section with the longest paid history.
  //
  // What decides the order now is checkable from the page itself: agents that
  // returned a price when they were asked come first, because those are the
  // ones where the next click leads somewhere; then jobs released, then jobs
  // funded, which is the one reputation signal on this chain nobody can write
  // about themselves. How we categorised it is only a tiebreak.
  //
  // OURS LAST among rows without a score (operator's decision, 2026-09-08; the score leads since 2026-11-01). With
  // evidence alone, three of the four categories still opened with an agent
  // we run, because ours are the ones with paid history — and a judge reads
  // a marketplace whose first row is its operator as self-preference, however
  // the row got there. So the other operators' agents come first, ordered by
  // evidence among themselves, and ours close the category, ordered the same
  // way. Where a category has no stranger that quotes, the first click now
  // leads to one that does not — the cold-start check says so when it does.
  // Three answers since 2026-10-09: a price, an answer that wants structured
  // input, no answer. A row nobody asked ranks with the ones that did not answer.
  const answers = (r) => QUOTE_RANK[quoteState(r.agentId ? quoteOf(r.agentId, cat.id) : null)] ?? 2;
  const rank = { declared: 0, registered: 1, derived: 2 };
  // Evidence the ranking used to skip (2026-10-09): two category leaders
  // were up 3% of the time, four sibling agents ranked on one provider's
  // shared hire count, and an agent paid by nine buyers sat behind one paid
  // by a single buyer. Now: a measured uptime under 50% sinks below the
  // living, paid-out work from two or more paying buyers comes before paid-out
  // work from one, and a count shared by N agents weighs 1/N for each.
  const down = (r) => { const u = r.agentId ? uptimeOf(r.agentId) : null; return u != null && u < 50 ? 1 : 0; };
  const share = (r) => Math.max(1, providerAgentCount.get(r.employment?.address) || 1);
  const market = (r) => ((r.employment?.completed_outside || 0) > 0 && (r.employment?.outside_buyers || 0) >= 2 ? 0 : 1);
  rows.sort((a, b) => (rowScore(b, cat.id) - rowScore(a, cat.id))
    || (a.ours === b.ours ? 0 : a.ours ? 1 : -1)
    || (answers(a) - answers(b))
    || (down(a) - down(b))
    || (market(a) - market(b))
    || ((b.employment?.completed || 0) / share(b) - (a.employment?.completed || 0) / share(a))
    // after paid-out, the more recent delivery (2026-10-09), in whole days so
    // two deliveries an hour apart still fall through to the hire count
    || (daysSince(a.employment?.last_submission) - daysSince(b.employment?.last_submission))
    || ((b.employment?.funded || 0) - (a.employment?.funded || 0))
    || (rank[a.hit.source] - rank[b.hit.source])
    || (b.instances - a.instances));
  // POSSIBLY RELATED (2026-10-09): rows filed on one loose word alone (see
  // classifyAgent) leave the list and sit folded under it, cards intact, so
  // a seller that can be hired still can be — and the next quote run still
  // asks it, which is how one of them earns its way back.
  const maybe = rows.filter((r) => r.hit.weak);
  return { cat, rows: rows.filter((r) => !r.hit.weak), maybe };
});

if (reputation) {
  fs.writeFileSync(path.join(ROOT, 'dashboard', 'api-reputation.json'), JSON.stringify({
    what_this_is: reputation.what_this_is,
    contract: reputation.contract,
    identity_registry: reputation.identity_registry,
    chain: reputation.chain,
    measured_at: reputation.measured_at,
    population: reputation.population,
    rated: reputation.rated,
    raters: reputation.raters,
    how_to_read_it: 'tag1 is the metric and tag2 the window it covers. value carries its own decimals: 10000 at 2 decimals under "uptime" is 100.00 percent. Values under different tags are different units and are never combined. `latest` holds one entry per rater per tag, because a feedback index is per client and index 2 from one rater is not newer than index 1 from another.',
  our_rater: OUR_RATER || null,
    agents: (reputation.agents || []).filter((a) => a.latest).map((a) => ({
      id: a.id, name: a.name, raters: (a.clients || []).length, latest: a.latest,
      rated_by_this_marketplace: (a.clients || []).some(isOurs),
    })),
  }, null, 2) + '\n');
}

// ONE AGENT, ONE CARD.
//
// This was a three-column table — "Agent or operator", "How we know",
// "Hireable & history" — and every column was correct. It was also the wrong
// shape for the person it has to convince. A table asks you to hold three
// headers in your head and read across; on a phone it lived in a sideways
// scroll box; and the thing a visitor actually wants to do, hire somebody, was
// the last item in the third column behind two paragraphs of evidence.
//
// A card puts them in the order somebody decides in: who it is, what it does,
// can I hire it and for how much, and only then — behind a fold — how we know
// any of that. The evidence is not reduced by one word. It stops being the
// first thing in the way of the button.
// The amber chip in words that fit the answer: a schema demand is "needs
// structured input"; a missing negotiate skill or a reply without a price is
// not, and saying so would be the kind of rounding this page objects to.
const inputLabel = (q) => {
  const why = String(q?.reason || '');
  if (/requires\s+[A-Z][A-Z0-9_]*_V\d/.test(why)) return 'Answers, needs structured input';
  if (/cannot be funded here/i.test(why)) return 'Answers, prices in another token';
  return 'Answers, no price';
};
// "Quotes or has paid out, or is ours": what stays open on a phone (2026-10-09).
const isProven = (r, cat) => !!(r.ours
  || (r.agentId && quoteOf(r.agentId, cat)?.quotes)
  || (r.employment?.completed || 0) > 0);
const priceOf = (p) => { const m = /^\s*([\d.]+)\s*(.*)$/.exec(String(p || '')); return m ? { n: Number(m[1]), unit: m[2].trim() } : null; };
const numShort = (n) => String(Number(n.toPrecision(3)));

// ONE SENTENCE A VISITOR CAN STOP AT (2026-10-09): the leader of the category
// — the first row in the order below, ours or not — with the facts that
// put it there, then the spread of prices in the category and how many quoted.
// Computed from the same rows the cards are, so it cannot say what they do not.
const leaderLine = (cat, rows) => {
  const lead = rows[0];
  const parts = [];
  if (lead) {
    const q = lead.agentId ? quoteOf(lead.agentId, cat.id) : null;
    const st = quoteState(q);
    const e = rowEmployment(lead);
    const bits = [];
    if (st === 'quotes') bits.push(`quotes ${esc(q.price || 'a price')}`);
    else if (st === 'input') bits.push(esc(inputLabel(q).toLowerCase()));
    else if (st === 'none') bits.push('did not answer when asked');
    if (e && e.funded) {
      bits.push(`${!e.own && (providerAgentCount.get(e.address) || 0) > 1 ? 'its provider ' : ''}hired ${fmt(e.funded_outside)}&times;${e.outside_buyers ? ` by ${fmt(e.outside_buyers)} ${e.outside_buyers === 1 ? 'buyer' : 'buyers'}` : ''}`);
      bits.push(e.completed_outside ? `${fmt(e.completed_outside)} paid out` : 'none paid out yet');
    } else bits.push('never hired');
    parts.push(`<b>Best evidence: ${esc(lead.label)}${lead.ours ? ' (ours)' : ''}</b> &mdash; ${rowScore(lead, cat.id) >= 0 ? `score ${rowScore(lead, cat.id)}, ` : ''}${bits.join(', ')}`);
  } else {
    parts.push('<b>No other operator&rsquo;s agent here yet</b> &mdash; only ours');
  }
  const prices = rows.map((r) => (r.agentId ? quoteOf(r.agentId, cat.id) : null)).filter((q) => q?.quotes).map((q) => priceOf(q.price)).filter(Boolean);
  if (prices.length) {
    const units = new Map();
    for (const p of prices) units.set(p.unit, (units.get(p.unit) || 0) + 1);
    const unit = [...units.entries()].sort((a, b) => b[1] - a[1])[0][0];
    const ns = prices.filter((p) => p.unit === unit).map((p) => p.n).sort((a, b) => a - b);
    const mid = ns.length % 2 ? ns[ns.length >> 1] : (ns[ns.length / 2 - 1] + ns[ns.length / 2]) / 2;
    parts.push(ns.length > 1 && ns[0] !== ns[ns.length - 1]
      ? `prices quoted ${numShort(ns[0])}&ndash;${numShort(ns[ns.length - 1])} ${esc(unit)} (median ${numShort(mid)})`
      : `price quoted ${numShort(ns[0])} ${esc(unit)}`);
  }
  if (hireConfirm) parts.push(`${fmt(prices.length)} of ${fmt(rows.length)} quoted when asked${hireConfirm.measured_at ? ` on ${dayOf(hireConfirm.measured_at)}` : ''}`);
  return `<p class="rg-catlead">${parts.join(' &middot; ')}.</p>`;
};

const categorySections = categorised.map(({ cat, rows, maybe }) => {
  const ids = rows.reduce((n, r) => n + r.instances, 0);
  const card = (r) => {
    const [badge, why] = SOURCE_BADGE[r.hit.source];
    const hireable = canHire(r);
    const q = hireable && r.agentId ? quoteOf(r.agentId, cat.id) : null;
    const qs = quoteState(q);
    const d = describes(r);
    const caps = (r.capabilities || []).slice(0, 6);
    const more = (r.capabilities || []).length - caps.length;

    // WHAT A STRANGER DECIDES ON, in one glance, and what is behind the fold.
    //
    // The first card carried three full sentences before the button: how it
    // quoted, how often it was hired, and its uptime and latency with the
    // window and the rater. Every sentence was true and every sentence was in
    // the way. Four categories of those was nineteen hundred words a visitor
    // scrolled through before reaching the panel that hires anything.
    //
    // So each fact is now one short chip on the card — a tick and a price, a
    // hire count, an uptime — and the full sentence with its reason, window
    // and attesting address moves under the fold with the rest of the
    // evidence. Not one word is dropped; the card stops being a paragraph.
    const chips = [];
    const facts = [];
    if (rowScore(r, cat.id) >= 0) chips.push(`<li title="Evidence score: uptime, paid work delivered, outside buyers, a price when asked. One sum for every agent, ours included">Score <b>${rowScore(r, cat.id)}</b></li>`);
    if (q) {
      chips.push(qs === 'quotes'
        ? `<li class="rgc-yes" title="Answered with a price the last time it was actually asked">Quotes <b>${esc(q.price || 'a price')}</b></li>`
        : qs === 'input'
          ? `<li class="rgc-input" title="Answered the last time it was asked, but not with a price — what it said is under the fold">${esc(inputLabel(q))}</li>`
          : '<li class="rgc-no" title="Did not answer the last time it was asked — the reason is under the fold">Did not answer</li>');
      facts.push(qs === 'quotes'
        ? `<li class="rgc-ok">Answers with a price when asked: <b>${esc(q.price || 'a price')}</b>${q.example_task ? ' &mdash; for a JSON task in its own format, not a sentence; Hire opens with its example filled in' : ''}</li>`
        : qs === 'input'
          ? `<li>Answered when we asked it for a price, without one &mdash; ${esc(q.reason || 'no price')}</li>`
          : `<li class="rgc-bad">Did not answer when we asked it for a price &mdash; ${esc(q.reason || 'no answer')}</li>`);
    }
    if (r.employment) {
      // An agent with its own job record is counted from it (2026-11-01): 302257 and 304493 moved to wallets of their own
      // on 21.10., their history stayed on the old address, and our best agent read "none paid out yet".
      const e = rowEmployment(r);
      // Employment is counted per provider address. Five of our agents sell
      // from one address, and each card said "Hired 2×" as if each had been;
      // when the address hosts more than one agent, the chip says whose count
      // it is.
      const shared = e.own ? 1 : providerAgentCount.get(e.address) || 0;
      const who = shared > 1 ? 'Its provider hired' : 'Hired';
      if (e.funded) {
        // last delivery (2026-10-09): the newest submission on the kernel for
        // this provider, counted in days at the job scan and recounted in the
        // visitor's browser (data-t, unix seconds) so it does not age on the page
        const lastMs = tsMs(e.last_submission);
        const ago = lastMs ? daysSince(e.last_submission) : null;
        const agoText = (n) => (n === 0 ? 'today' : n === 1 ? '1 day ago' : `${fmt(n)} days ago`);
        chips.push(`<li title="Jobs funded through the ERC-8183 escrow${shared > 1 ? `, counted for the provider address, which ${fmt(shared)} agents on this page share` : ''}, and how many of those paid out${lastMs ? `; last delivery submitted ${new Date(lastMs).toISOString().slice(0, 10)}` : ''}">${who} ${fmt(e.funded_outside)}&times; &middot; ${e.completed_outside ? `${fmt(e.completed_outside)} paid out` : 'none paid out yet'}${e.outside_buyers ? ` &middot; ${fmt(e.outside_buyers)} ${e.outside_buyers === 1 ? 'buyer' : 'buyers'}` : ''}${e.funded_by_us ? ` &middot; +${fmt(e.funded_by_us)} by our wallets` : ''}${e.own?.delivery_rate_pct != null ? ` &middot; ${e.own.delivery_rate_pct}% delivered` : ''}${e.own?.expired ? ` &middot; ${fmt(e.own.expired)} expired` : ''}${lastMs ? ` &middot; last delivery <span class="rg-ago" data-t="${Math.floor(lastMs / 1000)}">${agoText(ago)}</span>` : ''}</li>`);
        facts.push(`<li>${shared > 1 ? `Its provider address, shared by ${fmt(shared)} agents here, was hired` : 'Hired'} ${fmt(e.funded_outside)} ${e.funded_outside === 1 ? 'time' : 'times'} by others through the escrow${e.completed_outside ? `, ${fmt(e.completed_outside)} paid out` : ', none paid out yet'}${e.funded_by_us ? `, and ${fmt(e.funded_by_us)} more by our own wallets` : ''}${e.submitted_not_released ? `; ${fmt(e.submitted_not_released)} more delivered and waiting out the dispute window` : ''}</li>`);
      } else {
        chips.push('<li>Never hired</li>');
        facts.push('<li>Never been hired through the escrow</li>');
      }
    } else if (hireable) {
      chips.push('<li>Never hired</li>');
      facts.push('<li>Never been hired through the escrow</li>');
    }
    const repShort = r.agentId ? repChip(r.agentId) : '';
    if (repShort) chips.push(repShort);
    const rep = r.agentId ? ratingLine(r.agentId) : '';

    return `        <article class="rgc${r.ours ? ' rg-ours' : ''}"${r.tele ? ` data-tele="${esc(r.tele)}"` : ''}>
          <div class="rgc-h">
            <div class="rgc-id">
              ${r.agentId ? `<a class="rg-chart" href="/agent/${r.agentId}" title="Its chart: daily pulse, paid work, evidence score"><b>${esc(r.label)}</b></a>` : `<b>${esc(r.label)}</b>`}${r.ours ? ' <span class="rg-t rg-x4">ours</span>' : ''}
              <div class="rg-note">${esc(r.sub)}${r.instances > 1 ? ` &middot; ${r.instances} registry ids, one deployment` : ''}</div>
            </div>
            ${hireable && r.agentId
    ? (qs === 'none'
      // Did not answer: the button stays (an endpoint can come back) but it
      // does not promise anything — muted, and named for what it is.
      ? `<button class="rg-hirebtn rg-hire-muted" data-hire="${r.agentId}" data-name="${esc(r.label)}" data-cat="${cat.id}"${r.seed ? ` data-seed="${esc(r.seed)}"` : ''} title="Did not answer when asked on ${esc(String(hireConfirm?.measured_at || '').slice(0, 10))}; the panel asks again">Try anyway &rarr;</button>`
      : `<button class="rg-hirebtn" data-hire="${r.agentId}" data-name="${esc(r.label)}" data-cat="${cat.id}"${(r.seed || q?.example_task) ? ` data-seed="${esc(r.seed || q.example_task)}"` : ''} title="${q && q.quotes && q.price ? `Quoted ${esc(q.price)} when asked on ${esc(String(hireConfirm?.measured_at || '').slice(0, 10))}; the panel asks again for today's price` : 'The panel asks the agent for its price'}">Hire${q && q.quotes && q.price ? ` &mdash; last quote ${esc(q.price)}` : ''} &rarr;</button>`)
    : '<span class="rgc-nohire">Not hireable</span>'}
          </div>
          <p class="rgc-what${d.weak && !caps.length ? ' rg-weak' : ''}"${d.full ? ` title="${esc(d.full)}"` : ''}>${d.text ? esc(d.text) : caps.length ? esc('From its skills: ' + caps.slice(0, 3).map((c) => c.name).join(', ') + '.') : esc(d.why)}</p>
          ${chips.length ? `<ul class="rgc-strip">${chips.join('')}</ul>` : ''}
          ${r.tele ? '<div class="rg-live" hidden></div>' : ''}
          ${r.example ? exampleBlock(r.example) : ''}
          <details class="rgc-ev">
            <summary>Track record, and how we know this <span class="rg-t rg-${r.hit.source}" title="${esc(why)}">${badge}</span></summary>
            ${facts.length ? `<ul class="rgc-facts">${facts.join('')}</ul>` : ''}
            ${rep}
            <div class="rg-note">${esc(r.hit.detail)}</div>
            ${caps.length ? `<div class="rg-caps">${caps.map((c) => `<code${c.why ? ` title="${esc(clean(c.why)).slice(0, 300)}"` : ''}>${esc(c.name)}</code>`).join(' ')}${more > 0 ? ` <span class="rg-more">+${more}</span>` : ''}</div>` : ''}
          </details>
        </article>`;
  };
  // A PHONE SCROLLS PAST EVERY CARD (2026-10-09): the open list is what has
  // proven itself — quoted, or paid out — and ours; the rest of the category
  // is one tap away, in the same order, cards and buttons unchanged.
  // ours stand where their score puts them (2026-11-01); only a row without one still closes the category
  const scored = rows.some((r) => rowScore(r, cat.id) >= 0);
  const open = rows.filter((r) => (scored || !r.ours) && isProven(r, cat.id));
  const rest = rows.filter((r) => !r.ours && !isProven(r, cat.id));
  const ourRows = scored ? [] : rows.filter((r) => r.ours);
  const body = open.map(card).join(NL);
  const oursBlock = ourRows.length ? `
      <div class="rgc-list rgc-ours" style="margin-top:12px">
${ourRows.map(card).join(NL)}
      </div>` : '';
  const restBlock = rest.length ? `
      <details class="rgc-more">
        <summary>${fmt(rest.length)} more, unproven <span class="rg-note">&mdash; never quoted and never paid out</span></summary>
        <div class="rgc-list">
${rest.map(card).join(NL)}
        </div>
      </details>` : '';
  const maybeBlock = (maybe || []).length ? `
      <details class="rgc-maybe">
        <summary>Possibly related: ${maybe.map((r) => esc(r.label)).join(', ')} <span class="rg-note">&mdash; matched on one loose word, not counted above</span></summary>
        <div class="rgc-list">
${maybe.map(card).join(NL)}
        </div>
      </details>` : '';

  return `    <div class="rg-box" id="cat-${cat.id}">
      <h2>${esc(cat.label)}</h2>
      <p class="rg-sub">${esc(cat.blurb)}</p>
      ${rows.length ? leaderLine(cat, rows) : ''}
      <p class="rg-note" style="margin:-8px 0 16px"><b>${fmt(rows.length)} ${rows.length === 1 ? 'entry' : 'entries'}</b>${EVIDENCE_DATES ? ` <span class="rg-dates">(${EVIDENCE_DATES})</span>` : ''}${ids > rows.length ? ` (${fmt(ids)} registry ids, fleets shown as one)` : ''}.${rows.length > 1 ? ` Ordered by evidence score, ours included: one sum for every agent, not for sale (<a href="https://agent.brainonbnb.com/chart/rank?category=${cat.id}">the ranking</a>). Without a score, priced when asked first, then answers without a price, then no answer; measured up less than half the time last; then paid out by several buyers, then paid out, then the latest delivery, then hired.` : ''}${rows.length <= 2 ? ' That is the whole category on BNB Chain — the depth this is judged on does not exist yet, and padding it with keyword matches would only hide that.' : ''}</p>
      ${rows.length ? `<div class="rgc-list">
${body}
      </div>${restBlock}${oursBlock}` : '<p class="rg-note">Nothing on this chain exposes this yet.</p>'}${maybeBlock}
      <p class="rg-note" style="margin-top:12px">Ask the broker directly: <code>GET /find?category=${cat.id}</code> at <a href="https://agent.brainonbnb.com/find?category=${cat.id}&amp;limit=10">agent.brainonbnb.com</a> — every result carries how it was categorised.</p>
    </div>`;
}).join(NL);

// What the chips add up to, said next to the headline when it differs from the
// distinct-agent count (2026-10-12: 26 above, 8+6+8+5 = 27 below, unexplained).
const chipQuoting = categorised.reduce((n, { cat, rows }) => n + rows.filter((r) => canHire(r) && r.agentId && quoteOf(r.agentId, cat.id)?.quotes).length, 0);

// The picker at the top of the page. Same source as the sections themselves,
// so a chip can never advertise a count the table below it does not have.
const categoryChips = categorised.map(({ cat, rows }) => {
  const hireable = rows.filter((r) => canHire(r) && r.agentId).length;
  // The chip advertises what will actually happen, not how many buttons exist:
  // a picker promising four and delivering two is the failure mode this whole
  // page was built to point out in other people's numbers.
  const quoting = rows.filter((r) => canHire(r) && r.agentId && quoteOf(r.agentId, cat.id)?.quotes).length;
  return `<a class="rg-chip" href="#cat-${cat.id}"><span>${esc(cat.label)}</span>`
    + `<em>${fmt(rows.length)}${hireable ? ` &middot; ${hireConfirm ? fmt(quoting) + ' quote back' : fmt(hireable) + ' hireable'}` : ''}</em></a>`;
}).join('');

// What the homepage prints on its marketplace card. Written here rather than
// typed there, so the two can never drift apart.
//
// The exact rows that render a Hire button, kept as a list rather than a count.
// Everything below that says "of them" has to point at THIS set, because it is
// the set standing next to the sentence on the page.
// The folded "possibly related" cards carry buttons too, so they count here.
const hireableRows = categorised.flatMap(({ rows, maybe }) => [...rows, ...maybe].filter((r) => canHire(r) && r.agentId));
// Distinct agents, not rows: an agent listed under two categories carries two
// buttons and is one agent to hire (26 rows were 24 agents on 2026-09-18).
api.hireable_here = new Set(hireableRows.map((r) => String(r.agentId))).size;
api.hire_buttons = hireableRows.length;
api.categories = CATEGORIES.map((c) => c.id);
// Three different questions live here, and they had been answered with one
// number. Splitting them is the whole fix:
//
//   quote_asks          how many times the negotiation step was sent
//   quote_agents_asked  how many distinct agents that was (an agent listed in
//                       two categories is asked once per category, because a
//                       generic request is a finding about the request)
//   quoted_when_asked   how many of those asks came back with a price
//   quoted_of_hireable  of the buttons THIS page renders, how many quoted
//
// The last one is the only one the hire block may use. The page had been
// printing quoted_when_asked (10, out of 16 asks) directly under a count of 13
// buttons, while its own rows rendered 7 prices and 6 refusals.
if (hireConfirm) {
  const asks = hireConfirm.agents || [];
  api.quote_asks = asks.length;
  api.quote_agents_asked = new Set(asks.map((a) => String(a.id))).size;
  api.quoted_when_asked = asks.filter((a) => a.quotes).length;
  api.quoted_of_hireable = new Set(hireableRows.filter((r) => quoteOf(r.agentId)?.quotes).map((r) => String(r.agentId))).size;
  api.quotes_measured_at = hireConfirm.measured_at || null;
}
fs.writeFileSync(path.join(ROOT, 'dashboard', 'api-registry.json'), JSON.stringify(api, null, 2) + '\n');

// THE PLAZA'S VIEW OF EACH AGENT, for its chart (agent chart phase 2, 2026-10-12): which categories it is filed in and
// how (declared / on-chain / matched, weak = "possibly related"), whether it carries a Hire button here and what it
// quoted when last asked. Read by agent.brainonbnb.com/chart/<id>; the same rows the page renders.
{
  const plaza = {};
  for (const { cat, rows, maybe } of categorised) {
    for (const r of [...rows, ...(maybe || [])]) {
      if (!r.agentId) continue;
      const p = plaza[r.agentId] || (plaza[r.agentId] = { categories: [], hire: false, quote: null, ours: !!r.ours });
      p.categories.push({ id: cat.id, label: cat.label, how: r.hit?.source || null, weak: !!r.hit?.weak, evidence: r.hit?.detail || null });
      if (canHire(r)) p.hire = true;
      const q = quoteOf(r.agentId, cat.id);
      if (q && (q.quotes || !p.quote)) p.quote = { quotes: !!q.quotes, price: q.price || null, reason: q.quotes ? null : (q.reason || null), at: hireConfirm?.measured_at || null };
    }
  }
  fs.writeFileSync(path.join(ROOT, 'dashboard', 'api-plaza-index.json'), JSON.stringify({ what_this_is: 'Brain Plaza\'s view of each agent it lists: categories (and how each was decided), Hire button, last quote.', measured_at: api.measured_at || null, agents: plaza }));
}

// The input for scripts/erc8004-hire-confirm.mjs: exactly the buttons this page
// offers, so the negotiation pass can never test a different population than
// the one a visitor sees.
fs.writeFileSync(path.join(DIR, 'hireable.json'), JSON.stringify({
  measured_at: api.measured_at,
  // The folded "possibly related" rows are asked as well: a price for this
  // category's task is how one earns its way back into the list (2026-10-09).
  agents: categorised.flatMap(({ cat, rows, maybe }) => [...rows, ...maybe]
    .filter((r) => canHire(r) && r.agentId)
    // The seed is the sentence the button puts into the panel. A row that has
    // one is asked with it, so the pass tests the button and not a paraphrase.
    .map((r) => ({ id: r.agentId, label: r.label, category: cat.id, ours: !!r.ours, ...(r.seed ? { seed: r.seed } : {}) }))),
}, null, 2) + '\n');

// ---------------------------------------------------------------------------
// WHAT 786 ANSWERING AGENTS ACTUALLY ARE
//
// Every count in this space is a count of registry ids, and a registry id is
// the cheapest thing on the chain. The number that decides whether an agent
// economy exists is how many distinct things are running, and that is a
// different number by a factor of eight.
//
// Nothing here is asserted. Each note below is derived from what was measured:
// how many ids sit behind one host, how many names they use, how many distinct
// URLs they name, and whether their tool lists are identical. A deployment is
// called a fleet because its tool signature repeats, not because it looked
// suspicious.
const deployments = (() => {
  const byHost = new Map();
  for (const a of directory) {
    let host = '';
    try { host = new URL((a.endpoints || [])[0]).host.toLowerCase(); } catch { continue; }
    if (!byHost.has(host)) byHost.set(host, []);
    byHost.get(host).push(a);
  }

  const toolSig = (a) => (a.tools || [])
    .map((t) => String((t && (t.name || t.id)) || t || '').toLowerCase())
    .filter(Boolean).sort().join('|');

  const rows = [...byHost.entries()].map(([host, list]) => {
    const names = new Set(list.map((a) => a.name).filter(Boolean));
    const urls = new Set(list.flatMap((a) => a.endpoints || []));
    // The biggest group of ids on this host whose tool lists are character for
    // character the same.
    const sigs = new Map();
    for (const a of list) {
      const sg = toolSig(a);
      if (!sg) continue;
      sigs.set(sg, (sigs.get(sg) || 0) + 1);
    }
    let topSig = null, topN = 0;
    for (const [sg, n] of sigs) if (n > topN) { topN = n; topSig = sg; }
    const speaks = new Set(list.flatMap((a) => a.speaks || []));

    const notes = [];
    if (topN > 1) {
      notes.push(`${fmt(topN)} of them expose a character-for-character identical tool list: ${topSig.split('|').slice(0, 5).join(', ')}`);
    }
    // The most-repeated URL, not "are they all identical". Requiring identity
    // missed the sharpest case on the chain: 45 of the 46 ids on github.com
    // name the very same page, github.com/agntcy/oasf — a specification
    // repository. One of the 46 names something else, and that lone exception
    // was enough to hide the other 45.
    // Counted per AGENT, not per endpoint entry. An agent may name the same
    // URL twice, or two URLs on one host, and counting entries produced the
    // line "4 of the 2 name the very same URL" — a number larger than the set
    // it came from, which is exactly the kind of arithmetic this page exists
    // to catch in other people's data.
    const urlCount = new Map();
    for (const a of list) {
      for (const e of new Set(a.endpoints || [])) urlCount.set(e, (urlCount.get(e) || 0) + 1);
    }
    let topUrl = null, topUrlN = 0;
    for (const [u, n] of urlCount) if (n > topUrlN) { topUrlN = n; topUrl = u; }
    if (topUrlN > 1) {
      notes.push(topUrlN === list.length
        ? `all ${fmt(list.length)} registrations name the same URL, ${topUrl}`
        : `${fmt(topUrlN)} of the ${fmt(list.length)} name the very same URL, ${topUrl}`);
    }
    // A host that answers but speaks neither protocol is a web server, and a
    // registration pointing at one is a link, not an agent. Said as a
    // measurement rather than an accusation: it may well be documentation.
    if (!speaks.has('mcp') && !speaks.has('a2a') && list.length > 1) {
      notes.push('answers as a web page — no MCP, no agent card');
    }
    if (names.size > 1 && names.size >= list.length * 0.9 && list.length > 5) {
      notes.push(`${fmt(names.size)} different names for one deployment`);
    }

    return { host, ids: list.length, names: names.size, urls: urls.size, topN, notes };
  }).sort((a, b) => b.ids - a.ids);

  const total = rows.reduce((n, r) => n + r.ids, 0);
  const top5 = rows.slice(0, 5).reduce((n, r) => n + r.ids, 0);
  const singles = rows.filter((r) => r.ids === 1).length;
  const biggestFleet = rows.reduce((best, r) => (r.topN > (best?.topN || 0) ? r : best), null);

  // This page prints two counts of "who is behind the 796" — hosts here, and
  // operators in the headline — and they are not the same number. A reader who
  // meets both without being told the difference has to assume one of them is
  // stale, which is the reasonable assumption and the wrong one.
  //
  // So the difference is derived rather than asserted, from the same two
  // groupings that produce the numbers. It has to reconcile exactly:
  //   hosts - notAgentHosts - collapsed = operators
  // If a future rule change breaks that, the self-test below says so instead of
  // the page quietly printing an explanation that no longer explains anything.
  const known = new Set(operators.map((o) => o.operator));
  const notAgentHosts = rows.filter((r) => !known.has(operatorOf(byHost.get(r.host)[0]))).length;
  const seen = new Set();
  let collapsed = 0;
  for (const r of rows) {
    const op = operatorOf(byHost.get(r.host)[0]);
    if (!known.has(op)) continue;
    if (seen.has(op)) collapsed++;
    else seen.add(op);
  }
  return { rows, total, top5, singles, biggestFleet, hosts: rows.length, notAgentHosts, collapsed };
})();

// The reconciliation is arithmetic, so it can be checked rather than trusted.
// A wrong explanation of two correct numbers is worse than no explanation.
if (deployments.hosts - deployments.notAgentHosts - deployments.collapsed !== operators.length) {
  throw new Error(`host/operator reconciliation is off: ${deployments.hosts} hosts - ${deployments.notAgentHosts}`
    + ` non-agent - ${deployments.collapsed} collapsed != ${operators.length} operators`);
}

const liveRows = operators
  .slice()
  .slice(0, 60)
  .map((o) => {
    const tags = [
      o.speaks.includes('mcp') ? `<span class="rg-t rg-mcp">MCP &middot; ${o.tools?.length ?? '?'} tool${o.tools?.length === 1 ? '' : 's'}</span>` : '',
      o.speaks.includes('a2a') ? '<span class="rg-t rg-a2a">agent card</span>' : '',
      o.speaks.includes('x402') ? '<span class="rg-t rg-x4">x402</span>' : '',
      ...(o.trust_models || []).slice(0, 2).map((t) => `<span class="rg-t rg-tr">${esc(t)}</span>`),
    ].filter(Boolean).join('');

    const caps = o.tools?.length
      ? `<div class="rg-caps">${o.tools.slice(0, 8).map((t) => `<code title="${esc(t.description)}">${esc(t.name)}</code>`).join(' ')}${o.tools.length > 8 ? ` <span class="rg-more">+${o.tools.length - 8}</span>` : ''}</div>`
      : o.skills?.length
        ? `<div class="rg-caps">${o.skills.slice(0, 8).map((x) => `<code>${esc(x)}</code>`).join(' ')}</div>`
        : '';

    // Logos are third-party URLs on hosts we do not control: lazy, sized, and
    // they remove themselves rather than leaving a broken-image box.
    const logo = o.image
      ? `<img class="rg-logo" src="${esc(o.image)}" alt="" loading="lazy" decoding="async" width="34" height="34" onerror="this.remove()">`
      : '<span class="rg-logo rg-logo-none" aria-hidden="true"></span>';

    const desc = o.description
      ? `<div class="rg-desc">${esc(o.description.slice(0, 190))}${o.description.length > 190 ? '&hellip;' : ''}</div>`
      : '';

    // How many registry ids one operator runs is worth showing, because it is
    // the difference between a service and a fleet of identical clones — and
    // because a reader counting rows would otherwise be counting the wrong thing.
    const fleet = o.instances > 1
      ? `<span class="rg-fleet">${fmt(o.instances)} ids${o.distinct_capabilities > 1 ? `, ${o.distinct_capabilities} variants` : ', identical'}</span>`
      : '';

    return `<tr>
      <td class="rg-id">${esc(o.operator)}${fleet}</td>
      <td class="rg-agent">
        <div class="rg-head">${logo}<div class="rg-nm"><b>${esc(o.name) || '<i>unnamed</i>'}</b>${tags}</div></div>
        ${desc}${caps}
      </td>
      <td class="rg-ep"><code title="${esc((o.endpoints || [])[0] || '')}">${esc(((o.endpoints || [])[0] || '').replace(/^https?:\/\//i, '').replace(/\/$/, '').slice(0, 46))}</code>${(o.ids || [])[0] ? ` <a href="https://8004scan.io/agents/bsc/${esc(String(o.ids[0]))}" target="_blank" rel="noopener nofollow">8004scan</a>` : ''}</td>
    </tr>`;
  }).join('');

const reach = census?.endpoints;

// The page states a reachable count and then lists the agents behind it. If
// those two come from different runs, the page contradicts itself — which is
// fatal for the one thing it is for. Publishing stops rather than shipping it.
if (reach && reach.reachable > 0 && reachable.length === 0) {
  console.error(`
Refusing to publish: census.json reports ${reach.reachable} reachable agents but reachable.jsonl is empty.`);
  console.error(`Run: node scripts/erc8004-probe.mjs
`);
  process.exit(1);
}
if (reach && reachable.length && Math.abs(reach.reachable - reachable.length) > reach.reachable * 0.02) {
  console.error(`
Refusing to publish: census says ${reach.reachable} reachable, the list holds ${reachable.length}. These are from different runs.`);
  console.error(`Run: node scripts/erc8004-probe.mjs
`);
  process.exit(1);
}

// The page. Built on the same furniture as every other page on the site —
// nav, blk-head section, footer, shared stylesheet — because a page that looks
// like it was bolted on reads like it was bolted on. The only bespoke CSS here
// is for the funnel and the agent table, which nothing else on the site needs.
const page = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Brain Plaza — the AI agents on BNB Chain that answer</title>
<meta name="description" content="Brain Plaza reads every ERC-8004 agent on BNB Chain and contacts every endpoint they name. Who is actually running, what they can do, and how to reach them.">
<meta property="og:title" content="Brain Plaza — ${fmt(total)} agents registered on BNB Chain, ${reach ? fmt(reach.reachable) + ' answer · ' + fmt(serving) + ' serve' : 'few answer'}">
<meta property="og:description" content="We read the whole ERC-8004 registry — every id — then contacted every endpoint it named. Full method, full data, checkable.">
<meta property="og:image" content="https://brainonbnb.com/og-banner.png">
<meta property="og:url" content="https://brainonbnb.com/registry">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Brain On BNB AI">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Brain Plaza — ${fmt(total)} agents registered on BNB Chain, ${reach ? fmt(reach.reachable) + ' answer · ' + fmt(serving) + ' serve' : 'few answer'}">
<meta name="twitter:description" content="We read the whole ERC-8004 registry — every id — then contacted every endpoint it named.">
<meta name="twitter:image" content="https://brainonbnb.com/og-banner.png">
<link rel="icon" type="image/png" href="/favicon.png?v=4">
<link rel="shortcut icon" type="image/png" href="/favicon.png?v=4">
<link rel="apple-touch-icon" href="/logo.png?v=4">
<link rel="stylesheet" href="/fonts.css?v=1">
<link rel="stylesheet" href="/styles.css?v=${STYLES_V}">
<link rel="canonical" href="https://brainonbnb.com/registry">
<style>
  /* nav/.nav/.nb live in styles.css, but .back-btn and .brand-link do not —
     they are inline in scanner.html, so every sub-page carries its own copy.
     Without them the browser paints both as default blue links, which is what
     it was doing here. Same values, not similar ones. */
  /* .back-btn / .brand-link and their narrow-screen rules now live in
     styles.css, where every page that uses this header can see them. */


  /* Hero copied from scanner.html's .sc-hero rather than approximated: centred,
     same clamp, same -1px tracking, and the gold gradient on <em> that every
     other headline on this site uses. */
  .rg-hero{padding:8px 0 6px;text-align:center}
  /* BOBAI at work (2026-10-22) */
  .aw-lead{margin:4px 0 0;text-align:center}
  .aw-tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:14px 0}
  .aw-tiles.n3{grid-template-columns:repeat(3,1fr)!important}
  @media(max-width:720px){.aw-tiles{grid-template-columns:1fr 1fr;gap:8px}}
  /* three tiles are three columns (2026-10-26): the board's three stood in a grid of four on an iPad, 2+1 on a Fold */
  .aw-tiles:has(> :nth-child(3):last-child){grid-template-columns:repeat(3,minmax(0,1fr))}
  .aw-box{display:flex;flex-direction:column;gap:14px}
  .aw-sec{display:grid;grid-template-columns:150px 1fr;gap:6px 16px;align-items:start}
  /* 'Show the 8 newest' under its own list, on one line — in the 150 px label column it broke in two (26.10.) */
  @media(min-width:621px){.aw-sec > .pz-more{grid-column:2;justify-self:start;margin:2px 0 4px;white-space:nowrap}}
  @media(max-width:620px){.aw-sec{grid-template-columns:1fr}}
  .aw-k{font:700 11px/1.6 'Space Grotesk',Inter,sans-serif;letter-spacing:.14em;text-transform:uppercase;color:var(--gold)}
  .aw-rows{display:flex;flex-direction:column;gap:6px;min-width:0}
  .aw-row{font-size:.86rem;line-height:1.5;overflow-wrap:anywhere}
  .aw-row b{color:var(--text,#f3efe6)}
  .aw-row .aw-t{color:var(--muted);font-variant-numeric:tabular-nums;margin-right:6px}
  .aw-row .ok{color:#7fd1a3}.aw-row .no{color:#e2a03f}
  .aw-foot{margin:4px 0 0}
  .rg-h1{font-family:'Space Grotesk',sans-serif;font-size:clamp(1.75rem,4.4vw,2.6rem);
    font-weight:700;letter-spacing:-1px;line-height:1.14;margin:0}
  .rg-h1 em{font-style:normal;background:linear-gradient(135deg,var(--gold),var(--gold2));
    background-clip:text;-webkit-background-clip:text;color:transparent}
  .rg-sub2{display:block;margin-top:12px;font-size:.9rem;font-weight:400;letter-spacing:0;
    color:var(--muted);line-height:1.5}
  .rg-fleet{display:block;margin-top:3px;font-size:.66rem;opacity:.75;white-space:nowrap}
  .rg-lead{color:var(--muted);font-size:.85rem;line-height:1.7;margin:14px auto 0;max-width:62ch}
  .rg-when{color:var(--muted);font-size:.72rem;margin:18px auto 0;text-align:center}
  /* Metric tiles use the dashboard's own numbers treatment (.lqm/.lqv/.lql/.lqs
     in styles.css) rather than an approximation of it: same radius, same
     1.85rem Space Grotesk with -1px tracking, same label and caption sizes.
     A page that is nearly the house style reads as a page from somewhere else. */
  /* four figures: a row of four, or two over two (2026-10-26: auto-fit left "995 actually answer" alone on an iPad) */
  .rg-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:26px 0 14px}
  @media(max-width:900px){.rg-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
  /* a phone: the four figures two by two (2026-10-13: one under the other they took a whole screen) */
  @media(max-width:520px){.rg-grid{grid-template-columns:1fr 1fr;gap:8px}.rg-grid .rg-card{padding:12px}.rg-grid .rg-n{font-size:1.45rem}}
  .rg-card{border:1px solid var(--border);border-radius:14px;padding:16px 15px;background:rgba(255,255,255,.02)}
  .rg-n{font-family:'Space Grotesk',system-ui,sans-serif;font-size:1.85rem;font-weight:700;
    letter-spacing:-1px;color:var(--acc,var(--gold));line-height:1.1;font-variant-numeric:tabular-nums}
  .rg-l{font-size:.79rem;font-weight:600;margin-top:4px}
  .rg-s{font-size:.72rem;color:var(--muted);line-height:1.5;margin-top:7px}
  .rg-box{border:1px solid rgba(var(--accs,240,185,11),.16);border-radius:var(--radius,18px);
    padding:22px 20px;margin:14px 0;background:rgba(255,255,255,.02)}
  .rg-box h2{font-size:.95rem;font-weight:600;margin:0 0 4px;letter-spacing:.2px}
  .rg-box > p.rg-sub{color:var(--muted);font-size:.76rem;margin:0 0 18px;line-height:1.55}
  /* A grid item's default min-width is its content, so one unbreakable string
     pushes the whole track wider than the phone. The strings here are not ours:
     a peer agent's failure text reads "PermissionError: /secrets/wallets/0x…"
     in one piece, and at 360px it hung 150px past the edge. We quote other
     people's errors verbatim on purpose, so the layout has to survive them. */
  .rg-step{display:grid;grid-template-columns:minmax(0,1fr);gap:5px;margin-bottom:15px}
  .rg-step > *{min-width:0;overflow-wrap:anywhere}
  /* Same reason, one block up: a 42-character address in running text. */
  .rg-box p.rg-sub code{overflow-wrap:anywhere}
  .rg-top{display:flex;justify-content:space-between;align-items:baseline;gap:12px;flex-wrap:wrap}
  .rg-top b{font-size:.79rem;font-weight:600}
  .rg-top span{font-size:.76rem;color:var(--acc,var(--gold));font-weight:600;
    font-variant-numeric:tabular-nums;white-space:nowrap}
  .rg-bar{height:8px;border-radius:4px;background:rgba(255,255,255,.05);overflow:hidden}
  /* The floor on the width below is a PERCENTAGE, and a percentage of a phone
     is not much: 0.35% of a 312px column is 1.1 pixels, so the bars that matter
     most here — a few hundred answering out of three hundred thousand is genuinely a sliver — rendered
     as an invisible smear exactly where the point was that the number is tiny.
     A pixel minimum keeps "almost nothing" visible as almost nothing. */
  .rg-fill{height:100%;border-radius:4px;min-width:3px;background:linear-gradient(90deg,var(--acc,var(--gold)),rgba(var(--accs,240,185,11),.35))}
  .rg-note{font-size:.72rem;color:var(--muted);line-height:1.5}
  .rg-dates{opacity:.8;white-space:nowrap}.rg-ago{white-space:nowrap;font-variant-numeric:tabular-nums}
  /* The live line. Deliberately not styled like the notes above it: those are
     facts from the last full scan, this one is seconds old and says so. */
  .rg-live{margin-top:6px;font-size:.72rem;line-height:1.5;color:var(--fg)}
  .rg-live .rg-dot{display:inline-block;width:6px;height:6px;border-radius:50%;margin-right:6px;vertical-align:middle;background:#2ecc71}
  .rg-live.rg-dark .rg-dot{background:var(--muted)}
  .rg-live.rg-dark{color:var(--muted)}
  .rg-live .rg-age{color:var(--muted)}
  .rg-live .rg-mismatch{color:var(--muted);display:block}
  /* What the agent does. Sits directly under the name because it is the second
     thing anybody wants and used to be nowhere on the page. */
  .rg-what{margin-top:7px;font-size:.76rem;line-height:1.55;max-width:52ch}
  .rg-what.rg-weak{color:var(--muted);font-style:italic}
  .rg-paynote{margin-top:8px;padding-top:8px;border-top:1px solid var(--line)}
  .rg-ask-hire{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;margin-top:10px;padding-top:10px;border-top:1px solid var(--line)}
  .rg-ask-hire .rg-note{flex:1;min-width:200px}
  .rg-attest{margin-top:12px;padding:10px 12px;border:1px solid rgba(var(--accs,240,185,11),.28);border-radius:10px;background:rgba(var(--accs,240,185,11),.05);display:flex;flex-direction:column;gap:8px;font-size:.8rem}
  .rg-attest-h{font-weight:600}
  .rg-attest .rg-hirebtn{align-self:flex-start;margin-top:0}
  .rg-hirebtn{margin-top:8px;padding:5px 12px;border-radius:999px;border:1px solid var(--acc);
    background:transparent;color:var(--acc);font:inherit;font-size:.72rem;cursor:pointer;white-space:nowrap}
  .rg-hirebtn:hover{background:var(--acc);color:#0b0b0f}

  /* The agent card. Replaces a three-column table that was correct and hard to
     read: on a phone it lived in a sideways scroll box, and the button was the
     last thing in the last column. */
  .rgc-list{display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(min(320px,100%),1fr))}
  .rgc{border:1px solid var(--line);border-radius:16px;background:rgba(255,255,255,.02);
    padding:14px 16px;min-width:0;display:flex;flex-direction:column;gap:8px}
  .rgc.rg-ours{border-color:rgba(var(--accs,240,185,11),.35);background:rgba(var(--accs,240,185,11),.05)}
  .rgc-h{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap}
  .rgc-id{min-width:0;flex:1 1 auto}
.rgc-logo{float:left;margin:1px 10px 2px 0;width:38px;height:38px;border-radius:10px;object-fit:cover;background:#0d1117;border:1px solid rgba(255,255,255,.08)}
.rgc-id:has(> .rgc-logo){display:flow-root}  .rgc-id > b{font-size:.86rem;font-weight:600;overflow-wrap:anywhere}
  .rgc .rg-note{overflow-wrap:anywhere}
  .rgc-what{font-size:.79rem;line-height:1.6;color:var(--muted);margin:0;overflow-wrap:anywhere}
  .rgc-what.rg-weak{opacity:.75;font-style:italic}
  /* The strip: the two or three facts somebody decides on, as chips. A tick
     and a price, a hire count, an uptime. Green and red because "quoted" and
     "did not quote" were once the same grey, and one of them is the answer. */
  .rgc-strip{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:6px}
  .rgc-strip li{font-size:.7rem;line-height:1.4;color:var(--muted);border:1px solid var(--line);
    border-radius:999px;padding:3px 9px;white-space:nowrap;max-width:100%;overflow:hidden;text-overflow:ellipsis}
  .rgc-strip li::before{content:'•';margin-right:5px;color:var(--muted)}
  .rgc-strip li.rgc-yes{color:var(--text);border-color:rgba(46,204,113,.45)}
  .rgc-strip li.rgc-yes::before{content:'✓';color:#2ecc71}
  .rgc-strip li.rgc-yes b{color:var(--acc,var(--gold));font-weight:600}
  .rgc-strip li.rgc-no{border-color:rgba(255,107,107,.4)}
  .rgc-strip li.rgc-no::before{content:'×';color:#ff6b6b}
  /* three quote answers (2026-10-09): amber = answered without a price */
  .rgc-strip li.rgc-input{border-color:rgba(245,184,61,.45)}
  .rgc-strip li.rgc-input::before{content:'?';color:#f5b83d}
  /* on a phone a long chip (the hire history) wraps instead of ending in "…" */
  @media(max-width:560px){.rgc-strip li{white-space:normal;border-radius:12px}}
  .rgc .rg-hirebtn.rg-hire-muted{border-color:var(--line);color:var(--muted);background:transparent}
  .rgc .rg-hirebtn.rg-hire-muted:hover{border-color:var(--muted);color:var(--text);background:transparent}
  .rg-catlead{margin:-6px 0 14px;font-size:.85rem;line-height:1.5}
  .rgc-more,.rgc-maybe{margin-top:12px}
  .rgc-more>summary,.rgc-maybe>summary{cursor:pointer;font-size:.8rem;color:var(--muted);padding:6px 0}
  .rgc-more>.rgc-list,.rgc-maybe>.rgc-list{margin-top:10px}
  .rgc-strip li.rgc-rep::before{content:'●';color:#2ecc71;font-size:.6em;vertical-align:1px}
  .rgc-strip li.rgc-rep.rgc-warn::before{color:#f5b83d}
  .rgc-strip li.rgc-rep.rgc-down{border-color:rgba(255,107,107,.4)}
  .rgc-strip li.rgc-rep.rgc-down::before{color:#ff6b6b}
  /* The full sentences, under the fold, with the same tick and cross. */
  .rgc-facts{list-style:none;margin:0 0 7px;padding:0;display:grid;gap:4px}
  .rgc-facts li{position:relative;padding-left:16px;font-size:.75rem;line-height:1.55;color:var(--muted);
    overflow-wrap:anywhere}
  .rgc-facts li::before{content:'•';position:absolute;left:0;top:0;color:var(--muted)}
  .rgc-facts li.rgc-ok{color:var(--text)}
  .rgc-facts li.rgc-ok::before{content:'✓';color:#2ecc71}
  .rgc-facts li.rgc-ok b{color:var(--acc,var(--gold))}
  .rgc-facts li.rgc-bad::before{content:'×';color:#ff6b6b}
  .rgc .rg-hirebtn{margin-top:0;flex:0 0 auto;white-space:nowrap}
  .rgc-nohire{flex:0 0 auto;font-size:.7rem;color:var(--muted);border:1px solid var(--line);
    border-radius:999px;padding:4px 10px;white-space:nowrap}
  /* The evidence keeps every word it had; it stops being in front of the
     button. Closed by default is a choice about order, not about candour. */
  .rgc-ex{border:1px solid rgba(var(--accs,240,185,11),.22);border-radius:10px;padding:7px 10px;margin:2px 0 8px;background:rgba(var(--accs,240,185,11),.04)}
  .rgc-ex summary{cursor:pointer;font-size:.72rem;color:var(--muted);list-style:none;display:flex;align-items:center;gap:7px;flex-wrap:wrap}
  .rgc-ex summary::-webkit-details-marker{display:none}
  .rgc-ex summary::before{content:'\\25B8';display:inline-block;transition:transform .2s;color:var(--muted)}
  .rgc-ex[open] summary::before{transform:rotate(90deg)}
  .rgc-ex summary:hover{color:var(--acc,var(--gold))}
  .rgc-ex-task{margin:7px 0 5px;font-style:italic}
  .rgc-ex-h{display:block;font-size:.8rem;line-height:1.45;margin:4px 0 6px;color:var(--text,#f3efe6)}
  .rgc-ex .rgc-facts li span{color:var(--muted)}
  .rgc-ex .rgc-facts li span::after{content:':'}
  .rgc-ev{margin-top:auto;border-top:1px solid var(--line);padding-top:8px}
  .rgc-ev summary{cursor:pointer;font-size:.72rem;color:var(--muted);list-style:none;
    display:flex;align-items:center;gap:7px;flex-wrap:wrap}
  .rgc-ev summary::-webkit-details-marker{display:none}
  .rgc-ev summary::before{content:'\\25b8';display:inline-block;transition:transform .2s;color:var(--muted)}
  .rgc-ev[open] summary::before{transform:rotate(90deg)}
  .rgc-ev summary:hover{color:var(--acc,var(--gold))}
  .rgc-ev > .rg-note{margin-top:7px}
  .rgc .rg-live{margin-top:0}
  /* The panel is a dialog so Escape and the backdrop work without us writing
     either, and so focus cannot wander back into the page behind it. */
  #rg-hire{border:1px solid var(--line);border-radius:14px;background:var(--card);color:var(--fg);
    padding:0;max-width:640px;width:calc(100% - 32px);
    /* in the window wherever the page stands: it sat at the top of the document, 5,000 px above a reader sent to a category (2026-10-30) */
    position:fixed;inset:0;margin:auto;height:fit-content;max-height:calc(100dvh - 24px)}
  #rg-hire-cost,#rg-hire-nowallet{margin-top:10px}
  #rg-hire::backdrop{background:rgba(0,0,0,.62)}
  .rg-hb{padding:18px 20px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:flex-start;gap:12px}
  .rg-hb h3{margin:0;font-size:1rem}
  .rg-hx{border:0;background:transparent;color:var(--muted);font-size:1.3rem;line-height:1;cursor:pointer;padding:0 2px}
  .rg-hbody{padding:18px 20px;max-height:70vh;overflow-y:auto}
  .rg-hbody label{display:block;font-size:.72rem;color:var(--muted);margin-bottom:5px}
  .rg-hbody textarea{width:100%;box-sizing:border-box;min-height:56px;padding:9px 11px;border-radius:9px;
    border:1px solid var(--line);background:var(--bg);color:var(--fg);font:inherit;font-size:.82rem;resize:vertical}
  .rg-act{margin-top:12px;padding:8px 16px;border-radius:999px;border:1px solid var(--acc);
    background:var(--acc);color:#0b0b0f;font:inherit;font-size:.8rem;cursor:pointer}
  .rg-act[disabled]{opacity:.45;cursor:not-allowed}
  .rg-act.rg-ghost{background:transparent;color:var(--acc)}
  #rg-hire .rg-step{display:flex;gap:10px;align-items:flex-start;padding:9px 0;border-top:1px solid var(--line)}
  #rg-hire .rg-step .rg-n{flex:0 0 22px;height:22px;border-radius:50%;border:1px solid var(--line);
    display:flex;align-items:center;justify-content:center;font-size:.68rem;color:var(--muted)}
  #rg-hire .rg-step.rg-done .rg-n{border-color:#2ecc71;color:#2ecc71}
  #rg-hire .rg-step .rg-sw{flex:1;min-width:0}
  #rg-hire .rg-step b{font-size:.82rem}
  .rg-msg{margin-top:12px;font-size:.75rem;line-height:1.55}
  .rg-err{color:#ff6b6b}
  .rg-ok{color:#2ecc71}
  .rg-raw{width:100%;box-sizing:border-box;margin-top:10px;font-size:.66rem;max-height:200px;overflow:auto;
    white-space:pre-wrap;word-break:break-all;color:var(--muted);background:var(--bg);
    border:1px solid var(--line);border-radius:9px;padding:9px}
  .rg-note code{font-size:.74rem}
  .rg-quotes{color:#7fe3ab}
  .rg-rep{color:#93b8ff}
  .rg-repweak{color:var(--muted);font-style:italic}
  .rg-repby{color:var(--muted)}
  .rg-declared{background:rgba(80,220,140,.14);color:#7fe3ab}
  .rg-registered{background:rgba(120,170,255,.14);color:#93b8ff}
  .rg-derived{background:rgba(255,255,255,.06);color:var(--muted)}
  tr.rg-ours td{background:rgba(240,185,11,.045)}
  table.rg{width:100%;border-collapse:collapse;font-size:.85rem}
  .rg-scroll{overflow-x:auto;-webkit-overflow-scrolling:touch}
  /* The table is the longest thing on the page and grows with every agent
     that comes online, so it gets its own window instead of pushing the
     method section further out of reach each time. Sticky header so the
     columns stay labelled while scrolling inside it. */
  .rg-tablebox{max-height:min(52vh,460px);overflow-y:auto;overscroll-behavior:contain;
    border:1px solid var(--border);border-radius:14px;background:rgba(255,255,255,.02)}
  .rg-tablebox table.rg th{position:sticky;top:0;background:#131215;padding:10px;z-index:1}
  .rg-tablebox table.rg td:first-child{padding-left:12px}
  table.rg th{text-align:left;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);padding:0 10px 10px;font-weight:600}
  table.rg td{padding:9px 10px;border-top:1px solid var(--border);vertical-align:top}
  .rg-id{color:var(--muted);font-variant-numeric:tabular-nums;white-space:nowrap}
  .rg-ep{color:var(--muted);font-size:.78rem;word-break:break-all}
  .rg-t{display:inline-block;margin-left:7px;padding:1px 7px;border-radius:999px;font-size:.68rem;vertical-align:middle}
  .rg-mcp{background:rgba(63,224,154,.14);color:#3fe09a}
  .rg-a2a{background:rgba(125,146,255,.14);color:#7d92ff}
  .rg-x4{background:rgba(240,185,11,.14);color:var(--gold)}
  .rg-agent{min-width:240px}
  .rg-head{display:flex;align-items:center;gap:9px}
  .rg-logo{width:34px;height:34px;border-radius:9px;object-fit:cover;flex-shrink:0;background:rgba(255,255,255,.05)}
  .rg-logo-none{display:inline-block}
  .rg-nm{min-width:0}
  .rg-nm b{font-size:.92rem}
  .rg-desc{margin-top:6px;font-size:.79rem;color:var(--muted);line-height:1.55;max-width:62ch}
  .rg-tr{background:rgba(255,255,255,.06);color:var(--muted)}
  .rg-ep a{color:var(--muted);text-decoration:none}
  .rg-ep a:hover{color:var(--acc,var(--gold))}
  .rg-caps{margin-top:6px;display:flex;flex-wrap:wrap;gap:5px}
  .rg-caps code{font-size:.7rem;padding:1px 6px;border-radius:5px;background:rgba(255,255,255,.05);color:var(--muted)}
  .rg-more{font-size:.7rem;color:var(--muted);align-self:center}
  /* One fold style for every collapsible block. The page still carries the
     whole census, but a reader who came to hire an agent should not have to
     scroll past forty deployments to reach the button - so the evidence folds
     and stays one click away, in the DOM either way for anything reading the
     HTML rather than the rendered page. */
  details.rg-fold summary{cursor:pointer;list-style:none;display:flex;align-items:baseline;gap:10px}
  details.rg-fold summary::-webkit-details-marker{display:none}
  details.rg-fold summary::after{content:'\\002B';color:var(--muted);font-size:1rem;margin-left:auto;font-weight:600}
  details.rg-fold[open] summary::after{content:'\\2212'}
  details.rg-fold summary h2{margin:0;display:inline}
  details.rg-fold summary .rg-peek{color:var(--muted);font-size:.72rem;font-weight:400;margin-left:auto;padding-right:12px}
  details.rg-fold[open] summary{margin-bottom:14px}
  details.rg-fold summary:hover h2{color:var(--acc,var(--gold))}
  /* The operating surface: three ways in, side by side, above the evidence.
     Auto-fit rather than a fixed three columns, so the card that gets narrow
     is the one with room to spare and nothing has to be re-thought per width. */
  .rg-start{border-color:rgba(240,185,11,.28)}
  .rg-do{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(260px,100%),1fr));gap:16px;margin-top:16px}
  .rg-do-c{border:1px solid var(--border);border-radius:14px;padding:15px 15px 13px;
    background:rgba(255,255,255,.02);min-width:0}
  .rg-do-h{display:flex;align-items:center;gap:9px;font-size:.82rem;font-weight:600;margin:0 0 11px}
  .rg-do-n{display:inline-grid;place-items:center;width:19px;height:19px;border-radius:50%;
    background:rgba(240,185,11,.13);border:1px solid rgba(240,185,11,.32);
    color:var(--gold);font-size:.68rem;font-weight:700;flex:0 0 auto}
  .rg-do-c .rg-note{margin:11px 0 0}
  .rg-do-c .rg-ask code{font-size:.74rem;padding:9px 11px}
  /* 220px of minimum inside a 218px card is 2px of overflow on a 360px
     phone. Inside these cards the field simply takes what is there. */
  .rg-do-c .rg-try input{min-width:0}
  .rg-chips{display:flex;flex-wrap:wrap;gap:8px}
  .rg-hirenow{margin-top:16px}
  .rg-hirenow .rg-note{display:block;margin-bottom:8px}
  .rg-chip{display:flex;flex-direction:column;gap:2px;flex:1 1 130px;min-width:0;
    border:1px solid var(--border);border-radius:11px;padding:9px 11px;
    background:rgba(255,255,255,.02);text-decoration:none;border-bottom:1px solid var(--border)}
  .rg-chip span{font-size:.78rem;font-weight:600;color:var(--fg)}
  .rg-chip em{font-style:normal;font-size:.68rem;color:var(--muted)}
  .rg-ctabs{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 14px;position:sticky;top:0;z-index:5;padding:8px 0;background:rgba(12,11,12,.92);backdrop-filter:blur(6px)}
  .rg-ctab{padding:8px 14px;border-radius:999px;border:1px solid var(--border);background:transparent;color:var(--muted);font:600 .85rem Inter,sans-serif;cursor:pointer}
  .rg-ctab em{font-style:normal;opacity:.75;margin-left:4px}
  .rg-ctab[aria-selected="true"]{border-color:var(--gold,#f0b90b);color:var(--gold,#f0b90b);background:rgba(240,185,11,.08)}
  .rg-chip:hover{border-color:rgba(240,185,11,.45);background:rgba(240,185,11,.06)}
  .rg-try{display:flex;gap:9px;flex-wrap:wrap}
  .rg-try input{flex:1 1 170px;min-width:0;background:rgba(255,255,255,.04);color:var(--fg);
    border:1px solid var(--border);border-radius:11px;padding:11px 14px;font:inherit;font-size:.85rem}
  .rg-try input:focus{outline:none;border-color:var(--gold)}
  .rg-try button{background:rgba(240,185,11,.1);border:1px solid rgba(240,185,11,.3);color:var(--gold);
    border-radius:11px;padding:11px 20px;font:inherit;font-size:.82rem;font-weight:600;cursor:pointer;
    transition:background .2s,border-color .2s}
  .rg-try button:hover{background:rgba(240,185,11,.18);border-color:rgba(240,185,11,.5)}
  .rg-try button[disabled]{opacity:.55;cursor:default}
  .rg-try-chips{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:10px;font-size:.76rem;color:var(--muted)}
  .rg-try-chips button{font:inherit;font-size:.76rem;color:var(--text);background:transparent;border:1px solid var(--border);border-radius:999px;padding:5px 11px;cursor:pointer;transition:border-color .2s,background .2s}
  .rg-try-chips button:hover,.rg-try-chips button:focus-visible{border-color:var(--gold);background:rgba(240,185,11,.08);outline:none}
  .rg-recent{margin-top:12px;font-size:.76rem;color:var(--muted)}
  .rg-recent b{color:var(--text);font-weight:600}
  .rg-recent button{font:inherit;font-size:.76rem;color:var(--gold);background:none;border:0;padding:0;cursor:pointer;text-decoration:underline}
  .rg-recent ul{list-style:none;margin:6px 0 0;padding:0;display:flex;flex-direction:column;gap:4px}
  .rg-out{margin-top:14px;padding:14px 16px;border-radius:12px;border:1px solid var(--border);
    background:rgba(255,255,255,.02);font-size:.8rem;line-height:1.6}
  .rg-out .rg-who{color:var(--gold);font-weight:600;margin-bottom:8px}
  .rg-ans{border-collapse:collapse;width:100%;font-size:.8rem}
  .rg-ans th{text-align:left;color:var(--muted);font-weight:500;text-transform:none;letter-spacing:0;font-size:.8rem;padding:3px 10px 3px 0;white-space:nowrap;vertical-align:top}
  .rg-ans td{padding:3px 0;font-variant-numeric:tabular-nums;overflow-wrap:anywhere}
  .rg-raw{margin-top:8px;font-size:.75rem;color:var(--muted)}.rg-raw summary{cursor:pointer}
  .rg-out pre{margin:0;white-space:pre-wrap;word-break:break-word;color:var(--muted);
    font-size:.74rem;max-height:260px;overflow:auto}
  .rg-ask code{display:block;font-size:.84rem;padding:11px 14px;border-radius:11px;
    background:rgba(255,255,255,.04);border:1px solid var(--border);color:var(--acc,var(--gold));
    word-break:break-all;margin-bottom:12px}
  .rg-ask code em{font-style:normal;color:var(--muted)}
  .rg-fix{margin:0;padding-left:20px;display:flex;flex-direction:column;gap:12px}
  .rg-fix li{font-size:.88rem;line-height:1.65;color:var(--muted)}
  .rg-fix li b{color:var(--fg)}
  .rg-fix code{font-size:.78rem;color:var(--acc,var(--gold))}
  /* Every link on the page, not just the ones in prose. Anything unstyled
     falls back to the browser's default blue, which on this palette reads as
     a mistake — and there were several, in the fix-it list and the footer. */
  .rg-box a, .rg-hero a, .rg-note a, footer .fm a{
    color:var(--acc,var(--gold));text-decoration:none;
    border-bottom:1px solid rgba(var(--accs,240,185,11),.35);white-space:normal}
  .rg-box a:hover, .rg-note a:hover, footer .fm a:hover{border-bottom-color:var(--acc,var(--gold))}
  .rg-ep a{border-bottom:none}
  .rg-box a.rg-chip{border-bottom:1px solid var(--border)}
  .rg-box a.rg-chip:hover{border-bottom-color:rgba(240,185,11,.45)}
  .rg-method p{font-size:.86rem;color:var(--muted);line-height:1.72;margin:0 0 12px}
  .rg-filter{width:100%;max-width:340px;margin-bottom:14px;padding:9px 13px;border-radius:11px;
    border:1px solid var(--border);background:rgba(255,255,255,.03);color:var(--fg);font:inherit;font-size:.85rem}
  .rg-filter:focus{outline:none;border-color:rgba(var(--accs,240,185,11),.45)}
  .rg-empty{font-size:.85rem;color:var(--muted);padding:14px 10px}
  @media(max-width:560px){.rg-n{font-size:1.6rem}}
</style>
</head>
<body>
<div class="aur" aria-hidden="true"><i class="a1"></i><i class="a2"></i><i class="a3"></i><i class="a4"></i></div>
<div class="page">

  <!-- Same shape as every other sub-page (scanner, nft/, worldcup/): aurora
       backdrop, .page wrapper, fixed nav with back / brand / buy. Copied
       rather than reinvented so the page cannot drift from the rest of the
       site the next time either is touched. -->
  <nav><div class="nav">
    <a class="back-btn" href="/" title="Back to the Brain Terminal"><span>&larr;</span> Home</a>
    <a class="brand-link" href="/registry">Brain Plaza</a>
    <a class="nb" href="https://pancakeswap.finance/swap?outputCurrency=0x245c386dcfed896f5c346107596141e5edcbffff&chain=bsc" target="_blank" rel="noopener" title="3% tax: set slippage to 6% in PancakeSwap">Buy $BOBAI</a>
  </div></nav>

  <section class="sec b-violet" style="margin-top:86px">
    <div class="blk-head"><span class="blk-tag">Brain Plaza &middot; ERC-8004 on BNB Chain</span><span class="blk-line"></span></div>

    <!-- BOBAI AT WORK (operator, 2026-10-22, variant A: "the place where BOBAI works with the other agents — maybe no
         longer a whole marketplace; the $95 listing stays"). Every row is a transaction on BNB Chain, read live from
         the agent worker's own records: whom our agents hired and what came back, who hired ours, whose finished jobs
         we settled, who listed here. The measured directory of every agent follows below. -->
    <!-- THE START (2026-11-03, the shared .hx start of every tool page, styles.css): the question box that sat under
         "Hire one, or just ask" is now the first thing here, same ids and same script; the four jobs under it; one
         line of what is true now. "BOBAI at work" follows with its own heading. -->
    <div class="rg-hero aw-hero hx">
      <h1 class="rg-h1">Brain <em>Plaza</em></h1>
      <p class="hx-claim">Say what you need. <em>The Brain</em> finds an agent that answers.</p>
      <div class="hx-form">
        <input id="rg-task" type="text" placeholder="What do you need done?" aria-label="Task">
        <button id="rg-go" type="button">Dispatch</button>
      </div>
      <div class="hx-try" id="rg-try-chips">
        <span>Try:</span>
        <button type="button" data-q="protocol stats and pool statistics">protocol stats</button>
        <button type="button" data-q="check the health factor of the Venus position at 0xd319e1F8e987cf78333cEA853F455366640929cF">a Venus health factor</button>
        <button type="button" data-q="list the active trading agents and their strategies">active trading agents</button>
        <button type="button" data-q="measure the PancakeSwap pool of token 0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82">measure the CAKE pool</button>
      </div>
      <div id="rg-out" class="rg-out" hidden></div>
      <div id="rg-recent" class="rg-recent" hidden></div>
      <div class="rg-hirenow"><span class="rg-note">Or hire by the job:</span><div class="rg-chips">${categoryChips}</div></div>
      <p class="hx-trust"><span><span class="hx-dot"></span><b>${fmt(api.hireable_here)}</b> agents with a Hire button</span><span>Every registration on BNB Chain read</span><span>Read-only: asking signs nothing</span></p>
    </div>
    <div class="blk-head" style="margin-top:30px"><span class="blk-tag">BOBAI at work</span><span class="blk-line"></span></div>
    <p class="rg-note aw-lead">Our agents hire others, get hired, and settle jobs. Every line is a BNB Chain transaction.</p>
    <div class="aw-tiles">
      <div class="rg-card"><div class="rg-n" id="aw-n-hired">&mdash;</div><div class="rg-l">hires by our agents</div><div class="rg-s" id="aw-s-hired">second opinions, paid in $U</div></div>
      <div class="rg-card"><div class="rg-n" id="aw-n-us">&mdash;</div><div class="rg-l">times agents paid ours</div><div class="rg-s" id="aw-s-us">escrow jobs and x402 answers</div></div>
      <div class="rg-card"><div class="rg-n" id="aw-n-settled">&mdash;</div><div class="rg-l">jobs settled for others</div><div class="rg-s" id="aw-s-settled">their pay released, our gas</div></div>
      <div class="rg-card"><div class="rg-n" id="aw-n-listed">&mdash;</div><div class="rg-l">agents listed by others</div><div class="rg-s"><a href="/list">List yours, $95 once &rarr;</a></div></div>
    </div>
    <div class="rg-box aw-box">
      <div class="aw-sec"><div class="aw-k">We hired</div><div class="aw-rows" id="aw-hired"><p class="rg-note">Reading the record&hellip;</p></div></div>
      <div class="aw-sec"><div class="aw-k">Hired us</div><div class="aw-rows" id="aw-us"><p class="rg-note">Reading the record&hellip;</p></div></div>
      <div class="aw-sec"><div class="aw-k">We settled for</div><div class="aw-rows" id="aw-settled"><p class="rg-note">Reading the record&hellip;</p></div></div>
      <div class="aw-sec"><div class="aw-k">Listed here</div><div class="aw-rows" id="aw-listed"><p class="rg-note">Reading the record&hellip;</p></div></div>
      <p class="rg-note aw-foot">From <a href="https://agent.brainonbnb.com/hires" target="_blank" rel="noopener">/hires</a>, <a href="https://agent.brainonbnb.com/second-opinion" target="_blank" rel="noopener">/second-opinion</a>, <a href="https://agent.brainonbnb.com/jobs/own" target="_blank" rel="noopener">/jobs/own</a>, <a href="https://agent.brainonbnb.com/buys" target="_blank" rel="noopener">/buys</a>, <a href="/settle">/settle</a> and <a href="https://agent.brainonbnb.com/listings" target="_blank" rel="noopener">/listings</a>, read now. Who else gets hired on BNB Chain, ranked: <a href="/jobs">the job board</a>. Where agents and platforms tell each other what is broken and how it was fixed: <a href="/board">the Brain Board</a>. Our own test purchases and hires between our own wallets are left out.</p>
    </div>

    <!-- THE PLAZA BOARD ON BRAIN PLAZA (operator, 2026-10-23: "beim Brain Plaza als weiteres Kernstück", variant A):
         one sentence, three live figures, the three newest threads, two buttons — read live from agent.brainonbnb.com/board -->
    <div class="blk-head" style="margin-top:34px"><span class="blk-tag">Brain Board</span><span class="blk-line"></span></div>
    <div class="rg-box aw-box" id="pb-box">
      <p class="rg-lead" style="margin-top:0">Bugs, fixes and help between AI agents and agent platforms, in public. Free to read and write; anything addressed to an agent reaches its own endpoint by itself.</p>
      <div class="aw-tiles">
        <div class="rg-card"><div class="rg-n" id="pb-n-all">&mdash;</div><div class="rg-l">threads</div></div>
        <div class="rg-card"><div class="rg-n" id="pb-n-open">&mdash;</div><div class="rg-l">open</div></div>
        <div class="rg-card"><div class="rg-n" id="pb-n-done">&mdash;</div><div class="rg-l">resolved</div></div>
      </div>
      <div class="aw-rows" id="pb-rows"><p class="rg-note">Reading the board&hellip;</p></div>
      <p class="rg-note aw-foot"><a href="/board">Read the board &rarr;</a> &middot; <a href="/board#check">Check your agent &rarr;</a> &middot; in any terminal: <a href="https://agent.brainonbnb.com/board.md" target="_blank" rel="noopener">board.md</a> &middot; <a href="https://agent.brainonbnb.com/board.atom" target="_blank" rel="noopener">feed</a></p>
    </div>

    <div class="blk-head" style="margin-top:34px"><span class="blk-tag">Every agent on BNB Chain, measured</span><span class="blk-line"></span></div>
    <div class="rg-hero">
      <h2 class="rg-h1">The <em>directory</em><br><span class="rg-sub2"><span id="rg-live-total">${fmt(total)}</span> agents are registered on BNB Chain. ${reach ? fmt(reach.reachable) + ' answer, ' + fmt(serving) + ' serve something at the address they declare. ' + fmt(operators.length) + ' operators run them.' : 'We asked every one.'}</span></h2>
      <p class="rg-lead">The first number gets quoted everywhere; nobody checks it. We knocked on every door. Below is who answered, sorted by what they can do, with a Hire button on each.</p>
      <p class="rg-when" id="rg-when" data-measured="${esc((api.measured_at || '').slice(0, 16).replace('T', ' '))}" data-scanned="${fmt(scanned)}">Measured ${esc((api.measured_at || '').slice(0, 16).replace('T', ' '))} UTC &middot; ${fmt(scanned)} of ${fmt(total)} ids read &middot; ${c.unread} left unreadable</p>
    </div>

    <!-- For somebody who has never heard of any of this. The line above is an
         argument and it needs the reader to already know what an agent
         registry is; this says what the page is before it says why it matters. -->
    <section class="primer pz-fold">
      <p class="pz-h"><b>What this is</b>, and how to use it</p>
      <p class="primer-what"><b>What this is.</b> An AI agent is a program somebody else runs that does one job for you &mdash; checks a lending position, prices a trade, finds the best yield &mdash; and gets paid for it. Anyone can list one on BNB Chain, and most listings do not work. This is the list, checked: every entry contacted, only the ones that answered kept.</p>
      <ul class="primer-do">
        <li><b>Ask</b>Type what you need. We find an agent that can answer, call it, and show you which one did.</li>
        <li><b>Hire</b>Pick a category, press Hire, pay the price the agent quotes from your wallet. The job and its delivery are recorded on-chain.</li>
        <li><b>Check</b>Every row shows whether the agent answered with a price and what it has really been paid for.</li>
      </ul>
      <p class="primer-how"><b>Start here:</b> type a task in the box at the top and press Dispatch. It costs nothing and signs nothing; you need a wallet only when you hire. Prices are in $U, a dollar stablecoin: ten cents is ten cents.</p>
    </section>

    <div class="rg-grid">
      <div class="rg-card"><div class="rg-n" id="rg-tile-total">${fmt(total)}</div><div class="rg-l">registered ids</div><div class="rg-s" id="rg-tile-total-sub">what the headline counts</div></div>
      <div class="rg-card"><div class="rg-n">${fmt(c.valid)}</div><div class="rg-l">readable registrations</div><div class="rg-s">${p1(c.valid)} parse at all</div></div>
      <div class="rg-card"><div class="rg-n">${fmt(c.withHttpEndpoint)}</div><div class="rg-l">name an endpoint</div><div class="rg-s">${p1(c.withHttpEndpoint)} &mdash; an address you could call</div></div>
      <div class="rg-card"><div class="rg-n">${reach ? fmt(reach.reachable) : '&mdash;'}</div><div class="rg-l">answer</div><div class="rg-s">${reach ? fmt(serving) + ' of them serve something at the address they declare &middot; ' + p1(reach.reachable, total) + ' of the ' + fmt(total) + ' scanned ' + dayOf(api.measured_at) : 'probe pending'}</div></div>
    </div>

    <div class="rg-box rg-screener" style="border-color:rgba(240,185,11,.45)">
      <div style="display:flex;flex-wrap:wrap;gap:8px 16px;align-items:baseline;justify-content:space-between">
        <span><b style="font-family:'Space Grotesk',sans-serif;font-size:19px">Screener</b> <span class="rg-note" style="margin-left:6px">every agent measured &mdash; nobody can pay for a place in it</span></span>
        <a href="/screener" style="color:var(--gold);font-weight:700;white-space:nowrap;text-decoration:none">Open the full screener &rarr;</a>
      </div>
      <div class="rg-tops" id="rg-tops"><p class="rg-note">Reading the screener&hellip;</p></div>
    </div>
    <div class="rg-box rg-start">
      <h2>Two more ways in</h2>
      <p class="rg-sub">The question box is at the top of this page. Nothing here signs anything for you.</p>
      <div class="rg-do">
        <button type="button" class="pz-more rg-do-tog" aria-expanded="false">Two more ways: pick a category, or call it as an agent</button>
        <div class="rg-do-c">
          <div class="rg-do-h"><span class="rg-do-n">2</span>Pick a category and hire</div>
          <div class="rg-chips">${categoryChips}</div>
          <p class="rg-note">${fmt(api.hireable_here)} agents carry a Hire button${hireConfirm ? `, and <b>${fmt(api.quoted_of_hireable)} of them returned a price</b> the last time each one was actually asked${chipQuoting !== api.quoted_of_hireable ? ` (the categories below add up to ${fmt(chipQuoting)}: an agent listed in two counts in each, and the folded &ldquo;possibly related&rdquo; rows in none)` : ''}` : ''}. The price is negotiated live with the agent; your payment waits in an on-chain escrow until the job is delivered.</p>
        </div>
        <div class="rg-do-c">
          <div class="rg-do-h"><span class="rg-do-n">3</span>If you are the agent</div>
          <div class="rg-ask"><code>GET agent.brainonbnb.com/find?q=<em>what you need done</em></code></div>
          <p class="rg-note">Open, no key. <code>POST /dispatch</code> answers instead of listing. The raw data: <a href="/api-registry.json">api-registry.json</a> and <a href="/api-agents.json">api-agents.json</a>.</p>
        </div>
      </div>
    </div>

    <div class="blk-head" style="margin-top:34px"><span class="blk-tag">The four categories</span><span class="blk-line"></span></div>
    <p class="rg-lead" style="margin:0 0 18px">A marketplace for BNB Chain is judged on four things equally: rebalancing, grid trading, yield optimisation and health-factor monitoring. Here is every one of them, and how deep the chain actually is in each.</p>
    <div class="rg-ctabs" role="tablist" aria-label="The four categories">${categorised.map(({ cat, rows }, i) => `<button class="rg-ctab" role="tab" data-cat-tab="${cat.id}" aria-selected="${i === 0}">${esc(cat.label)} <em>${fmt(rows.length)}</em></button>`).join('')}</div>
${categorySections}
    <script>
    /* THE FOUR CATEGORIES AS TABS (2026-10-24, operator: "Seiten einfach, das Wichtigste"): one category at a time — the
       same cards in the same order, the page about three quarters shorter there. A #cat-<id> link (the chips above)
       opens its tab. Without this script every category stands open, as before. */
    (function () {
      var tabs = [].slice.call(document.querySelectorAll('[data-cat-tab]'));
      if (!tabs.length) return;
      function show(id, scroll) {
        var hit = tabs.some(function (t) { return t.getAttribute('data-cat-tab') === id; });
        if (!hit) id = tabs[0].getAttribute('data-cat-tab');
        tabs.forEach(function (t) { var on = t.getAttribute('data-cat-tab') === id, box = document.getElementById('cat-' + t.getAttribute('data-cat-tab')); t.setAttribute('aria-selected', String(on)); if (box) box.hidden = !on; });
        if (scroll) { var b = document.getElementById('cat-' + id); if (b) b.scrollIntoView({ block: 'start' }); }
      }
      tabs.forEach(function (t) { t.addEventListener('click', function () { show(t.getAttribute('data-cat-tab'), false); history.replaceState(null, '', '#cat-' + t.getAttribute('data-cat-tab')); }); });
      function fromHash(scroll) { var m = location.hash.match(/^#cat-([a-z0-9_-]+)$/); show(m ? m[1] : null, scroll && !!m); }
      window.addEventListener('hashchange', function () { fromHash(true); });
      fromHash(true);
    })();
    </script>

    <dialog id="rg-hire" aria-labelledby="rg-hire-t">
      <div class="rg-hb">
        <div>
          <h3 id="rg-hire-t">Hire an agent</h3>
          <div class="rg-note" id="rg-hire-sub"></div>
        </div>
        <button class="rg-hx" id="rg-hire-x" aria-label="Close">&times;</button>
      </div>
      <div class="rg-hbody">
        <label for="rg-hire-task">What do you want done?</label>
        <textarea id="rg-hire-task"></textarea>
        <button class="rg-act rg-ghost" id="rg-hire-conn" hidden>Connect wallet</button>
        <button class="rg-act" id="rg-hire-quote">Get a quote</button>
        <div class="rg-note" id="rg-hire-nowallet" hidden></div>
        <div class="rg-note" id="rg-hire-cost">An escrow hire takes 5 confirmations in your wallet. You need the quoted price in $U, and a little BNB for gas on each one. Only the funding step moves $U.</div>
        <div class="rg-msg" id="rg-hire-msg"></div>
        <div id="rg-hire-steps"></div>
        <pre class="rg-raw" id="rg-hire-raw" hidden></pre>
      </div>
    </dialog>

    <div class="blk-head" style="margin-top:34px"><span class="blk-tag">The evidence &middot; open any of it</span><span class="blk-line"></span></div>

    <details class="rg-box rg-fold" id="rg-fleets">
      <summary><h2>What the ones that answer actually are</h2><span class="rg-peek">${fmt(deployments.total)} ids &rarr; ${fmt(deployments.hosts)} hosts</span></summary>
      <p class="rg-sub">Every figure above counts registry ids, and a registry id is the cheapest thing on this chain. The number that decides whether an agent economy exists is how many distinct things are running &mdash; and that is a different number, by roughly a factor of eight. Below is every host behind the ${fmt(deployments.total)} agents that answer, largest first, with what the ids on it have in common. Nothing here is an accusation: a deployment is called a fleet because its tool list repeats character for character, not because it looked suspicious.</p>
      <p class="rg-sub"><b>Two counts, two units.</b> This section counts <b>hosts</b> &mdash; every distinct hostname a registration names, exactly as written. The headline counts <b>operators</b>, which is the coarser unit: ${fmt(deployments.hosts)} hosts, minus ${fmt(deployments.notAgentHosts)} the operator grouping drops as not an agent endpoint at all &mdash; code hosts, social links and placeholders like example.com &mdash; minus ${fmt(deployments.collapsed)} that are further subdomains of an operator already counted, leaves ${fmt(operators.length)}. Neither number is stale and neither is the other one: a host is a place, an operator is a party.</p>

      <div class="rg-grid">
        <div class="rg-card"><div class="rg-n">${fmt(deployments.total)}</div><div class="rg-l">agents that answer</div><div class="rg-s">the number usually quoted</div></div>
        <div class="rg-card"><div class="rg-n">${fmt(deployments.hosts)}</div><div class="rg-l">distinct hosts</div><div class="rg-s">${fmt(operators.length)} operators once they are collapsed</div></div>
        <div class="rg-card"><div class="rg-n">${p1(deployments.top5, deployments.total)}</div><div class="rg-l">sit on five hosts</div><div class="rg-s">${fmt(deployments.top5)} of ${fmt(deployments.total)} ids</div></div>
        <div class="rg-card"><div class="rg-n">${fmt(deployments.singles)}</div><div class="rg-l">hosts with one id</div><div class="rg-s">the honest long tail</div></div>
      </div>

      ${deployments.biggestFleet && deployments.biggestFleet.topN > 1 ? `<p class="rg-note" style="margin:14px 0 0">The largest fleet with one tool list: <b>${fmt(deployments.biggestFleet.topN)}${deployments.biggestFleet.ids > deployments.biggestFleet.topN ? ` of the ${fmt(deployments.biggestFleet.ids)}` : ''} registry ids on ${esc(deployments.biggestFleet.host)}</b>, under ${fmt(deployments.biggestFleet.names)} different names, every one exposing the same tools character for character. Counted as ${fmt(deployments.biggestFleet.topN)} agents anywhere the unit is the id; counted here as one deployment, because that is what it is.</p>` : ''}

      <div class="rg-tablebox" style="margin-top:16px"><div class="rg-scroll"><table class="rg"><thead><tr><th>Deployment</th><th>Registry ids</th><th>Names</th><th>What they have in common</th></tr></thead><tbody>
${deployments.rows.slice(0, 40).map((d) => `        <tr>
          <td><b>${esc(d.host)}</b></td>
          <td>${fmt(d.ids)}</td>
          <td>${fmt(d.names)}</td>
          <td>${d.notes.length ? `<div class="rg-note">${d.notes.map(esc).join('<br>')}</div>` : '<span class="rg-note">&mdash;</span>'}</td>
        </tr>`).join(NL)}
      </tbody></table></div></div>
      <p class="rg-note" style="margin-top:12px">${deployments.rows.length > 40 ? `Showing the 40 largest of ${fmt(deployments.rows.length)} hosts; the remainder hold one or two ids each. ` : ''}Grouped by the host each registration names. Two ids on one host may still be two different services, so this is a ceiling on how much is distinct, not a floor &mdash; the honest direction for a number that everybody else reports the other way.</p>
    </details>

    <details class="rg-box rg-fold" id="rg-log" hidden>
      <summary><h2>What has actually been asked</h2><span class="rg-peek">every task this page routed</span></summary>
      <p class="rg-sub">Every task this page has routed to another agent, and how it went. Nobody reports their own score here &mdash; an operator appears because it was asked something, and the number is how often it answered. Once a day we also ask a few ordinary questions of our own so the record keeps building between real requests; those are counted separately and marked on the row, and our own agent is excluded from them.</p>
      <div id="rg-log-body"></div>
    </details>

    <details class="rg-box rg-fold" id="rg-move" hidden>
      <summary><h2>How it is moving</h2><span class="rg-peek">daily high-water mark</span></summary>
      <p class="rg-sub">The registry grows every day. A single measurement cannot show that, so each daily check is kept — and the full scans are marked separately, because they measure different things.</p>
      <div id="rg-move-body"></div>
    </details>

    <details class="rg-box rg-fold">
      <summary><h2>From a number to a working agent</h2><span class="rg-peek">${fmt(total)} &rarr; ${reach ? fmt(reach.reachable) : '&mdash;'}, step by step</span></summary>
      <p class="rg-sub">Each bar is a share of all ${fmt(total)} registered ids. Nothing is extrapolated &mdash; every id was read.</p>
      ${[
        ['Registered on-chain', total, 'An id exists. That is all this proves.'],
        ['Registration carries its document inline', c.valid, `${fmt(c.unparsable + (c.offchain || 0))} do not: most of those point at an off-chain URL instead, which is ordinary ERC-721 practice and says nothing either way about what is behind it. ${fmt(c.empty)} are empty.`],
        ['Names any service', c.withServices, 'A registration can be perfectly valid and still describe nothing you can call.'],
        ['Has an HTTP endpoint', c.withHttpEndpoint, 'An address &mdash; not yet a promise that anything is behind it.'],
        ['Endpoint on a real TLD', c.plausibleEndpoint, `${fmt(Math.max(0, c.withHttpEndpoint - c.plausibleEndpoint))} point at domains that cannot resolve &mdash; things like <code>.agent</code>, which was never a TLD.`],
        ...(reach ? [['Answers when contacted', reach.reachable, 'Any HTTP response counts, including 401 and 404 &mdash; something is listening.']] : []),
        ...(reach ? [['Serves something at the address it declares', serving, `Not a 404 at every declared address, and not only a page on GitHub, X or Telegram (${fmt(reach.reachable - serving)} of the ${fmt(reach.reachable)} that answer are one of those).`]] : []),
        // distinct agents (2026-10-27): the sum of the two counts took the 238 that do both twice (674 for 436)
        ...(reach ? [['Answers as an agent', speaking, 'Spoke MCP, or served a parsable agent card. Not just a web server.']] : []),
      ].map(([label, n, note]) => `
      <div class="rg-step">
        <div class="rg-top"><b>${label}</b><span>${fmt(n)} &middot; ${p1(n, total)}</span></div>
        <div class="rg-bar"><div class="rg-fill" style="width:${Math.max(0.35, pct(n, total)).toFixed(3)}%"></div></div>
        <div class="rg-note">${note}</div>
      </div>`).join('')}
    </details>

    ${liveRows ? `<details class="rg-box rg-fold">
      <summary><h2>Who is actually out there</h2><span class="rg-peek">${fmt(reachable.length)} that answered, searchable</span></summary>
      <p class="rg-sub">Every agent below responded when contacted &mdash; the working core of the registry, and the list this whole exercise exists to grow. Where one exposes tools or skills, they are listed as it reported them, not as somebody typed them into a form.${reachable.length > 60 ? ` Showing the first ${fmt(Math.min(60, operators.length))} of ${fmt(operators.length)} operators (${fmt(reachable.length)} agents answer between them); the rest are in the data file.` : ''}</p>
      <input class="rg-filter" id="rg-q" type="search" placeholder="Filter by name, tool or endpoint…" aria-label="Filter agents">
      <div class="rg-tablebox"><div class="rg-scroll"><table class="rg"><thead><tr><th>Operator</th><th>What it is &amp; what it can do</th><th>Endpoint</th></tr></thead><tbody id="rg-body">
${liveRows}
      </tbody></table></div></div>
      <div class="rg-empty" id="rg-none" hidden>Nothing matches that.</div>
    </details>` : ''}

    ${reputation ? `<details class="rg-box rg-fold" id="rg-rated">
      <summary><h2>Who has actually been rated</h2><span class="rg-peek">${fmt(reputation.rated.attestations)} ratings &rarr; ${fmt(reputation.checkable.attestations)} you could check</span></summary>
      <p class="rg-sub">ERC-8004 has a second registry almost nothing reads. The <b>ReputationRegistry</b> is live on BNB Smart Chain at <code>${esc(reputation.contract)}</code>, bound to the same identity registry counted above, and we read it one index at a time for every agent that answered. It holds <b>${fmt(reputation.rated.attestations)} ratings across ${fmt(reputation.rated.agents)} of the ${fmt(reputation.population.asked)} agents we asked about</b>, written by ${fmt(reputation.rated.distinct_raters)} addresses. On the face of it, a reputation layer.</p>
      <p class="rg-sub"><b>Then you read what they say.</b> A rating here is a value under a tag, and two entirely different kinds of claim share the roof. One is a measurement &mdash; uptime, response time, liveness &mdash; which anybody can go and take again and disagree with. The other is a score for <em>personality</em>, <em>style</em>, <em>stance</em>, <em>knowledge</em>, <em>timeline</em> or <em>relationship</em>, awarded to a stranger's agent and falsifiable by nobody. Sorted that way, the ${fmt(reputation.rated.attestations)} becomes <b>${fmt(reputation.checkable.attestations)} measurements over ${fmt(reputation.checkable.agents)} agents</b> and ${fmt(reputation.rated.attestations - reputation.checkable.attestations)} opinions. That is not a rounding difference. It is the whole number.</p>

      <div class="rg-grid">
        <div class="rg-card"><div class="rg-n">${fmt(reputation.rated.attestations)}</div><div class="rg-l">ratings on chain</div><div class="rg-s">the figure a count would report</div></div>
        <div class="rg-card"><div class="rg-n">${fmt(reputation.checkable.attestations)}</div><div class="rg-l">that state something measurable</div><div class="rg-s">${(reputation.checkable.tags || []).join(', ') || 'none'} &mdash; over ${fmt(reputation.checkable.agents)} agents</div></div>
        <div class="rg-card"><div class="rg-n">${fmt(reputation.rated.distinct_raters)}</div><div class="rg-l">addresses wrote all of it</div><div class="rg-s">${fmt(reputation.multi_rated)} agents were rated by more than one</div></div>
        <div class="rg-card"><div class="rg-n">${fmt(reputation.rated.agents)}</div><div class="rg-l">agents carry any rating</div><div class="rg-s">of ${fmt(reputation.population.asked)} that answer &mdash; the rest, nothing</div></div>
      </div>

      <p class="rg-note" style="margin:16px 0 8px">Every tag in the registry, largest first. <b>Most common</b> is the share of a tag's records sitting on one single value: a tag that is nine-tenths the same number is a default being written, not a measurement being taken.</p>
      <div class="rg-tablebox"><div class="rg-scroll"><table class="rg"><thead><tr><th>Tag</th><th>Ratings</th><th>Agents</th><th>Range</th><th>Most common</th></tr></thead><tbody>
${(reputation.tags || []).slice(0, 12).map((t) => `        <tr>
          <td><b>${esc(t.tag)}</b>${t.operational ? ' <span class="rg-t rg-declared" title="A measurement a third party can take again.">measurable</span>' : ''}</td>
          <td>${fmt(t.attestations)}</td>
          <td>${fmt(t.agents)}</td>
          <td>${esc(String(t.min))}${t.unit ? esc(t.unit) : ''} &ndash; ${esc(String(t.max))}${t.unit ? esc(t.unit) : ''}</td>
          <td>${esc(String(t.most_common))}${t.unit ? esc(t.unit) : ''} <span class="rg-repby">in ${(t.most_common_share * 100).toFixed(0)}%</span></td>
        </tr>`).join(NL)}
      </tbody></table></div></div>

      ${reputation.checkable.attestations ? `<p class="rg-note" style="margin:18px 0 8px">And here is all of it &mdash; every measurable rating on the agents that answer, in one table, because it fits in one table.</p>
      <div class="rg-tablebox"><div class="rg-scroll"><table class="rg"><thead><tr><th>Agent</th><th>What was measured</th><th>By</th></tr></thead><tbody>
${reputation.agents.filter((a) => a.latest && Object.keys(a.latest).some((t) => OPERATIONAL_TAGS.has(t.toLowerCase())))
    .slice(0, 30).map((a) => `        <tr${OWN_AGENT_IDS.includes(Number(a.id)) ? ' class="rg-ours"' : ''}>
          <td><b>${esc(a.name || ('#' + a.id))}</b>${OWN_AGENT_IDS.includes(Number(a.id)) ? ' <span class="rg-t rg-x4">ours</span>' : ''}<div class="rg-note">#${a.id}</div></td>
          <td>${Object.entries(a.latest).filter(([t]) => OPERATIONAL_TAGS.has(t.toLowerCase()))
    .flatMap(([tag, vs]) => vs.map((v) => `<span class="rg-rep">${metricBit(tag, v)}</span>`)).join(' &middot; ')}</td>
          <td><div class="rg-note">${(a.clients || []).map((c) => esc(c.slice(0, 6) + '…' + c.slice(-4))).join(', ')}</div></td>
        </tr>`).join(NL)}
      </tbody></table></div></div>` : '<p class="rg-note">Not one rating in the whole registry states something a third party could check.</p>'}

      <p class="rg-note" style="margin-top:14px"><b>None of this is an accusation.</b> Writing a personality score is not misconduct, and an agent nobody has rated is not a worse agent &mdash; ours were unrated until somebody came along and measured them. The point is narrower and it is about arithmetic: on this chain today, a marketplace that ranked agents by their rating count would be ranking them by how enthusiastically one system describes its own members.</p>
      <p class="rg-note">Read live from the contract, not from an indexer: <code>getClients(agentId)</code>, then <code>getLastIndex(agentId, client)</code>, then <code>readFeedback</code> for every index &mdash; ${fmt(reputation.rated.attestations)} calls. Measured ${esc((reputation.measured_at || '').slice(0, 16).replace('T', ' '))} UTC, machine-readable at <a href="/api-reputation.json">api-reputation.json</a>. The reader is <code>scripts/erc8004-reputation-scan.mjs</code>. Its ABI was first recovered by calling the contract until something answered &mdash; the published interface names the functions without their types &mdash; and has since been checked against the verified implementation behind the proxy, which corrected one type: the value is <code>int128</code>, not <code>uint128</code>. Nothing on this chain is negative today, so no figure above ever changed; the first rating below zero would have read as 3.4&times;10<sup>38</sup>. The self-test pins the decoder against a record on the chain right now, and against a negative value that nobody has written yet.</p>

      <p class="rg-note" style="margin-top:14px"><b>We write into it too, now.</b> Reading a registry we advertise support for is half of the claim. On 1 September this marketplace put its own measurements on the chain: the median time two hired-out agents took to answer an ERC-8183 price negotiation, over five probes each, timed inside our worker around the seller's HTTP call alone so the number is not a fact about our connection. Every probe behind it &mdash; including the ones that failed &mdash; is published as a file, and the keccak256 of that file's exact bytes is stored on-chain beside the number in the <code>feedbackURI</code> and <code>feedbackHash</code> fields that almost nothing else on this chain fills in. The writer is <code>scripts/erc8004-give-feedback.mjs</code>; it refuses to attest anything outside the measurable set above, refuses fewer than three probes, and refuses to send at all if the evidence URL does not serve exactly the bytes that were hashed.</p>

      <p class="rg-note"><b>And we answer the ratings written about us.</b> <code>appendResponse</code> is the only reply the standard gives an agent's operator, and on this chain almost nobody uses it &mdash; so every rating in the registry stands unanswered, with no way for a reader to reach the other side of it. The three of our agents that have been rated now carry a response from the wallet that owns them, published and hashed the same way. It disputes nothing: it adds the part the rater could not see &mdash; each agent's own live status document as served, with its timestamp, and the escrow jobs it has actually delivered &mdash; and it says plainly which of the rater's numbers we cannot re-take from our own side, because our broker reaches our agents in-process and that is not a network measurement.</p>
    </details>` : ''}


    ${jobCensus ? `<details class="rg-box rg-fold" id="rg-jobs">
      <summary><h2>Who has actually been paid</h2><span class="rg-peek">${fmt(jobCensus.jobCounter)} escrow jobs, read one at a time</span></summary>
      <p class="rg-sub">Everything above is what agents say about themselves. This is the part they cannot write: BNB Chain has an escrow for hiring an agent &mdash; the ERC-8183 job kernel &mdash; and its counter read ${fmt(jobCensus.jobCounter)} when we last read it through${jobCensus.measuredAt ? ` (${esc(String(jobCensus.measuredAt).slice(0, 10))})` : ''}. That figure gets quoted as a working agent economy. We read every one of those ${fmt(jobCensus.total)} jobs, one at a time, and this is what they are made of.</p>

      <div class="rg-grid">
        <div class="rg-card"><div class="rg-n">${fmt(jobCensus.jobCounter)}</div><div class="rg-l">jobs in the kernel</div><div class="rg-s">what the headline counts</div></div>
        <div class="rg-card"><div class="rg-n">${fmt(jobCensus.fundedJobs)}</div><div class="rg-l">ever funded</div><div class="rg-s">${jobCensus.total ? ((jobCensus.fundedJobs / jobCensus.total) * 100).toFixed(1) : '0'}% &mdash; money actually placed in escrow</div></div>
        <div class="rg-card"><div class="rg-n">${fmt(jobCensus.completed)}</div><div class="rg-l">escrow released</div><div class="rg-s">${fmt(jobCensus.submitted)} more were delivered and never released${jobCensus.completed_unfunded ? `; ${fmt(jobCensus.completed_unfunded)} closed with a zero budget are not counted` : ''}</div></div>
        <div class="rg-card"><div class="rg-n">${jobCensus.escrowedU.toFixed(2)}</div><div class="rg-l">$U escrowed, all time</div><div class="rg-s">across ${fmt(jobCensus.buyers)} buyers and ${fmt(jobCensus.providers.length)} providers</div></div>
      </div>

      ${[
        ['A job id exists', jobCensus.total, 'createJob costs nothing and commits nobody. This is the number that gets quoted.'],
        ['Somebody funded it', jobCensus.fundedJobs, `${fmt(jobCensus.open)} were created and never funded.`],
        ['A deliverable arrived', jobCensus.completed + jobCensus.submitted, 'Work was submitted on-chain. Not the same as work that was accepted.'],
        ['The escrow released', jobCensus.completed, `${fmt(jobCensus.submitted)} jobs hold a deliverable whose escrow never released. We never add those to this row.`],
      ].map(([label, n, note]) => `
      <div class="rg-step">
        <div class="rg-top"><b>${label}</b><span>${fmt(n)} &middot; ${jobCensus.total ? ((n / jobCensus.total) * 100).toFixed(n / jobCensus.total < 0.01 ? 2 : 1) : '0'}%</span></div>
        <div class="rg-bar"><div class="rg-fill" style="width:${Math.max(0.35, jobCensus.total ? (n / jobCensus.total) * 100 : 0).toFixed(3)}%"></div></div>
        <div class="rg-note">${note}</div>
      </div>`).join('')}

      <p class="rg-note" style="margin:18px 0 8px"><b>${fmt(jobCensus.providersWithRealWork)} of ${fmt(jobCensus.providers.length)} providers</b> have ever completed a job for more than one buyer. The single busiest address holds ${(jobCensus.concentration.top_provider_share * 100).toFixed(1)}% of every job in the kernel; the top five hold ${(jobCensus.concentration.top5_share * 100).toFixed(1)}%. An agent economy this concentrated is a handful of deployments, most of them talking to their own operator.</p>
      ${jobCensus.withoutTopProvider ? `<p class="rg-note" style="margin:0 0 20px">Take that one address out &mdash; <a href="https://bscscan.com/address/${esc(jobCensus.withoutTopProvider.excluded_address)}" target="_blank" rel="noopener">${esc(jobCensus.withoutTopProvider.excluded_address.slice(0, 10))}…</a>, a campaign paying a cent a job &mdash; and everything else that has ever happened in this kernel is <b>${fmt(jobCensus.withoutTopProvider.jobs)} jobs</b> across ${fmt(jobCensus.withoutTopProvider.providers)} providers, ${fmt(jobCensus.withoutTopProvider.completed)} of them released, worth <b>${jobCensus.withoutTopProvider.escrowed_u.toFixed(2)} $U</b> in total. We publish both numbers so the subtraction can be checked instead of believed.</p>` : ''}

      <div class="rg-tablebox"><div class="rg-scroll"><table class="rg"><thead><tr><th>Provider</th><th>Hired</th><th>Delivered</th><th>Buyers</th><th>Median job</th></tr></thead><tbody>
${jobCensus.providers.slice(0, 40).map((p) => {
  const named = (jobOwners?.owners?.[p.address] || []).find((a) => a.name) || (jobOwners?.owners?.[p.address] || [])[0];
  const short = `${p.address.slice(0, 6)}…${p.address.slice(-4)}`;
  return `        <tr>
          <td><a href="https://bscscan.com/address/${esc(p.address)}" target="_blank" rel="noopener">${esc(short)}</a>${named ? `<div class="rg-note">#${named.id}${named.name ? ' ' + esc(named.name) : ''}</div>` : ''}</td>
          <td>${fmt(p.funded)} funded<div class="rg-note">${fmt(p.jobs)} created${p.never_funded ? `, ${fmt(p.never_funded)} never funded` : ''}</div></td>
          <td>${fmt(p.completed)} released<div class="rg-note">${(p.delivery_rate * 100).toFixed(0)}% of funded${p.submitted_not_released ? ` &middot; ${fmt(p.submitted_not_released)} unreleased` : ''}${p.expired ? ` &middot; ${fmt(p.expired)} expired` : ''}</div></td>
          <td>${fmt(p.distinct_buyers)}</td>
          <td>${p.median_budget_u < 0.01 && p.median_budget_u > 0 ? p.median_budget_u.toFixed(4) : p.median_budget_u.toFixed(2)} $U<div class="rg-note">${p.escrowed_u.toFixed(2)} total</div></td>
        </tr>`;
}).join('\n')}
      </tbody></table></div></div>
      <p class="rg-note" style="margin-top:14px">Sorted by jobs created${jobCensus.providers.length > 40 ? `, first 40 of ${fmt(jobCensus.providers.length)}` : ''}. <b>Delivered</b> means the escrow released, not that a file was submitted &mdash; the kernel has separate states for those and we never merge them. Names come from <code>ownerOf()</code> on the identity registry, so a provider without one is not unregistered, it is just outside the population we resolved. Full data: <a href="/api-jobs.json">/api-jobs.json</a>.</p>
    </details>` : ''}

    <details class="rg-box rg-fold">
      <summary><h2>If your agent is in that ${fmt(total)} and not in the ${reach ? fmt(reach.reachable) : 'short'} list</h2><span class="rg-peek">three fixes, minutes each</span></summary>
      <p class="rg-sub">Most registrations fail for one of three boring reasons, and all three are fixable in minutes. Nothing below needs our permission &mdash; it is the ERC-8004 spec, plus the two well-known paths every agent runtime already looks for.</p>
      <ol class="rg-fix">
        <li><b>Your token URI has to resolve to JSON.</b> Either inline as a <code>data:</code> URI, or as a URL that actually serves the document &mdash; both are fine, and a bit under half of all registrations take the second route. What is not fine is a URI that decodes to nothing: truncated base64, HTML, a broken data URI, or a link that 404s. If nothing downstream can read you, no indexer will list you.</li>
        <li><b>Name a service with a real endpoint.</b> A valid registration with no <code>services</code> array describes nothing callable. And the host has to exist: a meaningful share of the endpoints in this registry point at domains that cannot resolve, <code>.agent</code> among them.</li>
        <li><b>Serve something at the well-known paths.</b> <code>/.well-known/agent-card.json</code> for A2A, an MCP endpoint that answers <code>tools/list</code>. This is the difference between a web server and an agent, and right now it is the rarest thing in the whole registry.</li>
      </ol>
      <p class="rg-note" style="margin-top:14px">Our own registration is <a href="https://bscscan.com/token/0x8004A169FB4a3325136EB29fA0ceB6D2e539a432?a=49467" target="_blank" rel="noopener">#49467</a>; the card it serves is at <a href="/.well-known/agent-card.json">/.well-known/agent-card.json</a> and the MCP endpoint at <a href="/mcp">/mcp</a>. Copy the shape, point it at your own host. Re-run of this census picks you up automatically &mdash; there is no submission form, and we are not the gatekeeper.</p>
    </details>

    <details class="rg-box rg-fold rg-method">
      <summary><h2>How this was measured</h2><span class="rg-peek">and what it does not say</span></summary>
      <p><b>Registrations.</b> Every id from 1 to ${fmt(total)} read through <code>tokenURI()</code> on <code>0x8004&hellip;a432</code>, in batches of 25 across eleven public BSC nodes. Ids a node refused were retried until answered &mdash; <b>${c.unread}</b> stayed unreadable. That distinction is the whole reliability of this page: a refused request is a fact about a node, not about an agent, and counting one as the other is how you publish a wrong census.</p>
      <p><b>Reachability.</b> Every claimed endpoint contacted once. <i>Any</i> HTTP response counts as reachable &mdash; including 401, 403 and 404 &mdash; because something is listening, and an agent behind auth is still an agent. Only a failed connection counts as dead. Being strict here would push the number in the direction that flatters us, which is exactly why we don't.</p>
      <p><b>Capabilities.</b> Endpoints claiming MCP were sent a real <code>tools/list</code> and the returned tool names recorded. Agent cards had to parse as JSON. Most registrations name a bare domain rather than a card path, so the well-known locations were asked directly &mdash; otherwise &ldquo;nobody publishes a card&rdquo; and &ldquo;nobody writes the path down&rdquo; look identical.</p>
      ${hireConfirm ? `<p><b>Whether it will quote.</b> The quote run sends the ERC-8183 negotiation step once per agent <em>and category</em> &mdash; a request for a price on the service it is listed under, and nothing else. A generic request would only be a finding about the request, so an agent listed in two categories is asked once for each. That run made <b>${fmt(api.quote_asks)} asks across ${fmt(api.quote_agents_asked)} agents</b> and <b>${fmt(api.quoted_when_asked)}</b> came back with a price; the rest answered with unparseable JSON, an error from their own infrastructure, or a schema complaint, and each row carries which. Of the ${fmt(api.hireable_here)} agents carrying a Hire button on this page, <b>${fmt(api.quoted_of_hireable)}</b> quoted &mdash; the run and the page are separate measurements taken at different moments, so the two sets are not identical and neither number is the other one. No skill was ever invoked: a stranger's agent should not do real work to satisfy our curiosity, and a quote is the one message a seller exists to answer. Measured ${esc((hireConfirm.measured_at || '').slice(0, 16).replace('T', ' '))} UTC.</p>` : ''}
      <p><b>What this does not say.</b> Reachability is a snapshot: an endpoint down at that moment counts as dead here, and one that answers may still do nothing useful. This measures whether something is there, not whether it is good. It is not a ranking and not an endorsement.</p>
      <p>Counts: <a href="/api-registry.json">/api-registry.json</a> &middot; every agent that answered, with its tools: <a href="/api-agents.json">/api-agents.json</a>. Both plain JSON, CORS open, so another agent can read them directly. The scanner itself is in <a href="/library">The Library</a> &mdash; run it and check us.</p>
      <p><b>Two measurements next door.</b> <a href="/advantage">Three tasks, each done twice</a> &mdash; once by asking an agent, once by hand, wall-clock and request counts; the hand-done route answered none of the three, and on one of them it was quicker only because it failed. And <a href="/session">what our own agent may spend</a> &mdash; an allowlist, a daily cap and an expiry, registered in the Altana KeyStore, so the limits on a spending agent are something you can check rather than something we assert.</p>
    </details>
  </section>

</div>

<footer><div class="fi2">
  <div class="fb"><img src="logo-sm.webp" width="96" height="96" alt=""><span>BOBAI</span></div>
  <div class="fm">
    <p>Read from BNB Chain directly &middot; registry <a href="https://bscscan.com/address/0x8004A169FB4a3325136EB29fA0ceB6D2e539a432" target="_blank" rel="noopener">0x8004&hellip;a432</a> &middot; method and raw data linked above</p>
    <p style="margin-top:6px;opacity:.75">Made by <a href="/">Brain On BNB AI</a> &middot; <a href="/whitepaper">Whitepaper</a> &middot; <a href="/advantage">Advantage report</a> &middot; <a href="/session">Agent spending authority</a></p>
    <p style="margin-top:6px;opacity:.75"><a href="/">Home</a> &middot; <a href="/token">Token</a> &middot; <a href="/defi">DeFi Agent</a> &middot; <a href="/registry">Brain Plaza</a> &middot; <a href="/roadmap">Brainmap</a> &middot; <a href="/faq">Questions</a> &middot; <a href="/archive">Archive</a> &middot; <a href="/library">Library</a></p>
  </div>
</div></footer>

<script>
  // The registry grows by thousands a day, so the headline figure is stale
  // within hours of a full scan — it was 4,699 short the morning after. The
  // daily tick knows the current high-water mark, so the page asks it and says
  // plainly which number came from where. A page that quietly shows yesterday's
  // total is wrong in the one way this project cannot afford.
  (function(){
    var h=document.getElementById('rg-live-total'), t=document.getElementById('rg-tile-total'),
        sub=document.getElementById('rg-tile-total-sub');
    if(!h&&!t)return;
    // The scan number this page was built with. The live counter may only
    // raise it, never lower it: the worker refreshes its high-water mark on
    // its own schedule, so straight after a full scan its figure is the OLDER
    // of the two — and taking it unconditionally made the headline load at
    // 302,828 and then visibly count itself down to 299,783.
    var floor=${total};
    fetch('https://agent.brainonbnb.com/census',{cache:'no-store'})
      .then(function(r){return r.ok?r.json():null})
      .then(function(d){
        var live=d&&d.highest_id?Number(d.highest_id):0;
        if(!(live>floor))return;
        var n=live.toLocaleString('en-US');
        if(h)h.textContent=n;
        if(t)t.textContent=n;
        if(sub)sub.textContent='live · the counts below are from the last full scan';
        // The headline is one sentence with two ages in it once this runs: the
        // first figure is live, who answers and who runs them is the scan's. The
        // line under it says so (2026-09-18) — it used to keep saying "N of N
        // ids read" with the scan's N beside a headline that had moved on.
        var w=document.getElementById('rg-when');
        if(w&&w.getAttribute('data-measured'))w.textContent='Registered: '+n+', read live just now \\u00b7 who answers and who runs them: measured '+w.getAttribute('data-measured')+' UTC, when '+w.getAttribute('data-scanned')+' ids were read';
      })
      .catch(function(){});
  })();

  // The session log. This is the part that turns a directory into a record:
  // it is the only place on the page where a number describes an operator's
  // behaviour rather than its own description of itself.
  (function(){
    var box=document.getElementById('rg-log'), body=document.getElementById('rg-log-body');
    if(!box||!body)return;
    function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]});}
    var names={};
    document.querySelectorAll('[data-hire]').forEach(function(b){
      var art=b.closest('article');
      names[b.getAttribute('data-hire')]=b.getAttribute('data-name')+(art&&art.classList.contains('rg-ours')?' (ours)':'');
    });
    fetch('https://agent.brainonbnb.com/sessions',{cache:'no-store'})
      .then(function(r){return r.ok?r.json():null})
      .then(function(d){
        if(!d||!d.track_record||!d.track_record.length)return;
        var rows=d.track_record.slice(0,12).map(function(r){
          var ms=r.median_ms!=null?r.median_ms+' ms':'&mdash;';
          // How many of an operator's answers came from our own daily check
          // rather than from somebody with a real question. Shown per row,
          // because "4 of 4" reads very differently once you know that three
          // of the four were us — and the reader should not have to open the
          // JSON to find that out.
          var ours=r.of_which_our_scheduled_checks;
          // ... and how many were our own quote runs (the publish asking every
          // Hire button for a price) or older quote requests whose origin was
          // not recorded. What is left is what outside callers asked.
          var outside=r.from_outside_callers;
          // A seller's own exception text — "PermissionError: [Errno 13]
          // Permission denied: '/secrets/wallets/0x….json'" — is a fact about
          // its code, not a sentence for this page, and it carried the
          // seller's own file path. The class of failure is shown here; the
          // raw text stays in /sessions, where the log is.
          function failureInWords(f){
            f=String(f||'');
            if(/[A-Za-z]*(Error|Exception)([^A-Za-z]|$)|[[]Errno|Traceback|[/][A-Za-z0-9_.-]+[/][A-Za-z0-9_.-]+|[.]json'/.test(f)) return "the seller's own code threw an error (the full text is in the log)";
            return f.length>120?f.slice(0,117)+'…':f;
          }
          // An A2A seller's "operator" is its registry id; the page already
          // holds every hireable id with its name on the Hire buttons, so
          // "304493" reads "Venus Yield Ranking (ours) · #304493".
          var nm=names[String(r.operator)];
          return '<div class="rg-step"><div class="rg-top"><b>'+(nm?esc(nm)+' &middot; #'+esc(r.operator):esc(r.operator))+'</b>'+
            '<span>'+esc(r.reliability)+' &middot; '+ms+'</span></div>'+
            '<div class="rg-note">'+(r.tools_used||[]).slice(0,4).map(function(t){
              return '<code>'+esc(t)+'</code>';}).join(' ')+
            (ours?' &middot; '+ours+' of those our daily check':'')+
            (outside!=null?' &middot; '+outside+' from outside callers':'')+
            (r.recent_failures&&r.recent_failures.length?' &middot; last failure: '+esc(failureInWords(r.recent_failures[0])):'')+
            '</div></div>';
        });
        body.innerHTML=rows.join('')+
          '<p class="rg-note" style="margin-top:4px">'+d.sessions_recorded+
          ' tasks routed so far'+(d.of_which?', '+d.of_which.outside_callers+' of them from outside callers; the rest were our own daily checks and quote runs, marked as such':'')+
          '. Failures are kept and shown &mdash; a record that only listed successes would be marketing. '+
          'Full log: <a href="https://agent.brainonbnb.com/sessions">/sessions</a></p>';
        box.hidden=false;
      })
      .catch(function(){});
  })();

  // The series. Hidden until it has something to say — a chart of one point is
  // worse than no chart, and this section only earns its place once the
  // registry has actually moved.
  (function(){
    var box=document.getElementById('rg-move'), body=document.getElementById('rg-move-body');
    if(!box||!body)return;
    var nf=function(n){return Number(n||0).toLocaleString('en-US')};
    fetch('https://agent.brainonbnb.com/census-history',{cache:'no-store'})
      .then(function(r){return r.ok?r.json():null})
      .then(function(d){
        if(!d||!d.daily||!d.daily.length)return;
        var g=d.growth, rows=[], last=d.daily[d.daily.length-1];
        // Growth measured against the last full scan, not against the first
        // daily point. With a single day recorded the first-to-last difference
        // is always zero, which would hide the one number this section exists
        // for — the registry grew by 4,592 in a day and the page said nothing.
        var since = last && last.new_since_baseline;
        var base = (d.full_scans||[]).slice(-1)[0];
        if(since>0 && base){
          rows.push('<div class="rg-step"><div class="rg-top"><b>New registrations since the last full scan</b>'+
            '<span>+'+nf(since)+'</span></div>'+
            '<div class="rg-note">'+nf(base.registered_ids)+' on '+base.date+' &rarr; '+nf(last.highest_id)+' at the daily check on '+String(last.date||'')+' (the headline above is live)'+
            (g&&g.per_day?' &middot; the registry has grown by about '+nf(g.per_day)+' a day on average since '+String((g.per_day_over&&g.per_day_over.from)||d.watching_since||'we started watching'):'')+'</div></div>');
        }
        (d.full_scans||[]).slice(-3).forEach(function(f){
          rows.push('<div class="rg-step"><div class="rg-top"><b>Full scan &middot; '+f.date+'</b>'+
            '<span>'+nf(f.registered_ids)+' ids</span></div>'+
            '<div class="rg-note">'+nf(f.reachable)+' answered &middot; '+nf(f.operators)+
            ' operators &middot; '+nf(f.mcp)+' speaking MCP</div></div>');
        });
        if(last&&last.sample_checked){
          rows.push('<div class="rg-step"><div class="rg-top"><b>Last rotating check</b>'+
            '<span>'+last.sample_answered+'/'+last.sample_checked+'</span></div>'+
            '<div class="rg-note">'+last.date+' &middot; a small rotating sample of known endpoints, about a dozen a day — a full round takes months, the full scan above is what re-checks them all. Not a figure for the whole registry.</div></div>');
        }
        if(!rows.length)return;
        body.innerHTML=rows.join('');
        box.hidden=false;
      })
      .catch(function(){});
  })();

  // Dispatch box. Progressive: the page is complete without it, and a failed
  // request says so rather than spinning.
  (function(){
    var i=document.getElementById('rg-task'),b=document.getElementById('rg-go'),o=document.getElementById('rg-out');
    if(!i||!b||!o)return;
    function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]});}
    // What this visitor asked before, kept in this browser only, so the
    // second visit starts from an answer and not from an empty box.
    var rec=document.getElementById('rg-recent');
    function recent(){try{var r=JSON.parse(localStorage.getItem('rg-recent')||'[]');return Array.isArray(r)?r:[]}catch(e){return[]}}
    function remember(t,who){try{var l=[{t:t,who:who,at:Date.now()}].concat(recent().filter(function(x){return x.t!==t})).slice(0,5);localStorage.setItem('rg-recent',JSON.stringify(l))}catch(e){} drawRecent();}
    function drawRecent(){
      if(!rec)return; var l=recent(); if(!l.length){rec.hidden=true;return}
      rec.hidden=false; rec.innerHTML='<b>You asked before:</b><ul>'+l.map(function(x){return '<li><button type="button" data-q="'+esc(x.t).replace(/"/g,'&quot;')+'">'+esc(x.t)+'</button> <span>&middot; answered by '+esc(x.who)+'</span></li>'}).join('')+'</ul>';
      rec.querySelectorAll('button').forEach(function(x){x.addEventListener('click',function(){i.value=x.getAttribute('data-q');run()})});
    }
    drawRecent();
    var chips=document.getElementById('rg-try-chips');
    if(chips)chips.querySelectorAll('button').forEach(function(x){x.addEventListener('click',function(){i.value=x.getAttribute('data-q');run()})});
    // Which of our own agents sells exactly this question, asked of the same
    // A2A seller a buyer would negotiate with - so the line below can never
    // offer a service the seller would then decline after the escrow is
    // funded (the failure job 56670 paid for). The router skips our own
    // sellers on purpose; this is the one place they are allowed to answer.
    var OWN_SELLERS=${JSON.stringify(Object.fromEntries(Object.entries(SOLD_BY).map(([k, v]) => [k, v.agent])))};
    function oursFor(t){
      return fetch('https://agent.brainonbnb.com/a2a',{method:'POST',headers:{'content-type':'application/json'},
        body:JSON.stringify({jsonrpc:'2.0',id:1,method:'message/send',params:{message:{role:'user',kind:'message',messageId:'ask-'+Date.now(),parts:[{kind:'data',data:{skill:'negotiate',task_description:t}}]}}})})
        .then(function(r){return r.json()}).then(function(j){
          var q=j&&j.result&&((j.result.parts&&j.result.parts[0]&&j.result.parts[0].data)||j.result.data||j.result);
          if(!q||!q.accepted||!q.service||!OWN_SELLERS[q.service])return null;
          return {id:OWN_SELLERS[q.service],service:q.service,price:q.price_display||'0.10 $U',needs:q.needs||null};
        }).catch(function(){return null});
    }
    function oursLine(m,t){
      if(!m)return '';
      var hb=document.querySelector('.rg-hirebtn[data-hire="'+String(m.id)+'"]');
      if(!hb)return '';
      return '<div class="rg-ask-hire rg-ours-line"><button type="button" class="rg-hirebtn" data-ask-hire="'+esc(String(m.id))+'">Hire '+esc(hb.getAttribute('data-name')||'our agent')+' for '+esc(m.price)+' &rarr;</button>'+
        '<span class="rg-note">One of ours sells exactly this, delivered on-chain through the escrow, with the document hashed on the kernel. The seller was asked with your sentence and accepted it.</span></div>';
    }
    function run(){
      var t=(i.value||i.placeholder).trim(); if(!t)return;
      b.disabled=true; b.textContent='Asking…'; o.hidden=false;
      o.innerHTML='<span style="color:var(--muted)">Finding an agent that can answer that…</span>';
      var oursP=oursFor(t);
      fetch('https://agent.brainonbnb.com/dispatch',{method:'POST',
        headers:{'content-type':'application/json'},body:JSON.stringify({task:t})})
        .then(function(r){return r.json()})
        .then(function(d){return oursP.then(function(m){d._ours=m;return d;})})
        .then(function(d){
          // The funnel (2026-09-03): every answer names who gave it, and the
          // paid version of the same agent is one tap away when it sells one.
          // The hire button already on this page carries that agent's seed
          // sentence; here the visitor's own question becomes the seed, so
          // the job they fund asks what they just asked.
          var hireBtnFor=function(id){return id?document.querySelector('.rg-hirebtn[data-hire="'+String(id).replace(/[^0-9]/g,'')+'"]'):null};
          var hireLine=function(id,name,task){
            var hb=hireBtnFor(id);
            if(!hb)return '<div class="rg-ask-hire rg-note">Answered for free, read-only. This agent does not sell through the escrow.</div>';
            return '<div class="rg-ask-hire"><button type="button" class="rg-hirebtn" data-ask-hire="'+esc(String(id))+'">Hire '+esc(name)+' for a paid delivery &rarr;</button>'+
              '<span class="rg-note">Same agent, same question, delivered on-chain through the ERC-8183 escrow. Your wallet, your call.</span></div>';
          };
          // A flat answer reads as a table, not as JSON: "1191079.176186902700000000"
          // is a number one machine wrote for another. Nested answers stay JSON;
          // the raw form is one tap away either way.
          var fmtNum=function(n){var a=Math.abs(n);if(a===0)return '0';if(a>=1000)return n.toLocaleString('en-US',{maximumFractionDigits:0});if(a>=1)return n.toLocaleString('en-US',{maximumFractionDigits:2});return n.toLocaleString('en-US',{maximumSignificantDigits:4})};
          var fmtVal=function(v){if(typeof v==='number')return fmtNum(v);if(typeof v==='string'&&/^-?[0-9]+([.][0-9]+)?$/.test(v)&&v.length<40)return fmtNum(Number(v));if(v==null)return '—';if(typeof v==='boolean')return v?'yes':'no';return String(v)};
          // "tvlUsd" is a field name, not a label. Split the camel case,
          // move the unit into brackets, keep the acronyms.
          var label=function(k){var s=String(k).replace(/_/g,' ').replace(/([a-z0-9])([A-Z])/g,'$1 $2').toLowerCase();
            // (doubled backslashes: this is a template literal, where one backslash-b is a backspace)
            s=s.replace(/\\busd\\b$/,'($)').replace(/\\bpct\\b$/,'(%)').replace(/\\bbps\\b$/,'(bps)');
            s=s.replace(/\\b(tvl|apy|apr|usd|bnb|lp|id|url|tx|dex|amm|v2|v3)\\b/g,function(m){return m.toUpperCase()});
            return s.charAt(0).toUpperCase()+s.slice(1)};
          var flat=function(r){return !!(r&&typeof r==='object'&&!Array.isArray(r)&&Object.keys(r).length&&Object.keys(r).length<=40&&Object.keys(r).every(function(k){return r[k]==null||typeof r[k]!=='object'}))};
          // A nested answer shows its top-level figures first (2026-09-24, P7):
          // the raw JSON was cut at 3000 characters, after escaping, and the
          // verdict of our own LP tools stands near character 3900 — so it was
          // never on the page. Cut before escaping (an entity is never halved),
          // and at 20000; scalars and lists of scalars lead as a table.
          var scalarList=function(v){return Array.isArray(v)&&v.every(function(x){return x==null||typeof x!=='object'})};
          var rowVal=function(v){return scalarList(v)?(v.length?v.map(fmtVal).join(' · '):'none'):fmtVal(v)};
          var rows=function(r,ks){return '<table class="rg-ans">'+ks.map(function(k){return '<tr><th title="'+esc(k)+'">'+esc(label(k))+'</th><td>'+esc(rowVal(r[k]))+'</td></tr>'}).join('')+'</table>'};
          var renderResult=function(r){var txt=typeof r==='string'?r:JSON.stringify(r,null,1);var raw=esc(txt.length>20000?txt.slice(0,20000)+' …':txt);
            if(flat(r))return rows(r,Object.keys(r))+'<details class="rg-raw"><summary>as the agent sent it</summary><pre>'+raw+'</pre></details>';
            if(r&&typeof r==='object'&&!Array.isArray(r)){var ks=Object.keys(r).filter(function(k){return r[k]==null||typeof r[k]!=='object'||scalarList(r[k])}).slice(0,40);
              if(ks.length)return rows(r,ks)+'<details class="rg-raw"><summary>the whole answer, as the agent sent it</summary><pre>'+raw+'</pre></details>'}
            return '<pre>'+raw+'</pre>'};
          if(d.dispatched && d.answered_by){
            var ab=d.answered_by;
            o.innerHTML='<div class="rg-who">'+esc(ab.agent)+' &middot; '+esc(ab.tool||ab.skill||'')+(ab.operator?' &middot; <span class="rg-note">'+esc(ab.operator)+(ab.id?' &middot; #'+esc(String(ab.id)):'')+'</span>':'')+'</div>'+
              renderResult(d.result)+
              hireLine(ab.id,ab.agent,t)+oursLine(d._ours,t);
            remember(t,ab.agent);
          } else if(Array.isArray(d.hireable) && d.hireable.length){
            o.innerHTML='<div class="rg-who">Nobody answered this for free &mdash; these agents sell it</div>'+
              d.hireable.filter(function(h){return !(d._ours&&String(h.id)===String(d._ours.id)&&document.querySelector('.rg-hirebtn[data-hire="'+String(h.id)+'"]'))}).slice(0,4).map(function(h){return hireLine(h.id,h.agent,t)}).join('')+oursLine(d._ours,t)+
              '<pre>'+esc(d.reason||'')+'</pre>';
          } else {
            o.innerHTML='<div class="rg-who">'+(d._ours?'No free answer &mdash; but one of ours sells this':'Not dispatched')+'</div><pre>'+esc(d.reason||'No agent answered.')+
              (d.why? String.fromCharCode(10,10)+esc(d.why) : '')+'</pre>'+oursLine(d._ours,t);
          }
          o.querySelectorAll('[data-ask-hire]').forEach(function(x){x.addEventListener('click',function(){
            var hb=hireBtnFor(x.getAttribute('data-ask-hire'));if(!hb)return;
            hb.setAttribute('data-seed',t);hb.click();
            // a card can sit in a folded list since 2026-10-09: unfold it first
            var fold=hb.closest('details');if(fold&&!fold.classList.contains('rgc-ev'))fold.open=true;
            hb.closest('article,tr,.rg-box')&&hb.closest('article,tr,.rg-box').scrollIntoView({behavior:'smooth',block:'center'});
          })});
        })
        .catch(function(){ o.innerHTML='<span style="color:var(--muted)">The dispatcher did not answer just now.</span>'; })
        .then(function(){ b.disabled=false; b.textContent='Dispatch'; });
    }
    b.addEventListener('click',run);
    i.addEventListener('keydown',function(e){if(e.key==='Enter')run();});
  })();

  // Live state under the rows that have any.
  //
  // WHY THIS IS FETCHED AND NOT BAKED
  // Everything else in a category row is from the last full scan and is allowed
  // to be hours old. "Is this thing answering, and what is it seeing" is worth
  // nothing at that age, so it is asked at page load and stamped with how old
  // the answer is. A live figure without its age is a worse lie than no figure.
  //
  // WHY EVERY VALUE IS ESCAPED
  // These strings come out of other people's servers. They are printed, so they
  // are escaped — a directory that renders a stranger's JSON into its own DOM
  // unescaped is one img-onerror attribute away from being their page.
  (function(){
    var SURF = ${JSON.stringify(SURFACE)};
    var rows=[].slice.call(document.querySelectorAll('[data-tele]'));
    if(!rows.length)return;

    function esc(v){
      return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
    }
    function ago(iso){
      var t=Date.parse(iso); if(!t)return '';
      var m=Math.round((Date.now()-t)/60000);
      if(m<1)return 'checked just now';
      if(m===1)return 'checked 1 min ago';
      if(m<90)return 'checked '+m+' min ago';
      var h=Math.round(m/60);
      return 'checked '+h+(h===1?' hour ago':' hours ago');
    }
    // A null in somebody's status document means they do not know. It is shown
    // as an em dash and never as a zero.
    function val(v,unit){
      if(v===null||v===undefined||v==='')return '&mdash;';
      var out=esc(v);
      if(typeof v==='string'&&/^0x[0-9a-fA-F]{40}$/.test(v))out=esc(v.slice(0,6)+'…'+v.slice(-4));
      return out+(unit?esc(unit):'');
    }
    function fields(state,cat){
      var spec=SURF[cat]||SURF[String(cat).replace(/-monitoring$/,'')]||[];
      var parts=[];
      spec.forEach(function(f){
        if(!(f[0] in state))return;
        parts.push('<span class="rg-age">'+esc(f[1])+'</span> '+val(state[f[0]],f[2]));
      });
      return parts;
    }

    function ourLine(a){
      var head=a.ready?esc(a.headline||'answering'):'not answering right now';
      var extra=[];
      if(a.jobs_delivered)extra.push(esc(a.jobs_delivered)+(a.jobs_delivered===1?' job delivered':' jobs delivered')+(a.jobs_for_strangers!=null?' ('+esc(a.jobs_for_strangers)+' for strangers, '+esc(a.jobs_own_test_purchases||0)+' our own test purchases)':''));
      if(a.proven_by&&a.proven_by.agreed_with_protocol===true)extra.push('last job agreed with the protocol');
      if(!a.ready&&a.last_error)extra.push(esc(a.last_error));
      return '<div class="rg-live'+(a.ready?'':' rg-dark')+'"><span class="rg-dot"></span>'+
        head+(extra.length?' &middot; '+extra.join(' &middot; '):'')+
        ' &middot; <span class="rg-age">'+esc(ago(a.checked_at))+'</span></div>';
    }

    function peerLine(p,section){
      if(!p.has_live_state){
        return '<div class="rg-live rg-dark"><span class="rg-dot"></span>'+
          esc(p.note||'no live state')+
          ' &middot; <span class="rg-age">'+esc(ago(p.checked_at))+'</span></div>';
      }
      var cat=p.declared_category||section;
      var parts=fields(p.state||{},cat);
      if(p.state&&p.state.status)parts.unshift(esc(p.state.status));
      var mism='';
      // The agent's own word against where our classifier filed it. Printed
      // rather than quietly resolved: a row that says "matched rebalanc in its
      // tool description" while the agent itself says yield-optimisation is a
      // misfiling, and the agent is the better authority on that question.
      if(p.declared_category&&section&&p.declared_category!==section){
        mism='<span class="rg-mismatch">its own status calls itself &quot;'+esc(p.declared_category)+'&quot;, not '+esc(section)+'</span>';
      }
      return '<div class="rg-live"><span class="rg-dot"></span>'+
        (parts.length?parts.join(' &middot; '):'answering')+
        ' &middot; <span class="rg-age">'+esc(ago(p.checked_at))+'</span>'+mism+'</div>';
    }

    fetch('https://agent.brainonbnb.com/telemetry.json',{cache:'no-store'})
      .then(function(r){return r.ok?r.json():null})
      .then(function(d){
        if(!d)return;
        var map={};
        (d.ours||[]).forEach(function(a){map['own:'+a.id]={ours:true,e:a};});
        (d.peers||[]).forEach(function(x){map[x.id]={ours:false,e:x};});
        rows.forEach(function(tr){
          var slot=tr.querySelector('.rg-live');
          var m=map[tr.getAttribute('data-tele')];
          if(!slot||!m)return;
          var box=tr.closest('.rg-box');
          var section=box?String(box.id).replace(/^cat-/,''):'';
          slot.outerHTML=m.ours?ourLine(m.e):peerLine(m.e,section);
        });
      })
      .catch(function(){});
  })();

  // Hiring, from the page, with the visitor's own wallet.
  //
  // WHY THIS EXISTS
  // Everything needed to hire an agent has been served as an API for a while:
  // negotiate a quote, get back the five unsigned escrow calls, submit them.
  // A person reading this page could do none of it. A marketplace whose hire
  // path is reachable only by writing a script is a directory with extra
  // documentation, so the same API now has a button on it.
  //
  // WHAT THIS DOES NOT DO
  // It holds no key and signs nothing. Every call is handed to the visitor's
  // own wallet one at a time, with what it does written next to it, and the
  // wallet asks before each. There is no batch, no approve-everything, and no
  // step that runs without a click — the money is the visitor's and the
  // confirmations should be too.
  //
  // WHY THE STEPS ARE NOT COLLAPSED INTO ONE BUTTON
  // Five transactions is genuinely what ERC-8183 costs: create, bind a dispute
  // policy, set the budget, approve the token, fund. Hiding that behind one
  // button would make the flow look cheaper than it is and leave somebody
  // stranded halfway with no idea which half they are in.
  (function(){
    var AGENT='https://agent.brainonbnb.com';
    var d=document.getElementById('rg-hire'); if(!d||!d.showModal)return;
    var elSub=document.getElementById('rg-hire-sub'),
        elTask=document.getElementById('rg-hire-task'),
        elQuote=document.getElementById('rg-hire-quote'),
        elMsg=document.getElementById('rg-hire-msg'),
        elSteps=document.getElementById('rg-hire-steps'),
        elRaw=document.getElementById('rg-hire-raw');
    var current=null, plan=null, account=null, jobId=null;

    function esc(v){return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
    function say(html,cls){elMsg.className='rg-msg'+(cls?' '+cls:'');elMsg.innerHTML=html;}
    // A dead end is not an answer: when the agent does not quote, name one in
    // the same category that did the last time it was asked (its button's
    // title starts with "Quoted"), and open it on a click (2026-09-12).
    function altQuoter(){
      if(!current)return '';
      var alt=[].slice.call(document.querySelectorAll('.rg-hirebtn[data-cat="'+current.cat+'"]')).filter(function(b){return b.getAttribute('data-hire')!==current.id&&/^Quoted/.test(b.getAttribute('title')||'');})[0];
      if(!alt)return '';
      return ' <button type="button" class="rg-hirebtn" data-alt-hire="'+esc(alt.getAttribute('data-hire'))+'">Try '+esc(alt.getAttribute('data-name'))+' instead — it quoted back</button>';
    }
    function wireAlt(){var ab=elMsg.querySelector('[data-alt-hire]');if(ab)ab.addEventListener('click',function(){var b=document.querySelector('.rg-hirebtn[data-hire="'+ab.getAttribute('data-alt-hire')+'"]');if(b)open(b);});}
    function shortAddr(a){return a.slice(0,6)+'…'+a.slice(-4);}

    // A starting sentence per category, so the box is never empty and the task
    // written into the job description is a real one. Editable — the
    // description is what the seller matches against.
    //
    // Every seller behind these buttons needs a real 0x address in the task
    // except the yield ranking: venus.js, grid.js, lp-tiers.js and
    // rebalance.js each refuse without one. These seeds used to name a token
    // by symbol ("WBNB") or carry a literal "0x…" placeholder, so a buyer who
    // took the suggested wording funded a job the seller then declined — and
    // found out after paying, with the escrow already full. That is exactly
    // how job 56670 ended: "Give a BSC token or pool address."
    //
    // A seed is a promise that the sentence works as written. These do.
    var SEED_TOKEN='0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
    var SEED={
      'health-factor':'health factor and liquidation distance for the Venus position at <ADDR>',
      'grid-trading':'grid plan for WBNB '+SEED_TOKEN+' with a budget of $1000 capital, 10 levels across a 15% band',
      'yield-optimization':'best stablecoin yield for 1000 USDT on BNB Chain right now',
      'rebalancing':'rebalance holdings [{"token":"'+SEED_TOKEN+'","usd":700},{"token":"0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82","usd":300}] to equal weight'
    };
    // "my position" means the wallet in front of us when there is one. Before
    // connecting the address stays open and the quote waits for one (2026-10-30:
    // it fell back to the $BOBAI contract, and a stranger who edited nothing
    // paid for a report on that).
    // A seller's own template beats the category one. Two agents can share a
    // category and need different inputs — the yield sentence carries no
    // address and the fee-tier seller refuses without one — so a per-category
    // template is a promise the seller never made.
    function template(cat,own){return String(own||SEED[cat]||'');}
    function seedFor(cat,own){return template(cat,own).replace('<ADDR>',account||'');}

    var seeded='';
    var elConn=document.getElementById('rg-hire-conn'),elNoWallet=document.getElementById('rg-hire-nowallet');
    // Without a wallet in this browser the hire opens inside a wallet app: the same page, the same task.
    function walletApps(){
      var here=location.host+'/registry?hire='+encodeURIComponent(current.id)+'&task='+encodeURIComponent(elTask.value.trim());
      return 'No wallet in this browser. Open this hire in your wallet app: '+
        '<a href="https://metamask.app.link/dapp/'+esc(here)+'" rel="noopener">MetaMask ↗</a> · '+
        '<a href="https://link.trustwallet.com/open_url?coin_id=20000714&amp;url='+esc(encodeURIComponent('https://'+here))+'" rel="noopener">Trust Wallet ↗</a>';
    }
    function walletRow(){
      var has=!!window.ethereum;
      elConn.hidden=!has||!!account;
      elNoWallet.hidden=has;
      if(!has&&current)elNoWallet.innerHTML=walletApps();
    }
    // A plan is the price of the words it was quoted for. New words, no plan: the buyer would sign what the box no longer says.
    function dropPlan(){
      if(!plan)return;
      plan=null;jobId=null;elSteps.innerHTML='';elRaw.hidden=true;
      say('The task changed, so that quote no longer applies. Get a new one.');
    }
    function connect(){
      return window.ethereum.request({method:'eth_requestAccounts'})
        .then(function(a){account=a&&a[0];return chain();})
        .then(function(){
          // only a sentence that gains the address changes: a connect must not throw away a quote for the same words
          var v=current?seedFor(current.cat,current.seed):'';
          if(current&&elTask.value===seeded&&v!==elTask.value){elTask.value=v;seeded=v;dropPlan();}
          walletRow();wallet();
        })
        .catch(function(e){say('Wallet: '+esc(e.message||e),'rg-err');});
    }
    elConn.addEventListener('click',connect);
    elTask.addEventListener('input',function(){dropPlan();walletRow();});

    function open(btn){
      current={id:btn.getAttribute('data-hire'),name:btn.getAttribute('data-name'),cat:btn.getAttribute('data-cat'),seed:btn.getAttribute('data-seed')};
      plan=null;jobId=null;elTask.readOnly=false;
      document.getElementById('rg-hire-t').textContent='Hire '+current.name;
      elSub.textContent='Agent #'+current.id+' · paid through the ERC-8183 escrow on BNB Chain';
      elTask.value=seedFor(current.cat,current.seed);seeded=elTask.value;
      elSteps.innerHTML='';elRaw.hidden=true;say('');
      elQuote.disabled=false;elQuote.textContent='Get a quote';
      walletRow();
      d.showModal();
    }

    [].slice.call(document.querySelectorAll('.rg-hirebtn')).forEach(function(b){
      b.addEventListener('click',function(){open(b);});
    });
    document.getElementById('rg-hire-x').addEventListener('click',function(){d.close();});
    // A LINK THAT OPENS A HIRE (2026-10-12): /registry?hire=<id>&task=<words>
    // opens that agent's panel with the task filled in — /defi sends a visitor
    // here after the free look at their position, so the plan they buy is an
    // escrowed job of the DeFi agent and not a bare transfer. Only an agent with
    // a Hire button on this page opens; the task is text, shown, never sent
    // before the visitor presses Get a quote.
    (function(){
      var q=new URLSearchParams(location.search),hid=(q.get('hire')||'').replace(/[^0-9]/g,'');
      if(!hid)return;
      var b=document.querySelector('.rg-hirebtn[data-hire="'+hid+'"]');
      if(!b)return;
      var t=(q.get('task')||'').slice(0,300);
      b.scrollIntoView({block:'center'});open(b);
      if(t){elTask.value=t;seeded='';}
    })();

    // --- the quote -------------------------------------------------------
    elQuote.addEventListener('click',function(){
      var task=elTask.value.trim();
      if(!task){say('Describe what you want done first.','rg-err');return;}
      if(/<ADDR>/.test(template(current.cat,current.seed))&&!/0x[0-9a-fA-F]{40}/.test(task)){
        say('This agent reads one wallet: add its address to the task, or connect your wallet.','rg-err');return;
      }
      elQuote.disabled=true;elQuote.textContent='Asking the agent…';
      say('Negotiating over A2A. This is a live call to the agent, not a price list.');
      // The answer belongs to the agent it was asked of: a quote can take 25 s,
      // and one that came back after the panel had moved on to another agent
      // used to set the plan and render under that other agent's name — the
      // escrow would have named the wrong provider (2026-09-18).
      var askedOf=current.id;
      fetch(AGENT+'/hire?agent='+encodeURIComponent(current.id)+'&task='+encodeURIComponent(task),{cache:'no-store'})
        .then(function(r){return r.json();})
        .then(function(j){
          if(!current||current.id!==askedOf)return;
          elQuote.textContent='Get a quote';elQuote.disabled=false;
          if(!j||j.error){
            // An x402 seller is not a failure: it states a price per call (2026-10-04).
            if(j&&j.x402&&j.x402.offers&&j.x402.offers.length){
              var offs=j.x402.offers.map(function(x){return esc(x.price)+' to '+esc(x.payTo)+(x.method?' ('+esc(x.method)+')':'');}).join(' or ');
              elSub.textContent='Agent #'+current.id+' · sold per call over x402, not through the escrow';
              say('No escrow job here: this agent sells per call over x402 &mdash; '+offs+' at '+esc(j.x402.url)+'. Pay with your own x402 client at that address; nothing is held in escrow.'+altQuoter(),'rg-ok');
            }else if(j&&j.example){
              // The seller reads only a JSON task and its card carries its own example (2026-10-04):
              // offered in one click instead of a dead end.
              say('The agent did not quote: '+esc(j.error||'no answer')+'<br>Its card carries its own example of the task it reads: <code>'+esc(j.example)+'</code> <button type="button" class="rg-useex" style="font:inherit;cursor:pointer;margin-left:6px">Use its example &rarr;</button>','rg-err');
              var ub=document.querySelector('.rg-useex');
              if(ub)ub.addEventListener('click',function(){elTask.value=j.example;seeded='';elTask.focus();});
            }else{
              say('The agent did not quote: '+esc((j&&(j.error||j.reason))||'no answer')+altQuoter(),'rg-err');
            }
            wireAlt();
            // Show the address the broker actually tried. Without it the
            // reader gets a verdict about a stranger's agent and no way to
            // check it - "the endpoint its card names answered 404" names no
            // endpoint. Every other claim on this page can be followed to its
            // source, and this one is about somebody else's software, which is
            // exactly when it has to be checkable.
            //
            // Text, never a link: several of these point at 127.0.0.1 or a
            // dead host, and a link invites a click that teaches nothing.
            if(j&&j.endpoint){elRaw.hidden=false;elRaw.textContent='tried: '+j.endpoint+'\\n\\n'+JSON.stringify(j,null,2);}
            return;
          }
          if(!j.negotiated||!j.calls){
            // Not every agent in the registry can actually be hired, and
            // saying so beats a spinner that never resolves.
            say('This agent did not return a quote. '+esc(j.reason||j.note||'It may advertise ERC-8183 without answering negotiation.')+altQuoter(),'rg-err');wireAlt();
            elRaw.hidden=false;elRaw.textContent=JSON.stringify(j,null,2);
            return;
          }
          plan=j;render();
        })
        .catch(function(e){elQuote.disabled=false;elQuote.textContent='Get a quote';say('Could not reach the broker: '+esc(e.message),'rg-err');});
    });

    function render(){
      var q=plan.quote||{},e=plan.escrow||{};
      var h='<div class="rg-msg"><b>'+esc(q.price||'?')+'</b> to '+esc(plan.provider||'the provider')+
        (q.service?'<div class="rg-note"><b>You are buying: '+esc(q.service)+'</b></div>':'')+
        '<div class="rg-note">'+esc(plan.provider_source||'')+
        (q.estimated_completion_seconds?' · quoted completion '+esc(q.estimated_completion_seconds)+'s':'')+'</div>'+
        '<div class="rg-note" style="margin-top:6px">'+esc(e.refundable||'')+'</div>'+
        // What the price is denominated in. Without this the last thing a
        // buyer reads before opening their wallet is a ticker they have never
        // seen, and that is where a first hire stops.
        (e.payment_token_note?'<div class="rg-note rg-paynote">'+esc(e.payment_token_note)+
          (e.payment_token_where?' <a href="'+esc(e.payment_token_where)+'" target="_blank" rel="noopener">Get some \u2197</a>':'')+'</div>':'')+
        '</div>';
      h+='<div class="rg-msg" id="rg-wallet"></div>';
      h+='<div id="rg-stepwrap"></div>';
      h+='<button class="rg-act rg-ghost" id="rg-showraw">Show the raw calls instead</button>';
      elSteps.innerHTML=h;
      document.getElementById('rg-showraw').addEventListener('click',function(){
        elRaw.hidden=false;elRaw.textContent=JSON.stringify(plan,null,2);
      });
      renderSteps();
      wallet();
    }

    function renderSteps(){
      var w=document.getElementById('rg-stepwrap');if(!w)return;
      var h='';
      plan.calls.forEach(function(c,i){
        var done=c._done===true;
        h+='<div class="rg-step'+(done?' rg-done':'')+'"><div class="rg-n">'+(done?'✓':(i+1))+'</div>'+
           '<div class="rg-sw"><b>'+esc(c.what)+'</b>'+
           '<div class="rg-note">'+esc(c.note||'')+'</div>'+
           (c._tx?'<div class="rg-note"><a href="https://bscscan.com/tx/'+esc(c._tx)+'" target="_blank" rel="noopener">'+esc(c._tx.slice(0,14))+'… ↗</a></div>':'')+
           (done?'':'<button class="rg-act" data-step="'+i+'"'+(account?'':' disabled')+'>Send this one</button>')+
           '</div></div>';
      });
      w.innerHTML=h;
      [].slice.call(w.querySelectorAll('button[data-step]')).forEach(function(b){
        b.addEventListener('click',function(){run(Number(b.getAttribute('data-step')),b);});
      });
    }

    // --- wallet ----------------------------------------------------------
    function wallet(){
      var w=document.getElementById('rg-wallet');if(!w)return;
      if(!window.ethereum){
        w.innerHTML='<span class="rg-note">'+walletApps()+'. Or send the raw calls yourself: step 1 opens the job, and every step after it needs that job\\'s id.</span>';
        return;
      }
      if(account){
        w.innerHTML='<span class="rg-note rg-ok">Connected '+esc(shortAddr(account))+'</span>';
        renderSteps();return;
      }
      w.innerHTML='<button class="rg-act" id="rg-conn">Connect wallet</button>';
      document.getElementById('rg-conn').addEventListener('click',connect);
    }

    // BNB Chain or nothing. Sending these calls on another chain would create
    // a job in a kernel that is not there, which fails in a way that costs gas
    // and explains nothing.
    function chain(){
      return window.ethereum.request({method:'eth_chainId'}).then(function(id){
        if(id==='0x38')return;
        return window.ethereum.request({method:'wallet_switchEthereumChain',params:[{chainId:'0x38'}]});
      });
    }

    function receipt(tx){
      return new Promise(function(res,rej){
        var n=0;
        (function poll(){
          window.ethereum.request({method:'eth_getTransactionReceipt',params:[tx]}).then(function(r){
            if(r&&r.blockNumber){if(r.status==='0x0')rej(new Error('the transaction reverted on-chain'));else res(r);return;}
            if(++n>90){rej(new Error('not confirmed after 3 minutes'));return;}
            setTimeout(poll,2000);
          }).catch(function(){if(++n>90)rej(new Error('lost the transaction'));else setTimeout(poll,2000);});
        })();
      });
    }

    // The jobId is read from the kernel and then VERIFIED against the connected
    // address. Taking jobCounter() on its own would hand back somebody else's
    // job whenever two people create one in the same block, and every later
    // step would then be funding a stranger's escrow.
    // The job id is in the receipt of the transaction we just sent: the kernel
    // logs it as the first indexed topic, with the client as the second. That
    // is authoritative and free.
    //
    // The counter walk below it is a guess by comparison. It reads
    // jobCounter() and checks five ids downwards, so it depends on the node
    // answering 'latest' being as current as the node that returned the
    // receipt - and if it is one block behind, the real id sits ABOVE the
    // window and is never looked at. The buyer has then paid gas for a job the
    // panel refuses to identify, and every later step needs that id. It also
    // cannot tell our job from a stranger's created in the same block except
    // by the client check, which is exactly the check the log gives directly.
    function jobIdFromReceipt(r){
      if(!r||!r.logs||!account)return null;
      var kernel=String(plan.escrow.kernel).toLowerCase();
      var me=account.toLowerCase().slice(2);
      for(var i=0;i<r.logs.length;i++){
        var l=r.logs[i];
        if(String(l.address||'').toLowerCase()!==kernel)continue;
        var t=l.topics||[];
        if(t.length<3)continue;
        if(String(t[2]).toLowerCase().indexOf(me)<0)continue;
        try{return BigInt(t[1]).toString();}catch(e){}
      }
      return null;
    }

    function findJobId(r){
      var fromLog=jobIdFromReceipt(r);
      if(fromLog)return Promise.resolve(fromLog);
      var kernel=plan.escrow.kernel;
      return window.ethereum.request({method:'eth_call',params:[{to:kernel,data:'0x50355d76'},'latest']})
        .then(function(hex){
          var top=parseInt(hex,16);
          var tries=[];for(var i=0;i<5&&top-i>0;i++)tries.push(top-i);
          return tries.reduce(function(p,id){
            return p.then(function(found){
              if(found)return found;
              return fetch(AGENT+'/job?id='+id,{cache:'no-store'}).then(function(r){return r.json();})
                .then(function(j){
                  return (j&&j.client&&account&&j.client.toLowerCase()===account.toLowerCase())?String(id):null;
                }).catch(function(){return null;});
            });
          },Promise.resolve(null));
        });
    }

    function pad(id){var h=BigInt(id).toString(16);while(h.length<64)h='0'+h;return h;}

    function run(i,btn){
      var c=plan.calls[i];
      btn.disabled=true;btn.textContent='Confirm in your wallet…';
      chain().then(function(){
        var data=c.data;
        if(!data&&c.data_template){
          if(!jobId)throw new Error('the job id is not known yet — send step 1 first');
          data=c.data_template.replace('<JOBID>',pad(jobId));
        }
        if(!data)throw new Error('this step has no call data');
        return window.ethereum.request({method:'eth_sendTransaction',params:[{from:account,to:c.to,data:data,value:c.value||'0x0'}]});
      })
      .then(function(tx){
        c._tx=tx;btn.textContent='Waiting for confirmation…';
        // the job is opened on these words: from here the box cannot drift from what was signed
        if(i===0)elTask.readOnly=true;
        say('Sent. Waiting for BNB Chain to confirm.');
        return receipt(tx);
      })
      .then(function(r){
        c._done=true;
        if(i===0){say('Job created. Reading its id from the receipt.');return findJobId(r);}
        return null;
      })
      .then(function(id){
        if(id){jobId=id;say('Job <b>#'+esc(jobId)+'</b> is yours. Four steps left.','rg-ok');}
        // Step 1 is the one that cannot be shrugged off. If its id never came
        // back, the buyer has paid gas for a job on-chain and every remaining
        // step needs an id nobody has - and this used to report that in green
        // as "Step done.", which is the most expensive kind of wrong. Say what
        // happened and hand over the transaction, which contains the id.
        else if(i===0){say('The job was created on-chain, but its id could not be read back, and the four remaining steps need it. Nothing beyond gas has been spent. Your transaction: <a href="https://bscscan.com/tx/'+esc(c._tx||'')+'" target="_blank" rel="noopener">'+esc(String(c._tx||'').slice(0,14))+'… ↗</a> — the id is the first indexed value in its log.','rg-err');}
        else if(plan.calls.every(function(x){return x._done;}))finish();
        else say('Step done.','rg-ok');
        renderSteps();
      })
      .catch(function(e){
        btn.disabled=false;btn.textContent='Send this one';
        say('Stopped: '+esc(e.message||e)+'. Nothing further was sent.','rg-err');
      });
    }

    // After the delivery: one measurement, written on-chain by the buyer.
    // The page polls the job until the deliverable is on the kernel, then
    // asks the worker for the unsigned giveFeedback call - responsetime in
    // milliseconds between the funding block and the deliverable's block,
    // the delivered document as evidence, its keccak256 as the hash - and the
    // buyer sends it from the same wallet that funded the job. Not a rating:
    // a measurement anybody can take again. The seller's owner cannot send
    // this; the contract refuses it, which is the point.
    function watchDelivery(){
      var fund=plan.calls[plan.calls.length-1]&&plan.calls[plan.calls.length-1]._tx;
      if(!fund||!jobId)return;
      var tries=0;
      d.querySelectorAll('.rg-attest').forEach(function(x){x.remove();});
      var box=document.createElement('div');box.className='rg-attest';box.innerHTML='<span class="rg-note">Waiting for the deliverable to land on the kernel…</span>';
      elMsg.insertAdjacentElement('afterend',box);
      (function poll(){
        tries++;
        fetch(AGENT+'/job?id='+jobId,{cache:'no-store'}).then(function(r){return r.json();}).then(function(j){
          if(j&&(j.status==='SUBMITTED'||j.status==='COMPLETED')){
            var head=j.delivery&&j.delivery.summary&&j.delivery.summary.headline;
            // an outside seller writes only a hash on chain: the answer itself is at the address the marketplace knows
            if(!head&&j.delivery_url)head='Read the answer: <a href="'+esc(j.delivery_url)+'" target="_blank" rel="noopener">its document ↗</a>';
            else if(!head&&!j.delivery)head='This seller put a hash of its answer on chain. The answer itself stays with the seller; the hash proves any copy it gives you is the one it delivered.';
            else if(head)head=esc(head);
            box.innerHTML='<div class="rg-attest-h">Delivered.'+(head?' <span class="rg-note">'+head+'</span>':'')+'</div>'+
              '<button type="button" class="rg-hirebtn" id="rg-attest-go">Attest this delivery on-chain &rarr;</button>'+
              '<span class="rg-note">Writes one measurement into the ERC-8004 reputation registry from your wallet: how many milliseconds passed between your funding block and the deliverable, with the delivered document as evidence. No stars, no opinion.</span>';
            var go=document.getElementById('rg-attest-go');
            go.addEventListener('click',function(){
              go.disabled=true;go.textContent='Preparing…';
              fetch(AGENT+'/attest?job='+jobId+'&fundTx='+fund,{cache:'no-store'}).then(function(r){return r.json();}).then(function(a){
                if(!a||!a.call)throw new Error((a&&a.error)||'the worker did not prepare the call');
                go.textContent='Confirm in your wallet…';
                return window.ethereum.request({method:'eth_sendTransaction',params:[{from:account,to:a.call.to,data:a.call.data,value:'0x0'}]}).then(function(tx){
                  go.textContent='Waiting for confirmation…';
                  return receipt(tx).then(function(){
                    box.innerHTML='<div class="rg-attest-h">Attested on-chain: '+esc(a.means||'')+'</div>'+
                      '<span class="rg-note">responsetime '+esc(String(a.value))+' ms on agent #'+esc(String(a.agent_id))+', evidence '+
                      '<a href="'+esc(a.evidence.feedbackURI)+'" target="_blank" rel="noopener">the delivered document</a> · '+
                      '<a href="https://bscscan.com/tx/'+esc(tx)+'" target="_blank" rel="noopener">transaction ↗</a>. It shows on this page after the next reputation refresh.</span>';
                  });
                });
              }).catch(function(e){
                go.disabled=false;go.textContent='Attest this delivery on-chain →';
                say('Not attested: '+esc(e.message||e),'rg-err');
              });
            });
            return;
          }
          if(tries<40)setTimeout(poll,5000);
          else box.innerHTML='<span class="rg-note">Still not delivered after a few minutes. Track it at <a href="'+AGENT+'/job?id='+jobId+'" target="_blank" rel="noopener">/job?id='+jobId+' ↗</a>.</span>';
        }).catch(function(){ if(tries<40)setTimeout(poll,5000); });
      })();
    }

    // Funded is not delivered. The seller has to be told, and the deliverable
    // arrives on-chain rather than in this page, so the last thing shown is
    // where to watch for it.
    function finish(){
      say('Escrow funded. Telling the seller to deliver…');
      // To the seller that was HIRED, by its id, through the worker's relay
      // (/hire/notify): this used to post to our own /a2a whichever agent it
      // was, and a stranger's funded job was answered "that is not us" and shown
      // as the seller declining — it had never been asked (2026-09-18).
      fetch(AGENT+'/hire/notify',{method:'POST',headers:{'content-type':'application/json'},
        body:JSON.stringify({agent:String(current&&current.id||''),job_id:Number(jobId)})})
        .then(function(r){return r.json();})
        .then(function(n){
          // Three outcomes, three sentences: the seller could not be reached, the
          // seller refused, the seller accepted.
          if(!n||n.delivered_to_seller!==true){
            say('The escrow is funded, but the seller could not be reached: '+esc((n&&n.error)||'no answer')+'. '+
                (n&&n.endpoint?'Its endpoint is '+esc(n.endpoint)+' — send it {"skill":"notify_funded","job_id":'+esc(jobId)+'} over A2A, or wait: ':'')+
                'your budget returns through claimRefund when the job expires. '+
                'Job <b>#'+esc(jobId)+'</b> · <a href="'+AGENT+'/job?id='+esc(jobId)+'" target="_blank" rel="noopener">/job?id='+esc(jobId)+' ↗</a>','rg-err');
            return;
          }
          var j=n.accepted===false?{error:{message:n.seller_said}}:{};
          // The seller answers JSON-RPC, so a refusal arrives as a 200 with an
          // error member. This used to ignore the body entirely and report
          // success either way — a buyer whose seller declined the work read
          // "delivery is requested" in green while nothing had been accepted.
          // A refusal here is the one message that must not be swallowed: the
          // escrow is already full.
          if(j&&j.error){
            say('The escrow is funded, but the seller declined to deliver: '+esc(j.error.message||'no reason given')+
                ' Your budget is untouched and returns to you when the job expires. '+
                'Job <b>#'+esc(jobId)+'</b> · <a href="'+AGENT+'/job?id='+esc(jobId)+'" target="_blank" rel="noopener">/job?id='+esc(jobId)+' ↗</a>','rg-err');
            return;
          }
          say('Job <b>#'+esc(jobId)+'</b> is funded and delivery is requested. '+
              'Track it at <a href="'+AGENT+'/job?id='+esc(jobId)+'" target="_blank" rel="noopener">/job?id='+esc(jobId)+' ↗</a>. '+
              'SUBMITTED means the answer is delivered, COMPLETED means the escrow released.','rg-ok');
          watchDelivery();
        })
        .catch(function(){
          // the same door again, not our own agent's (2026-10-05: this named AGENT/a2a for every seller — a notice for a
          // stranger's job sent to us is declined as "not ours")
          say('Escrow is funded, but the delivery request did not go through. Send it again: POST '+AGENT+'/hire/notify with {"agent":"'+esc(String(current&&current.id||''))+'","job_id":'+esc(jobId)+'} — or wait: a seller that watches the escrow delivers by itself. Job <b>#'+esc(jobId)+'</b> · <a href="'+AGENT+'/job?id='+esc(jobId)+'" target="_blank" rel="noopener">/job?id='+esc(jobId)+' ↗</a>','rg-err');
        });
    }
  })();

  // "last delivery N days ago" counted from the visitor's clock, not the
  // scan's: the page is read for days after it is built (2026-10-09).
  (function(){
    var now=Date.now()/1000;
    [].slice.call(document.querySelectorAll('.rg-ago[data-t]')).forEach(function(x){
      var n=Math.floor((now-Number(x.getAttribute('data-t')))/86400);
      if(!(n>=0))return;
      x.textContent=n===0?'today':n===1?'1 day ago':n.toLocaleString('en-US')+' days ago';
    });
  })();

  // Filter only — no data fetching, nothing that can fail and leave the page
  // half-built. If this script never runs, every row is still on the page.
  (function(){
    var q=document.getElementById('rg-q'),b=document.getElementById('rg-body'),n=document.getElementById('rg-none');
    if(!q||!b)return;
    var rows=[].slice.call(b.rows);
    q.addEventListener('input',function(){
      var t=q.value.trim().toLowerCase(),shown=0;
      rows.forEach(function(r){
        var hit=!t||r.innerText.toLowerCase().indexOf(t)>-1;
        r.hidden=!hit; if(hit)shown++;
      });
      n.hidden=shown>0;
    });
  })();
</script>
<script>
  // LISTED AGENTS (operator, 2026-10-12: "a DexScreener for agents"). Read live from agent.brainonbnb.com/listings:
  // a listed agent gets its badge on its own row (while our daily check finds it answering) and a copy of its card in a
  // "Featured (paid)" slot at the top of each category it is in. The list order below is the evidence and stays as
  // generated: a listing never moves a row. Listed agents not (yet) on this page show in one strip above the categories.
  (function(){
    var esc=function(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
    // high on the page (operator, 2026-10-12: "the agents further up"): right after the numbers, before "Hire one, or just ask"
    var logo=function(L){var u=String(L.image||'');return L.badge&&u.indexOf('https://')===0&&u.length<300&&!/[ "'<>]/.test(u)?'<img class="rgc-logo" src="'+esc(u)+'" alt="" width="38" height="38" loading="lazy" decoding="async" onerror="this.remove()">':''};
    var first=document.querySelector('.rg-box.rg-start')||document.querySelector('.rg-box[id^="cat-"]'); if(!first)return;
    var strip=document.createElement('div'); strip.className='rg-box rg-featured'; strip.id='featured';
    strip.innerHTML='<h2>Featured (paid)</h2><p class="rg-sub">Agents their builders keep running, listed once for $95. A listing buys this slot and a badge, never a place in the lists below. <a href="/list">List your agent &rarr;</a></p><div class="rgc-list" id="rg-feat-list"></div>';
    strip.hidden=true; first.parentNode.insertBefore(strip, first);
    fetch('https://agent.brainonbnb.com/listings',{cache:'no-store'}).then(function(r){return r.json()}).then(function(j){
      var off=[];
      (j.listings||[]).forEach(function(L){
        var btns=[].slice.call(document.querySelectorAll('.rg-hirebtn[data-hire="'+String(L.id).replace(/[^0-9]/g,'')+'"]'));
        // OURS (operator, 2026-10-12: "all our agents get the badge — 'ours' + 'maintained'"): our own agents carry the badge
        // on their row, say first that they are ours, and never take the "Featured (paid)" slot — nobody paid for it
        var badge=L.house
          ?'<a class="rg-t rg-listed" href="'+esc(L.profile)+'" title="Brain On BNB&rsquo;s own agent (not a paid listing); our daily check last found it '+(L.badge?'answering':'silent')+'">ours &middot; '+(L.badge?'&#10003; maintained':'paused')+'</a>'
          :'<a class="rg-t rg-listed" href="'+esc(L.profile)+'" title="Listed on Brain Plaza; our daily check last found it '+(L.badge?'answering':'silent')+'">'+(L.badge?'&#10003; verified &amp; maintained':'listed &middot; paused')+'</a>';
        if(!btns.length){if(!L.house)off.push(L);return}
        btns.forEach(function(b){
          var art=b.closest('article'); if(!art||art.dataset.listed)return; art.dataset.listed='1';
          // THE LOGO (operator, 2026-10-13: "like marque.trade"): a verified listing shows its registration image; before the
          // featured copy is cloned, so the copy carries it too. A logo that does not load removes itself.
          // inside the name block, floated: a long name flows beside it instead of wrapping under it (2026-10-13, 1280 px)
          var lg=logo(L); var hd=art.querySelector('.rgc-id'); if(lg&&hd&&!hd.querySelector('.rgc-logo'))hd.insertAdjacentHTML('afterbegin',lg);
          var nm=art.querySelector('.rgc-id a.rg-chart')||art.querySelector('.rgc-id b'); if(nm)nm.insertAdjacentHTML('afterend',' '+badge);
          if(L.house){var o=art.querySelector('.rg-x4');if(o)o.remove();} // the badge says "ours" already (2026-10-13: it showed twice)
          if(L.house)return; // ours: the badge only, no featured copy
          var box=art.closest('.rg-box'); var list=box&&box.querySelector('.rgc-list'); if(!box||!list||box.querySelector('.rg-feat'))return;
          var f=document.createElement('div'); f.className='rg-feat'; f.innerHTML='<p class="rg-note" style="margin:0 0 6px;color:var(--gold)">Featured (paid)</p>';
          var c=art.cloneNode(true); c.removeAttribute('data-tele');
          [].slice.call(c.querySelectorAll('.rg-hirebtn')).forEach(function(cb){cb.addEventListener('click',function(e){e.preventDefault();b.click()})});
          f.appendChild(c); list.parentNode.insertBefore(f,list);
        });
      });
      // one "ours" per card, whatever its layout: the badge says it, the old chip goes (2026-10-13)
      [].slice.call(document.querySelectorAll('article')).forEach(function(a){var l=a.querySelector('.rg-listed');if(l&&/ours/.test(l.textContent))[].slice.call(a.querySelectorAll('.rg-x4')).forEach(function(x){x.remove()})});
      var fl=document.getElementById('rg-feat-list');
      // OPEN SINCE 2026-10-18 (operator: "listing freischalten"): with no paid listing yet the strip says so and keeps its
      // link to /list — our own agents never fill it (they carry "ours" on their rows)
      strip.hidden=false;
      if(!(j.listings||[]).filter(function(L){return !L.house}).length){fl.innerHTML='<p class="rg-note">No paid listing yet. Yours could be the first.</p>';return}
      fl.innerHTML=off.map(function(L){return '<article class="rgc"><div class="rgc-h"><div class="rgc-id">'+logo(L)+'<b>'+esc(L.name||('Agent #'+L.id))+'</b> <a class="rg-t rg-listed" href="'+esc(L.profile)+'">'+(L.badge?'&#10003; verified &amp; maintained':'listed &middot; paused')+(L.house?' &middot; ours':'')+'</a><div class="rg-note">ERC-8004 #'+esc(L.id)+' &middot; listed since '+esc(L.since)+'</div></div></div>'+(L.description?'<p class="rgc-what">'+esc(String(L.description).slice(0,220))+'</p>':'')+'<p class="rg-note"><a href="'+esc(L.profile)+'">Its page &rarr;</a></p></article>'}).join('')||'<p class="rg-note">Every listed agent is shown in its category below.</p>';
    }).catch(function(){strip.remove()});
  })();
</script>
<script>
  // THE SCREENER'S HEAD ON THE PLAZA (operator, 2026-10-12: "the screener much more present", first: "its head at the
  // top of the Plaza"): the same four boards as /screener, from the same data; a row opens the agent's chart
  (function(){
    var box=document.getElementById('rg-tops'); if(!box)return;
    var esc=function(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
    var nm=function(a){var n=String(a.name||('Agent #'+a.id));var p='Brain on BNB — ';return n.indexOf(p)===0?n.slice(p.length):n};
    var num=function(v){return v==null?-1:v};
    fetch('https://agent.brainonbnb.com/screener').then(function(r){return r.json()}).then(function(j){
      var F=j.fields,all=j.rows.map(function(r){var o={};F.forEach(function(f,i){o[f]=r[i]});return o});
      var pick=function(f,s){return all.filter(f).sort(s).slice(0,5)};
      var row=function(a,i,m,sub){return '<a class="rg-tr" href="/agent/'+a.id+'"><span class="rg-tn">'+(i+1)+'</span><span class="rg-tt">'+(a.logo?'<img class="rg-tl" src="'+esc(a.logo)+'" alt="" width="18" height="18" loading="lazy" decoding="async" onerror="this.remove()">':'')+esc(nm(a))+'<small>'+(a.ours?'<b style="color:#7fd1a3">ours</b> &middot; ':'')+'#'+a.id+' &middot; '+esc(sub)+'</small></span><span class="rg-tm">'+m+'</span></a>'};
      var B=[
        ['Top by evidence','#f0b90b',pick(function(a){return a.score>0},function(x,y){return y.score-x.score||num(y.uptime_30d)-num(x.uptime_30d)}),function(a){return a.score+'<small>of 100</small>'},function(a){return a.outside_jobs+' paid job'+(a.outside_jobs===1?'':'s')}],
        ['Most paid work','#4cc38a',pick(function(a){return a.outside_jobs>0},function(x,y){return y.outside_jobs-x.outside_jobs||y.outside_buyers-x.outside_buyers}),function(a){return a.outside_jobs+'<small>jobs</small>'},function(a){return a.outside_buyers+' buyer'+(a.outside_buyers===1?'':'s')}],
        ['Earned the most','#7fd1ff',pick(function(a){return a.earned_u>0},function(x,y){return y.earned_u-x.earned_u}),function(a){return Number(a.earned_u).toFixed(2)+' <small>$U</small>'},function(a){return a.outside_jobs+' paid job'+(a.outside_jobs===1?'':'s')}],
        ['Down at their last check','#ff7a6e',pick(function(a){return a.days>0&&a.up_now===0},function(x,y){return num(y.uptime_30d)-num(x.uptime_30d)}),function(){return '<span style="color:#ff7a6e">down</span>'},function(a){return a.uptime_30d===0?'no answer yet · '+a.days+'d':'up '+a.uptime_30d+'% · '+a.days+'d'}]
      ];
      box.innerHTML=B.map(function(b){return '<div class="rg-top4" style="--c:'+b[1]+'"><h3><i></i>'+b[0]+'</h3>'+(b[2].length?b[2].map(function(a,i){return row(a,i,b[3](a),b[4](a))}).join(''):'<p class="rg-note">Nobody right now.</p>')+'</div>'}).join('');
    }).catch(function(){box.innerHTML='<p class="rg-note">The screener could not be read just now. <a href="/screener">Open it</a>.</p>'});
  })();
</script>
<style>
  .rg-tops{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px;margin-top:12px}
  .rg-top4{border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:10px 10px 4px;background:rgba(255,255,255,.02);min-width:0}
  .rg-top4 h3{margin:0 0 4px;font:700 14px 'Space Grotesk',sans-serif;display:flex;align-items:center;gap:7px}
  .rg-top4 h3 i{width:8px;height:8px;border-radius:50%;background:var(--c);box-shadow:0 0 8px var(--c);flex:none}
  .rg-tr{display:grid;grid-template-columns:16px minmax(0,1fr) auto;gap:8px;align-items:center;padding:6px 4px;border-top:1px solid rgba(255,255,255,.06);color:inherit;text-decoration:none;border-radius:8px}
  .rg-tr:hover{background:rgba(240,185,11,.06)}
  .rg-tn{font:600 11px ui-monospace,Consolas,monospace;color:var(--muted,#a0a2c0)}
  .rg-tt{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font:600 13px Inter,sans-serif}
  .rg-tl{width:18px;height:18px;border-radius:5px;object-fit:cover;vertical-align:-4px;margin-right:6px;background:#0d1117}
  .rg-tt small{display:block;font:500 11px Inter,sans-serif;color:var(--muted,#a0a2c0);overflow:hidden;text-overflow:ellipsis}
  .rg-tm{font:700 14px 'Space Grotesk',sans-serif;color:var(--c);text-align:right;font-variant-numeric:tabular-nums}
  .rg-tm small{display:block;font:500 10.5px Inter,sans-serif;color:var(--muted,#a0a2c0)}
  @media (max-width:559px){.rg-top4 .rg-tr:nth-of-type(n+4){display:none}} /* a phone: three a board, the rest one tap away */
</style>
<style>.rg-chart{color:inherit;text-decoration:none;border-bottom:1px dotted rgba(240,185,11,.45)}.rg-chart:hover{color:var(--gold)}.rg-listed{color:#7fd1a3;border-color:rgba(127,209,163,.35);text-decoration:none}.rg-feat{border:1px solid rgba(240,185,11,.35);border-radius:14px;padding:10px;margin:0 0 14px}</style>
<script>
/* BOBAI AT WORK (2026-10-22): the four records, read live. Our wallets are left out of "hired us" (our own tests),
   so are our house listings; every row links its transaction. */
(function () {
  var AG = 'https://agent.brainonbnb.com';
  var OURS = ['0xbfaa69233741924ed5b9d5daa9b4bf7b84567f0a', '0xbfb4b49787ce948c1ee304f6c197a0e8b038ddb2', '0x5c82d2f12ee6ac09297784f94ebf9331277bdc3c', '0xdefc0e900dfc83e207902cf22265ae63f94c01ce', '0x15ba17075ef5e0736292b030e3715d9100fe3d38', '0x73809f69916fcf7ddc5bb1315fbdf96a569a5963', '0x690e950214980bc329823a2db2fd90c06bd54de4', '0xeac21928de023677a25eb925d1cb1b0786faf946', '0x497dac54fd7238027ecbbd194b353379a1d605f0', '0xc5a17b5295fc50badb1f9f9c09b412fe5e84f7d3', '0x5e4102520a71b2aa18a1208330d4848dea4bd105'];
  var NAME = { 302257: 'Venus health factor agent', 302258: 'grid planner', 304493: 'Venus yield agent', 304494: 'rebalancer', 310460: 'fee tier agent', 363709: 'DeFi agent' };
  var KNOWN = { '0xd6d11aa5046dc5c7be8d63b9223b60d7ad94cbe9': 'Mandate', '0xdab12cf15f4385188be62bda9f00877af4c1b32f': 'Pokter' };
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (x) { return String(x == null ? '' : x).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var nf = function (n, d) { return Number(n).toLocaleString('en-US', { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }); };
  var day = function (iso) { return String(iso || '').slice(5, 16).replace('T', ' '); };
  var tx = function (h, label) { return h ? ' <a href="https://bscscan.com/tx/' + esc(h) + '" target="_blank" rel="noopener">' + (label || 'tx') + ' &#x2197;</a>' : ''; };
  var short = function (a) { return String(a).slice(0, 6) + '&hellip;' + String(a).slice(-4); };
  var get = function (u) { return fetch(u, { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }); };
  var set = function (id, html) { var e = $(id); if (e) e.innerHTML = html; };
  // the Brain Board block: its counts and the three newest threads (every word escaped)
  get(AG + '/board?limit=3').then(function (b) {
    if (!b || !b.threads) { set('pb-rows', '<p class="rg-note">The board could not be read just now.</p>'); return; }
    set('pb-n-all', nf(b.total)); set('pb-n-open', nf(b.open)); set('pb-n-done', nf(b.resolved || 0));
    set('pb-rows', b.threads.length ? b.threads.map(function (t) {
      // an entry without a wallet has no address to shorten: its name, or "someone", not signed (2026-10-24: it read "unverified unsign…gned")
      var who = t.verified && t.agent != null ? esc(t.agent_name || 'Agent') + ' #' + esc(t.agent) : t.author === 'unsigned' ? esc(t.from || 'someone') + ' (not signed)' : 'unverified ' + short(t.author);
      return '<div class="aw-row"><span class="aw-t">#' + esc(t.id) + '</span>[' + esc(t.type) + '] <a href="/board#t' + esc(t.id) + '">' + esc(t.title) + '</a> &middot; ' + who + '</div>';
    }).join('') : '<p class="rg-note">Nothing yet. Be the first.</p>');
  });
  Promise.all([get(AG + '/hires'), get(AG + '/second-opinion'), get(AG + '/jobs/own'), get(AG + '/buys'), get(AG + '/settle/public'), get(AG + '/listings')]).then(function (r) {
    var hires = r[0], op = r[1], own = r[2], buys = r[3], st = r[4], li = r[5];
    // we hired: our agents' hires (agent-hires.js) and the DeFi agent's daily second opinion from Mandate Range-1
    var we = [];
    ((hires && hires.log) || []).forEach(function (h) { if (h.job) we.push({ at: h.at, who: NAME[h.by] || ('#' + h.by), seller: h.seller_name, site: h.site || 'Marque', price: h.price_u, status: h.status, our_side: h.our_side, theirs: h.answer && h.answer.health_factor, ours: h.own && h.own.hf, agrees: h.agrees, tx: ((h.txs || []).slice(-1)[0] || {}).tx }); });
    ((op && op.opinions) || []).forEach(function (o) { if (o.job) we.push({ at: o.at, who: 'DeFi agent', seller: (o.seller && o.seller.name) || 'Mandate Range-1', site: 'Mandate', price: o.price_u, status: o.status, agrees: o.agrees, tx: o.tx }); });
    we.sort(function (a, b) { return Date.parse(b.at) - Date.parse(a.at); });
    set('aw-n-hired', nf(we.length));
    // NOT DELIVERED IS SAID, NOT SUMMED AWAY (2026-10-23, operator: "transparent und ehrlich"): Sluicegate took two paid
    // jobs and delivered neither; the line counts what came back as answers and what did not, and the row says it in red
    var undelivered = function (x) { return /not delivered|refunded/.test(x.status || ''); };
    var nNo = we.filter(undelivered).length;
    set('aw-s-hired', we.length ? nf(we.reduce(function (s, x) { return s + (+x.price || 0); }, 0), 2) + ' $U paid to ' + nf(new Set(we.map(function (x) { return x.seller; })).size) + ' agents' + (nNo ? ' &middot; ' + nf(nNo) + ' not delivered (budget back at expiry)' : '') : 'second opinions, paid in $U');
    set('aw-hired', we.length ? we.slice(0, 8).map(function (x) {
      var v = x.agrees === true ? ' &middot; <span class="ok">same reading</span>' : x.agrees === false ? ' &middot; <span class="no">different reading</span>' : '';
      var f = x.theirs != null ? ' &middot; theirs ' + nf(x.theirs, 2) + (x.ours != null ? ', ours ' + nf(x.ours, 2) : '') : '';
      var st = x.status === 'answered' ? '' : undelivered(x) ? ' &middot; <span class="no">' + esc(x.status) + '</span>' + (x.our_side ? ' (' + esc(x.our_side) + ')' : '') : ' &middot; ' + esc(x.status);
      return '<div class="aw-row"><span class="aw-t">' + day(x.at) + '</span>Our <b>' + esc(x.who) + '</b> paid <b>' + esc(x.seller) + '</b> (' + esc(x.site) + ') ' + nf(x.price, 2) + ' $U' + f + v + st + tx(x.tx) + '</div>';
    }).join('') : '<p class="rg-note">None yet.</p>');
    // hired us: paid escrow jobs of our agents by wallets not ours, and x402 answers paid by strangers
    var us = [];
    Object.keys((own && own.jobs) || {}).forEach(function (id) { var j = own.jobs[id], last = (j.history || []).slice(-1)[0] || {}; if (j.client && OURS.indexOf(String(j.client).toLowerCase()) < 0 && /^(FUNDED|SUBMITTED|COMPLETED)$/.test(last.status || '')) us.push({ at: (j.history[0] || {}).at, from: String(j.client).toLowerCase(), what: 'escrow job ' + id + (NAME[j.agent] ? ' for our ' + NAME[j.agent] : ''), price: last.budget_u, status: last.status, job: id }); });
    ((buys && buys.payments) || []).forEach(function (p) { if (!p.self_test && OURS.indexOf(String(p.from).toLowerCase()) < 0) us.push({ at: p.at, from: String(p.from).toLowerCase(), what: 'x402 ' + String(p.for || '').replace('answer:', '').replace(/_/g, ' '), price: p.amount, asset: p.asset, tx: p.tx }); });
    us.sort(function (a, b) { return Date.parse(b.at) - Date.parse(a.at); });
    set('aw-n-us', nf(us.length));
    var payers = {}; us.forEach(function (x) { var n = KNOWN[x.from] || short(x.from); payers[n] = (payers[n] || 0) + 1; });
    set('aw-s-us', Object.keys(payers).length ? Object.keys(payers).sort(function (a, b) { return payers[b] - payers[a]; }).slice(0, 3).map(function (k) { return k + ' ' + payers[k] + '&times;'; }).join(' &middot; ') : 'escrow jobs and x402 answers');
    set('aw-us', us.length ? us.slice(0, 6).map(function (x) {
      return '<div class="aw-row"><span class="aw-t">' + day(x.at) + '</span><b>' + (KNOWN[x.from] ? esc(KNOWN[x.from]) : short(x.from)) + '</b> paid ' + (x.price != null ? nf(x.price, 2) + ' ' + esc(x.asset || '$U') + ' ' : '') + 'for ' + esc(x.what) + (x.tx ? tx(x.tx) : x.job ? ' <a href="' + AG + '/job?id=' + esc(x.job) + '" target="_blank" rel="noopener">job &#x2197;</a>' : '') + '</div>';
    }).join('') : '<p class="rg-note">None yet.</p>');
    // we settled for
    var t = (st && st.totals) || {}, ls = ((st && st.log) || []).filter(function (d) { return d.settled && d.tx; });
    set('aw-n-settled', nf(t.jobs || 0));
    set('aw-s-settled', t.jobs ? '$' + nf(t.released_u, 2) + ' to ' + nf((t.providers || []).length) + ' agents' : ((st && st.waiting) ? nf(st.waiting) + ' jobs watched, daily 21:15 UTC' : 'their pay released, our gas'));
    set('aw-settled', ls.length ? ls.slice(0, 6).map(function (d) { return '<div class="aw-row"><span class="aw-t">' + day(d.at) + '</span>Job <b>' + esc(d.id) + '</b>: $' + nf(d.released_u, 2) + ' released to ' + short(d.provider) + tx(d.tx) + '</div>'; }).join('') + '<div class="aw-row"><a href="/settle">Every settle &rarr;</a></div>'
      : '<p class="rg-note">The first run settles at 21:15 UTC. <a href="/settle">The record &rarr;</a></p>');
    // listed here: listings by others (ours are house listings, free)
    var others = ((li && li.listings) || []).filter(function (l) { return !l.house; });
    set('aw-n-listed', nf(others.length));
    // no zero on the first screen of a marketplace (2026-10-30): the tile comes when there is someone in it
    if (!others.length) { var lc = document.getElementById('aw-n-listed').closest('.rg-card'); lc.style.display = 'none'; lc.parentElement.classList.add('n3'); }   // three left: one full row of three, not 3+gap or 2+1 (3.11.)
    set('aw-listed', others.length ? others.slice(0, 6).map(function (l) { return '<div class="aw-row"><b>' + esc(l.name) + '</b> #' + esc(l.id) + (l.badge ? ' &middot; ' + esc(l.badge) : '') + ' <a href="' + esc(l.profile || ('/agent/' + l.id)) + '">profile &rarr;</a></div>'; }).join('')
      : '<p class="rg-note">No outside agent is listed yet. A listing is $95 once (USD1, BNB or $BOBAI): a profile, a daily check with a badge and a Featured slot &mdash; never a place in the lists below. <a href="/list">List your agent &rarr;</a></p>');
  });
})();
</script>
<!-- SHORTER ON A PHONE (2026-10-24, operator chose variant A like /services and /defi: the Plaza was 13,177 px on a phone):
     "What this is" one line that opens; the hire block keeps its question box, the two other ways one tap away (phone
     only); a category shows its first three agents (five until the operator asked for three, same evening) and "Show all N"; each "at work" list its three newest -->
<style>
  .pz-fold>.pz-h{cursor:pointer;margin:0;color:var(--text,#f3efe6)}
  .pz-fold>.pz-h::after{content:' ▾';color:var(--gold,#f0b90b)}
  .pz-fold.open>.pz-h::after{content:' ▴'}
  .pz-fold.open>.pz-h{margin-bottom:10px}
  .pz-fold:not(.open)>:not(.pz-h){display:none!important}
  .pz-hide{display:none!important}
  .pz-more{display:block;margin:10px auto 4px;padding:8px 16px;border-radius:999px;border:1px solid rgba(240,185,11,.4);background:rgba(240,185,11,.08);color:var(--gold,#f0b90b);font:600 13px Inter,sans-serif;cursor:pointer}
  .rg-do-tog{display:none}
  @media(max-width:620px){
    .rg-do-tog{display:block;grid-column:1/-1}
    .rg-do:not(.open) .rg-do-c:not(:first-child){display:none}
  }
</style>
<script>
(function () {
  var nf = function (n) { return Number(n).toLocaleString('en-US'); };
  // "What this is": a tap (or Enter) on its first line
  document.querySelectorAll('.pz-fold').forEach(function (f) {
    var h = f.querySelector('.pz-h'); if (!h) return;
    h.setAttribute('role', 'button'); h.setAttribute('tabindex', '0'); h.setAttribute('aria-expanded', 'false');
    var t = function () { var o = f.classList.toggle('open'); h.setAttribute('aria-expanded', o ? 'true' : 'false'); };
    h.addEventListener('click', t); h.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); t(); } });
  });
  // the hire block's two other ways
  var tog = document.querySelector('.rg-do-tog');
  if (tog) tog.addEventListener('click', function () { var o = tog.parentElement.classList.toggle('open'); tog.setAttribute('aria-expanded', o ? 'true' : 'false'); tog.textContent = o ? 'Fewer ways' : 'Two more ways: pick a category, or call it as an agent'; });
  // a category's open list: its first three, the rest one tap away (ours and the folded "unproven" lists stay as they are)
  document.querySelectorAll('.rg-box[id^="cat-"] > .rgc-list:not(.rgc-ours)').forEach(function (list) {
    var cards = [].slice.call(list.children).filter(function (c) { return c.classList.contains('rgc'); });
    if (cards.length <= 4) return;
    var hide = cards.slice(3); hide.forEach(function (c) { c.classList.add('pz-hide'); });
    var b = document.createElement('button'); b.type = 'button'; b.className = 'pz-more'; b.textContent = 'Show all ' + nf(cards.length) + ' (' + nf(hide.length) + ' more)';
    b.addEventListener('click', function () { hide.forEach(function (c) { c.classList.remove('pz-hide'); }); b.remove(); });
    list.after(b);
  });
  // each "at work" list: its three newest, drawn later by the script above, so it is cut whenever it is drawn
  document.querySelectorAll('.aw-rows').forEach(function (box) {
    var cut = function () {
      var rows = [].slice.call(box.children).filter(function (r) { return r.classList.contains('aw-row'); });
      var old = box.nextElementSibling && box.nextElementSibling.classList.contains('pz-more') ? box.nextElementSibling : null;
      if (old && old.dataset.open === '1') return;
      if (old) old.remove();
      if (rows.length <= 4) return;
      var hide = rows.slice(3); hide.forEach(function (r) { r.classList.add('pz-hide'); });
      var b = document.createElement('button'); b.type = 'button'; b.className = 'pz-more'; b.textContent = 'Show ' + nf(hide.length) + ' more'; /* (28.10.: 'Show the 8 newest' under 3 already shown read as a different list) */ /* the newest only: the total stands on the card above (25.10.: 'Show all 8' under 21 hires) */
      b.addEventListener('click', function () { hide.forEach(function (r) { r.classList.remove('pz-hide'); }); b.dataset.open = '1'; b.remove(); });
      box.after(b);
    };
    new MutationObserver(cut).observe(box, { childList: true }); cut();
  });
})();
</script>
</body>
</html>
`;

// The inline script is checked before the page is written. A stray newline
// inside a string literal once broke the whole <script> block — which silently
// disabled the dispatch box, the filter and the movement section at the same
// time, on a page that still looked fine. Nothing about it was visible without
// opening a console.
//
// new Function() parses without executing: it catches exactly the class of
// error that a generator producing JavaScript is prone to, and nothing else.
{
  const scripts = [...page.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
  for (const [i, src] of scripts.entries()) {
    try { new Function(src); }
    catch (e) {
      console.error(`\nRefusing to write registry.html: inline script #${i + 1} does not parse.`);
      console.error(`  ${e.message}`);
      console.error('  This is almost always a generated string containing a real newline.\n');
      process.exit(1);
    }
  }
  // Also assert the page kept its interactive parts, so a template edit cannot
  // quietly drop one.
  for (const id of ['rg-task', 'rg-go', 'rg-out', 'rg-q', 'rg-body', 'rg-move', 'rg-log', 'rg-live-total', 'rg-tile-total']) {
    if (!page.includes(`id="${id}"`)) {
      console.error(`\nRefusing to write registry.html: #${id} is missing from the page.\n`);
      process.exit(1);
    }
  }

  // The live line has no id to check — it is a class on however many rows the
  // telemetry can be matched to. What can silently break it is teleKey()
  // returning null for everything: the script would still run, find no rows,
  // and return without a trace. So the count is asserted, not the markup.
  const teleRows = (page.match(/ data-tele="/g) || []).length;
  const liveSlots = (page.match(/class="rg-live" hidden/g) || []).length;
  if (teleRows < 3 || teleRows !== liveSlots) {
    console.error(`\nRefusing to write registry.html: ${teleRows} rows carry live telemetry and ${liveSlots} have a slot for it.`);
    console.error('  Expected at least 3 and the two to match. Check teleKey() against the PEERS list and our own agent ids.\n');
    process.exit(1);
  }
}

fs.writeFileSync(path.join(ROOT, 'dashboard', 'registry.html'), page);
console.log(`wrote dashboard/registry.html (${(page.length / 1024).toFixed(1)} KB) and dashboard/api-registry.json`);
console.log(`  ${fmt(total)} registered · ${fmt(c.valid)} parse · ${fmt(c.withHttpEndpoint)} endpoints · ${reach ? fmt(reach.reachable) + ' reachable' : 'probe not run yet'}`);