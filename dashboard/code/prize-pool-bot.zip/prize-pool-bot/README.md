# Prize Pool & Payout Bot

Filled a prize pool from trading tax, then paid 39 wallets out.

The bot behind the World Cup prize pool: it took a slice of every trade into a pool wallet, tracked what the pool was worth as the price moved, and at the end sent the prizes out on-chain — 8.94M tokens across 39 winners, group stage and finals, each with its transaction hash. The price-capture script pins the token price at kickoff so a payout promised in dollars settles in tokens at an agreed, recorded rate.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A wallet holding the pool**
    ours: a dedicated wallet, funded by a slice of the tax
    also: a multisig if the pool is large enough to be worth arguing about
- **Somewhere the entries and scores live**
    ours: the Supabase project from the Worldcup bundle
    also: any Postgres, or any store you can read a winners list out of
- **A machine that can run Node 18+**
    ours: run by hand, watched, one round at a time
    also: none worth having. This one sends money to strangers — do not put it on a cron
- **Secrets at runtime: PRIVATE_KEY, database URL and key**
    ours: a local .env file
    also: a secret manager. Never the source
- **A dry run first**
    ours: --dry-run, every single time
    also: there is no alternative. Read the script before you copy it

## Run it

    node -r dotenv/config worldcup-bot.js
    node scripts/worldcup/wc-payout-final.js --dry-run

## What is in here

- `scripts/worldcup/wc-final-kickoff-prices.json`  (30 lines)
- `scripts/worldcup/wc-final-price-capture.js`  (99 lines)
- `scripts/worldcup/wc-payout-final.js`  (364 lines)
- `scripts/worldcup/wc-payout-group.js`  (495 lines)
- `worldcup-bot.js`  (411 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/prize-pool-bot.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/prize-pool-bot.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
