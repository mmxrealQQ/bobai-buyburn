# DeFi Agent — a PancakeSwap V3 range that runs itself

A concentrated-liquidity range and its reserve, kept by a cron: collect, re-set, grow. No human in the loop.

Holds a PancakeSwap V3 range in CAKE/BNB 0.05% — and a reserve range below the price when BNB waits — and looks after them. Once a day it collects the fees: half stays as capital, half buys $BOBAI that the agent holds. Every hour it checks the range; a range the price has left is re-set beside the price with the one token it ended in — one-sided, nothing is sold at the low or bought at the high. BNB that arrives while the range waits above the price opens a reserve range below it, a buy ladder under the sell ladder, and the two merge again once they hold the same token. A deposit is in the position within ten minutes. The width is not a setting: every hour a window of the pool's swaps is recorded, every candidate width is replayed over the last week with the agent's own re-set cost, and the width that ended the most ahead against simply holding is the one in use. Every decision is a pure function in one guards file, pinned in both directions by a self-test, and every run — including the ones that decided to do nothing — is written to a public record.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A wallet that holds the position**
    ours: one BSC wallet used for nothing else
    also: any wallet — the agent refuses when it finds positions it does not know, so keep it to itself
- **Somewhere that runs code on a schedule**
    ours: a Cloudflare Worker: a daily run, an hourly check, a ten-minute deposit watch
    also: a VPS with crontab or node on your own machine — scripts/lp-agent.mjs runs the same steps by hand, dry by default
- **Somewhere to keep the record**
    ours: one Cloudflare KV namespace
    also: Redis, SQLite, Postgres or a JSON file — one record, one width log, one price tape
- **A BSC RPC endpoint**
    ours: the public endpoints, with failover
    also: any node; a read that fails throws, so a throttled node never looks like an empty wallet
- **A V3 pool with real volume**
    ours: CAKE/BNB 0.05% on PancakeSwap V3
    also: any Uniswap-V3-style pool with WBNB on one side — the pool is one constant, the position manager another
- **One secret at runtime: LP_PRIVATE_KEY**
    ours: wrangler secret put
    also: a .env file for the hand script — anything but the source code

## Run it

    node scripts/lp-agent.mjs --self-test   # every guard, both ways, no chain needed
    node scripts/lp-agent.mjs                # dry: reads the wallet and prints what it would do
    cd worker-lp && npx wrangler deploy

## What is in here

- `scripts/lp-agent.mjs`  (1004 lines)
- `scripts/lp-fork-test.mjs`  (283 lines)
- `scripts/lp-portfolio.mjs`  (94 lines)
- `scripts/lp-windows.mjs`  (486 lines)
- `shared/lp-agent.js`  (1626 lines)
- `shared/lp-alerts.js`  (73 lines)
- `shared/lp-flow.js`  (261 lines)
- `shared/lp-guards.js`  (628 lines)
- `shared/package.json`  (7 lines)
- `worker-agent/lp-pools.js`  (321 lines)
- `worker-agent/lp-portfolio.js`  (246 lines)
- `worker-agent/lp-service.js`  (192 lines)
- `worker-agent/lp-windows.js`  (785 lines)
- `worker-lp/index.js`  (567 lines)
- `worker-lp/package.json`  (6 lines)
- `worker-lp/wrangler.toml`  (65 lines)
- `worker-lp/x402-settle.js`  (107 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/defi-agent.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/defi-agent.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
