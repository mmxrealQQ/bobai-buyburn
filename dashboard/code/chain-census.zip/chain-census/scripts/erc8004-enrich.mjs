// Fills in the parts of a registration the scan does not carry.
//
// The scan is a counting pass over a quarter of a million ids, so it records
// only what it needs to count with. A profile needs more: what the agent says
// it does, what trust model it claims, whether it advertises x402, what it
// looks like. That data is already on-chain in the same tokenURI — it just was
// not worth carrying through 280,000 iterations to get at the few thousand
// entries that have an endpoint.
//
// So this re-reads only the ids that made it into the directory. A few thousand
// calls, a couple of minutes, and it can run while the main scan is still
// going — the two touch different files.
//
// This step had no --dir flag while every other census script had one, so it
// could only ever write into the first census. The second census therefore
// never got a registrations.json at all, and the publisher — which reads that
// file for descriptions and images — silently fell back to an empty object:
// 795 published agents, 0 images. A missing enrichment looks exactly like an
// agent that declared nothing, which is why it went unnoticed for three days.
//
// Usage: node scripts/erc8004-enrich.mjs        (add --dir for a rescan)
import fs from 'node:fs';
import path from 'node:path';
import { censusDirArg } from './lib/census-dir.mjs';
import { HTTP_RE, REAL_TLD_RE } from './lib/census-endpoints.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const DIR = path.join(ROOT, 'data', censusDirArg());
const HITS = path.join(DIR, 'agents-with-endpoints.jsonl');
const OUT = path.join(DIR, 'registrations.json');

const REGISTRY = '0x8004A169FB4a3325136EB29fA0ceB6D2e539a432';
const TOKEN_URI = '0xc87b56dd';
const RPCS = [
  'https://bsc-dataseed1.defibit.io',
  'https://bsc-mainnet.public.blastapi.io',
  'https://bsc-dataseed.binance.org',
  'https://bsc-dataseed2.bnbchain.org',
  'https://bsc-dataseed3.bnbchain.org',
  'https://bsc-dataseed4.defibit.io',
];
const BATCH = 25;

let rr = 0;
const id32 = (n) => BigInt(n).toString(16).padStart(64, '0');

async function callBatch(ids) {
  const payload = ids.map((id, i) => ({
    jsonrpc: '2.0', id: i, method: 'eth_call',
    params: [{ to: REGISTRY, data: TOKEN_URI + id32(id) }, 'latest'],
  }));
  for (let a = 0; a < RPCS.length * 2; a++) {
    try {
      const r = await fetch(RPCS[rr++ % RPCS.length], {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload), signal: AbortSignal.timeout(20000),
      });
      if (!r.ok) continue;
      const j = await r.json();
      if (!Array.isArray(j)) continue;
      const out = new Array(ids.length).fill(null);
      let got = 0;
      for (const it of j) {
        if (typeof it.id !== 'number' || it.error) continue;
        out[it.id] = it.result; got++;
      }
      if (got) return out;
    } catch { /* next endpoint */ }
  }
  return new Array(ids.length).fill(null);
}

const decodeString = (hex) => {
  if (!hex || hex === '0x') return null;
  const b = hex.slice(2);
  try {
    const len = parseInt(b.slice(64, 128), 16);
    if (!(len > 0) || len > 2_000_000) return null;
    const by = [];
    for (let i = 0; i < len; i++) by.push(parseInt(b.substr(128 + i * 2, 2), 16));
    return Buffer.from(by).toString('utf8');
  } catch { return null; }
};

const parse = (raw) => {
  const s = decodeString(raw);
  if (!s) return null;
  const b64 = s.includes('base64,') ? s.split('base64,')[1] : null;
  try {
    return JSON.parse(b64 ? Buffer.from(b64, 'base64').toString('utf8') : s);
  } catch { return null; }
};

if (!fs.existsSync(HITS)) {
  console.error('Run erc8004-scan.mjs first.');
  process.exit(1);
}

const ids = [...new Set(
  fs.readFileSync(HITS, 'utf8').split('\n').filter(Boolean)
    .map((l) => { try { return JSON.parse(l).id; } catch { return null; } })
    .filter((x) => Number.isInteger(x)),
)].sort((a, b) => a - b);

console.log(`enriching ${ids.length.toLocaleString('en-US')} registrations`);

const registrations = {}, fresh = {};
for (let i = 0; i < ids.length; i += BATCH) {
  const chunk = ids.slice(i, i + BATCH);
  const res = await callBatch(chunk);
  for (let n = 0; n < chunk.length; n++) {
    const meta = parse(res[n]);
    if (!meta) continue;
    fresh[chunk[n]] = meta;
    const services = Array.isArray(meta.services) ? meta.services : [];
    registrations[chunk[n]] = {
      name: typeof meta.name === 'string' ? meta.name.slice(0, 90) : null,
      // The operator's own words about what the agent does. On a profile this
      // is the difference between a row and something a person can judge.
      description: typeof meta.description === 'string' ? meta.description.slice(0, 400) : null,
      image: typeof meta.image === 'string' && /^https:\/\//.test(meta.image) ? meta.image : null,
      active: meta.active === true,
      trust: Array.isArray(meta.supportedTrust) ? meta.supportedTrust.slice(0, 6) : [],
      x402: !!meta.x402Support,
      // Named services with their declared kind — "telegram", "web", "MCP" —
      // which is how an agent states its own surface area.
      services: services.map((s) => s && typeof s === 'object' ? {
        name: String(s.name || '').slice(0, 40),
        endpoint: typeof s.endpoint === 'string' ? s.endpoint.slice(0, 200) : null,
        version: s.version ? String(s.version).slice(0, 20) : null,
      } : null).filter(Boolean).slice(0, 10),
    };
  }
  if ((i / BATCH) % 10 === 0) process.stdout.write(`\r  ${Math.min(i + BATCH, ids.length)}/${ids.length}`);
}

fs.writeFileSync(OUT, JSON.stringify(registrations, null, 1) + '\n');

// THE SCAN READS AN ID ONCE; an agent that changes its registration later (setAgentURI) kept its old endpoints in the
// directory for good — the probe, the job scan and the published census all read them from the hits file (2026-10-13:
// five agents still sat at the shared /a2a they had left a week before). This pass has just read every one of them
// fresh, so their records are corrected here with the scan's own rules, one line per id. An id the nodes refused
// keeps its record: a refusal says nothing about the agent.
{
  const lines = fs.readFileSync(HITS, 'utf8').split('\n').filter(Boolean);
  const seenIds = new Set(), out = [];
  let changed = 0;
  for (const line of lines) {
    let rec; try { rec = JSON.parse(line); } catch { out.push(line); continue; }
    if (seenIds.has(rec.id)) continue;
    seenIds.add(rec.id);
    const meta = fresh[rec.id];
    if (!meta) { out.push(line); continue; }
    const services = Array.isArray(meta.services) ? meta.services : [];
    const http = services.map((x) => x && typeof x.endpoint === 'string' ? x.endpoint : null).filter((e) => e && HTTP_RE.test(e));
    if (!http.length) { out.push(line); continue; }
    const next = {
      id: rec.id, name: typeof meta.name === 'string' ? meta.name.slice(0, 80) : null, active: meta.active === true,
      endpoints: http.slice(0, 6),
      mcp: services.some((x) => x && /mcp/i.test(String(x.name || ''))),
      a2a: services.some((x) => x && /a2a/i.test(String(x.name || ''))),
      x402: !!meta.x402Support || services.some((x) => x && /x402/i.test(String(x.name || ''))),
      plausible: http.some((e) => REAL_TLD_RE.test(e.replace(/^https?:\/\//i, ''))),
      trust: Array.isArray(meta.supportedTrust) ? meta.supportedTrust : [],
    };
    const s = JSON.stringify(next);
    if (s !== line) changed++;
    out.push(s);
  }
  fs.writeFileSync(HITS + '.tmp', out.join('\n') + '\n');
  fs.renameSync(HITS + '.tmp', HITS);
  console.log(`  directory records corrected from the fresh read: ${changed} (${out.length} agents, one line each)`);
}
const withDesc = Object.values(registrations).filter((r) => r.description).length;
const withImg = Object.values(registrations).filter((r) => r.image).length;
const withTrust = Object.values(registrations).filter((r) => r.trust.length).length;
console.log(`\n  ${Object.keys(registrations).length} read · ${withDesc} describe themselves · ${withImg} have a logo · ${withTrust} declare a trust model`);
console.log(`written: ${path.relative(ROOT, OUT)}`);