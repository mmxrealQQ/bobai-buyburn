# Brain Pop 6.9 — the daily game in the terminal

60 seconds, one engine file, every tap replayed by the server.

The season game of the Brain Terminal (6 to 30 Nov 2026). One deterministic engine file runs in the browser AND on the server: the page sends only the taps [time, x, y], the worker replays them with the same file and the same seed, so no score can be typed in. Seven stations charge with the player's own hits and fire super powers by themselves; combos at 8, 16 and 24; a daily top 10 and an overall board in a Durable Object (SQLite).

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A worker with a Durable Object (SQLite)**
    ours: Cloudflare Workers, class PopBoard
    also: any server that can run an ES module and keep two small tables
- **The same engine file on both sides**
    ours: pop-engine.mjs, imported by the page and by the worker
    also: keep one file; a copy that drifts makes the replay disagree with the screen

## Run it

    node worker-pop/test.mjs
    node worker-pop/test2.mjs
    cd worker-pop && npx wrangler deploy

## What is in here

- `scripts/pop-chain-fork-test.mjs`  (64 lines)
- `temp/terminal-site/terminal/pop-engine.mjs`  (178 lines)
- `worker-agent/pop-chain.js`  (109 lines)
- `worker-pop/game.js`  (135 lines)
- `worker-pop/index.js`  (220 lines)
- `worker-pop/test.mjs`  (39 lines)
- `worker-pop/test2.mjs`  (62 lines)
- `worker-pop/wrangler.toml`  (13 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/brain-pop.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/brain-pop.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
