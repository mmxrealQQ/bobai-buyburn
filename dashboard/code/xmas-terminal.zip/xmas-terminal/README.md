# Xmas Terminal — the community builds the terminal's look

One npx command, your own AI agent, a sandboxed theme on the live terminal.

Anyone builds an Xmas look for the Brain Terminal (2026-11-17): npx https://brainonbnb.com/xmas/kit.tgz asks the terminal's name and the builder, writes the guide every agent reads (AGENTS/CLAUDE/GEMINI/Cursor/Copilot), and gives dev (the live terminal mirrored with the folder in it, saved = shown), check, upload, and pictures/clips with the builder's own OpenAI and Google keys. Themes live in a worker of their own with storage of its own and are served into sandboxed frames (opaque origin, no calls out, no eval, no clicks); the terminal tells them every trade, burn and move. Included: the worker, the kit, our own theme as a worked example, and the pins.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A worker and a key-value store of their own**
    ours: Cloudflare Workers + KV (bobai-xmas on workers.dev)
    also: any server that stores a bundle per version and serves files with a CSP header
- **A page that can frame the themes**
    ours: the Brain Terminal (terminal.js, the XMAS block): <iframe sandbox="allow-scripts">
    also: any page: two sandboxed frames and postMessage are the whole contract

## Run it

    node scripts/xmas-worker-regressions.mjs
    node scripts/xmas-kit-regressions.mjs
    npx wrangler deploy --config worker-xmas/wrangler.toml
    npm pack ./xmas-kit

## What is in here

- `scripts/xmas-admin.mjs`  (16 lines)
- `scripts/xmas-kit-regressions.mjs`  (67 lines)
- `scripts/xmas-worker-regressions.mjs`  (97 lines)
- `worker-xmas/index.js`  (13 lines)
- `worker-xmas/wrangler.toml`  (11 lines)
- `worker-xmas/xmas.js`  (231 lines)
- `xmas-kit/guide.md`  (207 lines)
- `xmas-kit/package.json`  (10 lines)
- `xmas-kit/template/back.html`  (24 lines)
- `xmas-kit/template/front.html`  (22 lines)
- `xmas-kit/xmas.mjs`  (326 lines)
- `xmas-themes/bobai-xmas-mmx_qq/theme/back.html`  (269 lines)
- `xmas-themes/bobai-xmas-mmx_qq/theme/front.html`  (103 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/xmas-terminal.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/xmas-terminal.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
