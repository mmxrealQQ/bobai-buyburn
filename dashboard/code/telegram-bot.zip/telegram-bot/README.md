# Telegram Bot

Buy alerts, burn alerts, price, whale tracking, captcha.

A full community bot as a single Cloudflare Worker: reads Swap and Transfer logs off the chain to post buy and burn alerts with generated images, answers /price, /burns, /security and friends, tracks a watchlist of whale wallets, and gates new joiners with a captcha. No polling server — a one-minute cron plus a webhook.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A bot token**
    ours: one from @BotFather, two minutes of work
    also: none — this is Telegram's only door
- **Somewhere to receive a webhook and run a cron**
    ours: a single Cloudflare Worker doing both
    also: any HTTPS endpoint: a small VPS, Deno Deploy, Vercel, Fly.io. Long-polling works too, at the cost of a process that never sleeps
- **Somewhere to keep state**
    ours: one Cloudflare KV namespace
    also: Redis, SQLite, Postgres — it stores the block cursor, the watchlist and the captcha queue
- **A BSC RPC endpoint that allows eth_getLogs**
    ours: a keyed endpoint, with free ones as fallback
    also: NodeReal, Ankr, QuickNode. Note that bsc-dataseed refuses log queries outright
- **One secret at runtime: BOT_TOKEN**
    ours: wrangler secret put
    also: any secret store your host offers

## Run it

    npx wrangler deploy
    then point the Telegram webhook at the worker URL

## What is in here

- `scripts/tg/tg-create-saga-pack.js`  (86 lines)
- `scripts/tg/tg-create-stickerset.js`  (101 lines)
- `scripts/tg/tg-delete-message.js`  (33 lines)
- `scripts/tg/tg-extend-stickerset.js`  (71 lines)
- `scripts/tg/tg-get-media.js`  (46 lines)
- `scripts/tg/tg-photo.js`  (79 lines)
- `scripts/tg/tg-saga-add-rest.js`  (56 lines)
- `scripts/tg/tg-saga-replace.js`  (38 lines)
- `scripts/tg/tg-send-sticker.js`  (45 lines)
- `scripts/tg/tg-update.js`  (65 lines)
- `worker-tg-bot/index.js`  (3769 lines)
- `worker-tg-bot/wrangler.toml`  (10 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/telegram-bot.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/telegram-bot.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
