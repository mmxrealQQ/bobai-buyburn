// SCANNER — the page layer. Every number shown here is produced by
// scanner-chain.js; this file decides only how it is presented and, just as
// importantly, how uncertainty is presented. Two rules run through all of it:
//
//   1. Nothing is rendered as markup from a name a stranger chose. Token names
//      are attacker-controlled strings and a contract can call itself
//      "<img onerror=…>". Everything foreign goes in through a text node.
//   2. Unknown is a state, not a blank. A property GoPlus did not check must
//      read "not checked" — never as an absent warning, which is how a reader
//      hears "fine". $Max returned undefined for is_honeypot and the old build
//      showed nothing at all, which is the most dangerous thing this page
//      could do.
import {RPC,GOPLUS,V2FACTORY,WBNB,BNB_PAIR,DEAD,NULLA,QUOTES,V2_FEE,STEPS,SEL as S,
  balOf,call,hx,addrAt,res2,decStr,rpcBatch,classify,priceToken,discover,indexedPool,priceQuote,flapInfo,flapLadder,UNI_QUOTER,
  ladderV2,onePctV2,ladderV3,onePctV3,ladderInf,onePctInf,infinityFind,infinityPool,infReachUsd,INF_CL_QUOTER,
  measureTax,venues,measureVenues,FACTORIES,simulateRoundTrip,
  curveInfo,curveLadder,curveFeed,FOURMEME_MANAGER,decOf,
  readHolders,lpCustody,contractAges,readActivity,readFlow,knownHolder} from './scanner-chain.js?v=40';

const $=id=>document.getElementById(id);
const NF={};const nf=(n,d=0)=>(NF[d]||(NF[d]=new Intl.NumberFormat('en-US',{minimumFractionDigits:d,maximumFractionDigits:d}))).format(Number(n)); // one formatter per decimal count, kept: toLocaleString built a new one on every call (35x slower, 2026-10-06), same output
// toPrecision() switches to exponential notation below 1e-7, which printed a real
// price as "$1.79e-8". Nobody quotes a token price that way. Write it out with
// every zero instead, at three significant digits. Longer, but unambiguous — and
// unlike the subscript-zero style ($0.0₈179) it survives being copied off the page,
// where the subscript silently degrades into an ordinary digit.
// The exponent comes from toExponential() rather than log10(), which is off by one
// for exact powers of ten (log10(0.001) = -3.0000000000000004).
const tiny=n=>{
  if(!(n>0))return Number(n||0).toFixed(2);
  const e=parseInt(n.toExponential(2).split('e')[1],10);
  // toFixed() caps at 100 decimals. Past that the expansion would be all zeros
  // and no significant digit at all, so keep the exponent rather than print a
  // number that reads as zero.
  return e<-98?n.toExponential(2):n.toFixed(Math.max(2,2-e));
};
const usd=n=>n==null?'—':n>=1000?'$'+nf(n):n>=1?'$'+nf(n,2):n>=0.01?'$'+nf(n,4):'$'+tiny(n);
const short=a=>a?a.slice(0,6)+'…'+a.slice(-4):'—';
// What a rebalance costs, said in units of what the position earns rather than
// in dollars — a dollar figure means nothing without the thing it is compared
// against. Rounded to whole windows only when there are whole windows to round
// to: the first version printed "about 0 windows" whenever the fees for one
// window happened to exceed the gas, which is the case this sentence exists to
// describe as GOOD news.
const costInWindows=(cost,fees)=>{
  if(!(cost>0))return 'nothing measurable';
  if(!(fees>0))return 'more than this range collected at all';
  const n=cost/fees;
  if(n>=1.5)return Math.round(n)+' windows of what it collected';
  if(n>=0.75)return 'about one window of what it collected';
  return Math.round(n*100)+'% of what it collected in one window';
};
// Two decimals lie at both ends: 99.998% burned rounds to a flat "100.00%",
// claiming more than the chain says, and a real 0.002% rounds to "0.00%",
// claiming it is not there. A sell tax of 4.45% must never print as "4.5%".
const pc=(v,d=2)=>v==null?'—':v>0&&v<0.01?'<0.01%':(v>=99.995&&v<100)?'>99.99%':v.toFixed(d)+'%';
const signed=v=>v==null?'—':(v<0?'':'+')+(Math.abs(v)<0.005?'0.00':v.toFixed(2))+'%';
function el(tag,cls,text){const e=document.createElement(tag);
  if(cls)e.className=cls;if(text!=null)e.textContent=text;return e}
function frag(parent,...kids){kids.forEach(k=>parent.append(k));return parent}
const link=(t,href,cls)=>{const a=el('a',cls||'lk',t);a.href=href;a.target='_blank';a.rel='noopener';return a};

function fail(msg,sub){
  const o=$('sc-out');o.hidden=true;o.textContent='';
  const e=$('sc-err');e.hidden=false;e.textContent='';
  e.appendChild(el('b',null,msg));if(sub)e.appendChild(el('span',null,sub));
  $('sc-status').textContent='';
}
function busy(on,msg){
  $('sc-go').disabled=on;$('sc-go').textContent=on?'Reading…':'Scan';
  $('sc-status').textContent=on?(msg||''):'';
}
const step=m=>{if($('sc-go').disabled)$('sc-status').textContent=m};

// GoPlus flags. The third column says what a MISSING value means: for most
// properties silence is just silence, and claiming otherwise would invent an
// all-clear the service never gave.
const FLAGS=[
  ['is_mintable','Mintable','More tokens can be created — the supply is not fixed.'],
  ['is_proxy','Proxy contract','The logic sits behind an upgradeable pointer and can be replaced.'],
  ['can_take_back_ownership','Ownership reclaimable','A renounce can be undone.'],
  ['hidden_owner','Hidden owner','Ownership is held somewhere other than the usual slot.'],
  ['selfdestruct','Self-destruct','The contract can delete itself.'],
  ['transfer_pausable','Transfers pausable','Someone can freeze all transfers.'],
  ['is_blacklisted','Blacklist','Individual wallets can be blocked from trading.'],
  ['slippage_modifiable','Tax changeable','The tax rate is not fixed — it can be raised later.'],
  ['personal_slippage_modifiable','Per-wallet tax','A different tax can be set for individual wallets.'],
  ['trading_cooldown','Trading cooldown','A forced wait is enforced between trades.'],
  ['is_anti_whale','Max transaction limit','A cap on trade size is enforced.'],
  ['anti_whale_modifiable','Trade cap changeable','That cap can be changed later.'],
  ['cannot_sell_all','Cannot sell all','Selling the full balance in one go is blocked.'],
];

// COLOUR — and what it is allowed to mean.
//
// Green/amber/red here say ONE thing: how much this costs you, measured against
// a floor that is not a matter of opinion. Every pool has an unavoidable toll —
// the swap fee plus the transfer tax — that you pay at any size. Everything on
// top of that is depth. So the bands compare what you actually pay against that
// floor, and the impact bands are read straight off the price you move.
//
// What the colour deliberately does NOT mean: that a token is good, safe, or
// worth buying. A deep pool with a renounced owner can still go to zero, and a
// thin one can be perfectly honest. Publishing a verdict about somebody else's
// token would put our name on a judgement we cannot stand behind — and the one
// time we got it wrong, that is the only thing anyone would remember.
//
// An earlier draft coloured these by percentile against a sample of 46 pools.
// That was dropped: a keyword-scraped sample of 46 is not a distribution, and
// dressing it up as one would be inventing authority.
const band=(v,ok,mid)=>v==null?'':v<=ok?' good':v<=mid?' mid':' bad';
const costBand=(pay,floor)=>{
  if(pay==null||!(floor>0))return '';
  return band(pay/floor,1.5,3);       // at most half again over the toll, or triple it
};
const impactBand=v=>v==null?'':band(Math.abs(v),1,5);   // 1% and 5% of the price you move

// ---- building blocks -------------------------------------------------------
function statRow(items){
  const g=el('div','st-row');
  items.forEach(it=>{
    const c=el('div','st');
    // A sub-cent price written out with every zero is far longer than a market
    // cap, and at the headline size it wrapped mid-number on a 390px phone — a
    // price broken across two lines invites a misread. Step the size down by
    // length instead of letting it break.
    const vs=String(it.v==null?'':it.v),
          fit=vs.length>=16?' st-xl':vs.length>=12?' st-lg':'';
    c.appendChild(el('div','st-v'+fit+(it.dim?' dim':'')+(it.tone||''),it.v));
    c.appendChild(el('div','st-l',it.l));
    if(it.s){
      const s=el('div','st-s',it.s);
      // An address printed as plain text is a dead end — the reader wants to go
      // look at the wallet, and making them copy it by hand is the difference
      // between a claim and something they can check.
      if(it.link)s.append(' ',link(it.link.t,it.link.href,'lk'));
      c.appendChild(s);
    }
    g.appendChild(c);
  });
  return g;
}
// ---- the route: what a trade of MY size returns ----------------------------
//
// The scan above prices a trade at a reference size. A trader's own question
// is narrower: at the size I mean to trade, which of the pools this pair lives
// in returns the most, what do I get back if I sell straight away (pool fees,
// my own price impact and the measured transfer tax in it), and what slippage
// does that take. The measurement has been sold to agents as
// pancakeswap_best_route (MCP, skill, /api/best-route) since August and had no
// card here — a person could not ask what an agent could (2026-09-18). Same
// rule as the two cards below: one number, one source, behind a button.
// Each of the three button cards names itself (data-card): they share every
// class, and the checker that picked them by position pressed the wrong button
// the day this card was put in front of the other two (2026-09-19).
function routeCard(token){
  const c=card('Which route returns the most at your size',
    'For trading. Quoted by the venue at the size you name, with the round trip and the slippage it takes.');
  c.dataset.card='route';
  const form=el('div','rt-form');
  const lab=el('label','rt-lab','Size in USD');
  const inp=document.createElement('input');
  inp.type='number';inp.min='1';inp.max='1000000';inp.step='1';inp.value='250';inp.className='rt-inp';inp.inputMode='decimal';
  inp.setAttribute('aria-label','Trade size in US dollars');
  const btn=el('button','sc-tierbtn','Quote the routes');
  btn.type='button';
  form.append(lab,inp,btn);
  const out=el('div','tier-out');
  c.append(form,out);

  const run=async()=>{
    if(btn.disabled)return;
    const usdSize=Math.min(1000000,Math.max(1,Number(inp.value)||250));
    inp.value=String(usdSize);
    btn.disabled=true;btn.textContent='Quoting…';
    out.textContent='';
    try{
      const r=await fetch('/api/best-route?address='+encodeURIComponent(token)+'&usd='+encodeURIComponent(usdSize));
      const d=await r.json();
      if(d.error){renderTierError(out,d.error);return;}
      renderRoute(out,d);
    }catch(e){
      renderTierError(out,'The quote did not come back. Nothing is cached here, so a retry usually works.');
    }finally{
      btn.disabled=false;btn.textContent='Quote again';
    }
  };
  btn.addEventListener('click',run);
  inp.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();run();}});
  return c;
}

function renderRoute(out,d){
  out.textContent='';
  const routes=(d.routes||[]);
  const quoted=routes.filter(r=>r.quoted);
  const sym=(d.token&&d.token.symbol)||'tokens', q=(d.quote&&d.quote.symbol)||'BNB';
  const amt=x=>x==null?'—':(Math.abs(x)>=1000?nf(x,0):Math.abs(x)>=1?nf(x,2):nf(x,6));
  // worse_than_best_pct is how much MORE the best route returns than this one
  // (best/out − 1): a dust pool reads 97,802,455%. What a person means by
  // "worse" is how much LESS arrives: w/(100+w). A pool that returns under a
  // hundredth of the best cannot fill the size at all and is named so.
  const lessPct=r=>{const w=Number(r.worse_than_best_pct)||0;return w<=0?0:w/(100+w)*100;};
  const cannotFill=r=>lessPct(r)>99;
  const ans=el('div','vd tier-ans');
  const line=(tone,head,body)=>{
    const r=el('div','vd-r vd-'+tone);
    r.appendChild(el('b',null,head));
    if(body)r.appendChild(el('span',null,body));
    ans.appendChild(r);
  };

  // A reason not to trade outranks every figure below it.
  for(const why of (d.refuse_to_trade||[]))line('bad','Do not trade this as it stands.',String(why));

  if(!quoted.length){
    line('unknown','No route could be quoted at this size.',
      'None of the '+routes.length+' pools answered the quote. That says nothing about the token — ask again in a moment, or try a smaller size.');
    out.appendChild(ans);
    return;
  }

  // 1. The answer: which route, what arrives.
  line('good',(d.best_route||quoted[0].route)+' returns the most at $'+nf(d.size_usd||0,0)+'.',
    'You pay '+amt(d.you_pay&&d.you_pay.amount)+' '+q+' and receive about '+amt(d.you_would_receive)+' '+sym+
    (()=>{const others=quoted.filter(r=>r.route!==d.best_route&&!cannotFill(r));const thin=quoted.filter(cannotFill).length;
      return (others.length?'. The other route'+(others.length>1?'s':'')+' would return up to '+nf(Math.max(...others.map(lessPct)),2)+'% less':(quoted.length>1?'':'. It is the only pool that quoted'))+
        (thin?(others.length||quoted.length>1?'; ':'. ')+thin+' pool'+(thin>1?'s are':' is')+' too thin to fill this size':'')+'.';})()+
    (d.best_route_is_the_deepest_pool===false?' It is not the pool holding the most money — depth and price at your size are different questions.':''));

  // 2. The round trip: what comes back if you sell at once.
  const rt=d.round_trip;
  if(rt&&rt.you_keep_pct!=null){
    const keep=rt.you_keep_pct, tone=keep>=95?'good':keep>=85?'mid':'bad';
    line(tone,'Sold straight back, '+nf(keep,2)+'% of your '+q+' returns.',
      'That is '+amt(rt.sell_back_immediately)+' '+q+' of '+amt(d.you_pay&&d.you_pay.amount)+'. Two pool fees and the price your own trade moves are in it'+
      (rt.you_keep_pct_pools_only!=null&&Math.abs(rt.you_keep_pct_pools_only-keep)>0.01?', and the measured transfer tax: through the pools alone it would be '+nf(rt.you_keep_pct_pools_only,2)+'%.':'.'));
  }

  // 3. The tax: measured, or said to be unknown — never zero by default.
  const tx=d.transfer_tax||{};
  if(tx.buy_pct!=null||tx.sell_pct!=null){
    const hi=Math.max(tx.buy_pct||0,tx.sell_pct||0);
    line(hi>10?'bad':hi>0?'mid':'good','Transfer tax measured: '+(tx.buy_pct!=null?nf(tx.buy_pct,2)+'% on a buy':'buy unknown')+', '+(tx.sell_pct!=null?nf(tx.sell_pct,2)+'% on a sell':'sell unknown')+'.',
      tx.source?String(tx.source):null);
  }else{
    line('unknown','The transfer tax could not be measured this time.',
      (tx.source?String(tx.source)+'. ':'')+(d.round_trip_caveat?String(d.round_trip_caveat):'Unknown is not zero: if this token takes a cut, the round trip above is too high.'));
  }

  // 4. The setting a wallet asks for.
  if(d.slippage_bps_needed!=null){
    line('mid','Slippage to set: about '+nf(d.slippage_bps_needed/100,2)+'%.',d.slippage_note?String(d.slippage_note):null);
  }
  out.appendChild(ans);

  // THE EVIDENCE: every pool asked, quoted or not.
  if(routes.length>1){
    const t=el('div','rt-t');
    const head=el('div','rt-r rt-hr');
    head.append(el('span',null,'route'),el('span','rt-num','you receive'),el('span','rt-num','against the best'));
    t.appendChild(head);
    for(const r of routes){
      const row=el('div','rt-r'+(r.route===d.best_route?' tier-best':''));
      row.append(el('span','tier-n',String(r.route)),
        el('span','rt-num',r.quoted?amt(r.out_tokens)+' '+sym:'no quote'),
        el('span','rt-num',r.quoted?(r.route===d.best_route||!lessPct(r)?'best':cannotFill(r)?'too thin for this size':'−'+nf(lessPct(r),2)+'%'):'—'));
      t.appendChild(row);
    }
    out.appendChild(t);
  }
  for(const x of (d.cannot_see||[]))out.appendChild(el('p','cd-foot',String(x)));
}

// ---- fee tiers: the question a liquidity provider has ----------------------
//
// Everything above this card answers "what would a trade cost me". This one
// answers the other side: a pair on PancakeSwap lives in up to five pools at
// once — V2 at 0.25% and V3 at 0.01/0.05/0.25/1.00% — and every interface,
// including the venue list further up this page, ranks them by the money
// already parked in them. That is a record of what other people did. It is not
// what the pool pays, and the two come apart constantly.
//
// WHY THIS ONE CALLS AN ENDPOINT ON A PAGE THAT OTHERWISE CALLS NONE
// The rest of this page reads the chain straight from the visitor's browser and
// costs nothing to run. This card asks brainonbnb.com/api/fee-tiers instead,
// and that is deliberate rather than lazy: the identical measurement is sold to
// agents through an MCP tool and an ERC-8183 agent, and a page that computed it
// a second time here would eventually disagree with them about which tier pays
// best. One number, one source. It is behind a button so the default scan is
// unchanged, and nothing on this card is fetched unless somebody asks for it.
function tierCard(token){
  const c=card('Which fee tier is paying its liquidity providers',
    'For providing liquidity, not for trading. Measured over a live window and deliberately not annualised.');
  c.dataset.card='tiers';
  const btn=el('button','sc-tierbtn','Measure the PancakeSwap tiers');
  btn.type='button';
  const out=el('div','tier-out');
  c.append(btn,out);

  btn.addEventListener('click',async()=>{
    if(btn.disabled)return;
    btn.disabled=true;btn.textContent='Measuring…';
    out.textContent='';
    try{
      const r=await fetch('/api/fee-tiers?address='+encodeURIComponent(token));
      const d=await r.json();
      if(d.error){renderTierError(out,d.error);return;}
      renderTiers(out,d);
      btn.remove();
    }catch(e){
      renderTierError(out,'The measurement did not come back. Nothing is cached here, so a retry usually works.');
    }finally{
      if(btn.isConnected){btn.disabled=false;btn.textContent='Measure the PancakeSwap tiers';}
    }
  });
  return c;
}

function renderTierError(out,msg){
  out.textContent='';
  out.appendChild(el('p','cd-foot',msg));
}

function renderTiers(out,d){
  out.textContent='';
  const measured=(d.tiers||[]).filter(t=>t.measured);

  // A refused range and a quiet pool arrive as the same emptiness and mean
  // opposite things — one of them is a fact about somebody's pool and the other
  // is a fact about our measurement. Never the same sentence.
  if(!measured.length){
    out.appendChild(el('p','cd-foot','None of the '+((d.tiers||[]).length)+
      ' tiers could be read this time: the log endpoint refused the range. That says nothing about whether the pair traded. Try again in a moment.'));
    return;
  }

  // THE ANSWER FIRST, THE EVIDENCE UNDER IT.
  //
  // The table below is five rows of numbers that a liquidity provider has to
  // hold in their head simultaneously to get an answer out of. The answer is
  // two sentences, so it goes first, in the same shape the scan result uses
  // further up this page.
  const best=d.best_paying_tier, most=d.most_capital_tier;
  const bestW=d.best_paying_tier_by_working_capital, mostW=d.most_working_capital_tier;
  const ans=el('div','vd tier-ans');
  const line=(tone,head,body)=>{
    const r=el('div','vd-r vd-'+tone);
    r.appendChild(el('b',null,head));
    if(body)r.appendChild(el('span',null,body));
    ans.appendChild(r);
  };
  const row=t=>(d.tiers||[]).find(x=>x.tier===t);

  // 1. Where a new dollar earns most. Withheld — loudly — when any tier went
  //    unread or any band came back truncated, because a ranking over a subset
  //    names whichever tier happened to be readable.
  if(bestW){
    const b=row(bestW);
    line('good',bestW+' pays the most per dollar that is actually working.',
      b&&b.fees_per_1000_usd_working!=null
        ?'It paid $'+b.fees_per_1000_usd_working.toFixed(4)+' per $1,000 of capital standing within '+
         (d.band_pct||2)+'% of the price, over this window. That is the figure to compare, because a dollar you add only earns beside the capital that is at the price.'
        :'Measured over the capital standing at the price rather than the capital in the pool.');
  }else if(d.comparison_complete===false){
    const n=(d.tiers_unreadable||[]).length;
    line('unknown',n+' of '+(d.tiers_found||0)+' tiers could not be read, so no tier is called best.',
      (d.best_paying_tier_among_readable?'Of the ones that were read, '+d.best_paying_tier_among_readable+' paid most. ':'')+
      'A ranking over an unknown subset would name whichever tier happened to answer. Ask again in a moment.');
  }else if(d.bands_complete===false){
    line('unknown','The tick book was too dense to read whole, so no tier is called best.',
      'One of these pools has more price levels inside the band than can be read in one pass. The capital shown for it is understated, and understating one tier flatters the others.');
  }else{
    line('unknown','Nothing traded on any tier that could be read in this window.',
      'No fees were paid, so no tier can be ranked by what it paid. The capital figures below still hold.');
  }

  // 2. The finding this panel exists for: what a pool HOLDS and what it has
  //    standing at the price are different numbers, and every interface an LP
  //    can consult shows the first one.
  if(most&&mostW&&most!==mostW){
    const a=row(most), b=row(mostW);
    line('mid',most+' holds the most money. '+mostW+' has the most of it at the price.',
      (a&&a.capital_usd!=null&&a.working_capital_usd!=null&&b&&b.working_capital_usd!=null)
        ?most+' holds '+usd(a.capital_usd)+' and stands '+usd(a.working_capital_usd)+' within '+(d.band_pct||2)+
         '% of the price. '+mostW+' stands '+usd(b.working_capital_usd)+'. Depth on a listing page is the first number; what you compete with is the second.'
        :'');
  }else if(d.working_capital_changes_the_answer===true&&best&&bestW&&best!==bestW){
    line('mid','By the usual measure '+best+' looks best. By working capital '+bestW+' is.',
      'Dividing the same fees by everything the pool holds rewards a pool for capital that earns nothing. Both figures are in the table.');
  }else if(most&&mostW&&most===mostW&&bestW){
    line('mid',most+' both holds the most and stands the most at the price.',
      'The two measures agree here, which is worth knowing rather than assuming.');
  }
  out.appendChild(ans);

  const rows=el('div','tier-t');
  const head=el('div','tier-r tier-hr');
  head.append(el('span','tier-n','tier'),el('span','tier-c','in the pool'),
    el('span','tier-w','at the price'),el('span','tier-v','traded'),
    el('span','tier-f','pays per $1,000 working'));
  rows.appendChild(head);

  // The header disappears below 560px, so each figure carries its own label
  // that only shows there. Two unexplained numbers side by side on a phone is
  // how a panel with more information ends up saying less.
  const cell=(cls,label,text,extra)=>{
    const s=el('span',cls+(extra||''));
    s.appendChild(el('i','tl',label));
    s.appendChild(document.createTextNode(text));
    return s;
  };

  (d.tiers||[]).forEach(t=>{
    const r=el('div','tier-r'+(t.tier===bestW?' tier-best':''));
    const n=el('span','tier-n',t.tier);
    if(t.tier===most)n.appendChild(el('em','tier-tag','most capital'));
    else if(t.tier===mostW)n.appendChild(el('em','tier-tag','most at the price'));
    r.appendChild(n);
    r.appendChild(cell('tier-c','in the pool',t.capital_usd==null?'—':usd(t.capital_usd)));
    // Share as well as amount: "$171K of $17.4M" is the whole point, and one
    // percent reads harder than it should without the figure it is a share of.
    r.appendChild(cell('tier-w','at the price',
      t.working_capital_usd==null?'—':usd(t.working_capital_usd)+
        (t.working_share_pct!=null?' ('+t.working_share_pct.toFixed(t.working_share_pct<10?1:0)+'%)':'')));
    if(!t.measured){
      r.appendChild(cell('tier-v dim','traded','not readable'));
      r.appendChild(cell('tier-f dim','pays per $1,000','—'));
    }else{
      r.appendChild(cell('tier-v','traded',t.volume_usd>0?usd(t.volume_usd):'nothing'));
      const pays=t.fees_per_1000_usd_working;
      r.appendChild(cell('tier-f','pays per $1,000',pays==null?'—':'$'+pays.toFixed(4),
        t.tier===bestW?' good':(pays===0?' dim':'')));
    }
    rows.appendChild(r);
  });
  out.appendChild(rows);

  const idle=(d.idle_capital||[]).reduce((s,x)=>s+(x.capital_usd||0),0);
  if(idle>=100){
    out.appendChild(el('p','cd-foot',usd(idle)+' sits in '+
      (d.idle_capital.length===1?'a tier that':'tiers that')+' saw no trade at all in this window: '+
      d.idle_capital.map(x=>x.tier).join(', ')+'.'));
  }

  const w=d.measured_window||{};
  out.appendChild(el('p','cd-foot','Measured over '+(w.minutes??'~59')+
    ' minutes of chain — a sample, not a rate, and not annualised. What a tier "pays" is what reaches its liquidity providers: the pool fee on the turnover less the part PancakeSwap keeps for the protocol, read from each pool (about a third on V3, 0.08 of V2’s 0.25). Capital is both sides of the pool. "At the price" is the part of it standing within '+
    (d.band_pct||2)+'% of the current price, walked from the pool’s own tick data and checked against PancakeSwap’s quoter; the rest is on the balance sheet and earns nothing while the price is where it is. It assumes the price stays in that band, which it will not do forever. Impermanent loss is not in any of this.'));
}

// THE QUESTION AFTER THE TIER, and the only one V3 really forces.
//
// The card above answers which of the five pools sharing this pair is worth
// being in. Having picked one, a liquidity provider still has to say between
// which two prices the money sits, and that decision moves the outcome far more
// than the tier does — three orders of magnitude, on the pair this was built
// against. Every interface offers a preset for it.
//
// This is not a preset and not a forecast. The V3 Swap event carries the
// liquidity that was active when each trade went through, so a position of a
// chosen size is walked back through the trades that actually happened: in
// range or not, and what share of the liquidity standing there it would have
// been. Behind a button, like the tier card, because it costs a measurement.
function rangeCard(token){
  const c=card('Which price range, if you did provide liquidity',
    'A V3 position is not in a pool, it is between two prices. Replayed against the trades that actually happened in a live window.');
  c.dataset.card='range';
  const btn=el('button','sc-tierbtn','Replay the ranges');
  btn.type='button';
  const out=el('div','tier-out');
  c.append(btn,out);

  btn.addEventListener('click',async()=>{
    if(btn.disabled)return;
    btn.disabled=true;btn.textContent='Replaying…';
    out.textContent='';
    try{
      const r=await fetch('/api/range-plan?address='+encodeURIComponent(token));
      const d=await r.json();
      if(d.error){renderTierError(out,d.error);return;}
      renderRanges(out,d);
      btn.remove();
    }catch(e){
      renderTierError(out,'The replay did not come back. Nothing is cached here, so a retry usually works.');
    }finally{
      if(btn.isConnected){btn.disabled=false;btn.textContent='Replay the ranges';}
    }
  });
  return c;
}

function renderRanges(out,d){
  out.textContent='';
  const rows=d.ranges||[];
  const w=d.measured_window||{};
  if(!rows.length||!w.swaps){
    out.appendChild(el('p','cd-foot','No swap in the measured window, so there is nothing to replay a position against. That is a fact about this pool in the last hour, not about the ranges.'));
    return;
  }

  const ans=el('div','vd tier-ans');
  const line=(tone,head,body)=>{
    const r=el('div','vd-r vd-'+tone);
    r.appendChild(el('b',null,head));
    if(body)r.appendChild(el('span',null,body));
    ans.appendChild(r);
  };
  const held=d.narrowest_range_that_held_the_whole_window;
  const best=d.best_earning_range_in_this_window;

  // The honest headline is the narrowest range that HELD, not the one that
  // earned most. The best earner is regularly a range the price walked out of,
  // and naming that as the answer would be recommending a position on the
  // strength of the hour before it broke.
  if(held){
    const row=rows.find(r=>r.width_pct!=null&&('±'+r.width_pct+'%')===held);
    const full=rows.find(r=>r.full_range);
    line('good',held+' is the narrowest range that held for the whole window.',
      (row&&full&&full.fees_usd_in_window>0)
        ? 'On $'+nf(d.capital_considered_usd)+' it would have collected '+usd(row.fees_usd_in_window)+
          ' — about '+Math.round(row.fees_usd_in_window/full.fees_usd_in_window)+
          ' times what the same money makes spread across every price. Narrow is where the fees are; it is also where the work is.'
        : 'Narrower ranges earn more per dollar and stop earning the moment the price leaves them.');
  }else{
    line('unknown','No range on this list held for the whole window.',
      'On this pool, in this hour, the price was outside every width at some point. That is worth knowing before placing anything, and it is why the crossing count is a column rather than a footnote.');
  }
  if(best&&held&&best!==held){
    const b=rows.find(r=>('±'+r.width_pct+'%')===best);
    line('mid',best+' collected the most — and the price crossed its edge '+
      (b?b.times_it_crossed_the_edge:'')+(b&&b.times_it_crossed_the_edge===1?' time':' times')+'.',
      'A position there earns nothing while it is outside, and putting it back costs about $'+
      (d.rebalance_cost_usd_assumed||0).toFixed(2)+' in gas — '+
      costInWindows(d.rebalance_cost_usd_assumed,b&&b.fees_usd_in_window)+
      '. After paying for that, '+(d.best_range_after_paying_to_put_it_back||'nothing here')+' came out ahead.');
  }
  // The sentence that stops a narrow range looking free even when it held: the
  // cost of nursing it is a real number and it belongs beside the reward.
  else if(held){
    const hr=rows.find(r=>('±'+r.width_pct+'%')===held);
    if(hr&&hr.fees_usd_in_window>0&&d.rebalance_cost_usd_assumed>0){
      line('mid','One crossing costs '+costInWindows(d.rebalance_cost_usd_assumed,hr.fees_usd_in_window)+'.',
        'Putting a position back is roughly $'+d.rebalance_cost_usd_assumed.toFixed(2)+
        ' of gas — 700,000 units priced well above the current floor. It did not happen in this window. It is the thing to watch if it does.');
    }
  }
  out.appendChild(ans);

  const t=el('div','tier-t');
  const head=el('div','tier-r tier-hr');
  head.append(el('span','tier-n','range'),el('span','tier-c','between'),
    el('span','tier-w','in range'),el('span','tier-v','edge crossed'),
    el('span','tier-f','collected on $'+nf(d.capital_considered_usd)));
  t.appendChild(head);
  const cell=(cls,label,text,extra)=>{
    const s=el('span',cls+(extra||''));
    s.appendChild(el('i','tl',label));
    s.appendChild(document.createTextNode(text));
    return s;
  };
  rows.forEach(r=>{
    const isHeld=held&&('±'+r.width_pct+'%')===held;
    const row=el('div','tier-r'+(isHeld?' tier-best':''));
    const n=el('span','tier-n',r.full_range?'full range':'±'+r.width_pct+'%');
    if(isHeld)n.appendChild(el('em','tier-tag','narrowest that held'));
    row.appendChild(n);
    row.appendChild(cell('tier-c','between',
      r.price_range?(r.price_range.low+' – '+r.price_range.high+(r.price_range.unit?' '+r.price_range.unit:'')):'every price'));
    row.appendChild(cell('tier-w','in range',
      r.share_of_window_in_range_pct==null?'—':r.share_of_window_in_range_pct+'%'));
    row.appendChild(cell('tier-v','edge crossed',
      r.times_it_crossed_the_edge===0?'never':r.times_it_crossed_the_edge+'×'));
    row.appendChild(cell('tier-f','collected','$'+r.fees_usd_in_window.toFixed(6),
      isHeld?' good':(r.fees_usd_in_window===0?' dim':'')));
    t.appendChild(row);
  });
  out.appendChild(t);

  out.appendChild(el('p','cd-foot','Measured over '+(w.minutes??'~59')+
    ' minutes of chain — a sample, not a rate, and not annualised. Replayed against the '+w.swaps+
    ' swaps that actually happened in it, using the liquidity the pool itself reported as active at each one — not a simulation of a market, arithmetic over trades that occurred. The pool paid $'+
    (w.fees_the_pool_paid_usd||0).toFixed(2)+' in fees across all of them'+
    (typeof w.paid_to_liquidity_pct==='number'&&w.paid_to_liquidity_pct<100?', of which the liquidity is credited '+w.paid_to_liquidity_pct.toFixed(0)+'% — the pool keeps the rest for the protocol, and every figure above is the part credited to the liquidity':'')+
    '. Not annualised: what a range did in one hour is not what it does over a year. '+
    (d.pair&&d.pair.token&&d.pair.quote?'This is the '+(d.pair.token.symbol||'token')+' / '+(d.pair.quote.symbol||'quote')+' pool'+(d.fee_pct!=null?' at '+d.fee_pct+'%':'')+' — a V3 pool, so it can be another pair than the tier card above measured when the token is deepest in V2 against a different quote. ':'')+
    (d.tier_chosen_because?'Pool picked for you: the '+d.tier_chosen_because+' — which tier PAYS best is the card above. ':'')+
    ((d.widths_this_tier_cannot_hold_pct||[]).length?'Not shown: ±'+d.widths_this_tier_cannot_hold_pct.join('%, ±')+'% — this tier’s tick spacing ('+d.tick_spacing+') cannot hold a range that narrow; the ranges shown sit on that grid. ':'')+
    'Impermanent loss is not in any of this, and it is worst exactly where the fees are best.'));
}

function card(title,sub){
  const c=el('section','cd');
  const h=el('div','cd-h');
  h.appendChild(el('h3',null,title));
  if(sub)h.appendChild(el('p',null,sub));
  c.appendChild(h);
  return c;
}

// ---- the answer, before the evidence ---------------------------------------
//
// Everything below this is a measurement and every one of them is worth having.
// None of them is the sentence somebody came here for. The result used to open
// with "Hard USDT backing" and "Liquidity / Mcap" — correct, and neither is a
// phrase a person uses about their own money. So the first thing on the page is
// now three plain answers: what a normal-sized trade costs you, whether the
// token takes a cut of every trade, and whether anybody can walk off with the
// liquidity. The numbers are the same ones the cards below carry; nothing new
// is computed and nothing is rounded into a claim.
//
// A line that cannot be answered says so. "Could not be measured" is an honest
// line; a green tick that means "we did not look" is not.
function verdictCard(d,pool,gp,gpOk,tax){
  const c=el('section','cd vd-card');
  const h=el('div','cd-h');
  h.appendChild(el('h3',null,'The short answer'));
  h.appendChild(el('p',null,'What is worth knowing before you trade this, in plain words. Every one of them is measured below.'));
  c.appendChild(h);
  const list=el('div','vd');

  const line=(tone,head,body)=>{
    const r=el('div','vd-r vd-'+tone);
    r.appendChild(el('b',null,head));
    r.appendChild(el('span',null,body));
    list.appendChild(r);
  };

  // 0. Can you get out at all (2026-10-09 review): the sell test stood only in the last card, while this card could
  //    quote a sell cost and a burned LP in green for a token whose sell the router refuses. It leads when it failed.
  const sim=d.sim;
  if(sim&&sim.ok&&!sim.sellable)line('bad','The sell did not go through.','A sell simulated on the chain just now, from a fresh address, was refused'+(sim.sell_error?' ('+sim.sell_error+')':'')+'. Whatever the costs below say, you may not be able to sell this token.');
  else if(sim&&sim.ok&&sim.sellable&&sim.through_scanned_pool!==false)line('good','A sell goes through right now.','Simulated on the chain just now, from a fresh address, through the pool measured here.');

  // 1. What a normal trade costs. The reference size is the row closest to $500
  //    rather than the smallest or the largest: the smallest flatters the pool
  //    and the largest scares people away from one that would have been fine.
  const rows=(d.rows||[]).slice().sort((a,b)=>Math.abs(a.usd-500)-Math.abs(b.usd-500));
  // ...among the sizes the pool can fill: a rung that runs the pool dry has
  // no cost, and the short answer must not quote a size that never fills.
  const ref=rows.find(r=>r.buyCost!=null&&r.sellCost!=null)||rows[0];
  const floors={buy:(1-(1-d.taxB)*(1-pool.fee))*100, sell:(1-(1-d.taxS)*(1-pool.fee))*100};
  if(ref&&ref.buyCost!=null&&ref.sellCost!=null){
    const worst=Math.max(ref.buyCost,ref.sellCost);
    const toll=Math.max(floors.buy,floors.sell);
    // Measured against the unavoidable toll for THIS pool, not against a fixed
    // percentage: 3% is cheap in a 1% fee tier with a 2% tax and dreadful in a
    // 0.05% pool with none.
    const tone=toll>0?(worst<=toll*1.5?'good':worst<=toll*3?'mid':'bad'):'mid';
    line(tone,'A $'+nf(ref.usd)+' trade costs you '+pc(ref.buyCost)+' to buy and '+pc(ref.sellCost)+' to sell.',
      'That is the whole cost: the pool fee, any transfer tax, and how far your own trade moves the price. '
      +(toll>0?'About '+toll.toFixed(toll<1?2:1)+'% of it is unavoidable at any size in this pool; the rest is depth.'
             :'Round trip, that is about '+pc(ref.buyCost+ref.sellCost)+' before the price moves at all.')
      // the round trip in one figure (2026-10-09 review): what is left of the money if you sold straight back
      +' Buy and sell straight back, and you keep about '+pc((1-ref.buyCost/100)*(1-ref.sellCost/100)*100)+' of your $'+nf(ref.usd)+'.');
  }else{
    line('unknown','A trade of this size could not be priced.',
      'The quoter did not return a price for every size, so no cost figure is shown at all rather than a partial one.');
  }

  // 2. The tax. The figure most likely to be wrong elsewhere, which is why this
  //    page measures it from executed trades instead of reading the label.
  const measured=tax&&tax.ok&&(tax.buy!=null||tax.sell!=null);
  if(d.taxB||d.taxS){
    const both=Math.round(d.taxB*1000)===Math.round(d.taxS*1000);
    line(d.taxB>=0.10||d.taxS>=0.10?'bad':'mid',
      both?'This token takes '+pc(d.taxB*100)+' out of every trade.'
          :'This token takes '+pc(d.taxB*100)+' when you buy and '+pc(d.taxS*100)+' when you sell.',
      (measured?'Measured from trades that actually executed, not read off the contract label.'
        :(d.simB||d.simS)?'Simulated on the chain at this block from a fresh address — the same trade run and its gap read, not a label. No executed trade was available to measure it from.'
              :'Reported by GoPlus and not verified here — no executed trade was available to measure it from.')
      +' It is already included in the cost above.');
  }else if(measured){
    line('good','No transfer tax. You keep what you trade, minus the pool fee.',
      'Measured from trades that actually executed. A token can still add one later if its contract allows it.');
  }else if(d.simB||d.simS){
    // SIMULATED 0% IS AN ANSWER (2026-11-15): with no executed trade to read, a buy and a sell simulated at this block
    // that both came to 0% said "could not be established" here, while the tax section and the cost note below said 0%
    line('good','No transfer tax in a buy and sell simulated at this block.',
      'Run on the chain from a fresh address and its gap read, not a label. No executed trade was available to measure it from; real wallets can be treated differently, and a token can add a tax later if its contract allows it.');
  }else{
    line('unknown','Whether it takes a transfer tax could not be established.',
      'No executed trade was available to measure it from, and no label is trusted in its place. Treat the cost above as a floor.');
  }

  // 3. Who can remove the liquidity. On a concentrated-liquidity pool there are
  //    no LP tokens to burn, so the honest line is that this question does not
  //    apply rather than a reassuring one that does not mean anything.
  // The LP ledger, when it was read (lpCustody, 2026-09-27), answers this by name — before GoPlus's list.
  const cu=d.custody,cuRead=cu&&(cu.read==='complete'||(cu.unreadPct??100)<50);
  const gone=cu&&(cu.withdrawnSinceCreation||[])[0];
  const lw=cu&&cu.largestWallet;
  if(pool.kind==='v2'&&cuRead&&gone&&gone.pctOfLpEverMinted>=50){
    line('bad','Most of the liquidity has already been pulled.',
      pc(gone.pctOfLpEverMinted)+' of all the LP ever minted for this pool was withdrawn by '+short(gone.address)+
      (gone.tokenCreator?', the token’s creator':gone.addedFirstLiquidity?', the wallet that added it':'')+'. What this page measures is what was left behind.');
  }else if(pool.kind==='v2'&&cuRead&&lw&&lw.pct>=10){
    line('bad',(lw.tokenCreator?'The token’s creator':lw.addedFirstLiquidity?'The wallet that added the liquidity':'One wallet')+' can withdraw '+(lw.pct>=99.99?'all of':pc(lw.pct)+' of')+' this liquidity.',
      short(lw.address)+' holds '+pc(lw.pct)+' of the LP tokens as a plain wallet — no lock, no burn — and can take that share of the pool out in one transaction, at any moment. '+
      (cu.read==='complete'?'Every LP transfer since the pool was created was read.':pc(cu.unreadPct)+' of the LP could not be attributed.'));
  }else if(pool.kind==='v2'&&cuRead&&(d.lpTot>0?(d.lpDead+d.lpNull)/d.lpTot*100:0)<99){
    line(cu.walletPct<10&&cu.unreadPct<10?'good':'mid','No single wallet can pull much of this liquidity.',
      'Of the LP: '+[['burned',cu.burnedPct],['locked',cu.lockedPct],['in farms',cu.farmPct],['at the exchange',cu.exchangeFeePct],['in wallets',cu.walletPct],['in other contracts',cu.contractPct],['not attributed',cu.unreadPct]]
        .filter(([,v])=>v>=0.01).map(([k,v])=>pc(v)+' '+k).join(', ')+'. The largest wallet holds '+(lw?pc(lw.pct):'none of it')+'.');
  }else if(pool.kind==='v2'){
    const burnedPct=d.lpTot>0?(d.lpDead+d.lpNull)/d.lpTot*100:0;
    const feePct=d.lpTot>0&&d.lpFee>0?d.lpFee/d.lpTot*100:0;
    const free=Math.max(0,100-burnedPct-feePct);
    if(burnedPct>=99){
      line('good','Nobody can pull the liquidity out. It is burned.',
        pc(burnedPct)+' of the LP tokens sit at a dead address. Burned liquidity can never be withdrawn by anyone, including the people who put it there.');
    }else if(free>=50){
      // "Somebody can pull this" is the right warning for one wallet holding
      // the lot and the wrong one for a blue chip whose LP sits across
      // thousands of addresses. Both are "not burned"; only one is a person who
      // could empty the pool tonight, and the largest single holder is what
      // separates them.
      const others=(gp.lp_holders||[]).filter(x=>{const a=(x.address||'').toLowerCase();
        return a!==DEAD&&a!==NULLA&&a!==(d.feeTo||'')&&x.is_locked!==1});
      const top=others.sort((a,b)=>(parseFloat(b.percent)||0)-(parseFloat(a.percent)||0))[0];
      const topPct=top?(parseFloat(top.percent)||0)*100:null;
      if(gpOk&&topPct!=null&&topPct<10){
        line('mid','The liquidity is not burned, but no single wallet holds much of it.',
          pc(free)+' of the LP can be withdrawn in principle, spread across many holders — the largest one has '+pc(topPct)+
          '. Nobody here can empty the pool on their own; a lot of them leaving at once is a different question, and not one this page can answer.');
      }else if(gpOk&&topPct!=null){
        line('bad','One wallet can withdraw most of this liquidity.',
          pc(free)+' of the LP is neither burned nor at the exchange, and a single wallet holds '+pc(topPct)+
          ' of it. That is not proof of anything — plenty of honest pools look like this — but it is the risk that empties a pool overnight.');
      }else{
        // Not burned is measured on-chain and certain. WHO holds it is not:
        // without the holder list this page cannot tell one wallet from ten
        // thousand, and those are very different risks. Saying "somebody can
        // pull this" here would be a claim built on the half we could not read.
        line('unknown','The liquidity is not burned, and we could not see who holds it.',
          pc(free)+' of the LP is withdrawable in principle — that part is read from the chain. The holder list comes from GoPlus, which '+(gpOk?'lists no holders for this pool':'did not answer')+', so whether that is one wallet or thousands is unknown rather than fine.');
      }
    }else{
      line('mid','Part of the liquidity can still be withdrawn.',
        pc(burnedPct)+' is burned for good; about '+pc(free)+' is not. The breakdown, including who holds the largest unburned share, is further down.');
    }
  }else{
    line('unknown','“Is the liquidity burned?” does not apply to this pool.',
      'It is a concentrated-liquidity pool: liquidity is held as individual positions rather than as LP tokens, so there is nothing to burn. Any position here can be closed by whoever opened it, at any time.');
  }

  c.appendChild(list);
  c.appendChild(el('p','cd-legend',
    'None of this says whether the token is a good idea. It says what trading it would cost you today and who could change that.'));
  return c;
}

function renderLadder(rows,taxNote,floors,venue){
  venue=venue||'pool';
  const wrap=el('div','lad');
  [['buy','Buying','up'],['sell','Selling','down']].forEach(([side,label,dir])=>{
    const floor=side==='buy'?floors.buy:floors.sell;
    const col=el('div','lad-c');
    const hd=el('div','lad-h lad-'+side);
    hd.appendChild(el('span','lad-t',label));
    hd.appendChild(el('span','lad-d','price '+dir));
    col.appendChild(hd);
    const head=el('div','lad-r lad-hr');
    head.append(el('span','lad-s','size'),el('span','lad-b',''),
      el('span','lad-p','impact'),el('span','lad-x','you pay'));
    col.appendChild(head);
    const vals=rows.map(r=>side==='buy'?r.buyMove:r.sellMove).filter(v=>v!=null).map(Math.abs);
    const max=Math.max(...vals,0.0001);
    rows.forEach(r=>{
      const mv=side==='buy'?r.buyMove:r.sellMove,cs=side==='buy'?r.buyCost:r.sellCost;
      const row=el('div','lad-r');
      row.appendChild(el('span','lad-s','$'+nf(r.usd)));
      const note=side==='buy'?r.buyNote:r.sellNote;
      // A size the pool cannot fill has no impact figure — it is beyond the
      // scale, not below it. The bar is drawn full and muted; an empty bar on
      // the largest size read as 'no impact' (found by the audit, 2026-09-09).
      const t=el('span','lad-b'),bar=el('i',[side==='sell'?'sell':'',note?'dry':''].filter(Boolean).join(' ')||null);
      bar.style.transform='scaleX('+(note?1:mv==null?0:Math.min(1,Math.abs(mv)/max)).toFixed(4)+')';
      t.appendChild(bar);row.appendChild(t);
      row.appendChild(el('span','lad-p'+(note?' lad-dry':impactBand(mv)),note?'runs out':signed(mv)));
      row.appendChild(el('span','lad-x'+(note?'':costBand(cs,floor)),cs==null?'—':cs.toFixed(2)+'%'));
      col.appendChild(row);
    });
    wrap.appendChild(col);
  });
  const box=el('div');box.appendChild(wrap);
  if(taxNote)box.appendChild(el('p','cd-foot',taxNote));
  const dryRows=rows.filter(r=>r.buyNote||r.sellNote);
  if(venue==='pool'&&dryRows.length)box.appendChild(el('p','cd-foot',
    '“Runs out” means the pool holds less in range than that size would take: the trade would not fill, so there is no price to quote.'));
  box.appendChild(el('p','cd-legend',
    'Colour is about cost, not quality. Green means you pay close to the unavoidable toll for this '+venue+' ('+
    (floors.buy>0?floors.buy.toFixed(2)+'% on a buy, '+floors.sell.toFixed(2)+'% on a sell':'fee plus tax')+
    ', payable at any size); amber is noticeably above it; red means the pool is moving under you. '+
    'It says nothing about whether the token is any good — a deep pool can still go to zero.'));
  return box;
}

// ---- tax card --------------------------------------------------------------
// The centrepiece, because it is the figure most likely to be wrong elsewhere.
// Measured values win; a label is shown as a label, with its disagreement
// spelled out rather than quietly averaged away.
function taxCard(tax,gp,gpOk,sim){
  const c=card('The transfer tax, measured',
    'Not taken from a label — read off trades that actually executed. The pool reports how many tokens it moved, the token’s own transfer events report how many arrived, and the gap is what the wallet was charged. Where the window holds no trade in a direction, the same trade is simulated on the chain at this block and its gap read the same way.');
  // A blank label is no label (GoPlus sends "" for unknown; Number("") is 0).
  const lab=v=>v!=null&&String(v).trim()!==''&&isFinite(Number(v));
  const gB=lab(gp.buy_tax)?Number(gp.buy_tax)*100:null,
        gS=lab(gp.sell_tax)?Number(gp.sell_tax)*100:null;
  // The simulated pair, when the probe could read what arrived. Second to a
  // real executed trade, ahead of a label: it happened on the chain, at this
  // block, just not with anyone's money.
  // Only a simulated trade through the pool that was read speaks for its tax
  // (simulateRoundTrip names the pair it traded).
  const simHere=sim&&sim.through_scanned_pool!==false;
  const sB=simHere&&sim.tax&&sim.tax.buy_pct!=null?sim.tax.buy_pct:null,
        sS=simHere&&sim.tax&&sim.tax.sell_pct!=null?sim.tax.sell_pct:null;
  if(tax.ok){
    const mB=tax.buy!=null?tax.buy*100:null,mS=tax.sell!=null?tax.sell*100:null;
    c.appendChild(statRow([
      {v:mB!=null?pc(mB):(sB!=null?pc(sB):(gB!=null?pc(gB):'—')),l:'Buy tax',dim:mB==null&&sB==null,
        tone:mB!=null?band(mB,0.01,5):(sB!=null?band(sB,0.01,5):''),
        s:tax.nBuy?'median of '+tax.nBuy+' executed buy'+(tax.nBuy===1?'':'s')
          :(sB!=null?'no buy in the window — simulated buy at this block':(gB!=null?'no buy in the window — GoPlus’s figure, unverified':'no buy in the window'))},
      {v:mS!=null?pc(mS):(sS!=null?pc(sS):(gS!=null?pc(gS):'—')),l:'Sell tax',dim:mS==null&&sS==null,
        tone:mS!=null?band(mS,0.01,5):(sS!=null?band(sS,0.01,5):''),
        s:tax.nSell?'median of '+tax.nSell+' executed sell'+(tax.nSell===1?'':'s')
          :(sS!=null?'no sell in the window — simulated sell at this block':(gS!=null?'no sell in the window — GoPlus’s figure, unverified':'no sell in the window'))},
    ]));
    // Two readings of the same tax, when both exist: the executed trades and
    // the simulation. They should agree; when they do not, both are shown.
    const both=[];
    if(mB!=null&&sB!=null&&Math.abs(mB-sB)>0.15)both.push('buy '+pc(mB)+' from executed trades vs '+pc(sB)+' simulated');
    if(mS!=null&&sS!=null&&Math.abs(mS-sS)>0.15)both.push('sell '+pc(mS)+' from executed trades vs '+pc(sS)+' simulated');
    if(both.length)c.appendChild(el('p','cd-foot','The simulation read a different gap than the executed trades: '+both.join('; ')+'. A tax that changes with the wallet, the size or the block does that; the executed trades are what real wallets paid.'));
    const parts=[];
    if(tax.spread.buy.length>1)parts.push('buys charged '+tax.spread.buy.map(x=>x+'%').join(', '));
    if(tax.spread.sell.length>1)parts.push('sells charged '+tax.spread.sell.map(x=>x+'%').join(', '));
    if(parts.length)c.appendChild(el('p','cd-foot','Every trade read: '+parts.join('; ')+
      '. A 0% entry is normal — deployers, tax sinks and allow-listed routers are usually exempt, which is why the median is used and not the average.'));
    const dis=[];
    if(gB!=null&&mB!=null&&Math.abs(gB-mB)>0.15)dis.push('buy '+pc(gB)+' vs '+pc(mB)+' measured');
    if(gS!=null&&mS!=null&&Math.abs(gS-mS)>0.15)dis.push('sell '+pc(gS)+' vs '+pc(mS)+' measured');
    if(dis.length){
      const w=el('div','warn warn-soft');
      w.appendChild(el('b',null,'GoPlus reports a different tax than the chain charged.'));
      w.appendChild(el('span',null,dis.join(' · ')+'. The figures on this page use the measured value. A label can be stale, can come from a partial simulation, or can include slippage from whatever size was simulated.'));
      c.appendChild(w);
    }
  }else if(sB!=null||sS!=null){
    c.appendChild(statRow([
      {v:sB!=null?pc(sB):(gB!=null?pc(gB):'—'),l:'Buy tax',dim:sB==null,tone:sB!=null?band(sB,0.01,5):'',s:sB!=null?'simulated buy at this block':(gB!=null?'GoPlus label, unverified':'—')},
      {v:sS!=null?pc(sS):(gS!=null?pc(gS):'—'),l:'Sell tax',dim:sS==null,tone:sS!=null?band(sS,0.01,5):'',s:sS!=null?'simulated sell at this block':(gS!=null?'GoPlus label, unverified':'—')},
    ]));
    c.appendChild(el('p','cd-foot','No executed trade to read ('+tax.reason+'), so the tax comes from a buy and a sell simulated on the chain at this block, from a fresh address: what the pair paid for the whole amount against what arrived. Real wallets may be treated differently — an exempt list, a size rule — which is why an executed trade outranks this when there is one.'));
    const dis=[];
    if(gB!=null&&sB!=null&&Math.abs(gB-sB)>0.15)dis.push('buy '+pc(gB)+' vs '+pc(sB)+' simulated');
    if(gS!=null&&sS!=null&&Math.abs(gS-sS)>0.15)dis.push('sell '+pc(gS)+' vs '+pc(sS)+' simulated');
    if(dis.length){
      const w=el('div','warn warn-soft');
      w.appendChild(el('b',null,'GoPlus reports a different tax than the simulation charged.'));
      w.appendChild(el('span',null,dis.join(' · ')+'. The figures on this page use the simulated value.'));
      c.appendChild(w);
    }
  }else{
    c.appendChild(statRow([
      {v:gB!=null?pc(gB):'—',l:'Buy tax (reported)',dim:true,s:'GoPlus label, unverified'},
      {v:gS!=null?pc(gS):'—',l:'Sell tax (reported)',dim:true,s:'GoPlus label, unverified'},
    ]));
    const w=el('div','warn warn-soft');
    w.appendChild(el('b',null,'Could not be measured: '+tax.reason+'.'));
    w.appendChild(el('span',null,(gB!=null||gS!=null)
      ? 'The numbers above come from GoPlus and are used in the “you pay” column, but nothing on the chain has confirmed them. Treat that column as indicative until this token trades again.'
      : 'No tax figure is available at all, so the “you pay” column below counts the pool fee only and is a floor, not the real cost.'));
    c.appendChild(w);
  }
  return c;
}

// ---- flags -----------------------------------------------------------------
function flagsCard(gp,gpOk,sim){
  // Three openings, because the card is reached three ways: a pool with the
  // simulation and GoPlus, a pool without GoPlus, and a token still on its
  // launch curve — where there is no router to sell into and the intro used
  // to promise a simulation the next line then called "not run".
  const c=card('Can you sell it, and what the contract can do',
    sim&&sim.curve
      ?(gpOk?'On the launch curve there is no pool and no router to sell into, so no sell is simulated here: whether a sell pays out is four.meme’s own answer above. The properties below are read from the verified source by GoPlus. Properties, not a rating — a token can carry several of them and be perfectly ordinary, or carry none and still go to zero.'
             :'On the launch curve there is no pool and no router to sell into, so no sell is simulated here: whether a sell pays out is four.meme’s own answer above. GoPlus did not answer for this token, so the contract properties could not be checked.')
    :gpOk?'The sell test is ours: a sell is simulated on the chain at this block, from a fresh address with no history. The properties below are read from the verified source by GoPlus. Properties, not a rating — a token can carry several of them and be perfectly ordinary, or carry none and still go to zero.'
        :'GoPlus did not answer for this token, so the contract properties could not be checked. The sell test below is ours and does not depend on it; every figure above comes off the chain directly.');
  const g=el('div','fg');
  const chip=(state,label,note)=>{const x=el('div','f f-'+state);
    x.appendChild(el('b',null,label));x.appendChild(el('span',null,note));return x};
  // THE SELL TEST FIRST. It is the one line a buyer will act on. A simulation
  // that could not run says so and is never drawn as a pass.
  if(sim&&sim.ok&&sim.through_scanned_pool===false)g.appendChild(chip('unk','Sell test: ran on another pair','The router could not trade through the pool measured above, so the test went through this token’s PancakeSwap V2 pair against BNB ('+String(sim.pair).slice(0,10)+'…) and '+(sim.sellable?'went through there':'was refused there'+(sim.sell_error?': '+sim.sell_error:''))+'. A tax or a sell block tied to the main pool does not show on a side pair: for the pool above this is “not checked”.'));
  else if(sim&&sim.ok&&sim.sellable)g.appendChild(chip('ok','Sell test: goes through','A sell of '+'one part in a thousand of the pool'+' went through on the chain just now, from an address with no history. It says nothing about tomorrow: an owner with a switch can still flip it.'));
  else if(sim&&sim.ok&&!sim.sellable)g.appendChild(chip('bad','Sell test: REVERTED','The router refused the sell'+(sim.sell_error?': '+sim.sell_error:'')+'. That is what a honeypot looks like from outside — and also what a trading pause or a max-wallet rule looks like. Do not buy what you cannot sell.'));
  else g.appendChild(chip('unk','Sell test: not run',(sim&&sim.reason)||'The simulation could not run for this token.'));
  if(!gpOk){c.appendChild(g);return c;}
  const owner=(gp.owner_address||'').toLowerCase();
  if(gp.owner_address==null)g.appendChild(chip('unk','Ownership not checked','GoPlus returned no owner field for this contract.'));
  else if(owner===NULLA||owner==='')g.appendChild(chip('ok','Ownership renounced','No owner address left on the contract.'));
  else if(owner===FOURMEME_MANAGER)g.appendChild(chip('on','Owned by four.meme','The owner is four.meme’s token manager ('+short(owner)+'), the contract that runs the launch curve — not a person’s wallet.'));
  else{const kn=knownHolder(owner);g.appendChild(chip('on','Owner active','Owner is '+short(owner)+(kn?', '+kn.name:'')+'.'));}
  if(gp.is_open_source==null)g.appendChild(chip('unk','Verification not checked','GoPlus did not report whether the source is verified.'));
  else if(gp.is_open_source==='1')g.appendChild(chip('ok','Source verified','The published code matches the deployed bytecode.'));
  else g.appendChild(chip('on','Source not verified','Nothing here can be checked against source code — including every other line in this list.'));
  // GoPlus's own verdict stays beside ours: two independent sell tests that
  // disagree are worth more than one that says nothing.
  if(gp.is_honeypot==='1')g.appendChild(chip('bad','Honeypot','GoPlus could not sell this token in a simulation.'));
  else if(gp.is_honeypot==null)g.appendChild(chip('unk','Sellability not checked by GoPlus','GoPlus ran no sell simulation for this token'+(sim?'; the sell test above is ours.':', and none was run here either.')));
  // The missing ones are listed by name. Silence about a property is not the
  // same as the property being absent, and only one of those two is safe to
  // let a reader assume.
  const unchecked=[];
  FLAGS.forEach(([k,label,note])=>{
    if(gp[k]==='1')g.appendChild(chip('on',label,note));
    else if(gp[k]==null)unchecked.push(label.toLowerCase());
  });
  c.appendChild(g);
  if(unchecked.length)c.appendChild(el('p','cd-foot',
    'Not checked for this token ('+unchecked.length+'): '+unchecked.join(', ')+
    '. GoPlus returned no value for these — that is not the same as “no”, and this page will not pretend it is. Proxy contracts in particular often come back only partly analysed.'));
  return c;
}

// ---- share this check (operator, 2026-10-12: "check before you ape", to pass on) ---------------------------------
// One link that opens straight on this token's scan (?token= skips nothing and asks the chain again when opened), with
// a copy button at the top of the result
function shareBar(token,symb){
  const o=$('sc-out');if(!o||o.querySelector('.sc-share'))return;
  const url='https://brainonbnb.com/scanner?token='+token;
  const d=document.createElement('div');d.className='sc-share';
  const t=document.createElement('span');t.innerHTML='<b>Share this check</b> ';
  const c=document.createElement('code');c.textContent=url.replace('https://','');t.appendChild(c);
  const b=document.createElement('button');b.type='button';b.textContent='Copy link';
  b.addEventListener('click',()=>{const done=()=>{b.textContent='Copied ✓';b.classList.add('ok');setTimeout(()=>{b.textContent='Copy link';b.classList.remove('ok')},1600)};
    (navigator.clipboard?navigator.clipboard.writeText(url):Promise.reject()).then(done,()=>{const x=document.createElement('textarea');x.value=url;document.body.appendChild(x);x.select();try{document.execCommand('copy');done()}catch(e){}x.remove()})});
  // POST IT (2026-10-13): the link now carries its own card (this token's check as the picture, /og/scan/<token>.png),
  // so X and Telegram get one click each. Neutral words, as on the card: what a trade costs, never a view on the token.
  const say=(symb?symb+': ':'')+'what would buying it really cost? Measured on BNB Chain';
  const share=(label,href)=>{const a=document.createElement('a');a.className='sc-sh';a.textContent=label;a.href=href;a.target='_blank';a.rel='noopener';return a};
  const acts=document.createElement('span');acts.className='sc-acts';
  acts.append(b,share('Post on X','https://x.com/intent/post?text='+encodeURIComponent(say)+'&url='+encodeURIComponent(url)),share('Telegram','https://t.me/share/url?url='+encodeURIComponent(url)+'&text='+encodeURIComponent(say)));
  d.append(t,acts);o.prepend(d);
  if(symb)d.title='Anyone who opens it sees '+symb+' scanned again, live';
}

// ---- main render -----------------------------------------------------------
function render(d){
  const o=$('sc-out');o.hidden=false;$('sc-err').hidden=true;o.textContent='';
  const teaser=$('sc-what');if(teaser)teaser.hidden=true;
  const {gp,gpOk,addr,pool,name,symb,px,quoteUsd,quoteSym,tax,supply,burned,hop,deeper,partial}=d;
  // Both sides valued for real. On a V2 pair this is exactly twice the quote
  // side by construction; on a V3 pool the two halves are not equal and
  // doubling would invent liquidity that is not there.
  const hard=d.q*quoteUsd,tvl=hard+d.tok*px;
  const circ=supply!=null?supply-burned:null,mcap=circ!=null&&px?circ*px:null;

  // header
  const head=el('header','hd');
  const ttl=el('div','hd-t');
  ttl.appendChild(el('h2',null,symb));
  ttl.appendChild(el('span','hd-n',name));
  head.appendChild(ttl);
  const meta=el('div','hd-m');
  meta.appendChild(el('span','badge',pool.kind==='v3'
    ? 'PancakeSwap V3 · '+(pool.fee*100).toFixed(2).replace(/0+$/,'').replace(/\.$/,'')+'% tier'
    : pool.kind==='inf'?'PancakeSwap Infinity CL · '+(+(pool.fee*100).toFixed(4))+'% fee'+(pool.hooks?' · hook':'')
    : (pool.venue||'PancakeSwap V2')+' · '+(pool.fee*100).toFixed(2)+'% fee'));
  meta.appendChild(el('span','badge badge-q',symb+' / '+quoteSym));
  if(gp.launchpad_token&&gp.launchpad_token.launchpad_name)
    meta.appendChild(el('span','badge badge-d','via '+gp.launchpad_token.launchpad_name));
  head.appendChild(meta);
  const lnk=el('div','hd-l');
  lnk.append(link(short(addr),'https://bscscan.com/token/'+addr),
    // an Infinity pool is an id inside the pool manager, not an address BscScan can open: its hook can be
    pool.kind==='inf'
      ? link('Pool id '+short(pool.pair),pool.hooks?'https://bscscan.com/address/'+pool.hooks:'https://bscscan.com/address/'+pool.key.pm)
      : link('Pool '+short(pool.pair),'https://bscscan.com/address/'+pool.pair),
    link('DexScreener','https://dexscreener.com/bsc/'+pool.pair),
    // The same reading as an agent gets it: the page proves the API works,
    // so the page names the API (2026-09-12).
    link('Same reading as JSON','/api/pool-scan?address='+addr));
  head.appendChild(lnk);
  o.appendChild(head);

  // The answer first. Everything after it is why.
  o.appendChild(verdictCard(d,pool,gp,gpOk,tax));
  // THE CHEAPER WAY IN, IN THE ANSWER (2026-10-14): the cost line is the deepest pool's, and CAKE's read 99.49% kept on a
  // $500 round trip while PancakeSwap's own quoter returned 99.88% through the V3 0.05% pool — a trader saw that only
  // after pressing "Quote the routes" at the bottom. Now, when another pool keeps at least a tenth of a percent more at
  // the same size, the answer says so under the cost line.
  { const vc=o.lastChild, list=vc&&vc.querySelector('.vd'), rs=(d.rows||[]).slice().sort((a,b)=>Math.abs(a.usd-500)-Math.abs(b.usd-500)), ref=rs.find(r=>r.buyCost!=null&&r.sellCost!=null);
    if(list&&ref){
      const here=(1-ref.buyCost/100)*(1-ref.sellCost/100)*100;
      fetch('/api/best-route?address='+encodeURIComponent(addr)+'&usd='+encodeURIComponent(ref.usd)).then(r=>r.json()).then(b=>{
        const rt=b&&b.round_trip;
        if(!rt||rt.you_keep_pct==null||!b.best_route_pool||b.best_route_pool.toLowerCase()===String(pool.pair).toLowerCase()||rt.you_keep_pct-here<0.1||(b.refuse_to_trade||[]).length)return;
        const r=el('div','vd-r vd-good'), s=el('span',null,'The cost above is for the deepest pool. At $'+nf(ref.usd)+', buying and selling straight back through '+(b.best_route||'another pool')+' keeps '+pc(rt.you_keep_pct)+' instead of '+pc(here)+' — quoted by PancakeSwap’s own quoter at block '+b.block+'. The swap page’s router usually finds it by itself; check that it did. Pool ');
        r.appendChild(el('b',null,'A cheaper way in: PancakeSwap '+(b.best_route||'')+'.'));
        s.appendChild(link(short(b.best_route_pool),'https://bscscan.com/address/'+b.best_route_pool)); r.appendChild(s);
        const cost=[...list.children].find(x=>/^A \$/.test(x.firstChild&&x.firstChild.textContent||''));
        list.insertBefore(r,cost?cost.nextSibling:list.firstChild);
      }).catch(()=>{});
    }
  }

  // headline stats
  o.appendChild(statRow([
    {v:usd(px),l:'Price'},
    {v:mcap!=null?usd(mcap):'—',l:'Market Cap',s:circ!=null?nf(circ)+' circulating':'supply unreadable'},
    // the half that holds leads (2026-10-09 review): the "Liquidity" headline counted the token's own side, which the
    // next card warns about in its first sentence; the pool's whole value stays as the subtitle
    {v:usd(hard),l:'Hard '+quoteSym+' backing',s:'pool value '+usd(tvl)+', counting both sides'},
  ]));

  // depth
  // The "half of it is the token itself" framing is a CONSTANT-PRODUCT fact: a
  // V2 pair is 50/50 by construction, so the quote side really is a floor. A
  // concentrated-liquidity pool is neither balanced nor a floor — $mubarak's V3
  // pool holds 36% quote, and as the price falls its positions convert toward
  // the token side, buying the quote out. Printing the V2 sentence over a V3
  // pool is right about the number and wrong about what it means.
  const v3=pool.kind==='v3'||pool.kind==='inf';
  // PANCAKESWAP INFINITY (2026-10-19): what is read differently, said before any figure — the same words as the API
  if(pool.kind==='inf'){
    const w=el('div','warn warn-soft');
    w.appendChild(el('b',null,'A PancakeSwap Infinity pool.'));
    w.appendChild(el('span',null,'Infinity keeps every pool’s tokens in one shared Vault, so this pool’s own reserves cannot be read on chain: its '+quoteSym+' backing below is '
      +(pool.liqSource==='quoter'?'what a sell pays out by the time it has halved the price, measured with the pool’s quoter (no index lists this pool)':'half of the index figure for it')
      +'. The trade costs and the 1% depth are not taken from that figure — PancakeSwap’s own Infinity quoter priced each size at block '+(tax&&tax.block||'—')+'.'
      +(pool.hooks?' The pool runs a hook contract ('+short(pool.hooks)+') on every swap; it can set the fee per trade or refuse a trade, and every figure here ran through it.':' No hook.')
      +' The tax is read from this pool’s own trades through the Vault; the sell test is not run on an Infinity pool yet.'));
    o.appendChild(w);
  }
  const dep=card('How deep is it really?',
    v3?'The two sides of a concentrated-liquidity pool are not balanced — what sits here is whatever the current price has left in range. The '+quoteSym+' side is still the half that does not depend on this token being worth anything.'
      :'Half of any “liquidity” headline is the token itself, valued at its own price — it shrinks exactly when it would be needed. The '+quoteSym+' side is the half that holds.');
  dep.appendChild(statRow([
    {v:usd(hard),l:'Hard '+quoteSym+' backing',
      s:nf(d.q,d.q<100?3:2)+' '+quoteSym+(v3
        ?' in the pool right now — not a fixed floor: as the price falls, positions convert toward the token side'
        :' — keeps its value if the price falls')},
    {v:mcap?pc(hard/mcap*100,1):'—',l:'Hard backing / Mcap',
      s:v3?'how much of the valuation is currently backed by '+quoteSym+' in range'
          :'the floor under the market cap'},
    // "More than X" is an answer; a dash is not. On a concentrated-liquidity
    // pool the sweep can run out of range before the price gives way — USDC/USDT
    // does not move one percent for any size the quoter will price — and
    // printing "—" there reads as a failure to measure when the finding is that
    // the pool is deeper than the largest size asked about.
    {v:d.up!=null?usd(d.up):(d.upMin!=null?'> '+usd(d.upMin):'—'),l:'Moves the price +1%',
      s:d.up!=null?'a buy this size, right now':(d.upMin!=null?'deeper than the largest size quoted':'a buy this size, right now')},
    {v:d.down!=null?usd(d.down):(d.downMin!=null?'> '+usd(d.downMin):'—'),l:'Moves the price −1%',
      s:d.down!=null?'a sell this size, right now':(d.downMin!=null?'deeper than the largest size quoted':'a sell this size, right now')},
  ]));
  o.appendChild(dep);

  // Qualified by absolute depth rather than by share: say so before any figure
  // is read, not in a footnote under it.
  if(partial!=null){
    const w=el('div','warn warn-soft');
    w.appendChild(el('b',null,'This is one pool of several for this token.'));
    w.appendChild(el('span',null,'It holds '+usd(d.mineUsd)+' — about '+pc(partial*100,1)+
      ' of the '+usd(d.mineUsd+d.otherLiq)+' this token has across all venues. Every figure below describes '+
      'this pool exactly and says nothing about the others. It is deep enough to be worth measuring on its own, '+
      'which is why it is shown; a trade routed by an aggregator may well take a different path.'));
    o.appendChild(w);
  }
  if(deeper){
    const w=el('div','warn warn-soft');
    w.appendChild(el('b',null,'A deeper pool exists for this token.'));
    const s=el('span');
    s.append('You asked about this pool, so this is the one measured. But the '+
      (deeper.kind==='v3'?'PancakeSwap V3 '+(deeper.fee*100).toFixed(2).replace(/0+$/,'').replace(/\.$/,'')+'% tier':'PancakeSwap V2')+
      ' pool against '+deeper.sym+' holds '+usd(deeper.hard)+' on its '+deeper.sym+
      ' side against this one’s '+usd(d.q*quoteUsd)+'. ');
    const a=el('a','lk','Scan that one instead →');
    a.href='?token='+deeper.pair;a.target='_self';
    s.appendChild(a);
    w.appendChild(s);
    o.appendChild(w);
  }
  if(hop&&!hop.direct){
    const w=el('div','warn warn-soft');
    w.appendChild(el('b',null,'Every dollar figure here is derived, not direct.'));
    w.appendChild(el('span',null,'This pool is quoted in $'+hop.sym+', not in BNB or a stablecoin, so $'+hop.sym+
      (hop.hopName
        ?' had to be priced through its own deepest pool first ('+hop.hopName+') — which holds $'+nf(hop.hopUsd||0)+' on its BNB or stablecoin side.'
        :' had to be priced through its own BNB pool first — which holds '+nf(hop.hopBnb||0,3)+' BNB.')+
      ' Everything above is only as trustworthy as that one pool: if it is thin or stale, so are these dollars. The percentages are unaffected.'));
    o.appendChild(w);
  }

  o.appendChild(taxCard(tax,gp,gpOk,d.sim));

  // ladder
  const lad=card('What a trade does to the price — and what it costs',
    'Two different things, routinely confused. Impact is how far this trade alone moves the price. “You pay” is what you give up against the spot price: a worse fill because the pool moves underneath you, plus the pool fee, plus the transfer tax.');
  // One direction can be measured while the other is not: a quiet pool may show
  // three sells and no buys inside the window. Saying "measured" for both would
  // then be false for half the column, so each side names its own source.
  const src=(m,sim)=>m?'measured':sim?'simulated at this block':'reported by GoPlus, unverified';
  const taxNote=(d.taxB||d.taxS)
    ? 'Costs include a '+pc(d.taxB*100)+' buy tax ('+src(tax.ok&&tax.buy!=null,d.simB)+
      ') and a '+pc(d.taxS*100)+' sell tax ('+src(tax.ok&&tax.sell!=null,d.simS)+
      '), plus the '+(pool.fee*100).toFixed(2)+'% pool fee.'
    : (tax.ok&&(tax.buy!=null||tax.sell!=null))
      ? 'Costs include the '+(pool.fee*100).toFixed(2)+'% pool fee only — the transfer tax measured 0% on the executed trades above, so nothing is added for it.'
    : (d.simB||d.simS)
      ? 'Costs include the '+(pool.fee*100).toFixed(2)+'% pool fee only — the transfer tax came to 0% on the buy and sell simulated at this block, so nothing is added for it.'
      : 'Costs include the '+(pool.fee*100).toFixed(2)+'% pool fee only — no transfer tax could be established for this token, measured or reported, so treat this column as a floor.';
  // The toll: what a trade of ANY size costs before depth enters the picture.
  const floors={buy:(1-(1-d.taxB)*(1-pool.fee))*100, sell:(1-(1-d.taxS)*(1-pool.fee))*100};
  lad.appendChild(renderLadder(d.rows,taxNote,floors));
  o.appendChild(lad);

  // LP
  if(pool.kind==='v2'){
    const lp=card('Who holds the LP tokens',
      'Burned LP can never be withdrawn by anyone. Locked LP sits in a timelock — a promise with an expiry date, not a burn. Everything else can be pulled at any moment.');
    const burnedPct=d.lpTot>0?(d.lpDead+d.lpNull)/d.lpTot*100:0;
    // The exchange's own share is neither burned nor anybody's to pull, so it is
    // taken out of the free figure rather than counted as a risk.
    const feePct=d.lpTot>0&&d.lpFee>0?d.lpFee/d.lpTot*100:0;
    const holders=(gp.lp_holders||[]).filter(x=>{const a=(x.address||'').toLowerCase();
      return a!==DEAD&&a!==NULLA&&a!==(d.feeTo||'')});
    const lockedPct=holders.filter(x=>x.is_locked===1).reduce((s,x)=>s+(parseFloat(x.percent)||0),0)*100;
    const freePct=Math.max(0,100-burnedPct-lockedPct-feePct);
    const big=holders.filter(x=>x.is_locked!==1).sort((a,b)=>(parseFloat(b.percent)||0)-(parseFloat(a.percent)||0))[0];
    lp.appendChild(statRow([
      {v:pc(burnedPct),l:'Burned',tone:burnedPct>=99?' good':burnedPct>=1?' mid':' bad',s:nf(d.lpDead+d.lpNull,2)+' of '+nf(d.lpTot,2)+' LP, at the dead address'},
      {v:gpOk?pc(lockedPct):'—',l:'Locked',dim:!gpOk,
        s:gpOk?(lockedPct>0?'in a locker GoPlus recognises':'none in a known locker'):'needs GoPlus, which did not answer'},
      {v:gpOk?pc(freePct):'—',l:'Withdrawable',dim:!gpOk,
        s:gpOk?(big?'largest single holder '+pc((parseFloat(big.percent)||0)*100)+' —':'held across wallets')
              :'on-chain, '+pc(Math.max(0,100-burnedPct-feePct))+' of the LP is simply not burned',
        link:gpOk&&big?{t:short(big.address),href:'https://bscscan.com/address/'+big.address}:null},
    ]));
    // The ledger, wallet by wallet (lpCustody, 2026-09-27): who holds the LP that is not burned, and what each is.
    if(d.custody&&d.custody.holders&&d.custody.holders.length){
      const cu=d.custody,KIND={burned:'burned',locked:'locked',farm:'farm',exchange_fee:'exchange fee',contract:'contract',wallet:'wallet',unclassified:'not classified'};
      const l=el('div','hd-l');const mx=cu.holders[0].pct||1;
      cu.holders.slice(0,6).forEach(r=>{
        const row=el('div','hd-r');
        row.appendChild(link(short(r.address)+' · '+(r.name||KIND[r.kind]||r.kind)+(r.tokenCreator?' · token creator':r.addedFirstLiquidity?' · added the liquidity':''),'https://bscscan.com/token/'+pool.pair+'?a='+r.address,'lk dim'));
        const bar=el('i','hd-b');bar.style.width=Math.max(2,r.pct/mx*100)+'%';row.appendChild(bar);
        row.appendChild(el('span','hd-p',pc(r.pct)));
        l.appendChild(row);
      });
      lp.appendChild(l);
      const gone=(cu.withdrawnSinceCreation||[])[0];
      lp.appendChild(el('p','cd-foot',(cu.read==='complete'
        ?'Every LP transfer since this pool was created was read from the chain — it is younger than the hour of logs a public node serves — so this list is complete.'
        :'Read for the likely holders only (GoPlus’s LP list, the token’s creator and owner, the known lockers and farms, whoever moved LP in the last hour); '+pc(cu.unreadPct)+' of the LP is held by nobody on that list and is not attributed.')+
        (gone?' Already withdrawn: '+pc(gone.pctOfLpEverMinted)+' of all the LP ever minted, by '+short(gone.address)+'.':'')+
        ' A wallet can withdraw its share at any moment; a known locker only when the lock expires.'));
    }
    // Named rather than left in the withdrawable bucket. On a pool that has run
    // for a while this is usually the entire unburned remainder, and reading it
    // as "somebody can pull this" is the wrong conclusion about the one holder
    // here who is not connected to the token at all.
    if(feePct>0){
      const f=el('p','cd-foot');
      f.append(pc(feePct)+' of the LP sits at '+(pool.venue||'the exchange')+'’s own protocol-fee address (');
      f.appendChild(link(short(d.feeTo),'https://bscscan.com/address/'+d.feeTo,'lk'));
      f.append('), which the pair mints to the venue every time liquidity moves. It grows on its own as the pool '+
        'trades and belongs to the exchange, not to the token — so it is counted separately from the figure above '+
        'rather than as liquidity somebody could pull.');
      lp.appendChild(f);
    }
    o.appendChild(lp);
  }else{
    const lp=card('LP ownership does not apply here',
      'This is a concentrated-liquidity pool. Liquidity is held as individual positions rather than as fungible LP tokens, so “LP burned” has no meaning at this venue — there is no LP token to burn. Who holds the positions is not read here. Depth can still leave at any time if position holders withdraw.');
    o.appendChild(lp);
  }

  // other venues
  // Dust is not a venue. A list of six pools holding fractions of a cent tells
  // the reader nothing and buries the one line that might matter, so anything
  // under $100 — or under a thousandth of the pool being measured — is dropped
  // and counted instead.
  const dustLine=Math.max(100,hard/1000),
        shown=(d.others||[]).filter(x=>(x.liquidity||0)>=dustLine),
        hidden=(d.others||[]).length-shown.length;
  if(shown.length){
    const ov=card('Where else it trades',
      'Everything above measures one pool, read exactly from the chain. These are the others: DexScreener’s index finds them, and each one’s depth is read from the chain too — both sides of the pool, in BNB or dollars. A figure marked “index” is DexScreener’s own (a pool quoted in another token).');
    const l=el('div','vn');
    shown.slice(0,6).forEach(x=>{
      const r=el('div','vn-r');
      r.appendChild(el('span','vn-n',x.name||'Unknown'));
      r.appendChild(el('span','vn-v',usd(x.liquidity||0)+(x.source==='index'?' · index':'')));
      r.appendChild(/^0x[a-fA-F0-9]{40}$/.test(x.pair)
        ? link(short(x.pair),'https://bscscan.com/address/'+x.pair,'lk dim')
        : el('span','lk dim','position-based'));
      l.appendChild(r);
    });
    ov.appendChild(l);
    ov.dataset.k=(shown.length+hidden)+' other pool'+(shown.length+hidden===1?'':'s');
    // The cutoff scales with the pool being measured, so it has to be named
    // rather than assumed: writing "$100" while actually hiding everything
    // under $606 states a number that is not the one used.
    if(hidden>0)ov.appendChild(el('p','cd-foot',hidden+' further pool'+(hidden===1?'':'s')+
      ' hold'+(hidden===1?'s':'')+' less than '+usd(dustLine)+' and '+(hidden===1?'is':'are')+
      ' not listed — under a thousandth of the hard '+quoteSym+' backing above, which is not a place anyone trades.'));
    o.appendChild(ov);
  }else if(Array.isArray(d.others)&&!d.others.length){
    o.appendChild(card('One pool only',
      'DexScreener indexes no other pool for this token. Everything tradable sits in the pool measured above.'));
  }else if((d.others||[]).length){
    o.appendChild(card('No other venue worth naming',
      'DexScreener indexes '+(d.others||[]).length+' further pool'+((d.others||[]).length===1?'':'s')+
      ' for this token, each holding less than '+usd(dustLine)+'. Everything tradable sits in the pool measured above.'));
  }

  o.appendChild(ageActivityCard(d));
  const fc=flowCard(d);if(fc)o.appendChild(fc);
  o.appendChild(routeCard(addr));
  o.appendChild(tierCard(addr));
  o.appendChild(rangeCard(addr));
  if(d.holders)o.appendChild(holdersCard(d.holders,d.symb,addr));
  o.appendChild(flagsCard(gp,gpOk,d.sim));
  o.appendChild(el('p','dis','Pool figures are read live from BNB Chain the moment you press Scan. The transfer tax is measured from recent executed trades where possible. Contract properties and the holder list come from GoPlus and are attributed as such; every holder balance is read on-chain. This page describes a pool — it does not check the deployer’s history, the socials, or anything off-chain; it cannot see an upgrade that has not happened yet; and it is not advice.'));
  const ref=(d.rows||[]).filter(r=>r.buyCost!=null).sort((a,b)=>Math.abs(a.usd-500)-Math.abs(b.usd-500))[0];
  foldCards(o,{dep:d.up!=null?'1% at '+usd(d.up):null,lad:ref?'$'+nf(ref.usd)+' buy: '+pc(ref.buyCost,2):null});
}

// ONE LINE PER CARD ON A PHONE (operator's pick, 26.10.): after a scan the phone page ran ~10,600 px. Below the
// short answer and the three figures, every card closes to its title, its one live figure and an arrow; a tap opens
// it. Only CSS hides anything (max-width 640px) — the cards keep their children, so a tool card's later answer lands
// where it always did, and the desktop page is unchanged.
function foldCards(o,given){
  const stV=(c,i=0)=>c.querySelectorAll('.st-v')[i];
  [...o.querySelectorAll(':scope > section.cd:not(.vd-card)')].forEach(c=>{
    const h=c.querySelector('.cd-h h3');if(!h)return;
    const t=h.textContent;let k=null,tone='';
    const take=(e,pre='',post='')=>{if(e){k=pre+e.textContent.trim()+post;tone=(e.className.match(/\b(good|mid|bad)\b/)||[''])[0]}};
    if(/^How deep/.test(t))k=given.dep;
    else if(/^What a trade does/.test(t))k=given.lad;
    else if(/^The transfer tax/.test(t)){const a=stV(c),b=stV(c,1);if(a&&b){k=a.textContent.trim()+' / '+b.textContent.trim();tone=(a.className+' '+b.className).match(/\bbad\b/)?'bad':(a.className.match(/\b(good|mid)\b/)||[''])[0]}}
    else if(/^Who holds the LP/.test(t))take(stV(c),'',' burned');
    else if(c.dataset.k)k=c.dataset.k;
    else if(/^Who is selling/.test(t))take(stV(c),'deployer sold ');
    else if(/^Can you sell/.test(t)){const f=c.querySelector('.f');if(f){k=f.querySelector('b').textContent.trim();tone=f.classList.contains('f-ok')?'good':f.classList.contains('f-bad')?'bad':''}}
    else if(c.querySelector('.st-v'))take(stV(c));
    const b=el('button','fx-h');b.type='button';b.setAttribute('aria-expanded','false');
    b.appendChild(el('span','fx-t',t));
    if(k)b.appendChild(el('span','fx-k'+(tone?' '+tone:''),k));
    b.appendChild(el('span','fx-c','›'));
    b.onclick=()=>b.setAttribute('aria-expanded',String(c.classList.toggle('fx-open')));
    c.classList.add('fx');c.prepend(b);
  });
}
function holdersCard(h,symb,token){
  // Unknown is a state, not a blank (2026-09-27): a token minutes old has no holder list anywhere yet, and the
  // card used to be left out — which reads as "nothing to see". It is drawn, dimmed, with the reason.
  if(h.unknown){
    const c=card('Who holds it — not known yet','The holder list comes from GoPlus, and for this token it is not usable: '+(h.reason||'no list')+'. Unknown is not the same as spread out — on a new token the deployer and a few wallets often hold most of it.');
    return c;
  }
  const c=card('Who holds it','The largest wallets that could sell into the pool, as a share of the circulating '+(symb||'')+' — pools, burn addresses, locked balances and the known exchange and staking wallets left out. The list is GoPlus’s; every balance was read on-chain just now.');
  const k=el('div','hd-k');
  const fig=(v,lab)=>{const b=el('div','hd-f');b.appendChild(el('b','',v));b.appendChild(el('span','',lab));k.appendChild(b)};
  const rows=h.top||[];
  fig(h.top10PctOfCirculating.toFixed(1)+'%','held by the top '+Math.min(10,h.wallets||rows.length));
  c.dataset.k=h.top10PctOfCirculating.toFixed(1)+'% top '+Math.min(10,h.wallets||rows.length);
  fig(rows.length?rows[0].pct.toFixed(1)+'%':'—','the largest single wallet');
  fig(h.count!=null?h.count.toLocaleString('en-US'):'—','holders');
  c.appendChild(k);
  const l=el('div','hd-l');const mx=rows.length?rows[0].pct:1;
  rows.slice(0,5).forEach(r=>{
    const row=el('div','hd-r');
    row.appendChild(link(short(r.address)+(r.contract?' · contract':''),'https://bscscan.com/token/'+token+'?a='+r.address,'lk dim'));
    const bar=el('i','hd-b');bar.style.width=Math.max(2,r.pct/mx*100)+'%';row.appendChild(bar);
    row.appendChild(el('span','hd-p',r.pct.toFixed(2)+'%'));
    l.appendChild(row);
  });
  c.appendChild(l);
  // Named apart rather than dropped silently: Binance 8 holds a quarter of CAKE's float, and a reader should see
  // that it was left out on purpose — customers' coins at an exchange are not one holder who can sell.
  if(h.excluded&&h.excluded.length)c.appendChild(el('p','cd-foot','Left out of the figures above: '+
    h.excluded.map(x=>x.name+' '+x.pct.toFixed(2)+'%').join(' · ')+' — exchange, lock and staking wallets, not one holder who could sell.'));
  return c;
}

// HOW OLD, AND WHO TRADES IT (2026-09-27). The pool's and the token's age from the first block their code
// existed (contractAges), and the swaps of the window the tax read covered (readActivity). The window is named,
// because "12 swaps" means nothing without it.
const ageText=a=>{if(!a||!(a.ageHours>=0))return '—';const h=a.ageHours;
  return h<1?Math.max(1,Math.round(h*60))+' min':h<48?(h<10?h.toFixed(1):Math.round(h))+' h':Math.round(h/24).toLocaleString('en-US')+' days'};
function ageActivityCard(d){
  const a=d.activity,ag=d.age||{};
  const c=card('How old, and who trades it',
    'Age is read off the chain: the first block the pool’s and the token’s contract code existed. Activity counts the swaps in this pool'+
    (a&&a.window?' over the last '+a.window.minutes+' minutes ('+a.window.blocks.toLocaleString('en-US')+' blocks)':'')+'.');
  c.appendChild(statRow([
    {v:ageText(ag.pool),l:'Pool age',dim:!ag.pool,s:ag.pool?'created '+String(ag.pool.createdAt).slice(0,16).replace('T',' ')+' UTC'+(ag.pool.exact?'':' (first block seen with code)'):'the archive node did not answer'},
    {v:ageText(ag.token),l:'Token age',dim:!ag.token,s:ag.token?'created '+String(ag.token.createdAt).slice(0,16).replace('T',' ')+' UTC':'the archive node did not answer'},
    {v:a?nf(a.swaps):'—',l:'Swaps',dim:!a,s:a?nf(a.buys)+' buys · '+nf(a.sells)+' sells':'the log node did not answer'},
    {v:a&&a.uniqueTraders!=null?nf(a.uniqueTraders):'—',l:'Addresses trading',dim:!a||a.uniqueTraders==null,s:a?(a.uniqueTraders!=null?nf(a.uniqueBuyers)+' bought · '+nf(a.uniqueSellers)+' sold':'sellers could not be read'):'—'},
    {v:a&&a.volumeUsd!=null?usd(a.volumeUsd):'—',l:'Volume',dim:!a,s:a&&a.buyVolumeUsd!=null?usd(a.buyVolumeUsd)+' bought · '+usd(a.sellVolumeUsd)+' sold':'—'},
    {v:a&&a.largestSellUsd?usd(a.largestSellUsd):'—',l:'Largest single sell',dim:!a||!a.largestSellUsd,s:a&&a.largestSellUsd?'in the same window':'no sell in the window'},
  ]));
  if(a)c.appendChild(el('p','cd-foot','A buy is counted to the address the pool paid, a sell to the address that sent the token in — a router or aggregator acting for many wallets counts once.'));
  return c;
}

// WHO IS SELLING (2026-09-27, readFlow). Drawn only when it has something to say: a deployer, a top holder or
// launch buyers to name — or, with a deployer known and the sellers read, the plain "no deployer sell in the last
// N minutes", which is itself an answer. Nothing read, no card.
function flowCard(d){
  const f=d.flow;if(!f)return null;
  const dep=f.deployer,ths=f.topHolderSelling||[],sn=f.snipers,min=f.window&&f.window.minutes;
  // Liquidity the deployer put back in the same window is netted (2026-09-27): BOBAI's own creator sells a third,
  // adds the rest with the BNB and burns the LP; the card says both halves.
  const back=dep&&dep.sold&&dep.sold.addedBack;
  const depSold=dep&&dep.sold&&dep.sold.sells>0,snOk=sn&&sn.read&&sn.wallets>0;
  if(!dep&&!ths.length&&!snOk)return null;
  if(dep&&!dep.sold&&!ths.length&&!snOk)return null;
  const c=card('Who is selling','The pool’s sells over the last '+min+' minutes, each put to the wallet whose tokens funded it — the deployer, the wallets it handed tokens to, and holders selling a real part of what they held'+(sn&&sn.read?'; and who bought in the first seconds after the liquidity went in':'')+'.');
  const above=new Set(f.balanceAboveSupply||[]);
  if(dep){
    const holds=above.has(dep.address)?'above the supply':dep.balancePctOfCirculating!=null?pc(dep.balancePctOfCirculating):'—';
    c.appendChild(statRow([
      {v:depSold?usd(dep.sold.usd):'none',l:'Deployer sold',tone:!depSold?' good':back&&!(dep.sold.netUsd>=1)?' mid':' bad',
        s:depSold?(dep.sold.byDeployer?dep.sold.byDeployer.sells+' sell'+(dep.sold.byDeployer.sells===1?'':'s')+' itself':'not itself')+((dep.sold.viaWalletsItFunded||[]).length?' · '+dep.sold.viaWalletsItFunded.length+' wallet(s) it funded':'')+(back?' · '+usd(back.usd)+' added back as liquidity, LP '+back.lp+' · net '+usd(dep.sold.netUsd):''):'in the last '+min+' minutes'+(dep.oneHopNotRead?' (its own wallet only)':''),
        link:{t:short(dep.address),href:'https://bscscan.com/address/'+dep.address}},
      {v:holds,l:'Deployer holds',tone:above.has(dep.address)?' bad':'',dim:dep.balancePctOfCirculating==null&&!above.has(dep.address),s:above.has(dep.address)?'its balance reads larger than the whole supply':'of the circulating supply · '+dep.source},
      {v:dep.lpPct!=null?pc(dep.lpPct):'—',l:'Deployer’s LP share',dim:dep.lpPct==null,s:dep.lpPct!=null?'of the pool’s LP tokens':(d.lpTot>0?'none — not on the LP holder list':'not read (a V3 position has no LP token)')},
    ]));
  }
  if(ths.length){
    const l=el('div','hd-l');
    ths.forEach(r=>{
      const row=el('div','hd-r');
      row.appendChild(link(short(r.address)+' · sold '+pc(r.soldPctOfBalance,1)+' of '+pc(r.heldPctBefore),'https://bscscan.com/token/'+d.addr+'?a='+r.address,'lk dim'));
      const bar=el('i','hd-b');bar.style.width=Math.max(2,Math.min(100,r.soldPctOfBalance))+'%';row.appendChild(bar);
      row.appendChild(el('span','hd-p',usd(r.usd)));
      l.appendChild(row);
    });
    c.appendChild(el('p','cd-foot','Holders that sold more than a quarter of what they held before the window'+(f.topHolderBasis==='size'?' (no holder list for this token: any seller that held 2% or more of the float counts)':' (from the top ten of the holder list)')+':'));
    c.appendChild(l);
  }
  if(snOk){
    c.appendChild(statRow([
      {v:nf(sn.wallets),l:'Launch buyers',s:'bought within '+sn.blocks+' blocks of the liquidity (block '+sn.launchBlock+')'},
      {v:pc(sn.holdPctOfCirculating),l:'They still hold',tone:sn.holdPctOfCirculating>10?' bad':'',s:'of the circulating supply'+(sn.walletsNotRead?' · '+sn.walletsNotRead+' more not read':'')},
    ]));
  }
  c.appendChild(el('p','cd-foot','A sell is put to the wallet whose transfer funded it; one sold through an aggregator shows as the aggregator. The deployer is the first mint’s recipient, else the token’s creator, else whoever added the first liquidity.'));
  return c;
}

// ---- the "not measurable here" path ---------------------------------------
function renderElsewhere(gp,addr,name,symb,hard,others,otherLiq,share,hasPool,oneSided){
  const o=$('sc-out');o.hidden=false;$('sc-err').hidden=true;o.textContent='';
  const teaser=$('sc-what');if(teaser)teaser.hidden=true;
  const head=el('header','hd');
  const ttl=el('div','hd-t');ttl.appendChild(el('h2',null,symb));ttl.appendChild(el('span','hd-n',name));
  head.appendChild(ttl);
  head.appendChild(frag(el('div','hd-l'),link(short(addr),'https://bscscan.com/token/'+addr),
    link('DexScreener','https://dexscreener.com/bsc/'+addr)));
  o.appendChild(head);
  const w=el('div','warn');
  // A pool that exists and holds only the token (Muskonomy's one-sided 1% V3 pool, 2026-09-27) is its own answer.
  const os=!hasPool&&oneSided&&oneSided[0];
  if(os){
    w.appendChild(el('b',null,'Pool found, but it holds no '+os.sym+' to sell into.'));
    w.appendChild(el('span',null,'The '+(os.kind==='v3'?'PancakeSwap V3 '+String(+(os.fee*100).toFixed(4))+'%':(os.venue||'PancakeSwap V2'))+' pool '+short(os.pair)+
      ' holds '+nf(os.tok||0)+' '+symb+' and no '+os.sym+': only the token’s own side, so a sell has nothing to be paid out of. There is no price anybody could get here yet, so no cost is shown.'));
  }else{
  w.appendChild(el('b',null,'No pool here can be measured exactly.'));
  w.appendChild(el('span',null,(hasPool
    ? 'The readable pool holds '+usd(hard)+' — '+pc(share*100)+' of the '+usd(hard+otherLiq)+' GoPlus sees across all venues. The rest sits'
    : 'It has no readable PancakeSwap pool. Its '+usd(otherLiq)+' of liquidity sits')+
    ' in venues this page cannot quote exactly. Deriving depth from the sliver that is readable would produce a number that is not merely imprecise but wrong, so none is shown. The contract properties below are unaffected — they belong to the token, not to a venue.'));
  }
  o.appendChild(w);
  // Dust is not a venue (the $100 line the pool path already draws).
  others=others.filter(x=>(x.liquidity||0)>=100);
  if(others.length){
    const ov=card('Where it actually trades','As reported by GoPlus.');
    const l=el('div','vn');
    others.slice(0,6).forEach(x=>{
      const r=el('div','vn-r');
      r.appendChild(el('span','vn-n',x.name||'Unknown'));
      r.appendChild(el('span','vn-v',usd(x.liquidity||0)+(x.source==='index'?' · index':'')));
      r.appendChild(/^0x[a-fA-F0-9]{40}$/.test(x.pair)
        ? link(short(x.pair),'https://bscscan.com/address/'+x.pair,'lk dim')
        : el('span','lk dim','position-based'));
      l.appendChild(r);
    });
    ov.appendChild(l);o.appendChild(ov);
  }
  o.appendChild(flagsCard(gp,!!(gp.token_name||gp.dex||gp.is_open_source!=null)));
  o.appendChild(el('p','dis','Contract properties come from GoPlus. Not advice.'));
}

// ---- the four.meme launch curve --------------------------------------------
// A token that is still raising on four.meme has no pool anywhere, and this
// page used to answer it with the "trades elsewhere" card and "$0 of liquidity"
// — a sentence about a market that does not exist, for a token that trades all
// day inside four.meme's contract. The three questions are the same as for a
// pool and are answered from four.meme's own helper contract: what a trade
// costs (its own quote for a buy and a sell of each size, fee included), where
// the money is (in the platform's contract until the raise completes — a
// readable balance, not a promise), and whether a sell would be paid out.
function renderCurve(gp,addr,name,symb,cv,rows,quoteUsd){
  // four.meme or flap.sh (2026-10-18): the same card, each platform named and read as itself
  const flap=cv.platform==='flap.sh', P=flap?'flap.sh':'four.meme', PC=flap?'flap.sh’s Portal contract':'four.meme’s contract';
  const o=$('sc-out');o.hidden=false;$('sc-err').hidden=true;o.textContent='';
  const teaser=$('sc-what');if(teaser)teaser.hidden=true;
  const head=el('header','hd');
  const ttl=el('div','hd-t');ttl.appendChild(el('h2',null,symb));ttl.appendChild(el('span','hd-n',name));
  head.appendChild(ttl);
  head.appendChild(frag(el('div','hd-l'),link(short(addr),'https://bscscan.com/token/'+addr),
    ...(flap?[]:[link('four.meme','https://four.meme/token/'+addr)])));
  o.appendChild(head);

  const q=cv.quoteSym||'the quote token';
  const priceUsd=quoteUsd>0?cv.price*quoteUsd:null;
  const qAmt=v=>v==null?'—':(v>=100?nf(v):v>=1?nf(v,2):v>=0.01?nf(v,4):tiny(v))+' '+q;

  // The answer first, in the same three lines a pool gets.
  const c=el('section','cd vd-card');
  const h=el('div','cd-h');
  h.appendChild(el('h3',null,'The short answer'));
  h.appendChild(el('p',null,'This token is still on its '+P+(flap?' bonding':' launch')+' curve. There is no PancakeSwap pool yet; every trade goes through '+PC+', and that is what was asked.'));
  c.appendChild(h);
  const list=el('div','vd');
  const line=(tone,hd,body)=>{const r=el('div','vd-r vd-'+tone);r.appendChild(el('b',null,hd));r.appendChild(el('span',null,body));list.appendChild(r)};

  const ref=rows.slice().sort((a,b)=>Math.abs(a.usd-500)-Math.abs(b.usd-500))[0];
  if(ref&&(ref.buyCost!=null||ref.sellCost!=null)){
    const worst=Math.max(ref.buyCost==null?0:ref.buyCost,ref.sellCost==null?0:ref.sellCost);
    const toll=cv.feePct;
    const tone=toll>0?(worst<=toll*1.5?'good':worst<=toll*3?'mid':'bad'):'mid';
    line(tone,'A $'+nf(ref.usd)+' trade costs you '+(ref.buyCost==null?'—':pc(ref.buyCost))+' to buy and '+(ref.sellCost==null?'—':pc(ref.sellCost))+' to sell.',
      P+'’s own quote for that size right now, its '+pc(toll)+' fee included. The rest is the curve moving under the trade'+(ref.buyNote?'; the buy side: '+ref.buyNote:'')+'.');
  }else{
    line('unknown','What a trade costs could not be quoted.',
      rows.length?'The curve answered no size this page asks about.':(quoteUsd>0?'The helper contract did not answer.':'The curve is raising in '+q+', which this page cannot express in dollars.'));
  }
  if(flap){
    // the money a sell is paid out of, against the figure an index shows for the same curve (its virtual reserve)
    const resUsd=quoteUsd>0?cv.reserve*quoteUsd:null;
    line(resUsd!=null&&resUsd<100?'bad':'mid','The curve holds '+qAmt(cv.reserve)+(resUsd!=null?' (about '+usd(resUsd)+')':'')+' to pay sells out of.',
      'That is all the money in it: a sell larger than this cannot be paid.'+(cv.indexUsd>0?' Index sites show about '+usd(cv.indexUsd)+' of “liquidity” for this curve; that figure counts the curve’s virtual reserve, which no sell is paid from.':'')+' '+(cv.progressPct==null?'':pc(cv.progressPct,1)+' of the supply that moves it to a DEX is sold.'));
  }else line('mid',(cv.progressPct==null?'The raise is in progress':pc(cv.progressPct,1)+' of the raise is done')+' — '+qAmt(cv.raised)+' of '+qAmt(cv.maxRaising)+'.',
    'The money raised sits in four.meme’s contract until the raise completes, not in the creator’s wallet. When it completes, four.meme lists the token on PancakeSwap; until then there is no liquidity to pull, because there is no pool.');
  const sellRow=rows.find(r=>r.sellCost!=null);
  if(sellRow)line('good','A sell would be paid out right now.',
    P+' quoted '+q+' for a sell of the size above at this block. That is the curve’s answer, not a simulation of your wallet; the token contract itself is a '+P+' template.');
  else if(flap&&rows.some(r=>r.sellNote))line('bad','No sell of $'+nf(rows[0].usd)+' or more can be paid out right now.','The curve holds less than that. Smaller sells are paid from what it holds, until it is empty.');
  else line('unknown','Whether a sell would be paid out could not be checked.','The '+(flap?'Portal':'helper contract')+' quoted no sell at any size this page asks about.');
  c.appendChild(list);o.appendChild(c);

  // The ladder, in the pool ladder’s own columns. "Impact" here is the cost
  // beyond the fee, which on a curve is the price moving under the trade.
  if(rows.length){
    const lad=card('What a trade really costs on the curve',P+'’s quote for each size, fee included, against its last price.');
    const shaped=rows.map(r=>({usd:r.usd,buyCost:r.buyCost,sellCost:r.sellCost,
      buyMove:r.buyCost==null?null:Math.max(0,r.buyCost-cv.feePct),
      sellMove:r.sellCost==null?null:-Math.max(0,r.sellCost-cv.feePct)}));
    const capped=rows.filter(r=>r.buyNote).map(r=>'$'+nf(r.usd));
    const noPay=rows.filter(r=>r.sellNote).map(r=>'$'+nf(r.usd));
    lad.appendChild(renderLadder(shaped,capped.length?'A dash on the buy side ('+capped.join(', ')+') means the curve has less left to sell than that size would take.':flap&&noPay.length?'A dash on the sell side ('+noPay.join(', ')+') means the curve holds less than that size to pay out.':null,{buy:cv.feePct,sell:cv.sellFeePct??cv.feePct},'curve'));
    o.appendChild(lad);
  }

  // The facts the lines above were made from.
  const f=card('The curve, as '+PC+' reports it',flap?'Read from the Portal (getTokenV5, quoteExactInput) at this block; nothing is cached.':'Read from TokenManagerHelper3 at this block; nothing is cached.');
  f.appendChild(statRow(flap?[
    {v:priceUsd!=null?usd(priceUsd):qAmt(cv.price),l:'Price',s:priceUsd!=null?qAmt(cv.price)+' per token':'per token'},
    {v:qAmt(cv.reserve),l:'In the curve',s:quoteUsd>0?'about '+usd(cv.reserve*quoteUsd)+', all a sell is paid from':'all a sell is paid from'},
    {v:nf(cv.sold),l:'Tokens sold',s:'of '+nf(cv.dexAtSupply)+', then a DEX'},
    {v:pc(cv.feePct),l:'Platform fee',s:'buy; '+pc(cv.sellFeePct??cv.feePct)+' sell'},
  ]:[
    {v:priceUsd!=null?usd(priceUsd):qAmt(cv.price),l:'Price',s:priceUsd!=null?qAmt(cv.price)+' per token':'per token'},
    {v:qAmt(cv.raised),l:'Raised',s:'of '+qAmt(cv.maxRaising)},
    {v:nf(cv.offersLeft),l:'Tokens left to sell',s:'of '+nf(cv.maxOffers)},
    {v:pc(cv.feePct),l:'Platform fee',s:'on every buy and sell'},
    ...(cv.launchTime?[{v:new Date(cv.launchTime*1000).toISOString().slice(0,10),l:'Launched',s:'on four.meme'}]:[]),
  ]));
  o.appendChild(f);

  // The router sell test has nothing to sell into here; the chip says so and
  // points at the curve's own answer above rather than reading as a failure.
  o.appendChild(flagsCard(gp,!!(gp.token_name||gp.dex||gp.is_open_source!=null),
    {ok:false,curve:true,reason:'Not applicable on the '+(flap?'bonding':'launch')+' curve: there is no pool and no router to sell into. Whether a sell would be paid out is answered above, from '+PC+'.'}));
  o.appendChild(el('p','dis','Curve figures come from '+(flap?'flap.sh’s Portal contract':'four.meme’s helper contract')+' on BNB Smart Chain; contract properties from GoPlus. Measurement, not advice.'));
}

// ---- orchestration ---------------------------------------------------------
// Every stage sets this. It exists for one reason: a scan that ends with an
// empty page and no message is the worst thing this tool can do — the reader
// cannot tell whether the token is fine, broken, or whether we are. Measured at
// 2 blanks in 16 runs before this net went in. Now an empty result is caught
// here, named by the stage it died in, and shown as an error like any other.
let stage='start';
const at=s=>{stage=s;step(s)};

// ONE SCAN AT A TIME (2026-09-18). "Try one", the history chips and the feed
// rows all start a scan without asking whether one is running; two scans
// then raced, the slower one drew the page last and set ?token= to an address
// the input field no longer showed. A scan in flight finishes first.
let scanning=false;
async function scan(input){
  if(scanning)return;
  scanning=true;
  try{return await scanOnce(input)}finally{scanning=false}
}
async function scanOnce(input){
  stage='start';
  busy(true,'identifying the address…');
  try{
    const askGoPlus=a=>fetch(GOPLUS+a).then(r=>r.ok?r.json():null)
      .then(j=>j&&j.result&&(j.result[a]||j.result[a.toLowerCase()])).catch(()=>null);
    // Fired against the input on the chance it IS the token, because it usually
    // is and this is the slow leg. If the input turns out to be a pool, the
    // answer describes the LP token instead — "Pancake LPs / Cake-LP", with the
    // wrong name, the wrong supply and the wrong tax — so it is asked again
    // against the real token once that is known, and this first answer dropped.
    let gpP=askGoPlus(input);

    let what;
    try{what=await classify(input)}
    catch(e){return fail('The chain did not answer.','The public BSC node refused or timed out. Nothing is cached here, so a retry in a few seconds usually works.')}

    // A pasted pool tells us the venue directly. Which side is "the token" is
    // then the only open question: it is the side that is not the quote, and
    // the quote is whichever side can be priced.
    let token,pool=null,tokDec,bnbUsd,hop,deeper=null,oneSided=[];
    const base=await rpcBatch([call(BNB_PAIR,S.reserves),call(BNB_PAIR,S.token0)]);
    const br=res2(base[0]),bIs0=addrAt(base[1])===WBNB;
    bnbUsd=br?(bIs0?br[1]/br[0]:br[0]/br[1]):0;
    if(!(bnbUsd>0))return fail('Could not price BNB.','The reference pool read back empty, so nothing could be stated in dollars.');

    if(what.kind==='v2pair'||what.kind==='v3pool'){
      at('reading the pool…');
      const [a,b]=[what.token0,what.token1];
      const qa=QUOTES.find(([x])=>x===a),qb=QUOTES.find(([x])=>x===b);
      if(qa&&!qb)token=b; else if(qb&&!qa)token=a;
      else if(qa&&qb)token=a;
      else{
        // Neither side is a currency we know. The quote is the one that has its
        // own BNB pool — $MatthewCoin/$SpaceX resolves this way.
        const pa=await priceToken(a,bnbUsd),pb=await priceToken(b,bnbUsd);
        token=(pb.usd!=null&&pa.usd==null)?a:(pa.usd!=null&&pb.usd==null)?b
             :((pb.hopBnb||0)>=(pa.hopBnb||0)?a:b);
      }
      const quote=token===a?b:a;
      const info=await rpcBatch([call(token,S.decimals),call(token,S.symbol),call(token,S.name)]);
      tokDec=decOf(info[0]);
      hop=await priceToken(quote,bnbUsd);
      if(hop.usd==null)return fail('That pool cannot be priced.',
        'It trades '+(decStr(info[1])||'this token')+' against '+short(quote)+
        ', which has no BNB pool of its own — so there is no way to express its depth in dollars without inventing one.');
      // The quote side must count in 18 decimals (see scanner-scan.js): refused
      // rather than answered 1e10 off.
      if(hop.dec!=null&&hop.dec!==18)
        return fail('That pool is quoted in a token with '+hop.dec+' decimals.',
          'Its depth cannot be stated correctly here yet: this scan counts the quote side in 18 decimals, as BNB and the stablecoins do. Paste the token itself instead — it is then measured in its deepest pool against BNB or a stablecoin.');
      if(what.kind==='v3pool'&&!what.pancake&&!what.uniswap)
        return fail('That V3 pool is neither a PancakeSwap nor a Uniswap pool.',
          'Its factory is '+short(what.factory||'')+'. The concentrated-liquidity maths on this page is priced through PancakeSwap\'s own quoter, which knows nothing about another venue\'s pool. Paste the token instead and the scan finds its PancakeSwap pools.');
      if(what.kind==='v2pair'&&!what.venue)
        return fail('That pool is on a venue this page does not price.',
          'Its factory is '+short(what.factory||'')+', which is not one of the constant-product venues whose swap fee has been derived and verified here (PancakeSwap V2, Uniswap V2, Biswap). Applying somebody else’s fee would quietly understate what a trade costs, so no figures are shown.');
      pool=what.kind==='v2pair'
        ?{kind:'v2',pair:input,quote,sym:hop.sym,usd:hop.usd,
          fee:what.venue.fee,venue:what.venue.name,factory:what.factory,
          tok:(addrAt(what.token0)===token?what.reserves[0]:what.reserves[1])/Math.pow(10,tokDec),
          q:(addrAt(what.token0)===token?what.reserves[1]:what.reserves[0])/1e18}
        :{kind:'v3',pair:input,quote,sym:hop.sym,usd:hop.usd,fee:what.fee/1e6,feeRaw:what.fee,
          sqrt:what.sqrt,tokenIs0:what.token0===token,...(what.uniswap?{venue:'Uniswap V3',quoter:UNI_QUOTER}:{})};
      if(pool.kind==='v3'){
        const bal=await rpcBatch([call(quote,balOf(input)),call(token,balOf(input))]);
        pool.q=Number(hx(bal[0]))/1e18;pool.tok=Number(hx(bal[1]))/Math.pow(10,tokDec);
      }
      pool.usd=hop.usd;pool.sym=hop.sym;
      if(token!==input)gpP=askGoPlus(token);
      // A pasted pool is honoured — you asked about that one. But the factories
      // are still asked what else exists, because a link often points at a side
      // pool while the real depth sits one fee tier over, and staying silent
      // about that would answer the question asked instead of the one meant.
      try{
        const alt=(await discover(token,tokDec,bnbUsd,{uniswap:true}))
          .find(c=>c.pair.toLowerCase()!==pool.pair.toLowerCase()&&c.hard>(pool.q||0)*pool.usd*1.15);
        if(alt)deeper=alt;
      }catch(e){}
      // A pasted pool with nothing on its quote side is the one-sided case (2026-09-27, as in scanner-scan.js).
      if(!(pool.q>0)){oneSided=[pool];pool=null}
    }else{
      token=input;
      at('asking the factories which pools exist…');
      const info=await rpcBatch([call(token,S.decimals),call(token,S.symbol),call(token,S.name)]);
      tokDec=decOf(info[0]);
      const cands=await discover(token,tokDec,bnbUsd,{uniswap:true});
      pool=cands[0]||null;oneSided=cands.oneSided||[];
      hop={direct:true,sym:pool?pool.sym:'BNB'};
      if(pool&&pool.kind==='v3'){
        const s=await rpcBatch([call(pool.pair,S.slot0),call(pool.pair,S.token0)]);
        pool.sqrt=hx('0x'+s[0].slice(2,66));pool.tokenIs0=addrAt(s[1])===token;
      }
    }

    const gp=(await gpP)||{},gpOk=!!(gp.token_name||gp.dex||gp.is_open_source!=null);
    const nameInfo=await rpcBatch([call(token,S.symbol),call(token,S.name),
      call(token,S.totalSupply),call(token,balOf(DEAD)),call(token,balOf(NULLA))]);
    const symb=(gp.token_symbol||decStr(nameInfo[0])||'?').trim().slice(0,16),
          name=(gp.token_name||decStr(nameInfo[1])||'Unknown token').trim().slice(0,60),
          supply=nameInfo[2]?Number(hx(nameInfo[2]))/Math.pow(10,tokDec):null,
          burned=(Number(hx(nameInfo[3]))+Number(hx(nameInfo[4])))/Math.pow(10,tokDec);

    // Venues from DexScreener, which indexes the small DEXes; GoPlus's list is
    // the fallback and only covers what it happens to know.
    at('checking where else it trades…');
    const dsAll=await measureVenues((await venues(token))||[],bnbUsd,token);
    // PancakeSwap Infinity CL pools found from their keys on chain and sized by the quoter (2026-10-19, infinityFind;
    // the same as scanner-scan.js): measured even when an index lists them, the larger figure stands.
    if(what.kind!=='v2pair'&&what.kind!=='v3pool'){
      at('looking for PancakeSwap Infinity pools…');
      for(const id of (await infinityFind(token).catch(()=>[])).slice(0,3)){
        const f=await infinityPool(token,tokDec,bnbUsd,{pair:id,probe:true}).catch(()=>null);
        if(!f)continue;
        const liq=Math.round(2*(await infReachUsd(f.pool,tokDec,f.px).catch(()=>0)));
        const listed=Math.max(0,...dsAll.filter(x=>x.pair===id).map(x=>x.liq||0),...(gp.dex||[]).filter(x=>String(x.pair||'').toLowerCase()===id).map(x=>parseFloat(x.liquidity)||0));
        if(!(liq>listed))continue;
        for(let i=dsAll.length-1;i>=0;i--)if(dsAll[i].pair===id)dsAll.splice(i,1);
        dsAll.push({pair:id,name:'PancakeSwap Infinity CL '+(+(f.pool.fee*100).toFixed(4))+'%',quote:f.hop.sym,liq,source:'quoter'});
      }
      dsAll.sort((a,b)=>b.liq-a.liq);
    }
    // A deeper PancakeSwap pool quoted in CAKE, BTCB, SOL… (2026-10-18, indexedPool; as in scanner-scan.js).
    if(what.kind!=='v2pair'&&what.kind!=='v3pool'){
      const idx=[...(dsAll||[]).map(x=>({pair:x.pair,liquidity:x.liq||0,source:x.source})),
        ...(gp.dex||[]).map(x=>({pair:String(x.pair||'').toLowerCase(),liquidity:parseFloat(x.liquidity)||0}))]
        .sort((a,b)=>b.liquidity-a.liquidity);
      const cur=pool?pool.pair.toLowerCase():null;
      const curIdx=cur?Math.max(0,...idx.filter(x=>x.pair===cur).map(x=>x.liquidity)):0;
      const ahead=idx.filter((x,i)=>x.pair!==cur&&x.liquidity>curIdx&&idx.findIndex(y=>y.pair===x.pair)===i);
      if(ahead.length){
        at('measuring the deeper pool the index names…');
        const found=await indexedPool(token,tokDec,bnbUsd,ahead,pool?(pool.q||0)*pool.usd:0).catch(()=>null);
        if(found){pool=found.pool;hop=found.hop}
      }
    }
    const others=dsAll.length
      ? dsAll.filter(x=>!pool||x.pair!==pool.pair.toLowerCase())
        .map(x=>({pair:x.pair,name:x.name+(x.quote?' · '+x.quote:''),liquidity:x.liq,source:x.source||'index'}))
      : (gp.dex||[]).filter(x=>x.pair&&(!pool||x.pair.toLowerCase()!==pool.pair.toLowerCase()))
        .map(x=>({pair:x.pair,name:x.name||x.liquidity_type||'Unknown',liquidity:parseFloat(x.liquidity)||0}))
        .sort((a,b)=>b.liquidity-a.liquidity);
    const otherLiq=others.reduce((s,x)=>s+(x.liquidity||0),0);
    const hard=pool?(pool.q||0)*pool.usd:0;
    // "Is the pool I can measure representative?" — and the comparison must use
    // ONE yardstick. It used to weigh our own one-sided figure (the quote tokens
    // actually sitting in the pool) against GoPlus's two-sided one, which values
    // both halves. On a V3 pool those differ by a factor of eight: $153k of real
    // USDT against their $868k. Every V3 pool therefore looked like a rounding
    // error next to the others and got refused — $MarsCoin's did, while trading
    // perfectly well. So when GoPlus has a figure for OUR pool, both sides of
    // the ratio come from GoPlus; only when it does not do we fall back to
    // measuring ours against theirs, which is the imperfect case.
    const mineFrom=list=>{if(!list||!pool)return null;
      const e=list.find(x=>(x.pair||'').toLowerCase()===pool.pair.toLowerCase());
      return e?(e.liq!=null?e.liq:parseFloat(e.liquidity)||0):null};
    const mine=mineFrom(dsAll)!=null?mineFrom(dsAll):mineFrom(gp.dex);
    const share=!pool?0
      :(mine!=null&&mine+otherLiq>0)?mine/(mine+otherLiq)
      :(otherLiq>0?hard/(hard+otherLiq):1);
    // A readable pool that holds a sliver of the real liquidity describes a side
    // pocket. $TUT keeps $2.0M in V3 and $338 in V2; a ladder off that pair says
    // "+68% on a $100 buy" for a token with two million dollars of depth. A
    // footnote does not survive a screenshot, so the ladder is not drawn at all.
    // Two questions, and the old guard only asked one of them. "What share of
    // the token's liquidity is this?" catches the side-pocket case — $v$ keeps
    // $19k here against $1.5M elsewhere, and a ladder off that would describe a
    // market nobody trades in. But share alone refused $BTCB, whose pool here
    // holds THIRTEEN MILLION DOLLARS and is merely one of several: perfectly
    // measurable, just not the whole story. So a pool also qualifies on its own
    // absolute depth, and when it qualifies that way the reader is told plainly
    // what share it is.
    const mineUsd=mine!=null?mine:hard*2;
    const deepEnough=mineUsd>=100000;
    // An address that is not a token at all used to land in the "trades
    // elsewhere" path and be told its "$0.00 of liquidity sits in venues this
    // page cannot quote exactly" — a sentence about a market that does not
    // exist. A wallet address pasted by mistake deserves to be told that.
    if(!pool&&!others.length&&!gpOk&&!(supply>0)&&!decStr(nameInfo[0])){
      // A wallet is told so (2026-10-09 review): no contract code at all is a fact the chain gives, not a guess
      const code=await fetch(RPC,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'eth_getCode',params:[token,'latest']}),signal:AbortSignal.timeout(8000)}).then(r=>r.json()).then(j=>j&&j.result).catch(()=>null);
      if(code==='0x')return fail('That is a wallet, not a token.','There is no contract code at this address. Paste the token’s contract address instead — it is on the token’s BscScan page, or in the swap that bought it.');
      return fail('That address is not a BSC token.',
        'It answers nothing to symbol() or totalSupply(), has no pool at any venue this page can read, and GoPlus does not list it. A wallet address, or a contract that is not a token, looks exactly like this.');
    }
    // No pool at all: ask four.meme before concluding "trades elsewhere". A
    // token still raising there has no pool by design, and its market lives in
    // the platform's contract. A graduated token falls through to the pool path.
    if(!pool&&!others.length){
      at('asking four.meme whether it is still on the curve…');
      const cv=await curveInfo(token);
      if(cv&&!cv.liquidityAdded){
        const quoteUsd=cv.quoteSym==='BNB'?bnbUsd:cv.quoteIsStable?1:0;
        const rows=await curveLadder(token,cv,quoteUsd,STEPS);
        renderCurve(gp,token,name,symb,cv,rows,quoteUsd);
        remember(token,symb);
        return;
      }
    }
    // flap.sh's curve (2026-10-18, flapInfo in scanner-chain.js; the same as /api/pool-scan): the index lists it as a
    // "flapsh" pair, so it is asked whether or not the index knows other venues
    if(!pool){
      at('asking flap.sh whether it is still on its curve…');
      const fl=await flapInfo(token);
      if(fl&&!fl.graduated){
        const hopQ=fl.quoteAddr&&!fl.quoteIsStable?await priceQuote(fl.quoteAddr,bnbUsd).catch(()=>null):null;
        const quoteUsd=fl.quoteSym==='BNB'?bnbUsd:fl.quoteIsStable?1:(hopQ&&hopQ.usd)||0;
        const cvF={...fl,quoteSym:fl.quoteSym||(hopQ&&hopQ.sym)||null,feePct:fl.feeBuyPct,sellFeePct:fl.feeSellPct,indexUsd:otherLiq};
        const rows=await flapLadder(token,fl,quoteUsd,STEPS);
        renderCurve(gp,token,name,symb,cvF,rows,quoteUsd);
        remember(token,symb);
        return;
      }
    }
    if(!pool||(share<0.25&&!deepEnough))
      return renderElsewhere(gp,token,name,symb,hard,others,otherLiq,share,!!pool,oneSided);
    const partial=share<0.25?share:null;

    // PRICE. For a constant-product pair the ratio of the two reserves IS the
    // price. For a concentrated-liquidity pool it is not, and using it anyway
    // put $TUT at $0.081 when the pool was quoting $0.127 — a 36% error that
    // then reappeared as a nonsensical "you pay 32.8%". V3 keeps its price in
    // sqrtPriceX96, so that is where it is read from.
    let px;
    if(pool.kind==='v3'||pool.kind==='inf'){
      const d0=pool.tokenIs0?tokDec:18,d1=pool.tokenIs0?18:tokDec,
            r=Math.pow(Number(pool.sqrt)/Math.pow(2,96),2)*Math.pow(10,d0-d1);
      px=(pool.tokenIs0?r:1/r)*pool.usd;
    }else px=(pool.q/pool.tok)*pool.usd;
    if(!(px>0))return fail('That pool is empty.','Both sides read back as zero — there is nothing to measure.');

    // How old the pool and the token are (contractAges, 2026-09-27): archive reads started now, beside the tax read.
    // An Infinity pool is an id, not a contract: no age to search. Its tax is read off its own Swap logs and the
    // Vault's transfers (measureTax); the sell test does not apply yet and says so (2026-10-19, as scanner-scan.js).
    const inf=pool.kind==='inf';
    const agesP=contractAges(inf?[token]:[pool.pair,token]).catch(()=>null);
    at('measuring the tax from real trades…');
    const tokenIs0=pool.kind==='v2'
      ? (await rpcBatch([call(pool.pair,S.token0)]).then(r=>addrAt(r[0])===token))
      : pool.tokenIs0;
    const tax=await measureTax(token,pool.pair.toLowerCase(),tokenIs0,pool.kind);
    at('simulating a sell…');
    const sim=inf?{ok:false,reason:'the sell test covers PancakeSwap V2 pairs and V3 pools; the sell side of this Infinity pool is priced by its own quoter below, hook included'}
      :await simulateRoundTrip(token,pool.pair.toLowerCase(),tokenIs0,pool.kind);
    // A blank label is no label: Number("") is 0 and would read as a labelled 0%.
    const lab2=v=>(v==null||String(v).trim()===''||!isFinite(Number(v))?NaN:Number(v));
    const gB=lab2(gp.buy_tax),gS=lab2(gp.sell_tax);
    // Which tax the cost columns use, per direction: an executed trade first,
    // the simulation second, the label last, zero (and said so) never quietly.
    const simHere=sim&&sim.through_scanned_pool!==false;
    const sB=simHere&&sim.tax&&sim.tax.buy_pct!=null?sim.tax.buy_pct/100:null,
          sS=simHere&&sim.tax&&sim.tax.sell_pct!=null?sim.tax.sell_pct/100:null;
    // A measured ~0 the simulation contradicts is a hidden fee leg (reflection-style
    // transfers emit only the net amount): the simulated figure stands for that side.
    const hid=(m,si)=>m!=null&&si!=null&&m<0.0015&&si-m>0.0015;
    const simOverB=tax.ok&&hid(tax.buy,sB),simOverS=tax.ok&&hid(tax.sell,sS);
    const taxB=tax.ok&&tax.buy!=null&&!simOverB?tax.buy:(sB!=null?sB:(isFinite(gB)?gB:0)),
          taxS=tax.ok&&tax.sell!=null&&!simOverS?tax.sell:(sS!=null?sS:(isFinite(gS)?gS:0)),
          simB=!(tax.ok&&tax.buy!=null)&&sB!=null,simS=!(tax.ok&&tax.sell!=null)&&sS!=null,
          usedTax=tax.ok||sB!=null||sS!=null||isFinite(gB)||isFinite(gS);

    at('quoting trade sizes…');
    let rows,up,down,upMin=null,downMin=null;
    if(pool.kind==='v2'){
      rows=ladderV2(pool.tok,pool.q,pool.fee,taxB,taxS,px,pool.usd);
      up=onePctV2(pool.q,pool.fee,1.01)*pool.usd;
      down=onePctV2(pool.tok,pool.fee,1/0.99)/(1-taxS)*px;
    }else if(inf){
      rows=await ladderInf(pool,tokDec,px,taxB,taxS);
      const oc=await onePctInf(pool,tokDec,px,taxS);
      up=oc.up;down=oc.down;upMin=oc.upMin;downMin=oc.downMin;
      if(rows.block&&tax.block==null)tax.block=rows.block;
    }else{
      rows=await ladderV3(pool.pair,token,pool.quote,pool.feeRaw,tokDec,px,pool.usd,
        taxB,taxS,pool.sqrt,pool.tokenIs0,pool.quoter);
      const oc=await onePctV3(pool.pair,token,pool.quote,pool.feeRaw,tokDec,px,pool.usd,
        pool.sqrt,pool.tokenIs0,taxS,pool.quoter);
      up=oc.up;down=oc.down;upMin=oc.upMin;downMin=oc.downMin;
    }

    let lpTot=0,lpDead=0,lpNull=0,lpFee=0,feeTo=null;
    if(pool.kind==='v2'){
      const lp=await rpcBatch([call(pool.pair,S.totalSupply),call(pool.pair,balOf(DEAD)),
        call(pool.pair,balOf(NULLA)),
        // The venue's own cut. A constant-product pair mints LP to the factory's
        // feeTo() on every liquidity event, so on any pool that has run for a
        // while some unburned LP belongs to the exchange, not to anybody near
        // the token. Listed as "withdrawable" without saying so, it reads as a
        // rug waiting to happen.
        pool.factory?call(pool.factory,S.feeTo):call(pool.pair,S.totalSupply)]);
      lpTot=Number(hx(lp[0]))/1e18;lpDead=Number(hx(lp[1]))/1e18;lpNull=Number(hx(lp[2]))/1e18;
      if(pool.factory){
        feeTo=addrAt(lp[3]);
        if(feeTo&&feeTo!==NULLA){
          const fb=await rpcBatch([call(pool.pair,balOf(feeTo))]);
          lpFee=Number(hx(fb[0]))/1e18;
        }else feeTo=null;
      }
    }

    // Who holds the LP and who trades it (2026-09-27): the same reads the API makes, from scanner-chain.js.
    at('reading who holds the LP and who trades it…');
    const [custody,activity]=await Promise.all([
      pool.kind==='v2'?lpCustody({pair:pool.pair,lpTot,feeTo,gp,head:tax.block}).catch(()=>null):null,
      inf?null:readActivity(token,pool.pair.toLowerCase(),tokenIs0,pool.kind,tax,pool.usd).catch(()=>null)]);
    const ages=await agesP;
    const age={pool:custody&&custody.pairCreatedAt?{createdAt:custody.pairCreatedAt,ageHours:(Date.now()-Date.parse(custody.pairCreatedAt))/3.6e6,exact:true}
      :(ages&&ages[pool.pair.toLowerCase()])||null,token:(ages&&ages[token])||null};
    const holdersP=readHolders({gp,token,tokDec,supply,burned,skip:[pool.pair,...others.map(o=>o.pair)],
      poolTok:pool.kind==='v2'?pool.tok:0,share,
      lpOwners:[...(custody?custody.holders.filter(h=>h.kind==='wallet'||h.kind==='unclassified').map(h=>h.address):[]),...(gp.creator_address?[gp.creator_address]:[])]})
      .catch(()=>({unknown:true,reason:'the balances could not be read from the chain'}));
    // Who is selling (readFlow, 2026-09-27): its log read runs beside the holder read, the same code as the API.
    const [holders,flow]=await Promise.all([holdersP,
      inf?null:readFlow({token,pair:pool.pair,kind:pool.kind,tokenIs0,activity,holders:holdersP,custody,gp,ageToken:age.token,agePool:age.pool,
        supply,burned,tokDec,quoteUsd:pool.usd,pools:others.map(o=>o.pair)}).catch(()=>null)]);
    render({gp,gpOk,sim,addr:token,pool,name,symb,px,q:pool.q,tok:pool.tok,
      quoteUsd:pool.usd,quoteSym:pool.sym,rows,up,down,upMin,downMin,tax,usedTax,
      supply,burned,lpTot,lpDead,lpNull,lpFee,feeTo,others,hop,deeper,taxB,taxS,simB,simS,partial,mineUsd,otherLiq,holders,
      custody,activity,age,flow});
    try{history.replaceState(null,'','?token='+token)}catch(e){}
    shareBar(token,symb);
    remember(token,symb);
  }catch(e){
    fail('Something went wrong reading this token.',
      (e&&e.message?e.message+'. ':'')+'Nothing here is cached, so trying again often works. If it keeps failing, the address may not be a BSC token or pool.');
  }finally{
    busy(false);
    again.hidden=false;
    // The net. If nothing was drawn and no error was shown, say so plainly
    // rather than leaving a blank page that looks like the token's fault.
    const out=$('sc-out');
    if((out.hidden||!out.children.length)&&$('sc-err').hidden)
      fail('The scan ended without a result.',
        'It stopped at “'+stage+'” without producing figures and without an error — almost always a public BSC node dropping a request mid-scan. Press Scan again; it normally works on the second try.');
  }
}

// Accept what people actually paste: a bare address, a BscScan link, a
// DexScreener link (which carries the POOL, not the token), a PancakeSwap URL.
const parseInput=s=>{const m=String(s||'').match(/0x[a-fA-F0-9]{40}/);return m?m[0].toLowerCase():null};
function submit(){
  const a=parseInput($('sc-in').value);
  if(!a)return fail('That is not a contract address.',
    'Paste a BSC token address, a pool address, or a BscScan / DexScreener link that contains one.');
  scan(a);
}
$('sc-go').addEventListener('click',submit);
$('sc-in').addEventListener('keydown',e=>{if(e.key==='Enter')submit()});

// ── Scanning a second token ────────────────────────────────────────────────
// The scanned address stays in the field on purpose, but that made the next
// scan a chore: select the whole thing, delete it, then paste. Three ways out,
// because the field is far above the fold once a result is drawn: a cross in
// the field, a button under the result, and select-on-click so a paste simply
// replaces what is there.
const again=$('sc-again'),clearBtn=$('sc-clear');
const showClear=()=>{clearBtn.hidden=!$('sc-in').value};
function startOver(scroll){
  $('sc-in').value='';showClear();
  const o=$('sc-out');o.hidden=true;o.textContent='';
  $('sc-err').hidden=true;$('sc-status').textContent='';
  const teaser=$('sc-what');if(teaser)teaser.hidden=false;
  again.hidden=true;
  // The URL still carried the old token; left alone, a reload would scan a
  // token that is no longer on the screen.
  try{history.replaceState(null,'',location.pathname)}catch(e){}
  if(scroll)$('sc-in').scrollIntoView({block:'center',behavior:'smooth'});
  $('sc-in').focus();
}
clearBtn.addEventListener('click',()=>startOver(false));
$('sc-again-btn').addEventListener('click',()=>startOver(true));
$('sc-in').addEventListener('input',showClear);
$('sc-in').addEventListener('focus',()=>{if(!again.hidden)$('sc-in').select()});
showClear();
// THE WAY IN FOR SOMEBODY WITH NO ADDRESS. Three tokens anyone on BNB Chain
// has heard of, plus whatever this visitor scanned before (kept in this
// browser only, never sent anywhere). Without this the page is a headline
// and an empty box, and the second visit starts from nothing again.
const TRY=[['CAKE','0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82'],['USD1','0x8d0d000ee44948fc98c9b98a4fa4921476f08b0d'],['BOBAI','0x245c386dcfed896f5c346107596141e5edcbffff']];
const RECENT_KEY='sc-recent';
function recent(){try{const r=JSON.parse(localStorage.getItem(RECENT_KEY)||'[]');return Array.isArray(r)?r.filter(x=>x&&/^0x[0-9a-f]{40}$/i.test(x.a)):[]}catch(e){return[]}}
function remember(addr,symb){
  try{
    const a=String(addr).toLowerCase();
    const list=[{a,s:String(symb||'').slice(0,12),t:Date.now()}].concat(recent().filter(x=>x.a!==a)).slice(0,5);
    localStorage.setItem(RECENT_KEY,JSON.stringify(list));
  }catch(e){}
  drawTry();
}
function drawTry(){
  const row=$('sc-try');if(!row)return;
  row.textContent='';
  const add=(label,addr,cls)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.title=addr;if(cls)b.className=cls;
    b.addEventListener('click',()=>{$('sc-in').value=addr;showClear();scan(addr)});row.appendChild(b)};
  const l=document.createElement('span');l.className='sc-try-l';l.textContent='Try one:';row.appendChild(l);
  for(const [s,a] of TRY)add(s,a);
  const rec=recent().filter(x=>!TRY.some(([,a])=>a===x.a));
  if(rec.length){const l2=document.createElement('span');l2.className='sc-try-l';l2.textContent='· you scanned:';row.appendChild(l2);
    for(const x of rec)add(x.s||x.a.slice(0,6)+'…'+x.a.slice(-4),x.a,'sc-try-recent')}
}
drawTry();

// ---- what is on four.meme's curve right now -------------------------------
// The list a person wants before pressing buy on a launch: the tokens traded
// on the curve in the last few minutes, with the raise, the price and what a
// $100 trade costs each way — read from four.meme's own contract, before any
// pool exists. Behind a button, not on load: it is a few dozen reads against
// the public log nodes, and a visitor who came with an address in hand should
// not pay for it. One tap on a row fills the field and scans it.
function drawFeed(){
  const box=$('sc-feed');if(!box)return;
  const btn=$('sc-feed-go');
  const body=$('sc-feed-body');
  btn.addEventListener('click',async()=>{
    btn.disabled=true;btn.textContent='Reading four.meme…';
    body.textContent='';
    try{
      const base=await rpcBatch([call(BNB_PAIR,S.reserves),call(BNB_PAIR,S.token0)]);
      const br=res2(base[0]),bIs0=addrAt(base[1])===WBNB;
      const bnbUsd=br?(bIs0?br[1]/br[0]:br[0]/br[1]):0;
      const f=await curveFeed({quoteUsd:{bnb:bnbUsd}});
      if(!f.list.length){body.appendChild(el('p','sc-feed-note','Nothing traded on the curve in the last '+f.blocks+' blocks. Try again in a minute.'));return}
      const t=el('table','sc-feed-t');
      const hd=el('tr');['Token','Raised','Price','$100 buy','$100 sell','Last trade'].forEach(h=>hd.appendChild(el('th',null,h)));
      t.appendChild(hd);
      for(const x of f.list){
        const r=el('tr');r.tabIndex=0;r.title='Scan '+x.token;r.setAttribute('role','button');r.setAttribute('aria-label','Scan '+(x.symbol||x.token)); // a row that acts is named as one (2026-10-09)
        const name=el('td');const b=el('b',null,x.symbol||short(x.token));name.appendChild(b);
        name.appendChild(el('span','sc-feed-a',short(x.token)));r.appendChild(name);
        const q=x.quoteSym||'?';
        r.appendChild(el('td',null,x.progressPct==null?'—':pc(x.progressPct,1)+' · '+(x.raised>=100?nf(x.raised):nf(x.raised,2))+' / '+nf(x.maxRaising)+' '+q));
        r.appendChild(el('td',null,x.priceUsd!=null?usd(x.priceUsd):'raising in '+q));
        r.appendChild(el('td','sc-feed-c'+(x.buyCost==null?'':costBand(x.buyCost,x.feePct)),x.buyCost==null?(x.buyNote?'more than is left':'—'):pc(x.buyCost)));
        r.appendChild(el('td','sc-feed-c'+(x.sellCost==null?'':costBand(x.sellCost,x.feePct)),x.sellCost==null?'—':pc(x.sellCost)));
        r.appendChild(el('td','sc-feed-m',(()=>{const sec=Math.round(x.blocksAgo*0.45);return x.blocksAgo<=2?'just now':sec<90?'~'+sec+' s ago':'~'+Math.round(sec/60)+' min ago'})()));
        const go=()=>{$('sc-in').value=x.token;showClear();scan(x.token);window.scrollTo({top:0,behavior:'smooth'})};
        r.addEventListener('click',go);r.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}});
        t.appendChild(r);
      }
      body.appendChild(t);
      if(matchMedia('(max-width:640px)').matches)body.appendChild(el('p','sc-feed-note','Swipe the table sideways for the sell cost and the last trade.')); // the box is narrower than the table on a phone (2026-10-09)
      body.appendChild(el('p','sc-feed-note','Read from four.meme’s contract at block '+nf(f.head)+': the last '+f.blocks+' blocks, newest first, tokens that have not graduated. Cost is four.meme’s own quote for that size, its fee included. Tap a row to scan it. Not a recommendation of anything.'));
    }catch(e){
      body.appendChild(el('p','sc-feed-note','The log nodes did not answer just now. Try again in a few seconds.'));
    }finally{btn.disabled=false;btn.textContent='Refresh'}
  });
}
drawFeed();
(function(){const raw=new URLSearchParams(location.search).get('token'),t=parseInput(raw);
  // A link that carries something that is not an address gets the same answer
  // a typed one does, instead of a page that silently shows nothing.
  if(raw&&!t){$('sc-in').value=raw;showClear();fail('That is not a contract address.','Paste a BSC token address, a pool address, or a BscScan / DexScreener link that contains one.');return}
  // Setting .value from script fires no input event, so the clear cross has
  // to be told by hand — otherwise arriving via ?token= shows an address with
  // no way to clear it, which is the one arrival that matters most.
  if(t){$('sc-in').value=t;showClear();scan(t)}})();

// Exported for scripts/dashboard-check/scanner-honeypot.mjs, which feeds this
// card GoPlus answers we could not find in the wild (no analysed honeypot in
// 370 tokens tried on 2 September) and pins what it draws for each. Nothing
// else imports it; the page runs exactly as before.
export { flagsCard, verdictCard };