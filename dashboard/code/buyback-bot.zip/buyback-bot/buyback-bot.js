// BOBAI Tax Distribution Bot
// Created autonomously by Claude Opus 4.6
//
// Runs via GitHub Actions every 10 minutes:
// 1. Checks buyback wallet for BNB from BOBAI 3% tax
// 2. Splits BNB three ways:
//    - 34% (1.0%) -> Creator wallet (revenue)
//    - 33% (1.0%) -> Buy $BOB + burn to dead address
//    - 33% (1.0%) -> Buy $BOBAI + burn to dead address (deflationary)
//
// 100% automatic, 100% transparent, 100% on-chain verifiable

const { createPublicClient, createWalletClient, http, fallback, parseAbi, formatEther, parseEther } = require('viem');
const { bsc } = require('viem/chains');
const { privateKeyToAccount } = require('viem/accounts');
const fs = require('fs');

const BOB_TOKEN = '0x51363f073b1e4920fda7aa9e9d84ba97ede1560e';
const BOBAI_TOKEN = '0x245c386dcfed896f5c346107596141e5edcbffff';
const WBNB = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
const DEAD_ADDRESS = '0x000000000000000000000000000000000000dEaD';
const CREATOR_WALLET = '0x15Ba17075ef5E0736292b030e3715d9100fe3d38';
const PANCAKE_ROUTER_V2 = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
const BOB_WBNB_PAIR = '0x3c79593e01A7f7FeD5d0735B16621e2D52A6bC58';
const BOBAI_WBNB_PAIR = '0x6eaDD4CB786898B34929444988380ed0CC6fD9A6';
const PRIZE_POOL_WALLET = '0x5E4102520A71B2AA18a1208330d4848dea4BD105';
// The liquidity agent's wallet (worker-lp): it holds the PancakeSwap V3
// CAKE/BNB position, grows it from what arrives and sends half of the fees it
// earns back here to be burned. Operator's instruction 2026-09-09.
const LP_AGENT_WALLET = '0xbFAA69233741924eD5b9d5DAA9B4Bf7B84567F0A';
const MIN_BNB = parseEther('0.001');
const GAS_RESERVE = parseEther('0.003');

// ============================================
// Phase windows (UTC). Bot auto-switches based on current time.
// ============================================
// BOB Liq Boost: 0.5% of trade -> BOB/BNB perma liq + LP burn (from creator share)
const LIQ_BOOST_START = new Date('2026-04-21T00:01:00Z').getTime();
const LIQ_BOOST_END   = new Date('2026-06-04T23:59:00Z').getTime();

// BOBAI Liq Boost: 0.5% of trade -> BOBAI/BNB perma liq + LP burn (from BOB burn share)
const BOBAI_LIQ_BOOST_START = new Date('2026-06-01T00:00:00Z').getTime();
const BOBAI_LIQ_BOOST_END   = new Date('2026-08-01T23:59:59Z').getTime();

// BOBAI Liq Boost EXTRA: +0.25% of trade -> BOBAI/BNB perma liq (from creator share)
const BOBAI_LIQ_EXTRA_START = new Date('2026-06-15T00:00:00Z').getTime();
const BOBAI_LIQ_EXTRA_END   = new Date('2026-08-01T23:59:59Z').getTime();

// WC26 Prize Pool: 0.52% of trade -> direct BNB to prize pool wallet (0.26% from creator + 0.26% from BOB burn)
const WC26_START = new Date('2026-06-11T00:01:00Z').getTime();
const WC26_END   = new Date('2026-07-19T23:59:00Z').getTime();

// BOBAI Liq Boost II: 0.8% of trade -> BOBAI/BNB perma liq + LP burn (all from the BOB burn
// share, creator untouched). Own window so the phase-1 constants above stay untouched history.
const BOBAI_LIQ_BOOST2_START = new Date('2026-08-08T00:00:00Z').getTime();
const BOBAI_LIQ_BOOST2_END   = new Date('2026-09-16T23:59:59Z').getTime();

// BOBAI Liq Boost III (operator, 2026-09-19): 0.3% of trade -> BOBAI/BNB perma liq + LP burn,
// again all from the BOB-burn share (0.8 - 0.3 = 0.5%), creator and BOBAI burn untouched.
// Runs beside the DeFi-agent share and the Giggle pot and ends with them, Nov 20 00:01 UTC
// (< like theirs, so that second is already 1/1/1). Same add path and log as I and II.
const BOBAI_LIQ_BOOST3_START = new Date('2026-09-19T18:00:00Z').getTime();
const BOBAI_LIQ_BOOST3_END   = new Date('2026-11-20T00:01:00Z').getTime();

// LP Agent share (operator, 2026-09-09: "ab jetzt gehen direkt je 10% von
// allen 1% an das lp wallet, in bnb"): 10 bps out of EACH of the three slices
// (BOBAI burn, BOB burn, creator) -> 30 bps of trade as BNB to the liquidity
// agent's wallet. Cut from the slices as they stand: during Liq Boost II the
// BOB-burn slice is 20 bps and keeps 10. Runs with the Giggle pot to Nov 20.
const LP_SHARE_START = new Date('2026-09-09T05:30:00Z').getTime();
const LP_SHARE_END   = new Date('2026-11-20T00:01:00Z').getTime();

// Giggle Academy pot ("Sunshine", announced on X 2026-07-13): from Sep 17
// another 10 bps out of each slice -> 30 bps of trade as BNB to the old
// prize-pool wallet, collected for 64 days and donated in one piece on UN
// World Children's Day through giggleacademy.com/support-us. Window ends at
// 00:01 UTC so Nov 20 is a whole day of donation, not of collection.
const GIGGLE_START = new Date('2026-09-17T00:01:00Z').getTime();
const GIGGLE_END   = new Date('2026-11-20T00:01:00Z').getTime();

function isLiqBoostActive() {
  const now = Date.now();
  return now >= LIQ_BOOST_START && now <= LIQ_BOOST_END;
}
function isBobaiLiqBoostActive() {
  const now = Date.now();
  return now >= BOBAI_LIQ_BOOST_START && now <= BOBAI_LIQ_BOOST_END;
}
function isBobaiLiqExtraActive() {
  const now = Date.now();
  return now >= BOBAI_LIQ_EXTRA_START && now <= BOBAI_LIQ_EXTRA_END;
}
function isWc26Active() {
  const now = Date.now();
  return now >= WC26_START && now <= WC26_END;
}
function isBobaiLiqBoost2Active() {
  const now = Date.now();
  return now >= BOBAI_LIQ_BOOST2_START && now <= BOBAI_LIQ_BOOST2_END;
}
function isBobaiLiqBoost3Active() {
  const now = Date.now();
  return now >= BOBAI_LIQ_BOOST3_START && now < BOBAI_LIQ_BOOST3_END;
}
function isLpShareActive() {
  const now = Date.now();
  return now >= LP_SHARE_START && now < LP_SHARE_END;
}
function isGiggleActive() {
  const now = Date.now();
  return now >= GIGGLE_START && now < GIGGLE_END;
}

// ============================================
// Tax allocation in basis points of trade (TAX_BPS = 300 means 3% total).
// Phase splits are built dynamically in main() and MUST sum to TAX_BPS.
//   Baseline (Standard): BOBAI burn 100 | BOB burn 100 | Creator 100
//   + BOB Liq Boost:     Creator -50, BOB liq +50
//   + BOBAI Liq Boost:   BOB burn -50, BOBAI liq +50
//   + BOBAI Liq Extra:   Creator -25, BOBAI liq +25
//   + WC26 Prize Pool:   Creator -26, BOB burn -26, WC26 pool +52
//   + BOBAI Liq Boost II: BOB burn -80, BOBAI liq +80
//   + BOBAI Liq Boost III: BOB burn -30, BOBAI liq +30
// Sum is verified before any on-chain action — bot aborts on mismatch.
// ============================================
const TAX_BPS = 300;

// ============================================
// Supabase REST helper (used to record WC26 TAX adds in wc_donations).
// Worldcup-bot picks pending TAX rows up at swap time and fills in amount_bobai.
// ============================================
async function sbInsert(table, row) {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) { console.log('[sb] missing credentials — skipping insert'); return; }
  try {
    const res = await fetch(`${url}/rest/v1/${table}`, {
      method: 'POST',
      headers: {
        apikey: key,
        Authorization: `Bearer ${key}`,
        'Content-Type': 'application/json',
        Prefer: 'return=minimal,resolution=ignore-duplicates',
      },
      body: JSON.stringify(row),
    });
    if (!res.ok) console.log(`[sb] insert ${table} failed: ${res.status} ${await res.text()}`);
  } catch (e) { console.log(`[sb] insert error: ${e.message}`); }
}

const WBNB_ABI = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function withdraw(uint256 wad)',
]);

const ROUTER_ABI = parseAbi([
  'function swapExactETHForTokensSupportingFeeOnTransferTokens(uint amountOutMin, address[] path, address to, uint deadline) payable',
  'function getAmountsOut(uint amountIn, address[] path) view returns (uint[] amounts)',
  'function addLiquidityETH(address token, uint amountTokenDesired, uint amountTokenMin, uint amountETHMin, address to, uint deadline) payable returns (uint amountToken, uint amountETH, uint liquidity)',
]);

const PAIR_ABI = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function getReserves() view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast)',
  'function token0() view returns (address)',
  'function transfer(address to, uint256 amount) returns (bool)',
]);

const ERC20_ABI = parseAbi([
  'function balanceOf(address) view returns (uint256)',
  'function transfer(address to, uint256 amount) returns (bool)',
]);

// WHAT A SENT TRANSACTION CAME TO (2026-09-18). Two things were taken on
// trust. A receipt wait that threw — a slow node, a timeout — was read as "the
// leg failed" although the transaction was out: the creator's share could
// arrive while the run stopped, and the next run split the remainder again,
// creator included. And a receipt was never looked at: a reverted swap or burn
// went on as if it had happened, a reverted burn into the log as burned. Now a
// transaction that was sent is asked about again before it is given up, and
// only status 'success' counts. Nothing is remembered between runs — the bot
// stays as stateless as it was.
// ONE NODE WAS THE WHOLE BOT (2026-09-18). Every read and every send went to
// one RPC. With that node down the bot does nothing, which is harmless — the
// tax waits and the next run splits it correctly. With that node FLAKY in the
// middle of a run, some legs go out and others do not, and the BNB of the ones
// that did not is split over all the shares again by the next run. The public
// BNB Chain nodes stand behind the first one now, asked only when it fails, in
// this order (rank:false — no racing, no reordering). A signed transaction
// sent twice is the same transaction: same nonce, same hash. `fallbacks:
// 'none'` is for a fork, where nothing may reach a real node.
const FALLBACK_RPCS = ['https://bsc-dataseed.binance.org/', 'https://bsc-dataseed1.bnbchain.org', 'https://bsc-dataseed2.bnbchain.org'];
function rpcTransport(primary, fallbacks) {
  const urls = [primary, ...(fallbacks === 'none' ? [] : FALLBACK_RPCS)].filter((u, i, all) => u && all.indexOf(u) === i);
  return urls.length > 1 ? fallback(urls.map((u) => http(u)), { rank: false }) : http(urls[0]);
}

async function waitMined(publicClient, hash) {
  try {
    return await publicClient.waitForTransactionReceipt({ hash });
  } catch (e) {
    console.log(`  receipt wait for ${hash} failed (${say(e)}) — asking again`);
  }
  for (let i = 0; i < 6; i++) {
    await sleep(5000);
    try {
      const rc = await publicClient.getTransactionReceipt({ hash });
      if (rc) return rc;
    } catch (e) { /* not there yet */ }
  }
  return null;
}
// Throws unless the transaction is in a block AND succeeded; the callers' own catch blocks do the rest.
async function mined(publicClient, hash, what) {
  const rc = await waitMined(publicClient, hash);
  if (!rc) throw new Error(`${what}: no receipt for ${hash} — it may still arrive`);
  if (rc.status !== 'success') throw new Error(`${what}: ${hash} reverted`);
  return rc;
}
// An error as it is logged: viem puts the RPC's URL into its messages, and the URL carries the key.
function say(e) {
  return String((e && e.message) || e).replace(/https?:[/][/][^ )"']+/g, '[rpc]');
}

// THE LEAST A BUY MAY BRING (2026-09-18). $BOBAI keeps 3% of every transfer,
// so of the quoted output the wallet receives 97% (measured on the bot's own
// swaps: 3,606 of 120,214 withheld). The router checks what ARRIVES against
// this minimum; 95% of the gross quote therefore left 2.06% of room, not the
// 5% the line says, and a price that moved more between quote and block
// reverted the leg — whose BNB the next run then split over all the shares
// again. The tax comes off first, then the 5%. $BOB has no transfer tax.
const TRANSFER_TAX_BPS = { [BOBAI_TOKEN.toLowerCase()]: 300n };
function minOutFor(quotedOut, tokenAddress) {
  const tax = TRANSFER_TAX_BPS[String(tokenAddress).toLowerCase()] || 0n;
  return (((quotedOut * (10000n - tax)) / 10000n) * 95n) / 100n;
}

async function swapAndBurn(walletClient, publicClient, account, bnbAmount, tokenAddress, tokenName) {
  const path = [WBNB, tokenAddress];

  let amountsOut;
  try {
    amountsOut = await publicClient.readContract({
      address: PANCAKE_ROUTER_V2,
      abi: ROUTER_ABI,
      functionName: 'getAmountsOut',
      args: [bnbAmount, path],
    });
    console.log(`  Expected ${tokenName} output: ${formatEther(amountsOut[1])}`);
  } catch (e) {
    console.log(`  Quote failed for ${tokenName}: ${say(e)}`);
    return null;
  }

  const minOut = minOutFor(amountsOut[1], tokenAddress);
  const deadline = BigInt(Math.floor(Date.now() / 1000) + 600);

  // Swap BNB -> token
  let txHash;
  try {
    txHash = await walletClient.writeContract({
      address: PANCAKE_ROUTER_V2,
      abi: ROUTER_ABI,
      functionName: 'swapExactETHForTokensSupportingFeeOnTransferTokens',
      args: [minOut, path, account.address, deadline],
      value: bnbAmount,
      gas: 300000n,
    });
    console.log(`  Swap TX: https://bscscan.com/tx/${txHash}`);
    await mined(publicClient, txHash, 'swap');
  } catch (e) {
    console.log(`  Swap failed for ${tokenName}: ${say(e)}`);
    return null;
  }

  // Check token balance
  const tokenBalance = await publicClient.readContract({
    address: tokenAddress,
    abi: ERC20_ABI,
    functionName: 'balanceOf',
    args: [account.address],
  });

  if (tokenBalance === 0n) {
    console.log(`  No ${tokenName} to burn.`);
    return null;
  }

  // Burn to dead address
  let burnHash;
  try {
    burnHash = await walletClient.writeContract({
      address: tokenAddress,
      abi: ERC20_ABI,
      functionName: 'transfer',
      args: [DEAD_ADDRESS, tokenBalance],
      gas: 500000n,
    });
    console.log(`  Burn TX: https://bscscan.com/tx/${burnHash}`);
    const receipt = await mined(publicClient, burnHash, 'burn');
    console.log(`  Burned ${formatEther(tokenBalance)} ${tokenName} in block ${receipt.blockNumber}`);
    return { txHash, burnHash, amount: formatEther(tokenBalance), block: Number(receipt.blockNumber) };
  } catch (e) {
    console.log(`  Burn failed for ${tokenName}: ${say(e)}`);
    return null;
  }
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// THE LIQUIDITY ADD, BEFORE ITS NEXT BOOST (2026-09-19). The path rests between
// boosts and had four things the swap-and-burn above had already lost:
// its chunk minimum was 95% of the GROSS quote (2.06% of real room on $BOBAI,
// which keeps 3% of every transfer) — minOutFor now; no receipt was looked at
// (a reverted add went on to 'Liquidity added!') — mined() now, and an error is
// said without its RPC URL; the router was approved for TWICE what it takes —
// exactly the balance now; and addLiquidityETH went out with both minimums 0,
// so whoever moved the price between the last chunk and the add set the ratio
// the LP was minted at. liqMins works out what the router will use from the
// reserves read just before, the way the router does, and allows 5% below it.
// The minimums are checked against the amounts BEFORE the token's transfer tax
// (the pair receives 97% of the $BOBAI; the router does not look at that).
function liqMins(tokenAmount, bnbAmount, reserveToken, reserveBnb) {
  if (reserveToken <= 0n || reserveBnb <= 0n) return null;
  const bnbOptimal = (tokenAmount * reserveBnb) / reserveToken;
  const used = bnbOptimal <= bnbAmount
    ? { token: tokenAmount, bnb: bnbOptimal }
    : { token: (bnbAmount * reserveToken) / reserveBnb, bnb: bnbAmount };
  return { tokenUsed: used.token, bnbUsed: used.bnb, tokenMin: (used.token * 95n) / 100n, bnbMin: (used.bnb * 95n) / 100n };
}

async function addLiquidityAndBurn(walletClient, publicClient, account, bnbAmount, tokenAddress, pairAddress, tokenName) {
  const SWAP_CHUNKS = 3;
  const halfBnb = bnbAmount / 2n;
  const liqBnb = bnbAmount - halfBnb;

  // Step 1: Buy token with half the BNB — chunked for MEV protection
  console.log(`  Buying ${tokenName} with ${formatEther(halfBnb)} BNB in ${SWAP_CHUNKS} chunks...`);
  const path = [WBNB, tokenAddress];
  const chunkSize = halfBnb / BigInt(SWAP_CHUNKS);

  for (let i = 0; i < SWAP_CHUNKS; i++) {
    const thisChunk = (i === SWAP_CHUNKS - 1) ? (halfBnb - chunkSize * BigInt(SWAP_CHUNKS - 1)) : chunkSize;
    console.log(`  Chunk ${i + 1}/${SWAP_CHUNKS}: ${formatEther(thisChunk)} BNB`);

    let amountsOut;
    try {
      amountsOut = await publicClient.readContract({
        address: PANCAKE_ROUTER_V2,
        abi: ROUTER_ABI,
        functionName: 'getAmountsOut',
        args: [thisChunk, path],
      });
      console.log(`    Expected ${tokenName}: ${formatEther(amountsOut[1])}`);
    } catch (e) {
      console.log(`    Quote failed: ${say(e)}`);
      return null;
    }

    const minOut = minOutFor(amountsOut[1], tokenAddress);
    const deadline = BigInt(Math.floor(Date.now() / 1000) + 300);

    try {
      const swapTx = await walletClient.writeContract({
        address: PANCAKE_ROUTER_V2,
        abi: ROUTER_ABI,
        functionName: 'swapExactETHForTokensSupportingFeeOnTransferTokens',
        args: [minOut, path, account.address, deadline],
        value: thisChunk,
        gas: 300000n,
      });
      console.log(`    Swap TX: https://bscscan.com/tx/${swapTx}`);
      await mined(publicClient, swapTx, `${tokenName} liquidity swap ${i + 1}`);
    } catch (e) {
      console.log(`    Swap chunk ${i + 1} failed: ${say(e)}`);
      return null;
    }

    if (i < SWAP_CHUNKS - 1) {
      console.log('    Waiting 5s for next chunk...');
      await sleep(5000);
    }
  }

  // Step 2: Check token balance
  const tokenBalance = await publicClient.readContract({
    address: tokenAddress,
    abi: ERC20_ABI,
    functionName: 'balanceOf',
    args: [account.address],
  });

  if (tokenBalance === 0n) {
    console.log(`  No ${tokenName} received.`);
    return null;
  }
  console.log(`  ${tokenName} received: ${formatEther(tokenBalance)}`);

  // Step 3: Approve the Router for what it will take, not more
  try {
    const approveTx = await walletClient.writeContract({
      address: tokenAddress,
      abi: parseAbi(['function approve(address spender, uint256 amount) returns (bool)']),
      functionName: 'approve',
      args: [PANCAKE_ROUTER_V2, tokenBalance],
      gas: 100000n,
    });
    await mined(publicClient, approveTx, `${tokenName} approve`);
    console.log(`  ${tokenName} approved for Router`);
  } catch (e) {
    console.log(`  Approve failed: ${say(e)}`);
    return null;
  }

  // Step 4: Add Liquidity ETH — LP to own wallet first, minimums from the reserves as they stand
  let mins;
  try {
    const [reserves, token0] = await Promise.all([
      publicClient.readContract({ address: pairAddress, abi: PAIR_ABI, functionName: 'getReserves' }),
      publicClient.readContract({ address: pairAddress, abi: PAIR_ABI, functionName: 'token0' }),
    ]);
    const tokenIs0 = token0.toLowerCase() === tokenAddress.toLowerCase();
    mins = liqMins(tokenBalance, liqBnb, tokenIs0 ? reserves[0] : reserves[1], tokenIs0 ? reserves[1] : reserves[0]);
  } catch (e) {
    console.log(`  Reserves not read: ${say(e)}`);
    return null;
  }
  if (!mins) {
    console.log('  The pair has no reserves — no add.');
    return null;
  }
  console.log(`  Router will use ${formatEther(mins.tokenUsed)} ${tokenName} + ${formatEther(mins.bnbUsed)} BNB (minimums 95%)`);

  const addDeadline = BigInt(Math.floor(Date.now() / 1000) + 300);
  let addLiqTxHash;
  try {
    addLiqTxHash = await walletClient.writeContract({
      address: PANCAKE_ROUTER_V2,
      abi: ROUTER_ABI,
      functionName: 'addLiquidityETH',
      args: [tokenAddress, tokenBalance, mins.tokenMin, mins.bnbMin, account.address, addDeadline],
      value: liqBnb,
      gas: 500000n,
    });
    console.log(`  Add Liq TX: https://bscscan.com/tx/${addLiqTxHash}`);
    await mined(publicClient, addLiqTxHash, `${tokenName} liquidity add`);
    console.log('  Liquidity added!');
  } catch (e) {
    console.log(`  Add liquidity failed: ${say(e)}`);
    return null;
  }

  // Step 5: Burn LP tokens — transfer to dead address
  const lpBalance = await publicClient.readContract({
    address: pairAddress,
    abi: PAIR_ABI,
    functionName: 'balanceOf',
    args: [account.address],
  });

  if (lpBalance === 0n) {
    console.log('  [WARN] No LP tokens on wallet!');
    return null;
  }

  let lpBurnTxHash;
  try {
    lpBurnTxHash = await walletClient.writeContract({
      address: pairAddress,
      abi: PAIR_ABI,
      functionName: 'transfer',
      args: [DEAD_ADDRESS, lpBalance],
      gas: 100000n,
    });
    console.log(`  LP Burn TX: https://bscscan.com/tx/${lpBurnTxHash}`);
    await mined(publicClient, lpBurnTxHash, `${tokenName} LP burn`);
    console.log(`  BURNED ${formatEther(lpBalance)} LP tokens to dead address`);
  } catch (e) {
    console.log(`  LP burn failed: ${say(e)}`);
    return null;
  }

  return {
    bnb: formatEther(bnbAmount),
    tokensBought: formatEther(tokenBalance),
    lpBurned: formatEther(lpBalance),
    addLiqTx: addLiqTxHash,
    lpBurnTx: lpBurnTxHash,
  };
}

// THE WORKER RUNS — THEN THIS DOES NOT (2026-09-18). This script is the
// fallback for a day Cloudflare is down, and nothing kept it from running
// beside the worker: two processes reading one balance, both splitting it, one
// of them logging to a local file the page never sees. The worker writes a
// heartbeat every ten minutes; while that heartbeat is fresh the worker is
// alive and this script refuses. No answer from the heartbeat (Cloudflare down
// — the day this script is for) lets it run; `--force` overrides. Pure + one fetch.
const WORKER_HEALTH_URL = 'https://logs.brainonbnb.com/health';
function heartbeatIsFresh(health, now = Date.now()) {
  const t = Date.parse(health && health.buyback);
  return Number.isFinite(t) && now - t < 15 * 60 * 1000 && now - t > -60 * 1000;
}
async function workerHeartbeat() {
  try {
    const r = await fetch(WORKER_HEALTH_URL, { signal: AbortSignal.timeout(10000) });
    return r.ok ? await r.json() : null;
  } catch (e) { return null; }
}

async function main() {
  if (!process.argv.includes('--force')) {
    const health = await workerHeartbeat();
    if (heartbeatIsFresh(health)) {
      console.error('[REFUSED] The Cloudflare worker is alive (heartbeat ' + health.buyback + ') and splits this wallet every ten minutes.');
      console.error('  This script is the fallback for a day it is down. Nothing was read, nothing was sent. (--force overrides.)');
      process.exitCode = 1;   // not process.exit(): on Windows it trips a libuv assertion while the fetch handle closes
      return;
    }
  }
  // THE BUYBACK WALLET'S KEY, AND NO OTHER (2026-09-18). This read PRIVATE_KEY
  // first — a leftover from GitHub Actions, where that name held the buyback
  // secret. In the local .env both names are set and PRIVATE_KEY is the
  // CREATOR wallet's: `npm run buyback`, the documented fallback for a day
  // Cloudflare is down, would have left the tax untouched and split the
  // creator wallet instead — more than half of it bought and burned, for good.
  // The buyback name wins, and whatever key is found has to open the buyback
  // wallet or nothing runs.
  const BUYBACK_WALLET = '0xdeFC0e900Dfc83e207902cF22265Ae63f94c01ce';
  const privateKey = process.env.BUYBACK_PRIVATE_KEY || process.env.PRIVATE_KEY;
  if (!privateKey) {
    console.log('[ERROR] No BUYBACK_PRIVATE_KEY (or PRIVATE_KEY) set');
    process.exit(1);
  }

  const rpcUrl = process.env.BSC_RPC_URL || 'https://bsc-dataseed.binance.org/';
  const account = privateKeyToAccount(privateKey);
  if (account.address.toLowerCase() !== BUYBACK_WALLET.toLowerCase()) {
    console.error('[ERROR] The key does not open the buyback wallet — nothing was sent.');
    console.error(`  Expected: ${BUYBACK_WALLET}`);
    console.error(`  Got:      ${account.address}`);
    console.error('  Set BUYBACK_PRIVATE_KEY to the buyback wallet\'s key.');
    process.exit(1);
  }

  // Detect active phases (date-based, UTC, auto-switching)
  const bobLiqBoost   = isLiqBoostActive();
  const bobaiLiqBoost = isBobaiLiqBoostActive();
  const bobaiLiqExtra = isBobaiLiqExtraActive();
  const wc26Active    = isWc26Active();
  const bobaiLiqBoost2 = isBobaiLiqBoost2Active();
  const bobaiLiqBoost3 = isBobaiLiqBoost3Active();
  const lpShare       = isLpShareActive();
  const giggle        = isGiggleActive();

  // Build per-phase BPS allocation from baseline (1/1/1)
  let bobaiBurnBps = 100;
  let bobBurnBps   = 100;
  let creatorBps   = 100;
  let bobLiqBps    = 0;
  let bobaiLiqBps  = 0;
  let wc26PoolBps  = 0;
  let lpAgentBps   = 0;
  let giggleBps    = 0;

  if (bobLiqBoost)   { creatorBps -= 50; bobLiqBps   += 50; }
  if (bobaiLiqBoost) { bobBurnBps -= 50; bobaiLiqBps += 50; }
  if (bobaiLiqExtra) { creatorBps -= 25; bobaiLiqBps += 25; }
  if (wc26Active)    { creatorBps -= 26; bobBurnBps  -= 26; wc26PoolBps += 52; }
  if (bobaiLiqBoost2){ bobBurnBps -= 80; bobaiLiqBps += 80; }
  if (bobaiLiqBoost3){ bobBurnBps -= 30; bobaiLiqBps += 30; }
  // Ten from each of the three, after the programs above have had their cut.
  if (lpShare)       { bobaiBurnBps -= 10; bobBurnBps -= 10; creatorBps -= 10; lpAgentBps += 30; }
  if (giggle)        { bobaiBurnBps -= 10; bobBurnBps -= 10; creatorBps -= 10; giggleBps  += 30; }

  const bpsSum = bobaiBurnBps + bobBurnBps + creatorBps + bobLiqBps + bobaiLiqBps + wc26PoolBps + lpAgentBps + giggleBps;

  console.log('============================================');
  console.log(`[${new Date().toISOString()}] BOBAI Tax Distribution Bot`);
  console.log(`Wallet: ${account.address}`);
  const phases = [];
  if (bobLiqBoost)   phases.push('BOB Liq Boost');
  if (bobaiLiqBoost) phases.push('BOBAI Liq Boost');
  if (bobaiLiqExtra) phases.push('BOBAI Liq Extra (+0.25%)');
  if (wc26Active)    phases.push('WC26 Prize Pool');
  if (bobaiLiqBoost2) phases.push('BOBAI Liq Boost II (0.8%)');
  if (bobaiLiqBoost3) phases.push('BOBAI Liq Boost III (0.3%)');
  if (lpShare)       phases.push('LP Agent share (0.3%)');
  if (giggle)        phases.push('Giggle Academy pot (0.3%)');
  console.log(`Active phases: ${phases.length ? phases.join(' + ') : 'Standard 1/1/1'}`);
  console.log(`Split (bps of trade, total=${bpsSum}):`);
  console.log(`  BOBAI burn ${bobaiBurnBps}  |  BOB burn ${bobBurnBps}  |  Creator ${creatorBps}`);
  if (bobLiqBps)   console.log(`  BOB liq    ${bobLiqBps}`);
  if (bobaiLiqBps) console.log(`  BOBAI liq  ${bobaiLiqBps}`);
  if (wc26PoolBps) console.log(`  WC26 pool  ${wc26PoolBps}`);
  if (lpAgentBps)  console.log(`  LP agent   ${lpAgentBps}`);
  if (giggleBps)   console.log(`  Giggle pot ${giggleBps}`);
  console.log('============================================');

  // SAFETY: refuse to act if shares don't sum to TAX_BPS.
  if (bpsSum !== TAX_BPS) {
    console.log(`[ABORT] BPS sum ${bpsSum} != ${TAX_BPS}. Config error — no TX sent.`);
    return;
  }
  if ([bobaiBurnBps, bobBurnBps, creatorBps, bobLiqBps, bobaiLiqBps, wc26PoolBps, lpAgentBps, giggleBps].some((b) => b < 0)) {
    console.log('[ABORT] a slice went negative — the programs cut more than there is. No TX sent.');
    return;
  }

  const publicClient = createPublicClient({
    chain: bsc,
    transport: rpcTransport(rpcUrl, process.env.BSC_RPC_FALLBACKS),
  });

  const walletClient = createWalletClient({
    account,
    chain: bsc,
    transport: rpcTransport(rpcUrl, process.env.BSC_RPC_FALLBACKS),
  });

  // Step 0: Unwrap any WBNB to native BNB
  const wbnbBalance = await publicClient.readContract({
    address: WBNB,
    abi: WBNB_ABI,
    functionName: 'balanceOf',
    args: [account.address],
  });
  if (wbnbBalance > 0n) {
    console.log(`Found ${formatEther(wbnbBalance)} WBNB — unwrapping to native BNB...`);
    try {
      const unwrapHash = await walletClient.writeContract({
        address: WBNB,
        abi: WBNB_ABI,
        functionName: 'withdraw',
        args: [wbnbBalance],
        gas: 50000n,
      });
      console.log(`  Unwrap TX: https://bscscan.com/tx/${unwrapHash}`);
      await mined(publicClient, unwrapHash, 'unwrap');
      console.log(`  Unwrapped ${formatEther(wbnbBalance)} WBNB → BNB`);
    } catch (e) {
      console.log(`  Unwrap failed: ${say(e)}`);
    }
  }

  // Step 1: Check BNB balance
  const balance = await publicClient.getBalance({ address: account.address });
  console.log(`BNB Balance: ${formatEther(balance)} BNB`);

  if (balance <= GAS_RESERVE + MIN_BNB) {
    console.log('Balance too low. Waiting for more tax fees...');
    return;
  }

  const available = balance - GAS_RESERVE;
  console.log(`Available for distribution: ${formatEther(available)} BNB\n`);

  // Step 2: Compute BNB amounts per bucket.
  // BOBAI burn = residual so all wei are accounted for (no dust left on wallet).
  const creatorAmount     = (available * BigInt(creatorBps))   / BigInt(TAX_BPS);
  const bobBurnAmount     = (available * BigInt(bobBurnBps))   / BigInt(TAX_BPS);
  const bobLiqAddAmount   = (available * BigInt(bobLiqBps))    / BigInt(TAX_BPS);
  const bobaiLiqAddAmount = (available * BigInt(bobaiLiqBps))  / BigInt(TAX_BPS);
  const wc26PoolAmount    = (available * BigInt(wc26PoolBps))  / BigInt(TAX_BPS);
  const lpAgentAmount     = (available * BigInt(lpAgentBps))   / BigInt(TAX_BPS);
  const giggleAmount      = (available * BigInt(giggleBps))    / BigInt(TAX_BPS);
  const bobaiBurnAmount   = available - creatorAmount - bobBurnAmount
                                      - bobLiqAddAmount - bobaiLiqAddAmount - wc26PoolAmount
                                      - lpAgentAmount - giggleAmount;

  console.log(`Creator:     ${formatEther(creatorAmount)} BNB (${creatorBps} bps)`);
  console.log(`BOB burn:    ${formatEther(bobBurnAmount)} BNB (${bobBurnBps} bps)`);
  console.log(`BOBAI burn:  ${formatEther(bobaiBurnAmount)} BNB (${bobaiBurnBps} bps + dust residual)`);
  if (bobLiqBps)   console.log(`BOB liq:     ${formatEther(bobLiqAddAmount)} BNB (${bobLiqBps} bps)`);
  if (bobaiLiqBps) console.log(`BOBAI liq:   ${formatEther(bobaiLiqAddAmount)} BNB (${bobaiLiqBps} bps)`);
  if (wc26PoolBps) console.log(`WC26 pool:   ${formatEther(wc26PoolAmount)} BNB (${wc26PoolBps} bps)`);
  if (lpAgentBps)  console.log(`LP agent:    ${formatEther(lpAgentAmount)} BNB (${lpAgentBps} bps)`);
  if (giggleBps)   console.log(`Giggle pot:  ${formatEther(giggleAmount)} BNB (${giggleBps} bps)`);

  // Step 3: Send creator share
  console.log(`\n--- Sending ${formatEther(creatorAmount)} BNB to Creator ---`);
  let creatorTxHash;
  try {
    creatorTxHash = await walletClient.sendTransaction({
      to: CREATOR_WALLET,
      value: creatorAmount,
    });
    console.log(`  TX: https://bscscan.com/tx/${creatorTxHash}`);
    await mined(publicClient, creatorTxHash, 'creator share');
    console.log('  Creator payment sent!');
  } catch (e) {
    console.log(`  Creator payment failed: ${say(e)}`);
    return;
  }

  // Step 3b: BOB Liq Add (only during BOB Liq Boost window)
  // Run BEFORE WC26 send so the pool is deeper when worldcup-bot swaps the
  // prize-pool BNB → BOBAI in the same minute (less slippage on that swap).
  let bobLiqResult = null;
  const MIN_LIQ = parseEther('0.0003');
  if (bobLiqAddAmount > MIN_LIQ) {
    console.log(`\n--- Adding BOB/BNB Liquidity (${formatEther(bobLiqAddAmount)} BNB) → LP to Dead ---`);
    bobLiqResult = await addLiquidityAndBurn(walletClient, publicClient, account, bobLiqAddAmount, BOB_TOKEN, BOB_WBNB_PAIR, 'BOB');
    if (bobLiqResult) {
      console.log('  BOB Liq Add SUCCESS!');
    } else {
      console.log('  BOB Liq Add FAILED — BNB stays on wallet for next run.');
    }
  }

  // Step 3c: BOBAI Liq Add (only during BOBAI Liq Boost window)
  let bobaiLiqResult = null;
  if (bobaiLiqAddAmount > MIN_LIQ) {
    console.log(`\n--- Adding BOBAI/BNB Liquidity (${formatEther(bobaiLiqAddAmount)} BNB) → LP to Dead ---`);
    bobaiLiqResult = await addLiquidityAndBurn(walletClient, publicClient, account, bobaiLiqAddAmount, BOBAI_TOKEN, BOBAI_WBNB_PAIR, 'BOBAI');
    if (bobaiLiqResult) {
      console.log('  BOBAI Liq Add SUCCESS!');
    } else {
      console.log('  BOBAI Liq Add FAILED — BNB stays on wallet for next run.');
    }
  }

  // Step 4: Buy & burn $BOB
  console.log(`\n--- Buying & Burning $BOB (${formatEther(bobBurnAmount)} BNB) ---`);
  const bobResult = await swapAndBurn(walletClient, publicClient, account, bobBurnAmount, BOB_TOKEN, 'BOB');

  // Step 5: Buy & burn $BOBAI
  console.log(`\n--- Buying & Burning $BOBAI (${formatEther(bobaiBurnAmount)} BNB) ---`);
  const bobaiResult = await swapAndBurn(walletClient, publicClient, account, bobaiBurnAmount, BOBAI_TOKEN, 'BOBAI');

  // Step 5a: the LP agent's share and the Giggle pot, plain BNB transfers.
  // A failed send is logged and the BNB stays on the wallet for the next
  // run, as with the WC26 send below; nothing is retried blind.
  let lpAgentTxHash = null;
  if (lpAgentAmount > 0n) {
    console.log(`\n--- Sending ${formatEther(lpAgentAmount)} BNB to the LP agent ---`);
    try {
      lpAgentTxHash = await walletClient.sendTransaction({ to: LP_AGENT_WALLET, value: lpAgentAmount });
      console.log(`  TX: https://bscscan.com/tx/${lpAgentTxHash}`);
      await mined(publicClient, lpAgentTxHash, 'LP agent share');
      console.log('  LP agent share sent!');
    } catch (e) {
      console.log(`  LP agent send failed: ${say(e)}`);
      lpAgentTxHash = null;
    }
  }
  let giggleTxHash = null;
  if (giggleAmount > 0n) {
    console.log(`\n--- Sending ${formatEther(giggleAmount)} BNB to the Giggle Academy pot ---`);
    try {
      giggleTxHash = await walletClient.sendTransaction({ to: PRIZE_POOL_WALLET, value: giggleAmount });
      console.log(`  TX: https://bscscan.com/tx/${giggleTxHash}`);
      await mined(publicClient, giggleTxHash, 'Giggle pot');
      console.log('  Giggle pot funded!');
    } catch (e) {
      console.log(`  Giggle pot send failed: ${say(e)}`);
      giggleTxHash = null;
    }
  }

  // Step 5b: Send WC26 Prize Pool share LAST (only during WC26 window).
  // Runs after all burns/liq-adds so worldcup-bot picks up the BNB into a pool
  // that's already been deepened (Liq-Add) and bought into (burn swaps) — and
  // so this send is the final on-chain action of the cycle, cleanly separating
  // protocol burns from the WC26 routing.
  let wc26TxHash = null;
  if (wc26PoolAmount > 0n) {
    console.log(`\n--- Sending ${formatEther(wc26PoolAmount)} BNB to WC26 Prize Pool ---`);
    try {
      wc26TxHash = await walletClient.sendTransaction({
        to: PRIZE_POOL_WALLET,
        value: wc26PoolAmount,
      });
      console.log(`  TX: https://bscscan.com/tx/${wc26TxHash}`);
      await mined(publicClient, wc26TxHash, 'WC26 pool');
      console.log('  WC26 pool funded!');
      // Track this TAX add in wc_donations. amount_bobai stays null —
      // worldcup-bot fills it in (proportional) when it swaps the pool's BNB.
      await sbInsert('wc_donations', {
        from_address: account.address.toLowerCase(),
        token: 'TAX',
        amount_in: formatEther(wc26PoolAmount),
        amount_bobai: null,
        tx_hash: wc26TxHash,
        swap_tx_hash: null,
      });
    } catch (e) {
      console.log(`  WC26 pool send failed: ${say(e)}`);
      wc26TxHash = null;
    }
  }

  // Step 6: Log to burns.json
  try {
    let burns = [];
    if (fs.existsSync('burns.json')) {
      burns = JSON.parse(fs.readFileSync('burns.json', 'utf8'));
    }
    const entry = {
      time: new Date().toISOString(),
      totalBnb: formatEther(available),
      creatorBnb: formatEther(creatorAmount),
      creatorTx: creatorTxHash,
    };
    if (bobResult) {
      entry.bobBurnBnb = formatEther(bobBurnAmount);
      entry.bobBurned = bobResult.amount;
      entry.bobSwapTx = bobResult.txHash;
      entry.bobBurnTx = bobResult.burnHash;
      entry.bobBlock = bobResult.block;
    }
    if (bobaiResult) {
      entry.bobaiBurnBnb = formatEther(bobaiBurnAmount);
      entry.bobaiBurned = bobaiResult.amount;
      entry.bobaiSwapTx = bobaiResult.txHash;
      entry.bobaiBurnTx = bobaiResult.burnHash;
      entry.bobaiBlock = bobaiResult.block;
    }
    if (lpAgentTxHash) { entry.lpAgentBnb = formatEther(lpAgentAmount); entry.lpAgentTx = lpAgentTxHash; }
    if (giggleTxHash)  { entry.giggleBnb  = formatEther(giggleAmount);  entry.giggleTx  = giggleTxHash; }
    burns.push(entry);
    fs.writeFileSync('burns.json', JSON.stringify(burns, null, 2));
    console.log('\nBurn logged to burns.json');
  } catch (e) {
    console.log('Failed to log burns:', e.message);
  }

  // Step 7: Log BOB liq boost (existing file, unchanged shape)
  if (bobLiqResult) {
    try {
      let liqLog = [];
      if (fs.existsSync('liq-boost-log.json')) {
        liqLog = JSON.parse(fs.readFileSync('liq-boost-log.json', 'utf8'));
      }
      liqLog.push({
        time: new Date().toISOString(),
        bnb: bobLiqResult.bnb,
        bobBought: bobLiqResult.tokensBought,
        lpBurned: bobLiqResult.lpBurned,
        addLiqTx: bobLiqResult.addLiqTx,
        lpBurnTx: bobLiqResult.lpBurnTx,
      });
      fs.writeFileSync('liq-boost-log.json', JSON.stringify(liqLog, null, 2));
      console.log('BOB liq boost logged to liq-boost-log.json');
    } catch (e) {
      console.log('Failed to log BOB liq boost:', e.message);
    }
  }

  // Step 8: Log BOBAI liq boost (new file, same shape)
  if (bobaiLiqResult) {
    try {
      let liqLog = [];
      if (fs.existsSync('bobai-liq-log.json')) {
        liqLog = JSON.parse(fs.readFileSync('bobai-liq-log.json', 'utf8'));
      }
      liqLog.push({
        time: new Date().toISOString(),
        bnb: bobaiLiqResult.bnb,
        bobaiBought: bobaiLiqResult.tokensBought,
        lpBurned: bobaiLiqResult.lpBurned,
        addLiqTx: bobaiLiqResult.addLiqTx,
        lpBurnTx: bobaiLiqResult.lpBurnTx,
      });
      fs.writeFileSync('bobai-liq-log.json', JSON.stringify(liqLog, null, 2));
      console.log('BOBAI liq boost logged to bobai-liq-log.json');
    } catch (e) {
      console.log('Failed to log BOBAI liq boost:', e.message);
    }
  }

  console.log('\n============================================');
  console.log(`[${new Date().toISOString()}] DISTRIBUTION COMPLETE`);
  console.log(`Creator:    ${formatEther(creatorAmount)} BNB`);
  if (wc26TxHash)     console.log(`WC26 pool:  ${formatEther(wc26PoolAmount)} BNB`);
  if (lpAgentTxHash)  console.log(`LP agent:   ${formatEther(lpAgentAmount)} BNB`);
  if (giggleTxHash)   console.log(`Giggle pot: ${formatEther(giggleAmount)} BNB`);
  if (bobLiqResult)   console.log(`BOB liq:    ${bobLiqResult.bnb} BNB → BOB/BNB LP burned`);
  if (bobaiLiqResult) console.log(`BOBAI liq:  ${bobaiLiqResult.bnb} BNB → BOBAI/BNB LP burned`);
  if (bobResult)      console.log(`BOB burned:   ${bobResult.amount}`);
  if (bobaiResult)    console.log(`BOBAI burned: ${bobaiResult.amount}`);
  console.log('============================================');
}

main().catch(console.error);