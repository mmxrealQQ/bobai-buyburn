# Liquidity Add & LP Burn

Adds liquidity, then burns the LP token it just received.

Takes BNB and tokens, adds them to the PancakeSwap V2 pair and sends the LP tokens straight to the dead address, so the liquidity can never be pulled again — not by us either. Handles the fee-on-transfer case, which is where most naive add-liquidity scripts revert. Includes the creator-share burn script.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A wallet holding both sides of the pair**
    ours: BNB and the token, in one wallet
    also: any PancakeSwap V2 pair, and any BSC DEX sharing that router interface — the router is one constant
- **A machine that can run Node 18+**
    ours: run by hand, when we decide to add
    also: put it on a cron if you want it automatic; nothing in it needs a human
- **Slippage set for a fee-on-transfer token**
    ours: ≥1500 bps
    also: none — a normal 1% simply reverts. This is the single thing that breaks naive add-liquidity scripts
- **One secret at runtime: PRIVATE_KEY**
    ours: a local .env file
    also: your shell environment, a secret manager, a hardware signer

## Run it

    npm i
    node -r dotenv/config add-liquidity-safe.js

## What is in here

- `add-liquidity-safe.js`  (324 lines)
- `burn-creator-bobai.js`  (98 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/liquidity-bot.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/liquidity-bot.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
