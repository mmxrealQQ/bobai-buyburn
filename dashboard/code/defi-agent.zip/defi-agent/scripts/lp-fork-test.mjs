#!/usr/bin/env node
// The DeFi agent's money paths, RUN — on a local copy of BNB Chain.
//
// The self-test (lp-agent.mjs --self-test) pins the rules and drives the plan
// functions over a chain that answers from a table. What it cannot do is send:
// whether the position manager takes a one-sided mint at these minimums,
// whether the router fills a "sell all of it", whether a merge and a re-set go
// through in one breath — that was only ever known after the agent had done
// it with the operator's capital. Several of those paths have never run
// (2026-09-18: the re-set upward, the merge, growing a reserve the price is
// in, finishing a re-set whose mint failed beside the reserve, selling the
// profit share of a re-set downward out of the fee token).
//
// This script forks the chain with anvil at the current block, takes the DeFi
// wallet's place by impersonation — NO KEY is read, nothing can reach the real
// chain: every transaction goes to 127.0.0.1 — moves the pool's price with a
// made-up whale, and runs the SAME execute functions the worker runs
// (shared/lp-agent.js) against PancakeSwap's real contracts and the agent's
// real positions. After each path it reads the chain and checks what must hold.
//
// Needs: anvil (foundry; ~/.foundry/bin/anvil.exe or ANVIL=…), and an RPC that
// serves historical state in BSC_RPC_KEYED_URL_2 (.env) — a fork reads state
// at its block for minutes, and the public endpoints prune it within seconds.
//
//   node scripts/lp-fork-test.mjs            every path
//   node scripts/lp-fork-test.mjs --only up  one of: up, down, reserve, resume, collect
import 'dotenv/config';
import { spawn } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { createPublicClient, createWalletClient, createTestClient, http, parseAbi, parseEther, formatEther, encodeFunctionData } from 'viem';
import { bsc } from 'viem/chains';
import {
  ADDR, ABI, readPosition, readPool, heldIds, healLadder, positionSide, unwindCalls,
  planRebalance, executeRebalance, planLadder, executeLadder, planIncrease, executeIncrease, planCollect, executeCollect,
  planSweep, executeSweep, INCOME_SOURCES, OPERATOR_WALLET, BOBAI_PAIR, DEAD, liquidityGasUsd, liquiditySplit,
} from '../shared/lp-agent.js';
import { RESERVE_COLLECT_MIN_BNB } from '../shared/lp-guards.js';

const PORT = 8546, LOCAL = `http://127.0.0.1:${PORT}`;
const FORK_URL = process.env.BSC_RPC_KEYED_URL_2 || process.env.BSC_RPC_KEYED_URL_1 || process.env.BSC_ARCHIVE_RPC_URL;
const ANVIL = process.env.ANVIL || path.join(os.homedir(), '.foundry', 'bin', process.platform === 'win32' ? 'anvil.exe' : 'anvil');
const only = (() => { const i = process.argv.indexOf('--only'); return i >= 0 ? process.argv[i + 1] : null; })();
const LP = ADDR.LP_WALLET, CAKE = '0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82', WHALE = '0x00000000000000000000000000000000000f00d1';
const ERC20 = parseAbi(['function balanceOf(address) view returns (uint256)', 'function transfer(address,uint256) returns (bool)', 'function approve(address,uint256) returns (bool)', 'function deposit() payable']);
const NPM = parseAbi(['function multicall(bytes[] data) payable returns (bytes[] results)', 'function decreaseLiquidity((uint256 tokenId,uint128 liquidity,uint256 amount0Min,uint256 amount1Min,uint256 deadline)) payable returns (uint256,uint256)']);

if (!FORK_URL) { console.error('No archive RPC in .env (BSC_RPC_KEYED_URL_2). A fork needs state at its block for minutes; the public endpoints prune it within seconds.'); process.exit(2); }
if (!fs.existsSync(ANVIL)) { console.error(`anvil not found at ${ANVIL} — install foundry, or set ANVIL=…`); process.exit(2); }

let failed = 0, n = 0;
const ok = (label, pass, detail = '') => { n++; if (!pass) failed++; console.log(`  ${pass ? 'ok  ' : 'FAIL'}  ${label}${detail ? ` — ${detail}` : ''}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// Half of Cloudflare's 1000 subrequests per invocation: the fork answers a receipt at once, the chain after a poll or two per transaction.
const RPC_BUDGET = 500;
const withinBudget = (what, count) => ok(`${what} stays inside half the worker's subrequest budget`, count > 0 && count < RPC_BUDGET, `${count} requests of ${RPC_BUDGET}`);

const anvil = spawn(ANVIL, ['--fork-url', FORK_URL, '--port', String(PORT), '--chain-id', '56', '--auto-impersonate', '--silent', '--no-rate-limit', '--gas-price', '100000000', '--block-base-fee-per-gas', '0'], { stdio: 'ignore' });
const stop = () => { try { anvil.kill(); } catch { /* gone */ } };
process.on('exit', stop); process.on('SIGINT', () => { stop(); process.exit(130); });

const chain = { ...bsc, rpcUrls: { default: { http: [LOCAL] } } };
// Every request the AGENT's code makes is counted (its reads through `pub`, its sends through the LP wallet): a
// Cloudflare invocation may make 1000 subrequests, and a path that grows past that would stop half way, on chain.
let rpcCount = 0;
const counting = () => http(LOCAL, { timeout: 120000, onFetchRequest: () => { rpcCount += 1; } });
const pub = createPublicClient({ chain, transport: counting() });
const test = createTestClient({ chain, mode: 'anvil', transport: http(LOCAL, { timeout: 120000 }) });
const walletOf = (address) => createWalletClient({ account: address, chain, transport: http(LOCAL, { timeout: 120000 }) });
// The agent's wallet, with one difference from production that belongs to the
// fork and not to the agent: every transaction is sent with a fixed gas limit
// instead of anvil's own estimate.
const lpWallet = (() => {
  const w = createWalletClient({ account: LP, chain, transport: counting() });
  if (process.env.FORK_GAS === '0') return w;   // FORK_GAS=0: anvil's own estimate, which is too tight for the manager's multicall (burn refunds) — measured 2026-09-18, the same call runs on the real chain
  const write = w.writeContract.bind(w);
  // 700k covers the largest call (a mint across ticks). The fork answers
  // eth_gasPrice with 1 gwei where the chain clears at 0.05, so a limit set
  // generously would not fit inside the agent's 0.003 BNB gas reserve after a
  // few transactions — on the real chain the limit is the node's estimate.
  w.writeContract = (req) => write({ ...req, gas: 700000n });
  return w;
})();
const bal = (token, who) => pub.readContract({ address: token, abi: ERC20, functionName: 'balanceOf', args: [who] });
const sendAs = async (from, req) => { const h = await walletOf(from).writeContract({ ...req, account: from, chain, gas: 25000000n /* the whale crosses hundreds of ticks in one swap */ }); const r = await pub.waitForTransactionReceipt({ hash: h }); if (r.status !== 'success') throw new Error('setup transaction reverted'); return r; };

for (let i = 0; i < 60; i++) { try { await pub.getBlockNumber(); break; } catch { await sleep(500); } }
const forkBlock = await pub.getBlockNumber();
console.log(`forked BNB Chain at block ${forkBlock} — every transaction below goes to ${LOCAL} and nowhere else\n`);

// The agent's own record and width verdict, as the worker reads them.
const rec = await fetch('https://agent.brainonbnb.com/lp/agent?format=json').then((r) => r.json());
const win = await fetch('https://agent.brainonbnb.com/lp/windows?format=json').then((r) => r.json());
const record = win.verdict, POOL = String(win.pool || rec.pool).toLowerCase();
const LADDER0 = { main: String(rec.ladder.main), reserve: rec.ladder.reserve == null ? null : String(rec.ladder.reserve) };
console.log(`ladder on record: main #${LADDER0.main}, reserve #${LADDER0.reserve}; pool ${POOL}; pick ±${record?.earnings_pick?.width}%\n`);

// A whale with all the BNB and CAKE it needs, and an approval for the router.
await test.setBalance({ address: WHALE, value: parseEther('2000000') });
await test.setBalance({ address: LP, value: (await pub.getBalance({ address: LP })) + parseEther('0.05') });   // gas for the paths, as the tax flow refills it
await sendAs(WHALE, { address: ADDR.WBNB, abi: ERC20, functionName: 'deposit', value: parseEther('1000000') });
let cakeRich = null;
for (const h of ['0x45c54210128a065de780c4b0df3d16664f7f859e', '0x5692db8177a81a6c6afc8084c2976c9933ec1bab', '0xa5f8c5dbd5f286960b9d90548680ae5ebff07652', '0x0ed7e52944161450477ee417de9cd3a859b14fd0']) {
  const b = await bal(CAKE, h); if (!cakeRich || b > cakeRich.b) cakeRich = { h, b };
}
await test.setBalance({ address: cakeRich.h, value: parseEther('1') });
await sendAs(cakeRich.h, { address: CAKE, abi: ERC20, functionName: 'transfer', args: [WHALE, cakeRich.b / 2n] });
for (const t of [ADDR.WBNB, CAKE]) await sendAs(WHALE, { address: t, abi: ERC20, functionName: 'approve', args: [ADDR.V3_SWAP_ROUTER, (1n << 256n) - 1n] });

const sqrtX96AtTick = (t) => BigInt(Math.floor(Math.pow(1.0001, t / 2) * 2 ** 96));
const pos0 = await readPosition(pub, LP, LADDER0);
const FEE = Number(pos0.pos[4]);
// The whale trades until the pool's price stands at `tick`: one swap with a
// price limit, so it stops exactly there whatever the depth is.
async function pushPriceTo(tick) {
  const now = (await readPool(pub, pos0.pos)).tick;
  const up = tick > now;   // CAKE is token0, WBNB token1: buying CAKE with WBNB raises the tick
  const [tokenIn, tokenOut] = up ? [ADDR.WBNB, CAKE] : [CAKE, ADDR.WBNB];
  const amountIn = await bal(tokenIn, WHALE);
  await sendAs(WHALE, { address: ADDR.V3_SWAP_ROUTER, abi: ABI.V3_ROUTER, functionName: 'exactInputSingle', args: [{ tokenIn, tokenOut, fee: FEE, recipient: WHALE, deadline: BigInt(Math.floor(Date.now() / 1000) + 3600), amountIn, amountOutMinimum: 0n, sqrtPriceLimitX96: sqrtX96AtTick(tick) }] });
  return (await readPool(pub, pos0.pos)).tick;
}
const valueOf = async (ladder) => {
  const p = await readPosition(pub, LP, ladder);
  const info = await readPool(pub, p.pos || pos0.pos);
  const price = info.sqrtP ** 2;
  const side = (x) => (x ? positionSide(x.pos, info.sqrtP, false).valueBnb : 0);
  const loose = (Number(await bal(ADDR.WBNB, LP)) + Number(await bal(CAKE, LP)) * price) / 1e18;
  return { main: p.pos ? side(p) : 0, reserve: side(p.reserve), loose, native: Number(formatEther(await pub.getBalance({ address: LP }))), tick: info.tick, p };
};
const total = (v) => v.main + v.reserve + v.loose + v.native;
const BOBAI = ADDR.BOBAI;

// What the worker's rebalance step does, in its order: the merge first when the
// ladder plan says so, then the re-set — with the ladder record kept in hand.
async function workerRebalance(ladder, { expectMerge = null, planOpts = {} } = {}) {
  const rpc0 = rpcCount;
  const plan = await planRebalance(pub, LP, { record, pool: POOL, ladder, ...planOpts });
  if (plan.no) return { plan, refused: plan.no };
  const txs = [];
  let merged = null;
  if (plan.summary.reserve) {
    const lp2 = await planLadder(pub, LP, { record, ladder });
    if (lp2.act === 'merge') { merged = await executeLadder(pub, lpWallet, lpWallet.account, lp2, () => {}, { txs }); ladder.reserve = null; }
    if (expectMerge != null) ok(`the ladder plan ${expectMerge ? 'merges the reserve first' : 'leaves the reserve where it is'}`, (lp2.act === 'merge') === expectMerge, `act ${lp2.act}: ${lp2.why}`);
  }
  const done = await executeRebalance(pub, lpWallet, lpWallet.account, plan, () => {}, { txs });
  if (done.new_position) ladder.main = String(done.new_position);
  return { plan, done, merged, txs, rpc: rpcCount - rpc0 };
}

async function scenario(name, key, fn) {
  if (only && only !== key) return;
  const snap = await test.snapshot();
  console.log(`\n${name}`);
  try { await fn(); } catch (e) { if (process.env.FORK_DEBUG) { const h = e.txs?.at(-1)?.hash; if (h) { const tr = await pub.request({ method: 'debug_traceTransaction', params: [h, { tracer: 'callTracer' }] }).catch((x) => String(x)); const walk = (c, d = 0) => { console.log(' '.repeat(d) + (c.type || '') + ' ' + (c.to || '') + ' ' + (c.input || '').slice(0, 10) + ' ' + (c.error || '') + ' ' + (c.revertReason || '') + ' gas ' + parseInt(c.gasUsed || '0', 16)); for (const x of c.calls || []) walk(x, d + 1); }; typeof tr === 'object' ? walk(tr) : console.log(tr); } } ok('the path ran to its end', false, String(e.shortMessage || e.message || e).slice(0, 300)); }
  await test.revert({ id: snap });
}

// ---------------------------------------------------------------------------
await scenario('RE-SET UPWARD — the price leaves above the main range: the reserve merges, one range below the price, all WBNB, no trade of the capital', 'up', async () => {
  const ladder = { ...LADDER0 };
  const hi = Number(pos0.pos[6]);
  const tick = await pushPriceTo(hi + 150);
  const before = await valueOf(ladder);
  ok('the whale moved the price above the range', tick >= hi + 100, `tick ${tick}, range top ${hi}`);
  const bobai0 = await bal(BOBAI, LP);
  const r = await workerRebalance(ladder, { expectMerge: LADDER0.reserve != null });
  if (r.refused) return ok('the plan re-sets', false, r.refused);
  withinBudget('plan, merge and re-set upward', r.rpc);
  ok('the plan is one-sided, below the price', r.plan.oneSided === 'above' && r.done.one_sided === 'below_price', `ticks ${r.done.new_ticks}`);
  const ids = await heldIds(pub, LP);
  ok('one position is left, and it is the new one — read off the mint receipt', ids.length === 1 && ids[0] === String(r.done.new_position), `held ${ids.join(', ')}`);
  const after = await valueOf(ladder);
  ok('the new range sits beside the price as it was AT THE MINT (20-29 ticks under it)', after.tick - r.done.new_ticks[1] >= 20 && after.tick - r.done.new_ticks[1] < 30, `tick ${after.tick}, range top ${r.done.new_ticks[1]}`);
  ok('the capital went back in whole: nothing of it is loose in the wallet', after.loose < 0.0005 * total(after), `${after.loose.toFixed(6)} BNB loose of ${total(after).toFixed(4)}`);
  ok('the fees the old range paid in CAKE were sold in full — the sale that asked for more than the wallet held before 2026-09-18', (await bal(CAKE, LP)) < 10n ** 15n, `CAKE left ${formatEther(await bal(CAKE, LP))}; swap ${r.done.swap ? JSON.stringify(r.done.swap).slice(0, 120) : 'none'}`);
  ok('the value is the same before and after, less gas and the fee share', Math.abs(total(after) + (r.done.bobai_bnb || 0) - total(before)) < 0.002 * total(before), `${total(before).toFixed(5)} → ${total(after).toFixed(5)} BNB (+ ${r.done.bobai_bnb || 0} into $BOBAI)`);
  ok('the profit share bought $BOBAI, held in the wallet', !(r.done.bobai_bnb > 0) || (await bal(BOBAI, LP)) > bobai0, `fees folded ${r.done.fees_folded_bnb}, into $BOBAI ${r.done.bobai_bnb}${r.done.fees_forward_why ? ' — ' + r.done.fees_forward_why : ''}`);
  console.log(`       ${r.txs.length} transactions: ${r.txs.map((t) => t.label.split(' ').slice(0, 3).join(' ')).join(' · ')}`);
});

// CENTRED, ±20% (operator's go, 2026-10-07: worker-lp LP_WIDTH_PCT "20", LP_RESET_MODE "centred"): the new range
// stands around the price and the capital is traded back to the range's mix, both ways the price can leave
for (const [key, dir] of [['cdown', 'down'], ['cup', 'up']]) {
  await scenario(`RE-SET CENTRED ±20% — the price leaves ${dir === 'down' ? 'below' : 'above'} the range: a range around the price, one trade back to the mix`, key, async () => {
    const ladder = { ...LADDER0, reserve: null };
    const lo = Number(pos0.pos[5]), hi = Number(pos0.pos[6]);
    const tick = await pushPriceTo(dir === 'down' ? lo - 150 : hi + 150);
    const before = await valueOf(ladder);
    ok(`the whale moved the price ${dir === 'down' ? 'below' : 'above'} the range`, dir === 'down' ? tick <= lo - 100 : tick >= hi + 100, `tick ${tick}, range ${lo}…${hi}`);
    const r = await workerRebalance(ladder, { expectMerge: null, planOpts: { widthOverride: 20, centred: true } });
    if (r.refused) return ok('the plan re-sets', false, r.refused);
    withinBudget(`plan and centred re-set ${dir}`, r.rpc);
    ok('the plan is centred: no one-sided side, width ±20%', r.plan.oneSided == null && !r.done.one_sided && r.plan.width === 20, `oneSided ${r.plan.oneSided}, width ${r.plan.width}`);
    const after = await valueOf(ladder);
    const [nl, nu] = r.done.new_ticks || [];
    const span = nu - nl, mid = (nl + nu) / 2;
    ok('the new range stands around the price at the mint (the price within a tenth of the span of its middle)', after.tick > nl && after.tick < nu && Math.abs(after.tick - mid) < span / 10, `tick ${after.tick}, range ${nl}…${nu}`);
    ok('…and is ±20% wide (about 3,650 ticks)', span > 3400 && span < 3900, `span ${span} ticks`);
    ok('the capital went back in whole: nothing of it is loose', after.loose < 0.003 * total(after), `${after.loose.toFixed(6)} BNB loose of ${total(after).toFixed(4)}`);
    ok('the value is kept, less gas, the fee share and the one trade (under 0.4%)', Math.abs(total(after) + (r.done.bobai_bnb || 0) - total(before)) < 0.004 * total(before), `${total(before).toFixed(5)} → ${total(after).toFixed(5)} BNB, trade ${JSON.stringify(r.done.swap || null).slice(0, 120)}`);
    console.log(`       ${r.txs.length} transactions: ${r.txs.map((t) => t.label.split(' ').slice(0, 3).join(' ')).join(' · ')}`);
  });
}

await scenario('RE-SET DOWNWARD — the price falls out of the main range into the reserve: one range above the price, all CAKE, and the profit share sold out of the CAKE fees', 'down', async () => {
  const ladder = { ...LADDER0 };
  const lo = Number(pos0.pos[5]);
  const tick = await pushPriceTo(lo - 150);
  const before = await valueOf(ladder);
  ok('the whale moved the price below the range', tick <= lo - 100, `tick ${tick}, range bottom ${lo}`);
  const bobai0 = await bal(BOBAI, LP);
  const r = await workerRebalance(ladder, { expectMerge: false });
  if (r.refused) return ok('the plan re-sets', false, r.refused);
  withinBudget('plan and re-set downward with the share sale', r.rpc);
  ok('the plan is one-sided, above the price', r.done.one_sided === 'above_price', `ticks ${r.done.new_ticks}`);
  const ids = await heldIds(pub, LP);
  ok('two positions are held: the new main range and the reserve that stood', ids.length === (LADDER0.reserve ? 2 : 1) && ids.includes(String(r.done.new_position)) && (!LADDER0.reserve || ids.includes(LADDER0.reserve)), `held ${ids.join(', ')}`);
  const after = await valueOf(ladder);
  ok('the new range sits 20-29 ticks above the price at the mint', r.done.new_ticks[0] - after.tick >= 20 && r.done.new_ticks[0] - after.tick < 30, `tick ${after.tick}, range bottom ${r.done.new_ticks[0]}`);
  ok('nothing of the capital is loose', after.loose < 0.0005 * total(after), `${after.loose.toFixed(6)} BNB loose`);
  ok('the profit share was bought although the fees came in CAKE (before 2026-09-18: "stays as capital")', !(r.done.fees_folded_bnb > 0.0002) || (r.done.bobai_bnb > 0 && (await bal(BOBAI, LP)) > bobai0), `fees folded ${r.done.fees_folded_bnb}, into $BOBAI ${r.done.bobai_bnb}, share sale ${r.done.share_swap ? 'yes' : 'no'}${r.done.fees_forward_why ? ' — ' + r.done.fees_forward_why : ''}`);
  ok('the value is the same before and after, less gas and the fee share', Math.abs(total(after) + (r.done.bobai_bnb || 0) - total(before)) < 0.002 * total(before), `${total(before).toFixed(5)} → ${total(after).toFixed(5)} BNB`);

  // … and BNB that arrives now joins the reserve the price is IN.
  if (LADDER0.reserve) {
    await test.setBalance({ address: LP, value: (await pub.getBalance({ address: LP })) + parseEther('0.06') });
    const lp3 = await planLadder(pub, LP, { record, ladder });
    ok('BNB arriving beside an all-CAKE main range grows the reserve', lp3.act === 'increase_reserve' && !lp3.no, `act ${lp3.act}: ${lp3.no || lp3.why}`);
    if (lp3.act === 'increase_reserve' && !lp3.no) {
      const liq0 = (await readPosition(pub, LP, ladder)).reserve.pos[7];
      const d = await executeLadder(pub, lpWallet, lpWallet.account, lp3, () => {}, { txs: [] });
      const liq1 = (await readPosition(pub, LP, ladder)).reserve.pos[7];
      ok('… through the ordinary increase, buying the side a range the price is in needs (a WBNB-only add reverted there)', liq1 > liq0 && Number(d.bnb_spent) > 0.05, `reserve side ${d.reserve_side}, liquidity ${liq0} → ${liq1}, spent ${d.bnb_spent} BNB, swap ${d.swap ? 'yes' : 'no'}`);
    }
  }
});

await scenario('A RE-SET WHOSE MINT FAILED BESIDE THE RESERVE — the main range is burnt, its CAKE lies loose: finished from the wallet, not sold into the reserve', 'resume', async () => {
  if (!LADDER0.reserve) return ok('needs a standing reserve', true, 'skipped: no reserve on record');
  const ladder = { ...LADDER0 };
  const lo = Number(pos0.pos[5]);
  await pushPriceTo(lo - 150);
  // The first half of a re-set, by hand: withdraw, collect, burn — and then nothing.
  const p = await readPosition(pub, LP, ladder);
  await sendAs(LP, { address: ADDR.V3_POSITION_MANAGER, abi: NPM, functionName: 'multicall', args: [unwindCalls(p.tokenId, p.pos[7], 0n, 0n, LP, BigInt(Math.floor(Date.now() / 1000) + 3600))] });
  const before = await valueOf(ladder);
  const seen = await readPosition(pub, LP, ladder);
  ok('the wallet reads as "no main range, the reserve rides along"', seen.positions === 0 && String(seen.reserve?.tokenId) === LADDER0.reserve && seen.main_missing === LADDER0.main);
  ok('the ladder is NOT closed while the capital lies loose', (await healLadder(pub, LP, { ...ladder })) === null, `${before.loose.toFixed(4)} BNB loose`);
  const inc = await planIncrease(pub, LP, null, ladder);
  ok('the increase step does not take the loose CAKE for a deposit', !!inc.no, inc.no);
  const r = await workerRebalance(ladder, { expectMerge: false });
  if (r.refused) return ok('the resume mints', false, r.refused);
  withinBudget('plan and resume', r.rpc);
  ok('the resume is one-sided on the token held, and trades nothing of the capital', r.plan.resume === true && r.done.one_sided === 'above_price' && !(r.done.swap && Number(r.done.swap.notional_bnb || 0) > 0.01 * before.loose), `swap ${r.done.swap ? JSON.stringify(r.done.swap).slice(0, 100) : 'none'}`);
  const ids = await heldIds(pub, LP);
  ok('the main range stands again beside the reserve, its id off the receipt', ids.length === 2 && ids.includes(LADDER0.reserve) && ids.includes(String(r.done.new_position)), `held ${ids.join(', ')}`);
  const after = await valueOf(ladder);
  ok('nothing is loose, and the value is what it was', after.loose < 0.0005 * total(after) && Math.abs(total(after) - total(before)) < 0.002 * total(before), `${total(before).toFixed(5)} → ${total(after).toFixed(5)} BNB, loose ${after.loose.toFixed(6)}`);
});

await scenario('THE COLLECT TAKES THE RESERVE RANGE\'S FEES TOO — the price trades through both ranges, both earn; one run collects both, sells, splits, buys $BOBAI', 'collect', async () => {
  if (!LADDER0.reserve) return ok('needs a standing reserve', true, 'skipped: no reserve on record');
  const ladder = { ...LADDER0 };
  // As the chain stands: the reserve is asked only when its fees are worth a transaction of their own.
  const asIs = await planCollect(pub, LP, ladder);
  const ro = asIs.summary.reserve_owed;
  ok('as the chain stands, the reserve is taken along exactly when it is owed the floor or more', !!ro && ro.collected_with_it === (ro.bnb_equivalent >= RESERVE_COLLECT_MIN_BNB) && (asIs.reserveTokenId != null) === ro.collected_with_it, ro ? `owed ${ro.bnb_equivalent} BNB against ${RESERVE_COLLECT_MIN_BNB}${ro.why ? ' — ' + ro.why : ''}` : 'no reserve_owed in the plan');
  // Volume through both ranges: down to the bottom of the reserve and back to where the price stood.
  const start = (await readPool(pub, pos0.pos)).tick;
  const resLo = Number((await readPosition(pub, LP, ladder)).reserve.pos[5]);
  // A range earns 0.05% of what trades through it: a reserve of a few hundredths of a BNB needs the price across it several times.
  const mainHi = Number(pos0.pos[6]);
  let trips = 0;
  for (; trips < 12; trips++) {
    await pushPriceTo(resLo + 60);
    await pushPriceTo(mainHi - 60);
    const look = await planCollect(pub, LP, ladder);
    // With room above the floor: the fees are mostly CAKE, and the way back down to `start` makes them worth less in BNB.
    if (!look.no && look.reserveTokenId != null && look.summary.reserve_owed.bnb_equivalent >= RESERVE_COLLECT_MIN_BNB * 1.3) break;
  }
  await pushPriceTo(start);
  console.log(`       the whale took the price across both ranges ${trips + 1} times`);
  const plan = await planCollect(pub, LP, ladder);
  const r2 = plan.summary.reserve_owed;
  ok('after the volume both ranges are owed fees, and the plan takes the reserve along', !plan.no && plan.reserveTokenId != null && String(plan.reserveTokenId) === LADDER0.reserve && r2.collected_with_it === true && r2.bnb_equivalent >= RESERVE_COLLECT_MIN_BNB && plan.summary.owed.bnb_equivalent > r2.bnb_equivalent, plan.no || `owed ${plan.summary.owed.bnb_equivalent} BNB in all, ${r2.bnb_equivalent} of it the reserve's`);
  if (plan.no || plan.reserveTokenId == null) return;
  const liq0 = (await readPosition(pub, LP, ladder)).reserve.pos[7], bobai0 = await bal(BOBAI, LP);
  const txs = [];
  const rpcBefore = rpcCount;
  const done = await executeCollect(pub, lpWallet, lpWallet.account, plan, () => {}, { txs });
  withinBudget('the collect of both ranges with sale and $BOBAI buy', rpcCount - rpcBefore);
  const after = await readPosition(pub, LP, ladder);
  ok('one run: collect, collect the reserve, sell, unwrap, buy $BOBAI', txs.some((t) => t.label === 'collect') && txs.some((t) => /reserve range's fees/.test(t.label)) && txs.some((t) => /sell the other side/.test(t.label)) && txs.some((t) => /buy BOBAI/.test(t.label)), txs.map((t) => t.label.split(' ').slice(0, 3).join(' ')).join(' · '));
  const dust = plan.owedOther / 1000n;   // the run's own sale trades through both ranges and pays them their share of its 0.05% fee: a speck, never a thousandth of what was sold
  ok('both ranges are owed nothing but the speck the run\'s own sale paid them, and the reserve\'s liquidity is untouched', after.owed0 < dust && after.owed1 < dust && after.reserve.owed0 < dust && after.reserve.owed1 < dust && after.reserve.pos[7] === liq0, `reserve owed ${after.reserve.owed0}/${after.reserve.owed1}`);
  const produced = Number(done.produced_bnb || 0), planned = plan.summary.owed.bnb_equivalent, gas = txs.filter((t) => !/buy BOBAI/.test(t.label)).reduce((g, t) => g + (t.gas_bnb || 0), 0);   // the fork charges 1 gwei, the chain 0.05; the $BOBAI buy comes after the run has counted what it produced
  ok('what the run produced is what both were owed, less its gas — the reserve\'s part is in the split', Math.abs(produced + gas - planned) < planned * 0.01 && produced + gas > (planned - r2.bnb_equivalent) * 1.02, `produced ${produced.toFixed(6)} + gas ${gas.toFixed(6)} of ${planned.toFixed(6)} BNB owed (main alone ${(planned - r2.bnb_equivalent).toFixed(6)})`);
  ok('half of it bought $BOBAI, held in the wallet', Number(done.bobai_bnb) > 0 && Math.abs(Number(done.bobai_bnb) - produced / 2) < produced * 0.01 && (await bal(BOBAI, LP)) > bobai0, `${done.bobai_bnb} BNB into $BOBAI, kept ${done.kept_bnb}`);
  ok('no CAKE and no WBNB of it is left loose', (await bal(CAKE, LP)) <= plan.heldOther + 10n ** 12n && (await bal(ADDR.WBNB, LP)) === 0n);
});

await scenario('THE FEES IN THIRDS (2026-10-14) — the price trades through the main range until it owes the collect floor; one collect: a third stays as capital, a third buys $BOBAI, a third goes to the operator as BNB', 'thirds', async () => {
  const ladder = { ...LADDER0 };
  const lo = Number(pos0.pos[5]), hi = Number(pos0.pos[6]), start = (await readPool(pub, pos0.pos)).tick;
  let plan = null, trips = 0;
  for (; trips < 20; trips++) {
    await pushPriceTo(lo + 60); await pushPriceTo(hi - 60);
    plan = await planCollect(pub, LP, ladder);
    if (!plan.no) break;
  }
  await pushPriceTo(start);
  plan = await planCollect(pub, LP, ladder);
  console.log(`       the whale took the price across the range ${trips + 1} times`);
  ok('after the volume the range owes the collect floor', !plan.no, plan.no || `owed ${plan.summary.owed.bnb_equivalent} BNB`);
  if (plan.no) return;
  const op0 = await pub.getBalance({ address: OPERATOR_WALLET }), bobai0 = await bal(BOBAI, LP), txs = [];
  const done = await executeCollect(pub, lpWallet, lpWallet.account, plan, () => {}, { txs });
  const produced = Number(done.produced_bnb), third = produced / 3, op1 = await pub.getBalance({ address: OPERATOR_WALLET });
  ok('the operator received a third of what the run produced, as BNB', Math.abs(Number(done.to_operator_bnb) - third) < produced * 0.01 && Number(formatEther(op1 - op0)) === Number(done.to_operator_bnb), `${done.to_operator_bnb} BNB of ${produced.toFixed(6)} produced; the operator's balance moved ${formatEther(op1 - op0)}`);
  ok('a third bought $BOBAI, held in the DeFi wallet', Math.abs(Number(done.bobai_bnb) - third) < produced * 0.01 && (await bal(BOBAI, LP)) > bobai0, `${done.bobai_bnb} BNB into $BOBAI`);
  ok('a third stays as capital', Math.abs(Number(done.kept_bnb) - third) < produced * 0.01, `${done.kept_bnb} BNB kept (${done.kept_pct}%)`);
  ok('the send to the operator is one plain transfer in the run', txs.filter((t) => /operator's third/.test(t.label)).length === 1, txs.map((t) => t.label.split(' ').slice(0, 4).join(' ')).join(' · '));
});

await scenario('EVERY AI PAYMENT: HALF BUYS $BOBAI, HALF TO THE OPERATOR (2026-10-14) — the x402 wallet holds USD1 a buyer paid; half goes to the operator as USD1, half buys $BOBAI that stays in that wallet; the DeFi wallet gets nothing', 'sweep', async () => {
  const src = INCOME_SOURCES.find((s) => s.key === 'x402');
  // a buyer's payment, on the fork: the whale buys 0.05 BNB of USD1 (a payment, not a market move) and sends it to the income wallet
  await sendAs(WHALE, { address: ADDR.V2_ROUTER, abi: parseAbi(['function swapExactETHForTokens(uint256,address[],address,uint256) payable returns (uint256[])']), functionName: 'swapExactETHForTokens', args: [0n, [ADDR.WBNB, src.token], src.wallet, BigInt(Math.floor(Date.now() / 1000) + 600)], value: parseEther('0.05') });
  await test.setBalance({ address: src.wallet, value: parseEther('0.01') });   // gas, as the wallet holds on the chain
  const usd0 = await bal(src.token, src.wallet), bobai0 = await bal(BOBAI, src.wallet), lpBnb0 = await pub.getBalance({ address: LP }), op0 = await bal(src.token, OPERATOR_WALLET);
  const plan = await planSweep(pub, src);
  ok('the plan sweeps the payment and quotes it in $BOBAI', !plan.no && plan.amount > 0n && plan.bobaiOut > 0n, plan.no || `${plan.summary.sweeping} USD1 -> about ${(Number(plan.bobaiOut) / 1e18).toFixed(0)} $BOBAI`);
  if (plan.no) return;
  const txs = [], done = await executeSweep(pub, walletOf(src.wallet), src.wallet, plan, () => {}, { txs });
  const usd1 = await bal(src.token, src.wallet), bobai1 = await bal(BOBAI, src.wallet), lpBnb1 = await pub.getBalance({ address: LP }), op1 = await bal(src.token, OPERATOR_WALLET);
  ok('three transactions: half to the operator, approve, one swap USD1 -> WBNB -> $BOBAI', txs.length === 3 && /half of the USD1 to the operator/.test(txs[0].label) && /buy \$BOBAI with the other half/.test(txs[2].label), txs.map((t) => t.label).join(' · '));
  ok('the swept USD1 has left the wallet', usd0 - usd1 === plan.amount, `${Number(usd0 - usd1) / 1e18} of ${Number(plan.amount) / 1e18}`);
  ok('the operator received exactly half, in USD1 as it was paid', op1 - op0 === plan.amount / 2n, `${Number(op1 - op0) / 1e18} USD1 of ${Number(plan.amount) / 1e18}`);
  ok('$BOBAI for the other half arrived in the income wallet, at least the floor (half the quote less the 3% tax less 5%)', bobai1 - bobai0 >= (plan.bobaiOut / 2n * 97n * 95n) / 10000n && Number(done.bobai_bought) > 0, `${done.bobai_bought} $BOBAI for half of a quote of ${(Number(plan.bobaiOut) / 1e18).toFixed(2)}`);
  ok('the DeFi wallet received nothing — its capital and record are untouched', lpBnb1 === lpBnb0, `${formatEther(lpBnb1 - lpBnb0)} BNB`);
});

await scenario('INCOME ALSO DEEPENS THE POOL (2026-10-22, plan c, switched on only here) — a bigger payment: half to the operator, of the $BOBAI half one half bought and held, the other half into the $BOBAI pool with LP to the dead address', 'sweepliq', async () => {
  const src = INCOME_SOURCES.find((s) => s.key === 'x402');
  await sendAs(WHALE, { address: ADDR.V2_ROUTER, abi: parseAbi(['function swapExactETHForTokens(uint256,address[],address,uint256) payable returns (uint256[])']), functionName: 'swapExactETHForTokens', args: [0n, [ADDR.WBNB, src.token], src.wallet, BigInt(Math.floor(Date.now() / 1000) + 600)], value: parseEther('0.4') });
  await test.setBalance({ address: src.wallet, value: parseEther('0.01') });
  const RES = parseAbi(['function getReserves() view returns (uint112,uint112,uint32)']);
  const usd0 = await bal(src.token, src.wallet), bobai0 = await bal(BOBAI, src.wallet), op0 = await bal(src.token, OPERATOR_WALLET), lp0 = await bal(BOBAI_PAIR, DEAD), wb0 = await bal(ADDR.WBNB, src.wallet);
  const r0 = await pub.readContract({ address: BOBAI_PAIR, abi: RES, functionName: 'getReserves' });
  const plan = await planSweep(pub, src);
  ok('the plan sweeps the payment', !plan.no && plan.amount > 0n, plan.no || `${plan.summary.sweeping} USD1, about ${plan.summary.implied_usd} $ a unit`);
  if (plan.no) return;
  const txs = [], done = await executeSweep(pub, walletOf(src.wallet), src.wallet, plan, () => {}, { txs, liquidity: true });
  const op1 = await bal(src.token, OPERATOR_WALLET), lp1 = await bal(BOBAI_PAIR, DEAD), bobai1 = await bal(BOBAI, src.wallet), usd1 = await bal(src.token, src.wallet), wb1 = await bal(ADDR.WBNB, src.wallet);
  const r1 = await pub.readContract({ address: BOBAI_PAIR, abi: RES, functionName: 'getReserves' });
  ok('the operator still receives exactly half, in USD1', op1 - op0 === plan.amount / 2n, `${Number(op1 - op0) / 1e18} of ${Number(plan.amount) / 1e18}`);
  ok('the liquidity part ran: WBNB, two approvals, addLiquidity', !!done.liquidity && txs.some((t) => /add both to the \$BOBAI pool/.test(t.label)), txs.map((t) => t.label.split(' ').slice(0, 4).join(' ')).join(' · '));
  ok('LP tokens were minted to the dead address (burned)', lp1 > lp0, `${done.liquidity?.lp_burned} LP to ${DEAD}`);
  // depth is the product of the reserves (the buy itself takes $BOBAI out; the add puts both sides in)
  ok('the pool got deeper: the product of its reserves grew', r1[0] * r1[1] > r0[0] * r0[1], `k ${(Number(r0[0]) * Number(r0[1]) / 1e36).toFixed(1)} -> ${(Number(r1[0]) * Number(r1[1]) / 1e36).toFixed(1)}`);
  ok('$BOBAI was bought and held in the income wallet too (the hold half)', bobai1 > bobai0 && Number(done.bobai_bought) > 0, `${done.bobai_bought} $BOBAI held; ${done.liquidity?.bobai_in} $BOBAI + ${done.liquidity?.wbnb_in} WBNB into the pool`);
  ok('all the swept USD1 left the wallet; at most dust of WBNB stays', usd0 - usd1 === plan.amount && wb1 - wb0 < parseEther('0.0005'), `${Number(usd0 - usd1) / 1e18} USD1 · WBNB left ${formatEther(wb1 - wb0)}`);
});

await scenario('INCOME ALSO DEEPENS THE POOL, AT TODAY\'S SIZE (22.10. evening: the line is the gas, not 10 $) — a sweep like the one of 21.10. (~3.40 $): half to the operator, and of the $BOBAI half a part into the pool when the gas is at most 5 % of it', 'sweepsmall', async () => {
  const src = INCOME_SOURCES.find((s) => s.key === 'x402');
  await sendAs(WHALE, { address: ADDR.V2_ROUTER, abi: parseAbi(['function swapExactETHForTokens(uint256,address[],address,uint256) payable returns (uint256[])']), functionName: 'swapExactETHForTokens', args: [0n, [ADDR.WBNB, src.token], src.wallet, BigInt(Math.floor(Date.now() / 1000) + 600)], value: parseEther('0.0047') });
  await test.setBalance({ address: src.wallet, value: parseEther('0.01') });
  const op0 = await bal(src.token, OPERATOR_WALLET), lp0 = await bal(BOBAI_PAIR, DEAD);
  const plan = await planSweep(pub, src);
  ok('the plan sweeps the small payment', !plan.no && plan.amount > 0n, plan.no || `${plan.summary.sweeping} USD1`);
  if (plan.no) return;
  // anvil answers eth_gasPrice with its own default (~1 gwei); the live chain's price is what the worker will read
  const liveGas = await createPublicClient({ chain: bsc, transport: http('https://bsc-dataseed.binance.org') }).getGasPrice();
  const pubLive = new Proxy(pub, { get: (t, k) => (k === 'getGasPrice' ? async () => liveGas : t[k]) });
  const gasUsd = await liquidityGasUsd(pubLive, plan);
  const want = liquiditySplit(plan.amount - plan.amount / 2n, plan.summary.implied_usd, src.decimals, true, gasUsd);
  const txs = [], done = await executeSweep(pubLive, walletOf(src.wallet), src.wallet, plan, () => {}, { txs, liquidity: true });
  ok('at the live gas price the pool part of a 3.40 $ sweep goes in', want.liq > 0n, `live gas ${Number(liveGas) / 1e9} gwei`);
  const op1 = await bal(src.token, OPERATOR_WALLET), lp1 = await bal(BOBAI_PAIR, DEAD);
  ok('the operator still receives exactly half', op1 - op0 === plan.amount / 2n, `${Number(op1 - op0) / 1e18} of ${Number(plan.amount) / 1e18}`);
  ok('the gas line was read and the pool part followed it', gasUsd > 0 && (want.liq > 0n) === !!done.liquidity, `gas of the pool part ${gasUsd?.toFixed(4)} $, line ${(gasUsd / 0.05).toFixed(2)} $, pool part ${want.liq_usd} $ -> ${done.liquidity ? 'into the pool' : 'held'}`);
  if (done.liquidity) ok('LP of the small part burned', lp1 > lp0, `${done.liquidity.lp_burned} LP`);
});

console.log(`\n${n - failed}/${n} checks pass on the fork of block ${forkBlock}`);
stop();
process.exit(failed ? 1 : 0);