# NFT Auto-Mint Bot

Watches the pair and mints to the buyer, unasked.

Reads Swap logs off the pair block by block, prices each buy in dollars, and mints an NFT straight to any wallet that crossed the threshold — no claim page, no signature from the buyer, no gas for them. Keeps its own cursor in KV so a restart never double-mints and never skips a block.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A deployed ERC-721 it is allowed to mint from**
    ours: the contract in the NFT Buy Drops bundle
    also: any ERC-721 with a mint function and a minter role
- **A wallet with gas**
    ours: the bot pays the mint, so the buyer pays nothing
    also: you could make the buyer claim and pay — but then it is a claim page, not a drop
- **Somewhere that runs code on a schedule**
    ours: a Cloudflare Worker cron
    also: crontab, GitHub Actions, any always-on process
- **Somewhere to keep the block cursor**
    ours: one KV namespace
    also: a file or a database row. Whatever it is, it must be durable: this is what stops a restart double-minting
- **One secret at runtime: PRIVATE_KEY**
    ours: wrangler secret put
    also: a .env file or your host's secret store

## Run it

    npx wrangler deploy

## What is in here

- `worker-nft-mint/index.js`  (582 lines)
- `worker-nft-mint/wrangler.toml`  (16 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/nft-mint-bot.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/nft-mint-bot.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
