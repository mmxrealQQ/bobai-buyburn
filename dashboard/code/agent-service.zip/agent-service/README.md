# The Agent Service — x402, Broker & Census

An agent that sells something, and gets paid without a human in the loop.

The paid half of the agent surface. It answers HTTP 402 with a price, takes USD1 on BNB Chain by two routes — standard x402 through a public facilitator, or a plain transfer plus the transaction hash — verifies the money actually arrived, and only then starts the work. It also publishes a catalogue at /.well-known/x402 so an agent holding nothing but the domain can discover what is for sale, a broker that searches every ERC-8004 agent on the chain, a dispatcher that routes a task to whichever of them can answer it, and the census that keeps that picture current. The dispatcher is deliberately read-only: anything that signs, sends or swaps is handed back for the caller to do themselves, never executed on their behalf.

## What you need

Written as: the requirement, then how we solved it, then what else works. None of
it is tied to the hosting we happen to use.

- **A wallet to be paid into**
    ours: one BSC wallet, separate from the bots
    also: any address — it is only ever a recipient, and the worker never holds its key
- **Somewhere that runs code on a schedule**
    ours: a Cloudflare Worker, 15-minute cron
    also: anything with a timer — the cron drives the watch sweep, the daily census and the canary
- **Somewhere to keep watches and the census**
    ours: one KV namespace
    also: Redis, SQLite, Postgres — it stores one record per watch and one blob per census tick
- **A payment facilitator, or none**
    ours: the public Dexter facilitator for the standard route
    also: the direct-transfer route needs no facilitator at all, which is why both are offered
- **A BSC RPC endpoint**
    ours: the public endpoints, with failover
    also: any node — note that some public RPCs cannot serve eth_getTransactionReceipt, which payment verification needs
- **Two secrets at runtime: X402_WALLET and the admin trigger secret**
    ours: wrangler secret put
    also: the ownership proofs in the catalogue are signed offline and pasted in as constants — the private key never reaches the worker

## Run it

    npx wrangler deploy
    node scripts/x402-catalog-proof.mjs --verify  # check the catalogue signs what it claims

## What is in here

- `docs/x402-catalog.md`  (138 lines)
- `scripts/x402-catalog-proof.mjs`  (139 lines)
- `shared/agent-registrations.js`  (55 lines)
- `shared/board-topics.js`  (70 lines)
- `shared/job-board.js`  (69 lines)
- `shared/job-summary.js`  (119 lines)
- `shared/lp-agent.js`  (1728 lines)
- `shared/lp-alerts.js`  (94 lines)
- `shared/lp-flow.js`  (269 lines)
- `shared/lp-guards.js`  (664 lines)
- `shared/own-jobs.js`  (103 lines)
- `shared/package.json`  (7 lines)
- `shared/plaza-board.js`  (275 lines)
- `shared/scan-pass.js`  (63 lines)
- `shared/thanks.js`  (64 lines)
- `shared/x402-permit2.js`  (81 lines)
- `worker-agent/agent-hires.js`  (317 lines)
- `worker-agent/agent-wallets.js`  (101 lines)
- `worker-agent/agent-watch.js`  (52 lines)
- `worker-agent/board-agent.js`  (75 lines)
- `worker-agent/board-checkup.js`  (246 lines)
- `worker-agent/board-outreach.js`  (146 lines)
- `worker-agent/board.js`  (1393 lines)
- `worker-agent/canary.js`  (78 lines)
- `worker-agent/catalog.js`  (164 lines)
- `worker-agent/categories.js`  (235 lines)
- `worker-agent/census.js`  (374 lines)
- `worker-agent/chart.js`  (191 lines)
- `worker-agent/dispatch.js`  (1029 lines)
- `worker-agent/escrow-for.js`  (78 lines)
- `worker-agent/find.js`  (304 lines)
- `worker-agent/grid.js`  (216 lines)
- `worker-agent/hire.js`  (1095 lines)
- `worker-agent/holder-pass.js`  (77 lines)
- `worker-agent/holders.js`  (155 lines)
- `worker-agent/index.js`  (4123 lines)
- `worker-agent/job-board.js`  (87 lines)
- `worker-agent/job-watch.js`  (145 lines)
- `worker-agent/ledger.js`  (41 lines)
- `worker-agent/listing.js`  (366 lines)
- `worker-agent/lp-pools.js`  (321 lines)
- `worker-agent/lp-portfolio.js`  (299 lines)
- `worker-agent/lp-service.js`  (322 lines)
- `worker-agent/lp-tiers.js`  (261 lines)
- `worker-agent/lp-windows.js`  (838 lines)
- `worker-agent/net.js`  (27 lines)
- `worker-agent/own-jobs.js`  (142 lines)
- `worker-agent/own-wallets.js`  (20 lines)
- `worker-agent/package.json`  (13 lines)
- `worker-agent/plain-tasks.js`  (175 lines)
- `worker-agent/public-refund.js`  (175 lines)
- `worker-agent/public-settle.js`  (245 lines)
- `worker-agent/pulse.js`  (144 lines)
- `worker-agent/range-task.js`  (106 lines)
- `worker-agent/rebalance.js`  (326 lines)
- `worker-agent/rug-watch.js`  (1215 lines)
- `worker-agent/second-opinion.js`  (92 lines)
- `worker-agent/self-fetch.js`  (15 lines)
- `worker-agent/sell.js`  (1034 lines)
- `worker-agent/session-revoke.js`  (188 lines)
- `worker-agent/session.js`  (159 lines)
- `worker-agent/sessions.js`  (163 lines)
- `worker-agent/standard-quote.js`  (169 lines)
- `worker-agent/submit.js`  (151 lines)
- `worker-agent/telemetry.js`  (727 lines)
- `worker-agent/understand.js`  (117 lines)
- `worker-agent/v3-depth.js`  (99 lines)
- `worker-agent/venus-work.js`  (274 lines)
- `worker-agent/venus.js`  (390 lines)
- `worker-agent/wrangler.toml`  (75 lines)
- `worker-agent/x402-catalog.js`  (174 lines)
- `worker-agent/x402-eip3009.js`  (132 lines)
- `worker-agent/x402.js`  (142 lines)
- `worker-agent/yield.js`  (516 lines)

## What is NOT in here

No private keys, no API tokens, no bot tokens, no wallet files. Every secret is
supplied at runtime through the environment — in the Cloudflare workers via
`wrangler secret put`, locally via a `.env` file you create yourself. The
config files name the variables and nothing more.

Cloudflare KV namespace ids have been replaced with placeholders, so a copied
config points at your resources rather than at ours.

Contract and wallet addresses are left as they are. They are public on the
chain and printed on the site, and leaving them in is what lets you hold this
code against the transactions it actually produced.

## Where this came from

Brain On BNB AI — https://brainonbnb.com
This bundle: https://brainonbnb.com/code/agent-service.zip
The same files as one text file, for handing to an AI: https://brainonbnb.com/code/agent-service.txt

Built by AI, start to finish. MIT licensed — see LICENSE.
