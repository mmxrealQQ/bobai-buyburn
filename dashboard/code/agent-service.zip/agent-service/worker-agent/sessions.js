// The public record of every task this router has passed on.
//
// This is the part of the Plaza that makes the rest mean anything. A directory
// lists what an operator says about itself. A broker matches those claims to a
// question. Neither can tell you whether the agent actually delivers — and that
// is the only thing a person hiring one wants to know.
//
// So every dispatch is written down: what was asked, who was asked, how long
// they took, and what came back or why nothing did. Nobody reports their own
// score. The score is the log.
//
// Two design points that matter more than they look:
//
//   Failures are kept, and kept visible. A record that only shows successes is
//   marketing. The useful signal is precisely the agent that stopped answering
//   last Tuesday, and hiding that would make the whole thing worthless.
//
//   The task text is stored, the answer is not. What an agent returned can be
//   long, can contain anything, and belongs to whoever asked. We keep the shape
//   of the exchange — tool, duration, success — and a short excerpt, never the
//   full payload.
//
// COST: one read and one write per dispatch, on an account near the free-plan
// KV limit. All sessions live in a single rolling key rather than one key each,
// which is the difference between two operations a day and two thousand.

const KEY = 'plaza:sessions';
export const MAX_SESSIONS = 400;
const EXCERPT = 220;

export async function recordSession(env, entry) {
  try {
    const log = JSON.parse((await env.AGENT.get(KEY)) || '[]');
    log.push({
      at: new Date().toISOString(),
      task: String(entry.task || '').slice(0, 160),
      // Every string in an entry is bounded (2026-09-18): `agent` was stored as
      // the caller gave it, a POST body with a megabyte in that field was kept
      // whole, and some twenty-five of them pass the size a KV value may have —
      // after which every write fails in silence and the log stands still.
      operator: entry.operator ? String(entry.operator).slice(0, 80) : null,
      agent: entry.agent ? String(entry.agent).slice(0, 80) : null,
      tool: entry.tool ? String(entry.tool).slice(0, 80) : null,
      // A target that is not an agent of the index (a bare URL somebody passed
      // to /hire): logged, but it opens no row of its own on the track record
      // — anyone can stand up a host that answers a quote and ask it N times.
      ...(entry.unlisted ? { unlisted: true } : {}),
      ms: entry.ms ?? null,
      ok: !!entry.ok,
      // Why it did not work is the part worth keeping. "no read-only tool
      // matched" and "did not answer" are different facts about an operator,
      // and collapsing them into "failed" throws away the useful half.
      outcome: String(entry.outcome || (entry.ok ? 'answered' : 'no result')).slice(0, 120),
      // Set when the task came from our own daily check rather than from
      // somebody with a real question. Kept because the alternative — letting
      // scheduled probes pad the same counter as organic traffic — would make
      // the record describe our cron instead of the operators.
      ...(entry.probe ? { probe: true } : {}),
      // Set when the task was one of our own quote runs: the registry publish
      // asks every Hire button for a price through the live /hire, and until
      // 2026-09-08 those 262 quote requests sat in the log next to strangers'
      // questions with nothing to tell them apart — "400 sessions" was, on
      // inspection, almost entirely us. Only a caller holding this worker's
      // own secret can set it, so a stranger cannot file its call as ours.
      ...(entry.ours ? { ours: String(entry.ours).slice(0, 24) } : {}),
      excerpt: entry.excerpt ? String(entry.excerpt).replace(/\s+/g, ' ').slice(0, EXCERPT) : null,
    });
    while (log.length > MAX_SESSIONS) log.shift();
    await env.AGENT.put(KEY, JSON.stringify(log));
  } catch { /* a lost log entry must never fail the dispatch it describes */ }
}

export async function readSessions(env) {
  try { return JSON.parse((await env.AGENT.get(KEY)) || '[]'); }
  catch { return []; }
}

// Where a session came from. Four answers, and the headline is only honest
// with all four next to it: on 2026-09-08 the log held 400 sessions, of which
// 26 were our daily checks, 262 our own quote runs and — in the newest forty —
// not one from a stranger. Quote runs were not marked before that day, so
// negotiate entries older than the marking are named for what they are: quote
// requests whose origin was not recorded (nearly all of them ours). They age
// out of the rolling log on their own.
export const ORIGIN_MARKED_SINCE = '2026-09-08T18:50:00.000Z';
export function originOf(s) {
  if (s.probe) return 'our_scheduled_checks';
  if (s.ours) return 'our_quote_runs';
  if (s.tool === 'erc8183:negotiate' && String(s.at || '') < ORIGIN_MARKED_SINCE) return 'quote_requests_before_marking';
  return 'outside_callers';
}
export function sessionOrigins(sessions, ownAgentIds = []) {
  const own = new Set(ownAgentIds.map(String));
  const out = { outside_callers: 0, our_scheduled_checks: 0, our_quote_runs: 0, quote_requests_before_marking: 0, to_our_own_agents: 0 };
  for (const s of sessions) {
    out[originOf(s)] += 1;
    if (own.has(String(s.agent))) out.to_our_own_agents += 1;
  }
  out.note = `outside_callers are sessions that carry no mark of ours — a task the operator typed into the page himself looks the same as a stranger's, so this is an upper bound on strangers, not a count of them. our_scheduled_checks is the daily canary; our_quote_runs is the registry publish asking every Hire button for a price through the live /hire (marked since ${ORIGIN_MARKED_SINCE.slice(0, 10)}); quote_requests_before_marking are negotiate calls from before that date whose origin was not recorded, nearly all of them ours. to_our_own_agents counts, across all four, the sessions routed to this project's own five agents.`;
  return out;
}

// The track record, derived rather than declared. Every number here comes from
// the log above; there is no field an operator can set.
export function trackRecord(sessions) {
  const by = new Map();
  for (const s of sessions) {
    const k = s.operator || s.agent;
    if (!k || s.unlisted) continue;
    if (!by.has(k)) by.set(k, { operator: k, agent: s.agent, asked: 0, answered: 0, probes: 0, quoteRuns: 0, unmarked: 0, times: [], tools: new Set(), last: null, failures: [] });
    const r = by.get(k);
    r.asked++;
    const o = originOf(s);
    if (o === 'our_scheduled_checks') r.probes++;
    else if (o === 'our_quote_runs') r.quoteRuns++;
    else if (o === 'quote_requests_before_marking') r.unmarked++;
    if (s.ok) {
      r.answered++;
      if (s.tool) r.tools.add(s.tool);
      if (typeof s.ms === 'number') r.times.push(s.ms);
    } else if (r.failures.length < 3 && !r.failures.includes(s.outcome)) {
      // Distinct reasons, not the same one three times over.
      r.failures.push(s.outcome);
    }
    if (!r.last || s.at > r.last) r.last = s.at;
  }
  return [...by.values()]
    .map((r) => ({
      operator: r.operator,
      agent: r.agent,
      tasks_routed: r.asked,
      answered: r.answered,
      // Stated as a fraction, not a percentage, while the counts are small.
      // "67%" off three attempts reads as a measurement; "2 of 3" reads as
      // what it is.
      reliability: `${r.answered} of ${r.asked}`,
      // Said out loud rather than hidden, because a record built mostly from
      // our own scheduled checks means something different from one built from
      // strangers' questions, and the reader is entitled to tell them apart.
      ...(r.probes ? { of_which_our_scheduled_checks: r.probes } : {}),
      ...(r.quoteRuns ? { of_which_our_quote_runs: r.quoteRuns } : {}),
      ...(r.unmarked ? { of_which_origin_not_recorded: r.unmarked } : {}),
      from_outside_callers: r.asked - r.probes - r.quoteRuns - r.unmarked,
      // A real median. The field carried this name from the start but was a
      // mean until 2026-09-03 — one 9-second answer among twenty 150 ms ones
      // read as "600 ms", which is a number no single request ever took.
      median_ms: r.times.length ? (() => { const t = [...r.times].sort((a, b) => a - b); const m = t.length >> 1; return Math.round(t.length % 2 ? t[m] : (t[m - 1] + t[m]) / 2); })() : null,
      tools_used: [...r.tools].slice(0, 8),
      last_seen: r.last,
      ...(r.failures.length ? { recent_failures: r.failures } : {}),
    }))
    // Coerced: the operator key arrives as whatever the caller passed, and an
    // agent id is a number. localeCompare on a number throws, which took the
    // whole endpoint down with a 500 the first time a session was recorded.
    .sort((a, b) => b.answered - a.answered || String(a.operator).localeCompare(String(b.operator)));
}